<template>
  <div class="content">
    <div class="page__name heading">Hồ sơ</div>
    <label for="">Việt ngoo</label>
  </div>
</template>

<script>
export default {
  name: "ProfilePage",
}
</script>

<style scoped>
.content {
  display: flex;
  flex-direction: column;
  flex: 1;
  box-sizing: border-box;
  padding: 16px;
  min-width: 500px;
  min-height: 500px;
  box-shadow: inset 0 1.5px 2px 0 rgb(0 0 0 / 10%);
}

.page__name {
  margin-bottom: 16px;
}

.page__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  margin-bottom: 16px;
}
</style>