<template>
  <div class="content">
    <div class="page__name heading">Báo cáo</div>
    <h1>SimpleDiagram.js</h1>
    <p>Example</p>
    <VNetworkGraph :nodes="nodes" :edges="edges"  :layouts="layouts" :configs="configs"/>
  </div>
</template>

<script>
import {VNetworkGraph} from "v-network-graph";
import * as vNG from "v-network-graph"
import { ref } from 'vue';

export default {
  name: "ReportPage",
  components: {
    VNetworkGraph, // Đăng ký component
  },
  data() {
    return {
      jsonString : `{
                      "nodes": {
                        "node1": { "name": "Node 1", "size": 16, "color": "gray" },
                        "node2": { "name": "Node 2", "color": "#4466cc" },
                        "node3": { "name": "Node 3", "size": 32, "color": "hotpink" },
                        "node4": { "name": "Node 4", "size": 24, "color": "lightskyblue" },
                        "node5": { "name": "Node 5" },
                        "node6": { "name": "Node 6" },
                        "node7": { "name": "Node 7" },
                        "node8": { "name": "Node 8" },
                        "node9": { "name": "Node 9", "size": 32, "color": "hotpink" }
                      },
                      "edges": {
                        "edge1": { "source": "node1", "target": "node2" },
                        "edge2": { "source": "node2", "target": "node3" },
                        "edge3": { "source": "node4", "target": "node5" },
                        "edge4": { "source": "node6", "target": "node7" },
                        "edge5": { "source": "node7", "target": "node8" },
                        "edge6": { "source": "node6", "target": "node8" },
                        "edge7": { "source": "node9", "target": "node8" }
                      },
                      "layouts": {
                        "nodes": {
                          "node1": { "x": 0, "y": 0 },
                          "node2": { "x": 50, "y": 50 },
                          "node3": { "x": 100, "y": 0 },
                          "node4": { "x": 150, "y": 50 },
                          "node5": { "x": 150, "y": 0 },
                          "node6": { "x": 200, "y": 100 },
                          "node7": { "x": 200, "y": 100 },
                          "node8": { "x": 200, "y": 100 },
                          "node9": { "x": 200, "y": 100 }
                        }
                      }
                    }`,
      nodes : null,
      edges: null,
      layouts: null,      
      configs:null,       
      // nodes: {
      //   node1: { name: 'Node 1', size: 16, color: "gray"},
      //   node2: { name: 'Node 2', color: "#4466cc" },
      //   node3: { name: 'Node 3' , size: 32,color: "hotpink",},
      //   node4: { name: 'Node 4', size: 24, color: "lightskyblue"},
      //   node5: { name: 'Node 5' },
      //   node6: { name: 'Node 6' },
      //   node7: { name: 'Node 7' },
      //   node8: { name: 'Node 8' },
      //   node9: { name: 'Node 9' ,size: 32, color: "hotpink"},
      // },
      // edges: {
      //   edge1: { source: 'node1', target: 'node2' },
      //   edge2: { source: 'node2', target: 'node3' },
      //   edge3: { source: 'node4', target: 'node5' },
      //   edge4: { source: 'node6', target: 'node7' },
      //   edge5: { source: 'node7', target: 'node8' },
      //   edge6: { source: 'node6', target: 'node8' },
      //   edge7: { source: 'node9', target: 'node8' },
      // },
      // layouts: {
      //   nodes: {
      //     node1: { x: 0, y: 0 },
      //     node2: { x: 50, y: 50 },
      //     node3: { x: 100, y: 0 },
      //     node4: { x: 150, y: 50 },
      //     node5: { x: 150, y: 0 },
      //     node6: { x: 200, y: 100 },
      //     node7: { x: 200, y: 100 },
      //     node8: { x: 200, y: 100 },
      //     node9: { x: 200, y: 100 },
      //   },
      // }
    };
  },

  created() {

    var data = JSON.parse(this.jsonString);

    this.nodes = data.nodes;
    this.edges = data.edges;
    this.layouts = data.layouts;
    this.configs = ref(
      vNG.defineConfigs({
        view: {
          panEnabled: false,   // thuộc tính di chuyển diagram
          zoomEnabled: false,   // thuộc tính zoom diagram
        },
        node: {
          draggable: false,  // thuộc tính di chuyển nodes
        },
      })
    )
  }
};
</script>

<style scoped>
.content {
  display: flex;
  flex-direction: column;
  flex: 1;
  box-sizing: border-box;
  padding: 16px;
  min-width: 500px;
  min-height: 500px;
  box-shadow: inset 0 1.5px 2px 0 rgb(0 0 0 / 10%);
}

.page__name {
  margin-bottom: 16px;
}

.page__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  margin-bottom: 16px;
}
</style>