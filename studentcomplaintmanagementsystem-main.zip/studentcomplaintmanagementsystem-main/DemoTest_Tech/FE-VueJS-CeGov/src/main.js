import { createApp } from 'vue'
import App from './App.vue'
import  { createRouter,createWebHistory }  from 'vue-router'
import EmulationTitle from './views/category/EmulationTitle.vue'
import LookupPage from './views/category/LookupPage.vue'
import ProfilePage from './views/category/ProfilePage.vue'
import ReportPage from './views/category/ReportPage.vue'
import VNetworkGraph from "v-network-graph"
import "v-network-graph/lib/style.css"

// Khai báo router
const routes = [
    { path: '/category', component: EmulationTitle },
    { path: '/lookup', component: LookupPage },
    { path: '/profile', component: ProfilePage },
    { path: '/report', component: ReportPage },


]

// khởi tạo router
const vueRouter = createRouter({ 
    history: createWebHistory(), 
    routes :routes
})

// Sử dụng router
const app = createApp(App);
app.use(vueRouter, VNetworkGraph).mount('#app') ;

