import { createRouter, createWebHistory } from "vue-router";
import CategoryPage from "../components/view/CategoryPage.vue";
import ComplaintPage from "../components/view/ComplaintPage.vue";
import FeedbackPage from "../components/view/FeedbackPage.vue";
import HomePage from "../components/view/HomePage_Test.vue";
import NotificationPage from "../components/view/NotificationPage.vue";
import ReportPage from "../components/view/ReportPage.vue";
import RequestPage from "../components/view/RequestPage.vue";
import StaffManagementPage from "../components/view/StaffManagementPage.vue";
import SuggestionPage from "../components/view/SuggestionPage.vue";

// Khai báo router
const routes = [
	{ path: "/category", component: CategoryPage },
	{ path: "/complaint", component: ComplaintPage },
	{ path: "/feedback", component: FeedbackPage },
	{ path: "/homepage", component: HomePage },
	{ path: "/notification", component: NotificationPage },
	{ path: "/report", component: ReportPage },
	{ path: "/request", component: RequestPage },
	{ path: "/staffManagement", component: StaffManagementPage },
	{ path: "/suggestion", component: SuggestionPage },
];

// khởi tạo router
const router = createRouter({
	history: createWebHistory(),
	routes,
});

export default router;
