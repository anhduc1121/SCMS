import { createApp } from "vue";
import App from "./App.vue";
import VNetworkGraph from "v-network-graph";
import "v-network-graph/lib/style.css";
import router from "./router";
import Vue3GoogleLogin from 'vue3-google-login'

const CLIENT_ID="215267008513-o8cjd0o1umu096iaqf5m9kqkbkgldufa.apps.googleusercontent.com"

// Sử dụng router
const app = createApp(App);
app
.use(Vue3GoogleLogin, {
    clientId: CLIENT_ID,
})
app.use(router, VNetworkGraph).mount("#app");


