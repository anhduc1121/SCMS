<template>
	<nav>
		<ul>
			<li><router-link to="/homepage">Home</router-link></li>
			<li><router-link to="/category">Category</router-link></li>
			<li><router-link to="/complaint">Complaint</router-link></li>
			<li><router-link to="/notification">Notification</router-link></li>
			<li><router-link to="/suggestion">Suggestion</router-link></li>
			<li><router-link to="/request">Request</router-link></li>
			<li>
				<router-link to="/staffManagement"
					>Staff Management</router-link
				>
			</li>
			<li><router-link to="/report">Report</router-link></li>
			<li><router-link to="/feedback">Feedback</router-link></li>
		</ul>
	</nav>
</template>

<script>
	export default {
		name: "TheMenu",
	};
</script>

<style scoped>
	nav ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
	}

	nav li {
		margin-bottom: 10px;
	}

	nav a {
		color: #333;
		text-decoration: none;
		padding: 10px;
		display: block;
	}

	nav a:hover {
		background-color: #f2f2f2;
	}
</style>
