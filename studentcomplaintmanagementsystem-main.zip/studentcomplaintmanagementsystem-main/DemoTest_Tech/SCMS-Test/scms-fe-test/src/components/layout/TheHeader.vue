<template>
  <header>
    <div class="logo">
      <img src="logo.png" alt="SCMS Logo" />
      <h1>SCMS</h1>
    </div>
    <h2>Complaint Report</h2>
  </header>
</template>

<script>
export default {
  name: 'TheHeader'
}
</script>

<style scoped>
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #2c3e50;
  color: #fff;
  padding: 10px;
}

.logo {
  display: flex;
  align-items: center;
}

.logo img {
  max-height: 40px;
  margin-right: 10px;
}
</style>