<template>
  <div class="main">
    <div class="section7">
      <div class="section7-text">Category/Sub-category</div>
      <div class="editCategory">
        <button class="btn-editCategory">Edit Category</button>
      </div>

      <div class="Tag-area"></div>
    </div>
    <div class="section7-icons">
      <div class="vCheck">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="35"
          width="35"
          viewBox="0 0 512 512"
        >
          <path
            fill="#63E6BE"
            d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-111 111-47-47c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l64 64c9.4 9.4 24.6 9.4 33.9 0L369 209z"
          />
        </svg>
      </div>
      <div class="xMark">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="35"
          width="35"
          viewBox="0 0 512 512"
        >
          <path
            fill="#e11f09"
            d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c9.4-9.4 24.6-9.4 33.9 0l47 47 47-47c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-47 47 47 47c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-47-47-47 47c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l47-47-47-47c-9.4-9.4-9.4-24.6 0-33.9z"
          />
        </svg>
      </div>
    </div>
    <div class="Complaint-title">
      <div class="title-Text">This is title</div>
      <div class="DateTime-box">
        <div class="Time-box">13:20</div>
        <div class="Date-box">11/03/2024</div>
      </div>
    </div>
    <div class="add-suggestion">
      <button class="btn-addSuggestion">Add Suggestion</button>
    </div>
    <div class="section1">
      <div class="section1-text">Câu hỏi</div>
      <div class="Suggestion">
        <button class="btn-Suggestion">Suggestion</button>
      </div>
    </div>
    <div class="section3">
      <!-- <ComplaintReply/> -->
    </div>
    <div class="section2">
      <input class="section2-input" type="text" placeholder="Enter text here" />
      <div class="Upload">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="33"
          width="33"
          viewBox="0 0 512 512"
        >
          <path
            d="M288 109.3V352c0 17.7-14.3 32-32 32s-32-14.3-32-32V109.3l-73.4 73.4c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l128-128c12.5-12.5 32.8-12.5 45.3 0l128 128c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L288 109.3zM64 352H192c0 35.3 28.7 64 64 64s64-28.7 64-64H448c35.3 0 64 28.7 64 64v32c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V416c0-35.3 28.7-64 64-64zM432 456a24 24 0 1 0 0-48 24 24 0 1 0 0 48z"
          />
        </svg>
      </div>
      <div class="Send">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="33"
          width="33"
          viewBox="0 0 512 512"
        >
          <path
            d="M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM294.6 135.1l99.9 107.1c3.5 3.8 5.5 8.7 5.5 13.8s-2 10.1-5.5 13.8L294.6 376.9c-4.2 4.5-10.1 7.1-16.3 7.1C266 384 256 374 256 361.7l0-57.7-96 0c-17.7 0-32-14.3-32-32l0-32c0-17.7 14.3-32 32-32l96 0 0-57.7c0-12.3 10-22.3 22.3-22.3c6.2 0 12.1 2.6 16.3 7.1z"
          />
        </svg>
      </div>
    </div>
  </div>
</template>
<script>
// import ComplaintReply from './ComplaintReply.vue';
export default {
  //   components: { ComplaintReply },
  name: "ComplaintDetails",
  data() {
    return {};
  },
};
</script>

<style>
@import url(../../../styles/complaint/ComplaintDetails.css);
</style>