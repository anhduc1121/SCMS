<template>
	<div>NotificationPage</div>
</template>

<script>
	export default {
		name: "NotificationPage",
	};
</script>

<style></style>
