<template>
	<div>SuggestionPage</div>
</template>

<script>
	export default {
		name: "SuggestionPage",
	};
</script>

<style></style>
