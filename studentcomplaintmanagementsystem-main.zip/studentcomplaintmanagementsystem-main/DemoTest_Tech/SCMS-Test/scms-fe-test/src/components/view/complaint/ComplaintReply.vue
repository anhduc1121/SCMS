<template>
  <div>
    <div class="container">
      <div class="col-lg-6 offset-lg-3">
        <div v-if="ready">
          <p v-for="(item, i) in info" :key="i">{{ item.name }} {{ item.type }}</p>
        </div>
        <div v-if="!ready">
          <h4>Set your name</h4>
          <form @submit.prevent="addName">
            <div class="mb-3">
              <input
                type="text"
                class="form-control col-9"
                v-model="name"
                placeholder="Enter your name"
              />
              <input
                type="submit"
                value="Save"
                class="btn btn-sm btn-info ml-1"
              />
            </div>
          </form>
        </div>
        <h1 v-else>{{ name }}</h1>
        <div class="card bg-info" v-if="ready">
          <div class="card-header">
            Real-time chat app
            <span class="float-right">{{ connections }} connections</span>
          </div>
          <ul class="list-group list-group-flush text-right">
            <small v-if="typing" class="text-white float-right"
              >{{ typing }} is typing</small
            >
            <li class="list-group-item" v-for="(message, index) in messages" :key="index">
              <span :class="{ 'float-left': message.type === 0 }"
                >{{ message.message }}
                <small>:{{ message.by }}</small>
              </span>
            </li>
          </ul>
          <div class="card-body">
            <form @submit.prevent="send">
              <div class="mb-3">
                <input
                  type="text"
                  class="form-control"
                  v-model="newMessage"
                  placeholder="Type here"
                />
              </div>

              <button type="submit" class="btn btn-sm btn-primary">Add</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
  
  <script>
import socketio from "@/socket";

export default {
  data() {
    return {
      newMessage: null,
      messages: [],
      typing: false,
      name: null,
      ready: false,
      info: [],
      connections: 0,
      socket: null,
    };
  },
  methods: {
    send() {
      //type: 0 is send
      this.messages.push({
        message: this.newMessage,
        type: 0,
        by: "Me",
      });
      this.socket.emit("chat-message", {
        message: this.newMessage,
        user: this.name,
      });
      this.newMessage = null;
    },

    addName() {
      this.ready = true;
      this.socket.emit("joined", this.name);
    },
  },
  watch: {
    newMessage(value) {
      value
        ? this.socket.emit("typing", this.name)
        : this.socket.emit("stopTyping");
    },
  },
  created() {
    this.socket = socketio;

    window.onbeforeunload = () => {
      this.socket.emit("left", this.name);
    };

    this.socket.on("connections", (data) => {
      this.connections = data;
    });

    this.socket.on("Created", (data) => {
      console.log(data);
    });

    this.socket.on("chat-message", (data) => {
      //type: 1 is receive
      this.messages.push({
        message: data.message,
        type: 1,
        by: data.user,
      });
    });

    this.socket.on("typing", (name) => {
      this.typing = name;
    });

    this.socket.on("stopTyping", () => {
      this.typing = false;
    });

    this.socket.on("joined", (data) => {
      this.info.push({ name: data, type: "Joined" });
      setTimeout(() => {
        this.info = [];
      }, 5000);
    });

    this.socket.on("left", (data) => {
      this.info.push({ name: data, type: "Left" });
      setTimeout(() => {
        this.info = [];
      }, 5000);
    });
  },
};
</script>
  
  <style>
/* Add your custom styles here */
</style>