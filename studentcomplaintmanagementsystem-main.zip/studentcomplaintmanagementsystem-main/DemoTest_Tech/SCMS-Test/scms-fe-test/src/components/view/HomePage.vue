<template>
  <div class="Page">
    <div class="left-block">
      <VDashboard :user="user" />
    </div>
    <div class="right-block">
      <div class="logo-block">
        <SCMS_Logo />
      </div>
      <div class="main-block">
        <ComplaintDetails v-if="BtnActive.Complaint.isActive && BtnActive.Complaint.isViewDetails" />
        <ListComplaint v-if="BtnActive.Complaint.isActive && !BtnActive.Complaint.isViewDetails" />
        <WelcomePage v-if="BtnActive.Home.isActive" />
      </div>
    </div>
  </div>
</template>
<script>
// import VDashboard from './VDashboard.vue';
// import WelcomePage from './WelcomePage.vue';
// import SCMS_Logo from "../Logo/SCMS_Logo.vue";
// import ListComplaint from '../Complaint/ListComplaint.vue';
// import eventBus from '../EventBus/eventBus';
// import ComplaintDetails from '../Complaint/ComplaintDetails.vue';

export default {
  name: "HomePage",
  components: {
    // VDashboard,
    // SCMS_Logo,
    // WelcomePage,
    // ListComplaint,
    // ComplaintDetails,
  },
  props: ["user"],
  // created(){
  //   if(eventBus.btnActive.Home.isActive === false){
  //     eventBus.btnActive.Home.isActive = true;
  //   }
  // },
  // computed: {
  //   BtnActive() {
  //     return eventBus.btnActive;
  //   },
  // },
};
</script>
<style>
 @import url("../../styles/HomePage.css");
</style>
