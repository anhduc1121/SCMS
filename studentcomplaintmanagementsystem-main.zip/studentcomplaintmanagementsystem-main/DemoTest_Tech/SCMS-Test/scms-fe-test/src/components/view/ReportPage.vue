<template>
	<div>ReportPage</div>
</template>

<script>
	export default {
		name: "ReportPage",
	};
</script>

<style></style>
