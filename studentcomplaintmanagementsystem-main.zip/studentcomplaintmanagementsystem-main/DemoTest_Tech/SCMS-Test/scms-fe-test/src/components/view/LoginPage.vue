<template>
    <div v-if="cookieExists">
      <!--Them phan quyen-->
      <HomePage :user="user" />
    </div>
    <div v-else class="main-login">
      <div class="logo-div">
        <img class="logo" src="../../assets/DH_FPT.jpg" alt="Logo-FPT" />
      </div>
      <GoogleLogin class="login-google" :callback="callback" prompt auto-login />
      <div class="login-screen">
        <form class="login-form">
          <div class="campus-text">Select a campus before sign in the system with type username</div>
          <div class="campus-feild">
            <select id="campusSelect" onchange="showSelectedCampus()">
              <option value="red">Red</option>
              <option value="blue">Blue</option>
              <option value="green">Green</option>
              <option value="yellow">Yellow</option>
            </select>
            <div id="selectedCampus">You haven't selected any Campus yet.</div>
  
  
          </div>
          <div class="login__field">
            <i class="login__icon fas fa-user"></i>
            <input type="text" class="login__input" placeholder="User name / Email">
          </div>
          <div class="login__field">
            <i class="login__icon fas fa-lock"></i>
            <input type="password" class="login__input" placeholder="Password">
          </div>
          <button class="button login__submit">
            <span class="button__text">Log In Now</span>
            <i class="button__icon fas fa-chevron-right"></i>
          </button>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  import { decodeCredential } from "vue3-google-login";
  // import eventBus from "./components/EventBus/eventBus";
  import HomePage from "../view/HomePage.vue";
  
  
  export default {
    name: "LoginPage",
    data() {
      return {
        cookieValue: '',
        permissions: null,
        user: null,
        callback: (response) => {
          console.log("login");
          console.log(response);
          this.user = decodeCredential(response.credential);
          this.cookieValue = this.user;
          console.log(this.user);
          //set cookie
        },
      };
    },
    mounted() {
      fetch("http://localhost:3000/permissions")
        .then((res) => res.json())
        .then((data) => {
          this.permissions = data;
          console.log(this.permissions);
          // eventBus.permissions = this.permissions;
        })
        .catch((err) => console.log(err.message));
    },
    methods: {
      setCookie() {
        this.$cookies.set("currentUser", this.user, 1)
      },
      getCookie() {
        this.cookieValue = this.$cookies.get('currentUser'); // Get the value of the cookie 'myCookie'
        console.log(this.cookieValue);
      },
    },
    computed: {
      cookieExists() {
        return this.cookieValue !== '';
      },
    },
    components: { HomePage },
  
  };
  
  
  </script>
  
  <style>
  .main-login {
    width: 100%;
    height: 72vh;
    position: relative;
  }
  
  .logo-div {
    width: 100%;
    position: absolute;
    top: 0%;
  }
  
  .logo {
    height: 15vh;
    vertical-align: middle;
  }
  
  .login-google {
    top: 25%;
    left: 50%;
    transform: translate(-50%, -50%);
    position: absolute;
  }
  
  .campus-text {
    font-family: 'Noto Sans', sans-serif;
  }
  
  .login-screen {
    position: relative;
    top: 30%;
    left: 40%;
    height: 450px;
    width: 360px;
    box-shadow: 0px 0px 24px #de8900;
  }
  
  .login-form {
    height: 90%;
    width: 90%;
    left: 5%;
    top: 5%;
    position: absolute;
  }
  
  .login__field {
    padding: 20px 0px;
    position: relative;
  }
  
  .login__icon {
    position: absolute;
    top: 30px;
    color: #de8900;
  }
  
  .login__input {
    border: none;
    border-bottom: 2px solid #020202;
    background: none;
    padding: 10px;
    padding-left: 24px;
    font-weight: 700;
    width: 75%;
    transition: .2s;
  }
  
  .login__input:active,
  .login__input:focus,
  .login__input:hover {
    outline: none;
    border-bottom-color: #de8900;
  }
  
  .login__submit {
    background: white;
    font-size: 14px;
    margin-top: 30px;
    padding: 16px 20px;
    border-radius: 26px;
    border: 1px solid #D4D3E8;
    text-transform: uppercase;
    font-weight: 700;
    display: flex;
    align-items: center;
    width: 100%;
    color: #de8900;
    box-shadow: 0px 2px 2px #de8900;
    cursor: pointer;
    transition: .2s;
  }
  
  .login__submit:active,
  .login__submit:focus,
  .login__submit:hover {
    border-color: #de8900;
    outline: none;
  }
  
  .button__icon {
    font-size: 24px;
    margin-left: auto;
    color: #de8900;
  }
  
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  </style>
  