<template>
	<div>FeedbackPage</div>
</template>

<script>
	export default {
		name: "FeedbackPage",
	};
</script>

<style></style>
