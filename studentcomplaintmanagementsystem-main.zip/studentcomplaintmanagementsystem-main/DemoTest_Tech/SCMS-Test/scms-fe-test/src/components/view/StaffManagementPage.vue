<template>
	<div>StaffManagementPage</div>
</template>

<script>
	export default {
		name: "StaffManagementPage",
	};
</script>

<style></style>
