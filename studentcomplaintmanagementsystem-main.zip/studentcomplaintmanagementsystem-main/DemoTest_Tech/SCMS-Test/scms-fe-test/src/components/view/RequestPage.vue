<template>
	<div>RequestPage</div>
</template>

<script>
	export default {
		name: "RequestPage",
	};
</script>

<style></style>
