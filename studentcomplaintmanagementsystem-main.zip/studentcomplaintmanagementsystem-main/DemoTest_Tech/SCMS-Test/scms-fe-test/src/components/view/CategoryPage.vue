<template>
	<div>CategoryPage</div>
</template>

<script>
	export default {
		name: "CategoryPage",
	};
</script>

<style></style>
