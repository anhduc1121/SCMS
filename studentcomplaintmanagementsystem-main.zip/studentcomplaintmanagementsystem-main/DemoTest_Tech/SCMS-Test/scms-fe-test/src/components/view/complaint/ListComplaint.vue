<template>
  <div class="main">
    <!--fillter-->
    <div class="filter-bar">
      <div class="select-category" @click="ShowListCategory()">
        <div class="select-content">Select Category</div>
        <div class="list-category" style="top: 100%" v-if="showListCategory">
          <ul class="opt-category">
            <li
              class="cate"
              v-for="(category, index) in categories"
              :key="index"
              @mouseover="showSubCategoryPopup(category)"
            >
              <div id="li-content">{{ category.name }}</div>
            </li>
          </ul>
        </div>
        <div class="display-sub" style="left: 100%" v-if="isDisplaySub">
          <ul class="list-sub">
            <li
              class="sub-cate"
              v-for="(sub, sub_index) in currentCategory.children"
              :key="sub_index"
            >
              {{ sub }}
            </li>
          </ul>
        </div>
      </div>
      <div class="select-status">
        <input type="checkbox" value="white" v-model="filters.isNew" />Not
        Opened
        <input type="checkbox" value="gray" v-model="filters.isRead" />Seen
        <input
          type="checkbox"
          value="green"
          v-model="filters.isCompleted"
        />Solved
        <input
          type="checkbox"
          value="red"
          v-model="filters.isRejected"
        />Rejected
      </div>
      <div class="sort-by">
        <div class="icon-sort">
          <i :class="className"></i>
        </div>
        Sort:
        <select
          class="select-sort"
          name="sort"
          v-model="filters.opt_value"
          @change="handleSelectChange"
        >
          <option selected value="AZ">By name A-Z</option>
          <option value="ZA">By name Z-A</option>
          <option value="time-asc">By time ascending</option>
          <option value="time-dec">By time decending</option>
        </select>
      </div>
      <div class="search">
        <input
          class="search-input"
          v-model="filters.textInput"
          type="text"
          placeholder="Enter text.."
        />
        <select class="searchBy">
          <option value="">By student name</option>
          <option value="">By tag</option>
          <option value="">By title</option>
        </select>
        <button class="btn-search">Search</button>
      </div>
    </div>
    <!-- table -->
    <div class="list-complaint">
      <!-- <div class="list-complaint-thead">
        <div class="in-row complaint-from">From</div>
          <div class="in-row complaint-title">Title</div>
          <div class="in-row complaint-tag">Tags</div>
          <div class="in-row complaint-time">Time</div>
          <div class="in-row complaint-status">Status</div>
      </div> -->
      <div class="list-complaint-tbody">
        <div
          class="row-complaint"
          v-for="(complaint, index) in slicedItems"
          :key="index"
          :style="{
            backgroundColor: getStatusColor(complaint.StatusTicketID),
          }"
          @click="handleRowClick(complaint)"
        >
          <div class="in-row complaint-pin">Pin</div>
          <div class="in-row complaint-from">
            {{ complaint.AccountIDCreate }}
          </div>
          <div class="in-row complaint-title">{{ complaint.Title }}</div>
          <div class="in-row complaint-tag">
            <div class="tag-name">
              <div class="tag-content">Nguyen Ba Van</div>
              <div class="remove-tag">X</div>
            </div>
            <div class="tag-name">
              <div class="tag-content">Le Duc Viet</div>
              <div class="remove-tag">X</div>
            </div>
            <!-- {{ complaint.AccountIDBehaveCreate }} -->
          </div>
          <div class="in-row complaint-time">{{ complaint.CreateDate }}</div>
          <div class="in-row complaint-status">{{ complaint.Status }}</div>
        </div>
      </div>
    </div>
    <div class="paging">
      <button
        class="paging-item paging-left"
        @click="prevPage"
        :disabled="currentPage === 1"
      >
        Previous
      </button>
      <div class="paging-item paging-middle">
        <div
          class="page-number page-current"
          :style="{
            backgroundColor: selectColor(pageNumbers.first),
            color: selectFontColor(pageNumbers.first),
          }"
        >
          {{ pageNumbers.first }}
        </div>
        <div
          class="page-number page-current"
          :style="{
            backgroundColor: selectColor(pageNumbers.second),
            color: selectFontColor(pageNumbers.second),
          }"
          v-if="pageNumbers.second"
        >
          {{ pageNumbers.second }}
        </div>
        <div
          class="page-number page-current"
          v-if="pageNumbers.last > 2"
          :style="{
            backgroundColor: selectColor(pageNumbers.third),
            color: selectFontColor(pageNumbers.third),
          }"

        >
          {{ pageNumbers.third }}
        </div>
        <div class="page-number page-space" v-if="pageNumbers.last > 3">
          ...
        </div>
        <div
          class="page-number page-total"
          v-if="pageNumbers.last > 3"
          :style="{
            backgroundColor: selectColor(pageNumbers.last),
            color: selectFontColor(pageNumbers.last),
          }"
        >
          {{ pageNumbers.last }}
        </div>
      </div>
      <button
        class="paging-item paging-right"
        @click="nextPage"
        :disabled="currentPage === totalPages"
      >
        Next
      </button>
    </div>
  </div>
</template>
  
  <script>
import axios from "axios";
import eventBus from "../EventBus/eventBus";

export default {
  components: {},
  name: "ListComplaint",
  created() {
    this.fetchData();
    //this.pageNumbers.last = this.totalPages;
  },
  data() {
    return {
      AZ: "fa-solid fa-arrow-down-a-z",
      ZA: "fa-solid fa-arrow-down-z-a",
      time_asc: "fa-solid fa-arrow-down-short-wide",
      time_dec: "fa-solid fa-arrow-down-wide-short",
      filters: {
        opt_value: "AZ",
        textInput: "",
        isNew: false,
        isRead: false,
        isCompleted: false,
        isRejected: false,
      },
      isDisplaySub: false,
      showListCategory: false,
      currentCategory: [],
      categories: [],
      className: this.AZ,
      complaints: [],
      pageNumbers: {
        first: 1,
        second: 2,
        third: 3,
        last: 4,
      },
      currentPage: 1, // Current page number
      itemsPerPage: 10, // Number of items to display per page
    };
  },
  methods: {
    hidePopup() {
      this.isDisplaySub = false;
    },
    ShowListCategory() {
      if (this.showListCategory) {
        this.showListCategory = false;
      } else {
        this.showListCategory = true;
      }
      if (!this.showListCategory) {
        this.isDisplaySub = false;
      }
    },
    showSubCategoryPopup(category) {
      this.currentCategory = category;
      this.isDisplaySub = true;
    },
    handleRowClick(complaint) {
      eventBus.btnActive.Complaint.isViewDetails = true;
      eventBus.btnActive.Complaint.complaintID = complaint.TicketID;
    },
    getStatusColor(status) {
      if (status === "Rejected") {
        return "#FF5656";
      } else if (status === "Completed") {
        return "#79F565";
      } else if (status === "Process") {
        return "#E2E2E2";
      } else {
        return "white"; // Default color
      }
    },
    handleSelectChange() {
      // Xử lý sự kiện khi chọn option
      if (this.filters.opt_value === "ZA") {
        this.className = this.ZA;
      } else if (this.filters.opt_value === "time-asc") {
        this.className = this.time_asc;
      } else if (this.filters.opt_value === "time-dec") {
        this.className = this.time_dec;
      } else {
        this.className = this.AZ;
      }
      console.log(this.filters.opt_value); // In giá trị option được chọn ra console
    },

    fetchData() {
      axios
        .get("http://localhost:3000/complaints")
        .then((response) => {
          // Handle the response from the server
          console.log(response.data);
          // Assign the response data to a component property
          this.complaints = response.data;
        })
        .catch((error) => {
          // Handle any errors that occurred during the request
          console.error(error);
        });

      axios
        .get("http://localhost:3000/categories")
        .then((response) => {
          // Handle the response from the server
          console.log(response.data);
          // Assign the response data to a component property
          this.categories = response.data;
        })
        .catch((error) => {
          // Handle any errors that occurred during the request
          console.error(error);
        });
    },
    // postData() {
    //   const data = {
    //     // Your data to be sent
    // };
    //   axios
    //     .post("your-api-endpoint", data)
    //     .then((response) => {
    //       // Handle the response from the server
    //       console.log(response.data);
    //     })
    //     .catch((error) => {
    //       // Handle any errors that occurred during the request
    //       console.error(error);
    //     });
    // },
    pageDisplay(page) {
      this.pageNumbers.last = this.totalPages;
      if (this.totalPages === 2) {
        this.pageNumbers.first = 1;
        this.pageNumbers.second = 2;
        this.pageNumbers.third = 0;
      } else if (this.totalPages === 1) {
        this.pageNumbers.first = 1;
        this.pageNumbers.second = 0;
        this.pageNumbers.third = 0;
      }
      if (page >= 3 && page < this.pageNumbers.last) {
        this.pageNumbers.first = page - 2;
        this.pageNumbers.second = page - 1;
        this.pageNumbers.third = page;
      }
    },
    selectColor(selectPage) {
      if (this.currentPage === selectPage) {
        return "#ff7a00";
      } else {
        return "white";
      }
    },
    selectFontColor(selectPage) {
      if (this.currentPage !== selectPage) {
        return "#ff7a00";
      } else {
        return "white";
      }
    },
    goToPage(page) {
      if (page >= 1 && page <= this.totalPages) {
        this.currentPage = page;
      }
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
        this.pageDisplay(this.currentPage);
      }
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.pageDisplay(this.currentPage);
      }
    },
    
  },
  computed: {
    slicedItems() {
      const startIndex = (this.currentPage - 1) * this.itemsPerPage;
      const endIndex = startIndex + this.itemsPerPage;
      return this.complaints.slice(startIndex, endIndex);
    },
    totalPages() {
      var total = Math.ceil(this.complaints.length / this.itemsPerPage);
      //this.pageNumbers.last = total;
      return total;
    },
  },
  //   mounted() {
  //     fetch("http://localhost:3000/complaints")
  //       .then((res) => res.json())
  //       .then((data) => (this.complaints = data))
  //       .catch((err) => console.log(err.message));
  //   },
};
</script>
  
  <style>
.main {
  /* background-color: blue; */
  width: 100%;
  height: 72vh;
  border: 1px solid rgba(0, 0, 0, 0.3);
  position: relative;
  font-family: "Noto Sans", sans-serif;
}
.filter-bar {
  border: 1px solid rgba(0, 0, 0, 0.3);
  position: absolute;
  width: 96%;
  left: 2%;
  top: 1%;
  height: 8vh;
  min-height: 60px;
}
.select-category {
  background-color: #f89045;
  width: 12%;
  height: 5vh;
  position: absolute;
  border: 1px solid rgba(0, 0, 0, 0.5);
  left: 1%;
  top: 15%;
}
.select-content {
  position: absolute;
  top: 20%;
  left: 8%;
  font-size: 16px;
}
.select-status {
  position: absolute;
  /* border: 1px solid rgba(0, 0, 0, 0.5); */
  bottom: -45%;
  left: 40%;
}
.sort-by {
  width: 16%;
  height: 30px;
  position: absolute;
  border: 1px solid rgba(0, 0, 0, 0.5);
  left: 14%;
  top: 20%;
}
.icon-sort {
  position: absolute;
  width: 18%;
  left: 1%;
}
.select-sort {
  position: absolute;
  width: 80%;
  left: 20%;
  height: 26px;
  border: none;
  font-size: 12px;
  top: 1%;
  text-align: center;
  border-left: 1px solid rgba(0, 0, 0, 0.5);
}
.search {
  position: absolute;
  width: 68%;
  left: 32%;
  height: 28px;
}
.search-input {
  position: absolute;
  left: 0;
  width: 60%;
  height: 28px;
  top: 44%;
}
.searchBy {
  position: absolute;
  left: 61%;
  width: 15%;
  top: 40%;
  height: 28px;
  font-size: 12px;
}
.btn-search {
  position: absolute;
  left: 77%;
  height: 35px;
  background-color: #32be1c;
  border-radius: 10px;
  color: white;
  width: 15%;
  top: 25%;
}
.select-category {
  position: absolute;
}
.list-category {
  position: absolute;
  top: 100%;
  width: 100%;
}
.opt-category {
  list-style: none;
  padding: 0;
  width: 100%;
}
.cate {
  width: 100%;
  margin: 0;
  padding: 0;
  background-color: #f89045;
  height: 30px;
  border: 1px solid rgba(0, 0, 0, 0.5);
  font-size: 14px;
}
#li-content {
  width: 100%;
  height: 30px;
  line-height: 30px;
}
.display-sub {
  position: absolute;
  width: 100%;
  left: 100%;
  background-color: #fdc399;
  z-index: 3;
}

.list-sub {
  list-style: none;
  padding: 0;
  margin: 0;
}
.sub-cate {
  height: 26px;
  font-size: 12px;
  line-height: 26px;
  border: 1px solid rgba(0, 0, 0, 0.5);
}

.sub-popup {
  position: absolute;
  top: 0;
}

.select-category:hover {
  cursor: pointer;
}
.list-category {
  position: absolute;
  top: 20%;
}
.list-complaint {
  position: absolute;
  top: 20%;
  width: 100%;
  height: 65%;
}
.paging {
  position: absolute;
  width: 40%;
  height: 8%;
  left: 30%;
  bottom: 1%;
  color: #ff7a00;
}
.paging-item {
  float: left;
  height: 40px;
}
.paging-left {
  border: 2px solid #ff7a00;
  border-radius: 15px;
  width: 20%;
}
.paging-middle {
  width: 60%;
  line-height: 40px;
}
.page-number {
  border: 2px solid #ff7a00;
  border-radius: 15px;
  float: left;
  width: 40px;
  height: 40px;
  font-weight: 600;
  border-radius: 20px;
  margin-left: 3%;
  margin-right: 3%;
}
.page-space {
  border: none;
}
.paging-right {
  border: 2px solid #ff7a00;
  border-radius: 15px;
  width: 20%;
}
.row-complaint {
  height: 90px;
  border: 2px solid rgba(0, 0, 0, 0.5);
  margin-bottom: 1px;
}
.row-complaint:hover {
  cursor: pointer;
}
.in-row {
  margin-top: 30px;
  float: left;
  height: 30px;
  line-height: 30px;
  border-radius: 5px;
  border: 1px solid rgba(0, 0, 0, 1);
  background-color: white;
}
.list-complaint-thead {
  position: absolute;
  left: 3%;
  top: 0;
  width: 94%;
  background-color: aqua;
  float: left;
  border: 1px solid rgba(0, 0, 0, 0.5);
}
.list-complaint-tbody {
  position: absolute;
  top: 0%;
  left: 3%;
  width: 94%;
  max-height: 100%;
  overflow-y: scroll;
  border-top: 1px solid rgba(0, 0, 0, 0.5);
  border-bottom: 1px solid rgba(0, 0, 0, 0.5);
  border-right: 1px solid rgba(0, 0, 0, 0.5);
}
.complaint-from {
  width: 16%;

  margin: 30px 1% 0 1%;
}
.complaint-title {
  width: 43%;
}
.complaint-tag {
  width: 17%;
  margin: 10px 1% 0 1%;
  height: 70px;
  max-height: 70px;
  overflow-y: scroll;
  z-index: 2;
}
.tag-name {
  float: top;
  font-size: 12px;
  width: 150px;
  max-height: 24px;
  line-height: 24px;
  font-weight: 600;
}
.tag-content {
  float: left;
  border: 1px solid rgba(0, 0, 0, 0.5);
  border-radius: 5px;
  max-height: 24px;
  margin: 3px;
  width: 110px;
}
.remove-tag {
  float: left;
  border: 1px solid rgba(0, 0, 0, 0.5);
  border-radius: 10px;
  width: 24px;
  height: 24px;
  max-height: 24px;
  margin: 3px;
}
.complaint-time {
  width: 10%;
}
.complaint-status {
  width: 5%;
  margin: 30px 1% 0 1%;
}
.complaint-pin {
  width: 2%;
  margin: 30px 0 0 1%;
}
</style>
  