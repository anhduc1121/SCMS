<template>
	<div>ComplaintPage</div>
</template>

<script>
	export default {
		name: "ComplaintPage",
	};
</script>

<style></style>
