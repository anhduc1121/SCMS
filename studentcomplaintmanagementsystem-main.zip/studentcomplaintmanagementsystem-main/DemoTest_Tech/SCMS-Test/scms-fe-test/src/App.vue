<template>
  <div id="app">
    <div class="container">
			<TheHeader />
			<div class="content-wrapper">
				<TheMenu />
				<TheContent />
			</div>
		</div>
    <!-- <LoginPage /> -->
  </div>
</template>

<script>
import TheMenu from "./components/layout/TheMenu.vue";
import TheHeader from "./components/layout/TheHeader.vue";
import TheContent from "./components/layout/TheContent.vue"; 
// import LoginPage from "./components/view/LoginPage.vue";
import { decodeCredential } from "vue3-google-login";
export default {
  name: "App",
  data() {
    return {
      cookieValue: "",
      permissions: null,
      user: null,
      callback: (response) => {
        console.log("login");
        console.log(response);
        this.user = decodeCredential(response.credential);
        this.cookieValue = this.user;
        console.log(this.user);
        //set cookie
      },
    };
  },
  components: {
    TheMenu,
    TheHeader,
    TheContent,
    // LoginPage,
  },
};
</script>

<style>
@import url(styles/main.css);
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.container {
  /* max-width: 960px; */
  margin: 0 auto;
  padding: 20px;
}

.content-wrapper {
  display: flex;
}

footer {
  margin-top: 20px;
  text-align: center;
}

.pagination a {
  color: #333;
  text-decoration: none;
  padding: 5px 10px;
  background-color: #f2f2f2;
  margin: 0 5px;
}

.pagination a:hover {
  background-color: #ddd;
}
</style>
