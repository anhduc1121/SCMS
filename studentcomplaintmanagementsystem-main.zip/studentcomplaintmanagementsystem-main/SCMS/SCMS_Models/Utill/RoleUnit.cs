﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCMS_Models.Utill
{
    public class RoleUnit
    {
        public const string? Role_Student = "Student";
        public const string? Role_Staff = "Staff";
        public const string? Role_Admin = "Admin";
    }
}
