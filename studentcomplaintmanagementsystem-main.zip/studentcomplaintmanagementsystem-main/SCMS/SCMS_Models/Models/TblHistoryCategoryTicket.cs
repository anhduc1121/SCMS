﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblHistoryCategoryTicket
{
    public Guid HistoryCategoryTicketId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid TicketId { get; set; }

    public Guid CategoryTicketId { get; set; }

    public bool? IsDelete { get; set; }

    public virtual TblCategoryTicket CategoryTicket { get; set; } = null!;

    public virtual TblTicket Ticket { get; set; } = null!;
}
