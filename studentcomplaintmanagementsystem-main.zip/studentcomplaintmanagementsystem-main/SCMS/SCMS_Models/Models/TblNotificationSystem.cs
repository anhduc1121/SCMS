﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblNotificationSystem
{
    public Guid NotificationSystemId { get; set; }

    public string? Content { get; set; }

    public string? Title { get; set; }

    public string? UrlSulg { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool? IsDelete { get; set; }

    public virtual ICollection<TblHistoryNotification> TblHistoryNotifications { get; set; } = new List<TblHistoryNotification>();

    public virtual ICollection<TblNotificationSystemView> TblNotificationSystemViews { get; set; } = new List<TblNotificationSystemView>();
}
