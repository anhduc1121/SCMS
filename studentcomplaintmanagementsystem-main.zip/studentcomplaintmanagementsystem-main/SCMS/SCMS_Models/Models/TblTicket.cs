﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicket
{
    public Guid TicketId { get; set; }

    public string Title { get; set; } = null!;

    public string? Description { get; set; }

    public DateTime CreateDate { get; set; }

    /// <summary>
    /// EstimateTime+CreateDate
    /// </summary>
    public DateTime? DurationTime { get; set; }

    /// <summary>
    /// thoi gian con lai
    /// </summary>
    public DateTime? ActualTime { get; set; }

    /// <summary>
    /// thoi gian sinh vien ky vong
    /// </summary>
    public int? EstimateTime { get; set; }

    public DateTime Kpitime { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public string Status { get; set; } = null!;

    /// <summary>
    /// Student or Staff
    /// </summary>
    public Guid AccountIdCreate { get; set; }

    public Guid? AccountIdbehaveCreate { get; set; }

    public Guid StatusTicketId { get; set; }

    public Guid CategoryTicketId { get; set; }

    /// <summary>
    /// Account update
    /// </summary>
    public Guid? AccountIdupdate { get; set; }

    public DateTime? EndDate { get; set; }

    public string? FileId { get; set; }

    public virtual TblAccount AccountIdCreateNavigation { get; set; } = null!;

    public virtual TblAccount? AccountIdbehaveCreateNavigation { get; set; }

    public virtual TblAccount? AccountIdupdateNavigation { get; set; }

    public virtual TblCategoryTicket CategoryTicket { get; set; } = null!;

    public virtual TblStatusTicket StatusTicket { get; set; } = null!;

    public virtual ICollection<TblHistoryAccountTicketsOnline> TblHistoryAccountTicketsOnlines { get; set; } = new List<TblHistoryAccountTicketsOnline>();

    public virtual ICollection<TblHistoryCategoryTicket> TblHistoryCategoryTickets { get; set; } = new List<TblHistoryCategoryTicket>();

    public virtual ICollection<TblNotification> TblNotifications { get; set; } = new List<TblNotification>();

    public virtual ICollection<TblPinTicket> TblPinTickets { get; set; } = new List<TblPinTicket>();

    public virtual ICollection<TblTagTicket> TblTagTickets { get; set; } = new List<TblTagTicket>();

    public virtual ICollection<TblTicketAttachment> TblTicketAttachments { get; set; } = new List<TblTicketAttachment>();

    public virtual ICollection<TblTicketComment> TblTicketComments { get; set; } = new List<TblTicketComment>();

    public virtual ICollection<TblTicketDepartment> TblTicketDepartments { get; set; } = new List<TblTicketDepartment>();

    public virtual ICollection<TblTicketFeedback> TblTicketFeedbacks { get; set; } = new List<TblTicketFeedback>();

    public virtual ICollection<TblTicketHandling> TblTicketHandlings { get; set; } = new List<TblTicketHandling>();

    public virtual ICollection<TblTicketReport> TblTicketReports { get; set; } = new List<TblTicketReport>();
}
