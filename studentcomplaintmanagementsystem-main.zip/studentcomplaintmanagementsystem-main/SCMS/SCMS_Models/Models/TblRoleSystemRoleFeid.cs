﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblRoleSystemRoleFeid
{
    public Guid RoleFeidId { get; set; }

    public Guid RoleId { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public virtual TblRole Role { get; set; } = null!;

    public virtual TblRoleFeid RoleFeid { get; set; } = null!;
}
