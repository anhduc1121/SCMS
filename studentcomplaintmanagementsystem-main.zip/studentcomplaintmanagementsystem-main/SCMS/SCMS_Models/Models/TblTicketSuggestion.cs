﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketSuggestion
{
    public Guid TicketSuggestionId { get; set; }

    public string? Title { get; set; }

    public string? Description { get; set; }

    public Guid? CategoryTicketId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public bool IsAccept { get; set; }

    public Guid? RequestUpdateId { get; set; }

    public Guid? AccountCreatorId { get; set; }

    public Guid? AccountUpdateId { get; set; }

    public string? FileId { get; set; }

    public virtual TblAccount? AccountCreator { get; set; }

    public virtual TblAccount? AccountUpdate { get; set; }

    public virtual TblCategoryTicket? CategoryTicket { get; set; }

    public virtual ICollection<TblTicketSuggestion> InverseRequestUpdate { get; set; } = new List<TblTicketSuggestion>();

    public virtual TblTicketSuggestion? RequestUpdate { get; set; }

    public virtual ICollection<TblTicketSuggestionAttachment> TblTicketSuggestionAttachments { get; set; } = new List<TblTicketSuggestionAttachment>();

    public virtual ICollection<TblTicketSuggestionDetail> TblTicketSuggestionDetails { get; set; } = new List<TblTicketSuggestionDetail>();
}
