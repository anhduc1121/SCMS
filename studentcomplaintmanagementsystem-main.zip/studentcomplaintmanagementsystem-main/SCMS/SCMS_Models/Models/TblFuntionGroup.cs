﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblFuntionGroup
{
    public Guid FunctionActionApi { get; set; }

    public Guid RoleId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual TblFunctionActionApi FunctionActionApiNavigation { get; set; } = null!;

    public virtual TblRole Role { get; set; } = null!;
}
