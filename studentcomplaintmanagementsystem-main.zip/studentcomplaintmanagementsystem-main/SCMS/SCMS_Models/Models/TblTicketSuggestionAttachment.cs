﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketSuggestionAttachment
{
    public Guid TicketSuggestionAttachmentsId { get; set; }

    public string? FileType { get; set; }

    public string? Description { get; set; }

    public string UrlPath { get; set; } = null!;

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public bool IsDelete { get; set; }

    public string? FileName { get; set; }

    public Guid? TicketSuggestionId { get; set; }

    public Guid? TicketSuggestionDetailId { get; set; }

    public string? FileId { get; set; }

    public virtual TblTicketSuggestion? TicketSuggestion { get; set; }

    public virtual TblTicketSuggestionDetail? TicketSuggestionDetail { get; set; }
}
