﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblNotificationSystemView
{
    public Guid AccountId { get; set; }

    public Guid NotificationSystemId { get; set; }

    public DateTime CreateDate { get; set; }

    public virtual TblAccount Account { get; set; } = null!;

    public virtual TblNotificationSystem NotificationSystem { get; set; } = null!;
}
