﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblFunctionActionApi
{
    public Guid FunctionActionApiId { get; set; }

    public string FuntionNameController { get; set; } = null!;

    public string FuntionNameAction { get; set; } = null!;

    public string? FuntionNameDescription { get; set; }

    public DateTime CreateDate { get; set; }

    public bool Status { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual ICollection<TblFuntionGroup> TblFuntionGroups { get; set; } = new List<TblFuntionGroup>();
}
