﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace SCMS_Models.Models;

public partial class ScmsContext : DbContext
{
    public async Task<List<ExEmployee>> GetAllEmployeesWithFilters(string partOfEmail, int orderByDate)
    {
        return await this.Set<ExEmployee>()
            .FromSqlRaw("EXEC GetAllEmployeesWithFilters @partOfEmail, @orderByDate",
                new SqlParameter("@partOfEmail", partOfEmail),
                new SqlParameter("@orderByDate", orderByDate))
            .ToListAsync();
    }


    public async Task<List<ExStatusAccount>> GetAllStatusAccount()
    {
        return await this.Set<ExStatusAccount>()
        .FromSqlRaw("EXEC GetAllStatusAccount")
            .ToListAsync();
    }
}
