﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblAccountRole
{
    public Guid RoleId { get; set; }

    public Guid AccountId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual TblAccount Account { get; set; } = null!;

    public virtual TblRole Role { get; set; } = null!;
}
