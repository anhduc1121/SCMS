﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblHistoryNotification
{
    public Guid HistoryNotificationId { get; set; }

    public DateTime? CreateDate { get; set; }

    public string? Title { get; set; }

    public string Status { get; set; } = null!;

    public string? To { get; set; }

    public Guid? NotificationSystemId { get; set; }

    public Guid? NotificationId { get; set; }

    public virtual TblNotification? Notification { get; set; }

    public virtual TblNotificationSystem? NotificationSystem { get; set; }
}
