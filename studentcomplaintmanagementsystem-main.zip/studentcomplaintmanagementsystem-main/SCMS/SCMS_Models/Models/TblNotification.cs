﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblNotification
{
    public Guid NotificationId { get; set; }

    public string? Content { get; set; }

    public string? Title { get; set; }

    public string? UrlSulg { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsView { get; set; }

    public Guid AccountId { get; set; }

    public bool IsDelete { get; set; }

    public Guid TicketId { get; set; }

    public Guid? TicketCommentId { get; set; }

    public virtual TblAccount Account { get; set; } = null!;

    public virtual ICollection<TblHistoryNotification> TblHistoryNotifications { get; set; } = new List<TblHistoryNotification>();

    public virtual ICollection<TblNotificationEmail> TblNotificationEmails { get; set; } = new List<TblNotificationEmail>();

    public virtual TblTicket Ticket { get; set; } = null!;

    public virtual TblTicketComment? TicketComment { get; set; }
}
