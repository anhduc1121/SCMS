﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblCampus
{
    public Guid CampusId { get; set; }

    public string? CampusName { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public virtual ICollection<TblAccount> TblAccounts { get; set; } = new List<TblAccount>();
}
