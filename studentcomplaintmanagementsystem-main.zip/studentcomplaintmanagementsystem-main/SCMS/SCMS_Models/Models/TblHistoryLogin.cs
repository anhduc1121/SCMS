﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblHistoryLogin
{
    public Guid HistoryLoginId { get; set; }

    public string? Token { get; set; }

    public DateTime CreateDate { get; set; }

    public bool? IsDelete { get; set; }

    public bool? ModifyUpdate { get; set; }

    public Guid AccountId { get; set; }

    public bool IsFeid { get; set; }

    public bool? IsGoogle { get; set; }

    public virtual TblAccount Account { get; set; } = null!;
}
