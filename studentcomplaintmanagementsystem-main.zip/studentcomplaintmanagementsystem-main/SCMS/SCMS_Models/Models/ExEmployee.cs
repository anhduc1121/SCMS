﻿using System.ComponentModel.DataAnnotations;

namespace SCMS_Models.Models
{
    public class ExEmployee
    {
        [Key]
        public Guid EmployeeId { get; set; }
        public string EmployeeEmail { get; set; }
        public string? Firstname { get; set; }
        public string? Lastname { get; set; }
        public DateTime? CreateDate { get; set; }

        public string? Phone { get; set; }

        public string? Address { get; set; }

        public string? CampusName { get; set; }

        public string? StatusName { get; set; }
        public Guid StatusId { get; set; }
        public Guid CampusId { get; set; }

        public Guid DepartmentId { get; set; }

        public string? DepartmentName { get; set; }
    }
}
