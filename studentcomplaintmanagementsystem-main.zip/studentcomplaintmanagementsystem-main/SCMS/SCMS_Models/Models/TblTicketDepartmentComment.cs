﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketDepartmentComment
{
    public Guid TicketDepartmentCommentId { get; set; }

    public string? Comment { get; set; }

    public DateTime CreateDate { get; set; }

    public string? Rate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid? AccountId { get; set; }

    public Guid TicketDepartmentsId { get; set; }

    public string? FileId { get; set; }

    public virtual TblAccount? Account { get; set; }

    public virtual ICollection<TblTicketDepartmentAttachment> TblTicketDepartmentAttachments { get; set; } = new List<TblTicketDepartmentAttachment>();

    public virtual TblTicketDepartment TicketDepartments { get; set; } = null!;
}
