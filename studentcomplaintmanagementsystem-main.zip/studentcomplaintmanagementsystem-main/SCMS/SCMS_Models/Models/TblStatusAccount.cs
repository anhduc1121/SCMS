﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblStatusAccount
{
    public Guid StatusAccountId { get; set; }

    public string StatusAccountName { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public bool IsDelete { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual ICollection<TblAccount> TblAccounts { get; set; } = new List<TblAccount>();
}
