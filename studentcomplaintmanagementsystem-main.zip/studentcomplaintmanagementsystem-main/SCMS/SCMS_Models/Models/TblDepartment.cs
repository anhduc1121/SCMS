﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblDepartment
{
    public Guid DepartmentId { get; set; }

    public bool IsDelete { get; set; }

    public string DepartmentName { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid AccountCreateId { get; set; }

    public Guid? AccountUpdateId { get; set; }

    public string ResponsiblePersonEmail { get; set; } = null!;

    public virtual TblAccount AccountCreate { get; set; } = null!;

    public virtual TblAccount? AccountUpdate { get; set; }

    public virtual ICollection<TblAccount> TblAccounts { get; set; } = new List<TblAccount>();

    public virtual ICollection<TblTicketDepartment> TblTicketDepartments { get; set; } = new List<TblTicketDepartment>();
}
