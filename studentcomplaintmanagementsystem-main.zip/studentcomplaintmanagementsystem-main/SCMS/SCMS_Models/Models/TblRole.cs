﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblRole
{
    public Guid RoleId { get; set; }

    public string RoleName { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public virtual ICollection<TblAccountRole> TblAccountRoles { get; set; } = new List<TblAccountRole>();

    public virtual ICollection<TblFuntionGroup> TblFuntionGroups { get; set; } = new List<TblFuntionGroup>();

    public virtual ICollection<TblPageRole> TblPageRoles { get; set; } = new List<TblPageRole>();

    public virtual ICollection<TblRoleSystemRoleFeid> TblRoleSystemRoleFeids { get; set; } = new List<TblRoleSystemRoleFeid>();

    public virtual ICollection<TblTicketHandling> TblTicketHandlings { get; set; } = new List<TblTicketHandling>();
}
