﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblNotificationEmail
{
    public Guid NotificationEmailId { get; set; }

    public string? Title { get; set; }

    public string? Content { get; set; }

    public string? TypeMessage { get; set; }

    public string Status { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid? NotificationId { get; set; }

    public virtual TblNotification? Notification { get; set; }
}
