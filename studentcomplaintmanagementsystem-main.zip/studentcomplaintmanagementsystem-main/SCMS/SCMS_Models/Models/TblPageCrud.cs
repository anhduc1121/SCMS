﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblPageCrud
{
    public Guid PageCrudId { get; set; }

    public string? PageCrudName { get; set; }

    public string? PageCrudDescription { get; set; }

    public bool? IsDelete { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid PageId { get; set; }

    public virtual TblPage Page { get; set; } = null!;

    public virtual ICollection<TblPageRole> TblPageRoles { get; set; } = new List<TblPageRole>();
}
