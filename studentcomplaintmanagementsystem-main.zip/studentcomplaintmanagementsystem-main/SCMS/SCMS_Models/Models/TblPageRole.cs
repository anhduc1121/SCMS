﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblPageRole
{
    public Guid PageCrudId { get; set; }

    public Guid RoleId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid? AccountCreateId { get; set; }

    public Guid? AccountUpdateId { get; set; }

    public virtual TblPageCrud PageCrud { get; set; } = null!;

    public virtual TblRole Role { get; set; } = null!;
}
