﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketDepartment
{
    public Guid TicketDepartmentsId { get; set; }

    public string Title { get; set; } = null!;

    public string? Description { get; set; }

    public DateTime CreateDate { get; set; }

    public string? Rate { get; set; }

    public DateTime? DurationTime { get; set; }

    public DateTime? ActualTime { get; set; }

    public DateTime? EstimateTime { get; set; }

    public DateTime? Kpitime { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public string Status { get; set; } = null!;

    public bool? IsDelete { get; set; }

    public Guid CategoryTicketId { get; set; }

    public Guid StatusTicketId { get; set; }

    public Guid AccountIdCreate { get; set; }

    public Guid? AccountId { get; set; }

    public Guid? TicketId { get; set; }

    public Guid? DepartmentId { get; set; }

    public string? FileId { get; set; }

    public virtual TblAccount? Account { get; set; }

    public virtual TblAccount AccountIdCreateNavigation { get; set; } = null!;

    public virtual TblCategoryTicket CategoryTicket { get; set; } = null!;

    public virtual TblDepartment? Department { get; set; }

    public virtual TblStatusTicket StatusTicket { get; set; } = null!;

    public virtual ICollection<TblPinTicket> TblPinTickets { get; set; } = new List<TblPinTicket>();

    public virtual ICollection<TblTicketDepartmentAttachment> TblTicketDepartmentAttachments { get; set; } = new List<TblTicketDepartmentAttachment>();

    public virtual ICollection<TblTicketDepartmentComment> TblTicketDepartmentComments { get; set; } = new List<TblTicketDepartmentComment>();

    public virtual ICollection<TblTicketDepartmentCommentsImport> TblTicketDepartmentCommentsImports { get; set; } = new List<TblTicketDepartmentCommentsImport>();

    public virtual TblTicket? Ticket { get; set; }
}
