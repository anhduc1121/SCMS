﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblSystemSetting
{
    public Guid SystemSettingId { get; set; }

    public string SystemSettingName { get; set; } = null!;

    public int Time { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid? AccountCreateId { get; set; }

    public Guid? AccountUpdateId { get; set; }

    public bool IsDelete { get; set; }

    public Guid? RoleId { get; set; }

    public virtual TblAccount? AccountCreate { get; set; }

    public virtual TblAccount? AccountUpdate { get; set; }
}
