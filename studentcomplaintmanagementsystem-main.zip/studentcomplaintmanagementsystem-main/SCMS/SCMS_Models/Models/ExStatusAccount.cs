﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCMS_Models.Models
{
    public class ExStatusAccount
    {
        [Key]
        public Guid StatusId { get; set; }

        public string StatusName { get; set; } = null!;

    }
}
