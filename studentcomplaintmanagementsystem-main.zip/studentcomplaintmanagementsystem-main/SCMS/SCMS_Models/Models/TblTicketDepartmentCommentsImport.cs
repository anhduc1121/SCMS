﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketDepartmentCommentsImport
{
    public Guid TicketDepartmentCommentsImportId { get; set; }

    public string? Comment { get; set; }

    public DateTime CreateDate { get; set; }

    public string? Rate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid TicketDepartmentsId { get; set; }

    public string ColumView { get; set; } = null!;

    public string? FileId { get; set; }

    public byte? No { get; set; }

    public virtual ICollection<TblTicketDepartmentAttachment> TblTicketDepartmentAttachments { get; set; } = new List<TblTicketDepartmentAttachment>();

    public virtual TblTicketDepartment TicketDepartments { get; set; } = null!;
}
