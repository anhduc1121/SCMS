﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTagTicketAttachment
{
    public Guid TagTicketAttachmentId { get; set; }

    public string Url { get; set; } = null!;

    public string? FileName { get; set; }

    public string? FileType { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid TagTicketId { get; set; }

    public string? FileId { get; set; }

    public virtual TblTagTicket TagTicket { get; set; } = null!;
}
