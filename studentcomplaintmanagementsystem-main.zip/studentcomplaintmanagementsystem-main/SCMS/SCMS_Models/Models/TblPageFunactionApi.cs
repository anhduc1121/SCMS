﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblPageFunactionApi
{
    public Guid PageId { get; set; }

    public Guid FunctionActionApiId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual TblFunctionActionApi FunctionActionApi { get; set; } = null!;

    public virtual TblPage Page { get; set; } = null!;
}
