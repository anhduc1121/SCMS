﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblPinTicket
{
    public Guid PinPinTicketId { get; set; }

    public Guid? TicketId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid AccountId { get; set; }

    public Guid? TicketDepartmentsId { get; set; }

    public virtual TblAccount Account { get; set; } = null!;

    public virtual TblTicket? Ticket { get; set; }

    public virtual TblTicketDepartment? TicketDepartments { get; set; }
}
