﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTagTicket
{
    public Guid TagTicketId { get; set; }

    public string? RequestDetails { get; set; }

    public string? UrlPathRequest { get; set; }

    public string? ResponseDetails { get; set; }

    public string? UrlPathResponse { get; set; }

    public string IsAccept { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid? RequiredAccountId { get; set; }

    public Guid? AccountCreateId { get; set; }

    public Guid TicketId { get; set; }

    public virtual TblAccount? AccountCreate { get; set; }

    public virtual TblAccount? RequiredAccount { get; set; }

    public virtual ICollection<TblTagTicketAttachment> TblTagTicketAttachments { get; set; } = new List<TblTagTicketAttachment>();

    public virtual TblTicket Ticket { get; set; } = null!;
}
