﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketFeedback
{
    public Guid TicketFeedbackId { get; set; }

    public string? TicketFeedbackPositive { get; set; }

    public string? TicketFeedbackNegative { get; set; }

    public string Rate { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid TicketId { get; set; }

    public bool IsCancel { get; set; }

    /// <summary>
    /// nhân viên đc đánh giá
    /// </summary>
    public Guid AccountIdStaff { get; set; }

    public Guid? AccountIdUpdate { get; set; }

    public virtual TblAccount AccountIdStaffNavigation { get; set; } = null!;

    public virtual TblAccount? AccountIdUpdateNavigation { get; set; }

    public virtual TblTicket Ticket { get; set; } = null!;
}
