﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketHandlingStatus
{
    public Guid TicketHandlingStatusId { get; set; }

    public string? TicketHandlingStatusName { get; set; }

    public bool IsDelete { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public string? ColorStatus { get; set; }

    public virtual ICollection<TblTicketHandling> TblTicketHandlings { get; set; } = new List<TblTicketHandling>();
}
