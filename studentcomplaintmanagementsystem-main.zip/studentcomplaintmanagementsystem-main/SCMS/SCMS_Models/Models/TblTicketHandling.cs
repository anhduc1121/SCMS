﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketHandling
{
    public Guid TicketHandlingId { get; set; }

    public string? Content { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? EstimateTime { get; set; }

    public Guid? RoleId { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public DateTime? Kpitime { get; set; }

    public bool IsDelete { get; set; }

    public Guid? AccountManagerId { get; set; }

    public Guid? TicketCommentId { get; set; }

    public Guid TicketHandlingStatusId { get; set; }

    public Guid? TicketHandlingParentId { get; set; }

    public Guid? TicketId { get; set; }

    public int? ExecutionSequence { get; set; }

    public bool? IsAccpect { get; set; }

    public virtual ICollection<TblTicketHandling> InverseTicketHandlingParent { get; set; } = new List<TblTicketHandling>();

    public virtual TblRole? Role { get; set; }

    public virtual TblTicket? Ticket { get; set; }

    public virtual TblTicketComment? TicketComment { get; set; }

    public virtual TblTicketHandling? TicketHandlingParent { get; set; }

    public virtual TblTicketHandlingStatus TicketHandlingStatus { get; set; } = null!;
}
