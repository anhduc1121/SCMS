﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblPage
{
    public Guid PageId { get; set; }

    public string? PageName { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool? IsDelete { get; set; }

    public virtual ICollection<TblPageCrud> TblPageCruds { get; set; } = new List<TblPageCrud>();
}
