﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class GoogleApiCredential
{
    public int Id { get; set; }

    public string? UserId { get; set; }

    public byte[]? CredentialData { get; set; }

    public string? Key { get; set; }

    public string? Value { get; set; }
}
