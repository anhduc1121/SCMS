﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketSuggestionDetail
{
    public Guid TicketSuggestionDetailId { get; set; }

    public string? Comment { get; set; }

    public DateTime CreateDate { get; set; }

    public string? Rate { get; set; }

    public Guid TicketSuggestionId { get; set; }

    public int? QuantitySelected { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public bool IsAccept { get; set; }

    public Guid? RequestUpdateId { get; set; }

    public string ColumView { get; set; } = null!;

    public byte? No { get; set; }

    public string? FileId { get; set; }

    public virtual ICollection<TblTicketSuggestionDetail> InverseRequestUpdate { get; set; } = new List<TblTicketSuggestionDetail>();

    public virtual TblTicketSuggestionDetail? RequestUpdate { get; set; }

    public virtual ICollection<TblTicketSuggestionAttachment> TblTicketSuggestionAttachments { get; set; } = new List<TblTicketSuggestionAttachment>();

    public virtual TblTicketSuggestion TicketSuggestion { get; set; } = null!;
}
