﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblAccount
{
    public Guid AccountId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Picture { get; set; }

    public string Email { get; set; } = null!;

    public string? Phone { get; set; }

    public string? Address { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid? CampusId { get; set; }

    public Guid StatusAccountId { get; set; }

    public bool IsDelete { get; set; }

    public Guid? RequestUpdateId { get; set; }

    public Guid? EducationId { get; set; }

    public bool IsGoogle { get; set; }

    public bool IsFeid { get; set; }

    public Guid? CampusFeidId { get; set; }

    public Guid? UserFeidId { get; set; }

    public string? RoleNameFeid { get; set; }

    public Guid? DepartmentId { get; set; }

    public virtual TblCampus? Campus { get; set; }

    public virtual TblDepartment? Department { get; set; }

    public virtual TblEducation? Education { get; set; }

    public virtual ICollection<TblAccount> InverseRequestUpdate { get; set; } = new List<TblAccount>();

    public virtual TblAccount? RequestUpdate { get; set; }

    public virtual TblStatusAccount StatusAccount { get; set; } = null!;

    public virtual ICollection<TblAccountRole> TblAccountRoles { get; set; } = new List<TblAccountRole>();

    public virtual ICollection<TblCategoryTicket> TblCategoryTicketAccountIdCreateNavigations { get; set; } = new List<TblCategoryTicket>();

    public virtual ICollection<TblCategoryTicket> TblCategoryTicketAccountIdUpdateNavigations { get; set; } = new List<TblCategoryTicket>();

    public virtual ICollection<TblDepartment> TblDepartmentAccountCreates { get; set; } = new List<TblDepartment>();

    public virtual ICollection<TblDepartment> TblDepartmentAccountUpdates { get; set; } = new List<TblDepartment>();

    public virtual ICollection<TblHistoryAccountTicketsOnline> TblHistoryAccountTicketsOnlines { get; set; } = new List<TblHistoryAccountTicketsOnline>();

    public virtual ICollection<TblHistoryLogin> TblHistoryLogins { get; set; } = new List<TblHistoryLogin>();

    public virtual ICollection<TblNotificationSystemView> TblNotificationSystemViews { get; set; } = new List<TblNotificationSystemView>();

    public virtual ICollection<TblNotification> TblNotifications { get; set; } = new List<TblNotification>();

    public virtual ICollection<TblPinTicket> TblPinTickets { get; set; } = new List<TblPinTicket>();

    public virtual ICollection<TblSystemSetting> TblSystemSettingAccountCreates { get; set; } = new List<TblSystemSetting>();

    public virtual ICollection<TblSystemSetting> TblSystemSettingAccountUpdates { get; set; } = new List<TblSystemSetting>();

    public virtual ICollection<TblTagTicket> TblTagTicketAccountCreates { get; set; } = new List<TblTagTicket>();

    public virtual ICollection<TblTagTicket> TblTagTicketRequiredAccounts { get; set; } = new List<TblTagTicket>();

    public virtual ICollection<TblTicket> TblTicketAccountIdCreateNavigations { get; set; } = new List<TblTicket>();

    public virtual ICollection<TblTicket> TblTicketAccountIdbehaveCreateNavigations { get; set; } = new List<TblTicket>();

    public virtual ICollection<TblTicket> TblTicketAccountIdupdateNavigations { get; set; } = new List<TblTicket>();

    public virtual ICollection<TblTicketComment> TblTicketComments { get; set; } = new List<TblTicketComment>();

    public virtual ICollection<TblTicketDepartment> TblTicketDepartmentAccountIdCreateNavigations { get; set; } = new List<TblTicketDepartment>();

    public virtual ICollection<TblTicketDepartment> TblTicketDepartmentAccounts { get; set; } = new List<TblTicketDepartment>();

    public virtual ICollection<TblTicketDepartmentComment> TblTicketDepartmentComments { get; set; } = new List<TblTicketDepartmentComment>();

    public virtual ICollection<TblTicketFeedback> TblTicketFeedbackAccountIdStaffNavigations { get; set; } = new List<TblTicketFeedback>();

    public virtual ICollection<TblTicketFeedback> TblTicketFeedbackAccountIdUpdateNavigations { get; set; } = new List<TblTicketFeedback>();

    public virtual ICollection<TblTicketReport> TblTicketReportAccountIdStaffNavigations { get; set; } = new List<TblTicketReport>();

    public virtual ICollection<TblTicketReport> TblTicketReportAccountIdUpdateNavigations { get; set; } = new List<TblTicketReport>();

    public virtual ICollection<TblTicketSuggestion> TblTicketSuggestionAccountCreators { get; set; } = new List<TblTicketSuggestion>();

    public virtual ICollection<TblTicketSuggestion> TblTicketSuggestionAccountUpdates { get; set; } = new List<TblTicketSuggestion>();
}
