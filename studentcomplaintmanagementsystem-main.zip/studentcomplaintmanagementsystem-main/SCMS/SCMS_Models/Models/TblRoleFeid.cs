﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblRoleFeid
{
    public bool IsDelete { get; set; }

    public Guid RoleFeidId { get; set; }

    public string RoleFeidName { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public virtual ICollection<TblRoleSystemRoleFeid> TblRoleSystemRoleFeids { get; set; } = new List<TblRoleSystemRoleFeid>();
}
