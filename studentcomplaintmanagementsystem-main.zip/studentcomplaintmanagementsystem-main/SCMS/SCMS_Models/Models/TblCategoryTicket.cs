﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblCategoryTicket
{
    public Guid CategoryTicketId { get; set; }

    public string CategoryName { get; set; } = null!;

    public bool? Status { get; set; }

    public string? FullPath { get; set; }

    public string? Description { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public int ResponseTime { get; set; }

    public int? ResponseHours { get; set; }

    public Guid AccountIdCreate { get; set; }

    public Guid? CategoryTicketParentId { get; set; }

    public bool IsDelete { get; set; }

    public string ResponsiblePersonEmail { get; set; } = null!;

    public Guid? AccountIdUpdate { get; set; }

    public virtual TblAccount AccountIdCreateNavigation { get; set; } = null!;

    public virtual TblAccount? AccountIdUpdateNavigation { get; set; }

    public virtual TblCategoryTicket? CategoryTicketParent { get; set; }

    public virtual ICollection<TblCategoryTicket> InverseCategoryTicketParent { get; set; } = new List<TblCategoryTicket>();

    public virtual ICollection<TblHistoryCategoryTicket> TblHistoryCategoryTickets { get; set; } = new List<TblHistoryCategoryTicket>();

    public virtual ICollection<TblTicketComment> TblTicketComments { get; set; } = new List<TblTicketComment>();

    public virtual ICollection<TblTicketDepartment> TblTicketDepartments { get; set; } = new List<TblTicketDepartment>();

    public virtual ICollection<TblTicketSuggestion> TblTicketSuggestions { get; set; } = new List<TblTicketSuggestion>();

    public virtual ICollection<TblTicket> TblTickets { get; set; } = new List<TblTicket>();
}
