﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblStatusTicket
{
    public Guid StatusTicketId { get; set; }

    public string StatusTicketName { get; set; } = null!;

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public bool IsDelete { get; set; }

    public virtual ICollection<TblTicketDepartment> TblTicketDepartments { get; set; } = new List<TblTicketDepartment>();

    public virtual ICollection<TblTicket> TblTickets { get; set; } = new List<TblTicket>();
}
