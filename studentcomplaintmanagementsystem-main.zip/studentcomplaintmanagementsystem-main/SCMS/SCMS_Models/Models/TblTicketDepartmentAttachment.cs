﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketDepartmentAttachment
{
    public Guid TicketDepartmentAttachment { get; set; }

    public string? Description { get; set; }

    public string? UrlPath { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool IsDelete { get; set; }

    public Guid? TicketDepartmentCommentId { get; set; }

    public Guid TicketDepartmentsId { get; set; }

    public string? FileName { get; set; }

    public string? FileType { get; set; }

    public string? FileId { get; set; }

    public Guid? TicketDepartmentCommentsImportId { get; set; }

    public virtual TblTicketDepartmentComment? TicketDepartmentComment { get; set; }

    public virtual TblTicketDepartmentCommentsImport? TicketDepartmentCommentsImport { get; set; }

    public virtual TblTicketDepartment TicketDepartments { get; set; } = null!;
}
