﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketReport
{
    public Guid TicketReportId { get; set; }

    public string Description { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public Guid AccountIdStaff { get; set; }

    public Guid? AccountIdUpdate { get; set; }

    public bool IsCancel { get; set; }

    public Guid TicketId { get; set; }

    public virtual TblAccount AccountIdStaffNavigation { get; set; } = null!;

    public virtual TblAccount? AccountIdUpdateNavigation { get; set; }

    public virtual ICollection<TblTicketReportAttachment> TblTicketReportAttachments { get; set; } = new List<TblTicketReportAttachment>();

    public virtual TblTicket Ticket { get; set; } = null!;
}
