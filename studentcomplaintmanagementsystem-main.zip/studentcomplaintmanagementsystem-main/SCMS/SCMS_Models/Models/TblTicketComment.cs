﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketComment
{
    public Guid TicketCommentId { get; set; }

    public string? Comment { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public bool? IsDelete { get; set; }

    public Guid? AccountCreateId { get; set; }

    public Guid TicketId { get; set; }

    public Guid? CategoryTicketId { get; set; }

    public string? FileId { get; set; }

    public virtual TblAccount? AccountCreate { get; set; }

    public virtual TblCategoryTicket? CategoryTicket { get; set; }

    public virtual ICollection<TblNotification> TblNotifications { get; set; } = new List<TblNotification>();

    public virtual ICollection<TblTicketAttachment> TblTicketAttachments { get; set; } = new List<TblTicketAttachment>();

    public virtual ICollection<TblTicketHandling> TblTicketHandlings { get; set; } = new List<TblTicketHandling>();

    public virtual TblTicket Ticket { get; set; } = null!;
}
