﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace SCMS_Models.Models;

public partial class ScmsContext : DbContext
{
    public ScmsContext()
    {
    }

    public ScmsContext(DbContextOptions<ScmsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<GoogleApiCredential> GoogleApiCredentials { get; set; }

    public virtual DbSet<TblAccount> TblAccounts { get; set; }

    public virtual DbSet<TblAccountRole> TblAccountRoles { get; set; }

    public virtual DbSet<TblCampus> TblCampuses { get; set; }

    public virtual DbSet<TblCategoryTicket> TblCategoryTickets { get; set; }

    public virtual DbSet<TblDepartment> TblDepartments { get; set; }

    public virtual DbSet<TblEducation> TblEducations { get; set; }

    public virtual DbSet<TblFunctionActionApi> TblFunctionActionApis { get; set; }

    public virtual DbSet<TblFuntionGroup> TblFuntionGroups { get; set; }

    public virtual DbSet<TblHistoryAccountTicketsOnline> TblHistoryAccountTicketsOnlines { get; set; }

    public virtual DbSet<TblHistoryCategoryTicket> TblHistoryCategoryTickets { get; set; }

    public virtual DbSet<TblHistoryLogin> TblHistoryLogins { get; set; }

    public virtual DbSet<TblHistoryNotification> TblHistoryNotifications { get; set; }

    public virtual DbSet<TblNotification> TblNotifications { get; set; }

    public virtual DbSet<TblNotificationEmail> TblNotificationEmails { get; set; }

    public virtual DbSet<TblNotificationSystem> TblNotificationSystems { get; set; }

    public virtual DbSet<TblNotificationSystemView> TblNotificationSystemViews { get; set; }

    public virtual DbSet<TblPage> TblPages { get; set; }

    public virtual DbSet<TblPageCrud> TblPageCruds { get; set; }

    public virtual DbSet<TblPageRole> TblPageRoles { get; set; }

    public virtual DbSet<TblPinTicket> TblPinTickets { get; set; }

    public virtual DbSet<TblRole> TblRoles { get; set; }

    public virtual DbSet<TblRoleFeid> TblRoleFeids { get; set; }

    public virtual DbSet<TblRoleSystemRoleFeid> TblRoleSystemRoleFeids { get; set; }

    public virtual DbSet<TblStatusAccount> TblStatusAccounts { get; set; }

    public virtual DbSet<TblStatusTicket> TblStatusTickets { get; set; }

    public virtual DbSet<TblSystemSetting> TblSystemSettings { get; set; }

    public virtual DbSet<TblTagTicket> TblTagTickets { get; set; }

    public virtual DbSet<TblTagTicketAttachment> TblTagTicketAttachments { get; set; }

    public virtual DbSet<TblTicket> TblTickets { get; set; }

    public virtual DbSet<TblTicketAttachment> TblTicketAttachments { get; set; }

    public virtual DbSet<TblTicketComment> TblTicketComments { get; set; }

    public virtual DbSet<TblTicketDepartment> TblTicketDepartments { get; set; }

    public virtual DbSet<TblTicketDepartmentAttachment> TblTicketDepartmentAttachments { get; set; }

    public virtual DbSet<TblTicketDepartmentComment> TblTicketDepartmentComments { get; set; }

    public virtual DbSet<TblTicketDepartmentCommentsImport> TblTicketDepartmentCommentsImports { get; set; }

    public virtual DbSet<TblTicketFeedback> TblTicketFeedbacks { get; set; }

    public virtual DbSet<TblTicketHandling> TblTicketHandlings { get; set; }

    public virtual DbSet<TblTicketHandlingStatus> TblTicketHandlingStatuses { get; set; }

    public virtual DbSet<TblTicketReport> TblTicketReports { get; set; }

    public virtual DbSet<TblTicketReportAttachment> TblTicketReportAttachments { get; set; }

    public virtual DbSet<TblTicketSuggestion> TblTicketSuggestions { get; set; }

    public virtual DbSet<TblTicketSuggestionAttachment> TblTicketSuggestionAttachments { get; set; }

    public virtual DbSet<TblTicketSuggestionDetail> TblTicketSuggestionDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
        optionsBuilder.UseSqlServer(config.GetConnectionString("MyCnn"));
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ExEmployee>().HasNoKey();
        modelBuilder.Entity<ExStatusAccount>().HasNoKey();

        modelBuilder.Entity<GoogleApiCredential>(entity =>
        {
            entity.Property(e => e.Key).HasMaxLength(100);
            entity.Property(e => e.UserId).HasMaxLength(100);
        });

        modelBuilder.Entity<TblAccount>(entity =>
        {
            entity.HasKey(e => e.AccountId).HasName("PK_Account");

            entity.ToTable("tbl_Account");

            entity.HasIndex(e => e.Email, "UQ__tbl_Acco__A9D10534F86455A7").IsUnique();

            entity.Property(e => e.AccountId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Address).HasMaxLength(200);
            entity.Property(e => e.CampusId).HasColumnName("CampusID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");
            entity.Property(e => e.Email).HasMaxLength(250);
            entity.Property(e => e.FirstName).HasMaxLength(250);
            entity.Property(e => e.LastName).HasMaxLength(250);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Phone).HasMaxLength(13);
            entity.Property(e => e.RequestUpdateId).HasColumnName("RequestUpdateID");

            entity.HasOne(d => d.Campus).WithMany(p => p.TblAccounts)
                .HasForeignKey(d => d.CampusId)
                .HasConstraintName("FK_tbl_Account_tbl_Campus");

            entity.HasOne(d => d.Department).WithMany(p => p.TblAccounts)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK_tbl_Account_Tbl_Departments");

            entity.HasOne(d => d.Education).WithMany(p => p.TblAccounts)
                .HasForeignKey(d => d.EducationId)
                .HasConstraintName("FK_tbl_Account_tbl_Education");

            entity.HasOne(d => d.RequestUpdate).WithMany(p => p.InverseRequestUpdate)
                .HasForeignKey(d => d.RequestUpdateId)
                .HasConstraintName("FK_tbl_Account_tbl_Account");

            entity.HasOne(d => d.StatusAccount).WithMany(p => p.TblAccounts)
                .HasForeignKey(d => d.StatusAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Account_tbl_StatusAccount");
        });

        modelBuilder.Entity<TblAccountRole>(entity =>
        {
            entity.HasKey(e => new { e.RoleId, e.AccountId });

            entity.ToTable("tblAccount_Role");

            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");

            entity.HasOne(d => d.Account).WithMany(p => p.TblAccountRoles)
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblAccount_Role_tbl_Account");

            entity.HasOne(d => d.Role).WithMany(p => p.TblAccountRoles)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblAccount_Role_tbl_Role");
        });

        modelBuilder.Entity<TblCampus>(entity =>
        {
            entity.HasKey(e => e.CampusId).HasName("PK_Campus");

            entity.ToTable("tbl_Campus");

            entity.Property(e => e.CampusId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("CampusID");
            entity.Property(e => e.CampusName).HasMaxLength(100);
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCategoryTicket>(entity =>
        {
            entity.HasKey(e => e.CategoryTicketId).HasName("PK_tbl_CategoryComplaint");

            entity.ToTable("tbl_CategoryTicket");

            entity.Property(e => e.CategoryTicketId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("CategoryTicketID");
            entity.Property(e => e.CategoryName).HasMaxLength(100);
            entity.Property(e => e.CategoryTicketParentId).HasColumnName("CategoryTicketParentID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.FullPath).HasColumnType("ntext");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.ResponsiblePersonEmail)
                .HasMaxLength(200)
                .HasColumnName("responsible_person_email");
            entity.Property(e => e.Status).HasDefaultValue(true);

            entity.HasOne(d => d.AccountIdCreateNavigation).WithMany(p => p.TblCategoryTicketAccountIdCreateNavigations)
                .HasForeignKey(d => d.AccountIdCreate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_CategoryTicket_tbl_Account");

            entity.HasOne(d => d.AccountIdUpdateNavigation).WithMany(p => p.TblCategoryTicketAccountIdUpdateNavigations)
                .HasForeignKey(d => d.AccountIdUpdate)
                .HasConstraintName("FK_tbl_CategoryTicket_tbl_Account1");

            entity.HasOne(d => d.CategoryTicketParent).WithMany(p => p.InverseCategoryTicketParent)
                .HasForeignKey(d => d.CategoryTicketParentId)
                .HasConstraintName("FK_tbl_CategoryTicket_tbl_CategoryTicket");
        });

        modelBuilder.Entity<TblDepartment>(entity =>
        {
            entity.HasKey(e => e.DepartmentId);

            entity.ToTable("Tbl_Departments");

            entity.Property(e => e.DepartmentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("DepartmentID");
            entity.Property(e => e.AccountCreateId).HasColumnName("AccountCreateID");
            entity.Property(e => e.AccountUpdateId).HasColumnName("AccountUpdateID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DepartmentName).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.ResponsiblePersonEmail)
                .HasMaxLength(200)
                .HasColumnName("responsible_person_email");

            entity.HasOne(d => d.AccountCreate).WithMany(p => p.TblDepartmentAccountCreates)
                .HasForeignKey(d => d.AccountCreateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Tbl_Departments_tbl_Account1");

            entity.HasOne(d => d.AccountUpdate).WithMany(p => p.TblDepartmentAccountUpdates)
                .HasForeignKey(d => d.AccountUpdateId)
                .HasConstraintName("FK_Tbl_Departments_tbl_Account");
        });

        modelBuilder.Entity<TblEducation>(entity =>
        {
            entity.HasKey(e => e.EducationId);

            entity.ToTable("tbl_Education");

            entity.Property(e => e.EducationId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EducationName).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblFunctionActionApi>(entity =>
        {
            entity.HasKey(e => e.FunctionActionApiId);

            entity.ToTable("tbl_FunctionActionAPI");

            entity.HasIndex(e => new { e.FuntionNameController, e.FuntionNameAction }, "UQ_FunctionActionAPI_Controller_Action").IsUnique();

            entity.Property(e => e.FunctionActionApiId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FuntionNameAction).HasMaxLength(200);
            entity.Property(e => e.FuntionNameController).HasMaxLength(200);
            entity.Property(e => e.FuntionNameDescription).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Status).HasDefaultValue(true);
        });

        modelBuilder.Entity<TblFuntionGroup>(entity =>
        {
            entity.HasKey(e => new { e.FunctionActionApi, e.RoleId });

            entity.ToTable("tbl_FuntionGroup");

            entity.Property(e => e.FunctionActionApi).HasColumnName("FunctionActionAPI");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");

            entity.HasOne(d => d.FunctionActionApiNavigation).WithMany(p => p.TblFuntionGroups)
                .HasForeignKey(d => d.FunctionActionApi)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_RoleFuntion_tbl_FunctionActionAPI");

            entity.HasOne(d => d.Role).WithMany(p => p.TblFuntionGroups)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_RoleFuntion_tbl_Role");
        });

        modelBuilder.Entity<TblHistoryAccountTicketsOnline>(entity =>
        {
            entity.HasKey(e => e.HistoryAccountTicketsOnlineId);

            entity.ToTable("tbl_HistoryAccountTicketsOnline");

            entity.Property(e => e.HistoryAccountTicketsOnlineId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("HistoryAccountTicketsOnlineID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.Account).WithMany(p => p.TblHistoryAccountTicketsOnlines)
                .HasForeignKey(d => d.AccountId)
                .HasConstraintName("FK_tbl_HistoryAccountTicketsOnline_tbl_Account");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblHistoryAccountTicketsOnlines)
                .HasForeignKey(d => d.TicketId)
                .HasConstraintName("FK_tbl_HistoryAccountTicketsOnline_tbl_Tickets");
        });

        modelBuilder.Entity<TblHistoryCategoryTicket>(entity =>
        {
            entity.HasKey(e => e.HistoryCategoryTicketId).HasName("PK_HistoryCategoryComplaint");

            entity.ToTable("tbl_HistoryCategoryTicket");

            entity.Property(e => e.HistoryCategoryTicketId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("HistoryCategoryTicketID");
            entity.Property(e => e.CategoryTicketId).HasColumnName("CategoryTicketID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsDelete).HasDefaultValue(false);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.CategoryTicket).WithMany(p => p.TblHistoryCategoryTickets)
                .HasForeignKey(d => d.CategoryTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_HistoryCategoryTicket_tbl_CategoryTicket");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblHistoryCategoryTickets)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_HistoryCategoryTicket_tbl_Tickets");
        });

        modelBuilder.Entity<TblHistoryLogin>(entity =>
        {
            entity.HasKey(e => e.HistoryLoginId);

            entity.ToTable("tbl_HistoryLogin");

            entity.Property(e => e.HistoryLoginId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("HistoryLoginID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsGoogle).HasDefaultValue(false);

            entity.HasOne(d => d.Account).WithMany(p => p.TblHistoryLogins)
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_HistoryLogin_tbl_Account");
        });

        modelBuilder.Entity<TblHistoryNotification>(entity =>
        {
            entity.HasKey(e => e.HistoryNotificationId);

            entity.ToTable("Tbl_HistoryNotification");

            entity.Property(e => e.HistoryNotificationId)
                .ValueGeneratedNever()
                .HasColumnName("HistoryNotificationID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.NotificationSystemId).HasColumnName("NotificationSystemID");
            entity.Property(e => e.Status)
                .HasMaxLength(1)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.Title).HasColumnType("ntext");
            entity.Property(e => e.To).HasMaxLength(200);

            entity.HasOne(d => d.Notification).WithMany(p => p.TblHistoryNotifications)
                .HasForeignKey(d => d.NotificationId)
                .HasConstraintName("FK_Tbl_HistoryNotification_tbl_Notification");

            entity.HasOne(d => d.NotificationSystem).WithMany(p => p.TblHistoryNotifications)
                .HasForeignKey(d => d.NotificationSystemId)
                .HasConstraintName("FK_Tbl_HistoryNotification_tbl_NotificationSystem");
        });

        modelBuilder.Entity<TblNotification>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK_Notification");

            entity.ToTable("tbl_Notification");

            entity.Property(e => e.NotificationId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Content).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketCommentId).HasColumnName("TicketCommentID");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");
            entity.Property(e => e.Title).HasColumnType("ntext");
            entity.Property(e => e.UrlSulg).HasColumnType("ntext");

            entity.HasOne(d => d.Account).WithMany(p => p.TblNotifications)
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Notification_tbl_Account");

            entity.HasOne(d => d.TicketComment).WithMany(p => p.TblNotifications)
                .HasForeignKey(d => d.TicketCommentId)
                .HasConstraintName("FK_tbl_Notification_tbl_TicketComments");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblNotifications)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Notification_tbl_Tickets");
        });

        modelBuilder.Entity<TblNotificationEmail>(entity =>
        {
            entity.HasKey(e => e.NotificationEmailId);

            entity.ToTable("tbl_NotificationEmail");

            entity.Property(e => e.NotificationEmailId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("NotificationEmailID");
            entity.Property(e => e.Content).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Status).HasMaxLength(2);
            entity.Property(e => e.Title).HasColumnType("ntext");
            entity.Property(e => e.TypeMessage).HasColumnType("ntext");

            entity.HasOne(d => d.Notification).WithMany(p => p.TblNotificationEmails)
                .HasForeignKey(d => d.NotificationId)
                .HasConstraintName("FK_tbl_NotificationEmail_tbl_Notification");
        });

        modelBuilder.Entity<TblNotificationSystem>(entity =>
        {
            entity.HasKey(e => e.NotificationSystemId);

            entity.ToTable("tbl_NotificationSystem");

            entity.Property(e => e.NotificationSystemId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("NotificationSystemID");
            entity.Property(e => e.Content).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsDelete).HasDefaultValue(false);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Title).HasColumnType("ntext");
            entity.Property(e => e.UrlSulg).HasColumnType("ntext");
        });

        modelBuilder.Entity<TblNotificationSystemView>(entity =>
        {
            entity.HasKey(e => new { e.AccountId, e.NotificationSystemId });

            entity.ToTable("tbl_NotificationSystemView");

            entity.Property(e => e.NotificationSystemId).HasColumnName("NotificationSystemID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Account).WithMany(p => p.TblNotificationSystemViews)
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_NotificationSystemView_tbl_Account");

            entity.HasOne(d => d.NotificationSystem).WithMany(p => p.TblNotificationSystemViews)
                .HasForeignKey(d => d.NotificationSystemId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_NotificationSystemView_tbl_NotificationSystem");
        });

        modelBuilder.Entity<TblPage>(entity =>
        {
            entity.HasKey(e => e.PageId).HasName("PK_tblPage");

            entity.ToTable("tbl_Page");

            entity.Property(e => e.PageId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("PageID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsDelete).HasDefaultValue(false);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.PageName).HasMaxLength(200);
        });

        modelBuilder.Entity<TblPageCrud>(entity =>
        {
            entity.HasKey(e => e.PageCrudId);

            entity.ToTable("tbl_PageCRUD");

            entity.Property(e => e.PageCrudId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("PageCrudID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.PageCrudDescription).HasMaxLength(200);
            entity.Property(e => e.PageCrudName).HasMaxLength(200);
            entity.Property(e => e.PageId).HasColumnName("PageID");

            entity.HasOne(d => d.Page).WithMany(p => p.TblPageCruds)
                .HasForeignKey(d => d.PageId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_PageCRUD_tbl_Page");
        });

        modelBuilder.Entity<TblPageRole>(entity =>
        {
            entity.HasKey(e => new { e.PageCrudId, e.RoleId }).HasName("PK_tblPage_FunactionAPI");

            entity.ToTable("tbl_PageRole");

            entity.Property(e => e.PageCrudId).HasColumnName("PageCrudID");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.AccountUpdateId).HasColumnName("AccountUpdateID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");

            entity.HasOne(d => d.PageCrud).WithMany(p => p.TblPageRoles)
                .HasForeignKey(d => d.PageCrudId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_PageRole_tbl_PageCRUD");

            entity.HasOne(d => d.Role).WithMany(p => p.TblPageRoles)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_PageRole_tbl_Role");
        });

        modelBuilder.Entity<TblPinTicket>(entity =>
        {
            entity.HasKey(e => e.PinPinTicketId).HasName("PK_PinComplaint");

            entity.ToTable("tbl_PinTicket");

            entity.Property(e => e.PinPinTicketId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("PinPinTicketID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketDepartmentsId).HasColumnName("TicketDepartmentsID");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.Account).WithMany(p => p.TblPinTickets)
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_PinTicket_tbl_Account");

            entity.HasOne(d => d.TicketDepartments).WithMany(p => p.TblPinTickets)
                .HasForeignKey(d => d.TicketDepartmentsId)
                .HasConstraintName("FK_tbl_PinTicket_tbl_TicketDepartments");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblPinTickets)
                .HasForeignKey(d => d.TicketId)
                .HasConstraintName("FK_tbl_PinTicket_tbl_Tickets");
        });

        modelBuilder.Entity<TblRole>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK_Role");

            entity.ToTable("tbl_Role");

            entity.Property(e => e.RoleId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("RoleID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.RoleName).HasMaxLength(200);
        });

        modelBuilder.Entity<TblRoleFeid>(entity =>
        {
            entity.HasKey(e => e.RoleFeidId);

            entity.ToTable("tbl_RoleFeid");

            entity.Property(e => e.RoleFeidId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("RoleFeidID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.RoleFeidName).HasMaxLength(200);
        });

        modelBuilder.Entity<TblRoleSystemRoleFeid>(entity =>
        {
            entity.HasKey(e => new { e.RoleFeidId, e.RoleId });

            entity.ToTable("tbl_RoleSystem_RoleFeid");

            entity.Property(e => e.RoleFeidId).HasColumnName("RoleFeidID");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");

            entity.HasOne(d => d.RoleFeid).WithMany(p => p.TblRoleSystemRoleFeids)
                .HasForeignKey(d => d.RoleFeidId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_RoleSystem_RoleFeid_tbl_RoleFeid");

            entity.HasOne(d => d.Role).WithMany(p => p.TblRoleSystemRoleFeids)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_RoleSystem_RoleFeid_tbl_Role");
        });

        modelBuilder.Entity<TblStatusAccount>(entity =>
        {
            entity.HasKey(e => e.StatusAccountId).HasName("PK_StatusAccount");

            entity.ToTable("tbl_StatusAccount");

            entity.Property(e => e.StatusAccountId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.StatusAccountName).HasMaxLength(100);
        });

        modelBuilder.Entity<TblStatusTicket>(entity =>
        {
            entity.HasKey(e => e.StatusTicketId).HasName("PK_StatusComplaint");

            entity.ToTable("tbl_StatusTickets");

            entity.Property(e => e.StatusTicketId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.StatusTicketName).HasMaxLength(100);
        });

        modelBuilder.Entity<TblSystemSetting>(entity =>
        {
            entity.HasKey(e => e.SystemSettingId);

            entity.ToTable("Tbl_SystemSetting");

            entity.Property(e => e.SystemSettingId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.SystemSettingName).HasMaxLength(200);

            entity.HasOne(d => d.AccountCreate).WithMany(p => p.TblSystemSettingAccountCreates)
                .HasForeignKey(d => d.AccountCreateId)
                .HasConstraintName("FK_Tbl_SystemSetting_tbl_Account");

            entity.HasOne(d => d.AccountUpdate).WithMany(p => p.TblSystemSettingAccountUpdates)
                .HasForeignKey(d => d.AccountUpdateId)
                .HasConstraintName("FK_Tbl_SystemSetting_tbl_Account1");
        });

        modelBuilder.Entity<TblTagTicket>(entity =>
        {
            entity.HasKey(e => e.TagTicketId).HasName("PK_TagComplaint");

            entity.ToTable("tbl_TagTickets");

            entity.Property(e => e.TagTicketId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TagTicketID");
            entity.Property(e => e.AccountCreateId).HasColumnName("AccountCreateID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsAccept)
                .HasMaxLength(1)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.RequestDetails).HasColumnType("ntext");
            entity.Property(e => e.RequiredAccountId).HasColumnName("RequiredAccountID");
            entity.Property(e => e.ResponseDetails).HasColumnType("ntext");
            entity.Property(e => e.UrlPathRequest).HasColumnType("ntext");
            entity.Property(e => e.UrlPathResponse).HasColumnType("ntext");

            entity.HasOne(d => d.AccountCreate).WithMany(p => p.TblTagTicketAccountCreates)
                .HasForeignKey(d => d.AccountCreateId)
                .HasConstraintName("FK_tbl_TagTickets_tbl_Account");

            entity.HasOne(d => d.RequiredAccount).WithMany(p => p.TblTagTicketRequiredAccounts)
                .HasForeignKey(d => d.RequiredAccountId)
                .HasConstraintName("FK_tbl_TagTickets_tbl_Account1");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTagTickets)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TagTickets_tbl_Tickets");
        });

        modelBuilder.Entity<TblTagTicketAttachment>(entity =>
        {
            entity.HasKey(e => e.TagTicketAttachmentId);

            entity.ToTable("tbl_TagTicketAttachments");

            entity.Property(e => e.TagTicketAttachmentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TagTicketAttachmentID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.FileName).HasColumnType("ntext");
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TagTicketId).HasColumnName("TagTicketID");
            entity.Property(e => e.Url).HasColumnType("ntext");

            entity.HasOne(d => d.TagTicket).WithMany(p => p.TblTagTicketAttachments)
                .HasForeignKey(d => d.TagTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TagTicketAttachments_tbl_TagTickets");
        });

        modelBuilder.Entity<TblTicket>(entity =>
        {
            entity.HasKey(e => e.TicketId).HasName("PK_Complaint");

            entity.ToTable("tbl_Tickets");

            entity.Property(e => e.TicketId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketID");
            entity.Property(e => e.AccountIdCreate).HasComment("Student or Staff");
            entity.Property(e => e.AccountIdbehaveCreate).HasColumnName("AccountIDBehaveCreate");
            entity.Property(e => e.AccountIdupdate)
                .HasComment("Account update")
                .HasColumnName("AccountIDUpdate");
            entity.Property(e => e.ActualTime)
                .HasComment("thoi gian con lai")
                .HasColumnType("datetime");
            entity.Property(e => e.CategoryTicketId).HasColumnName("CategoryTicketID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.DurationTime)
                .HasComputedColumnSql("([ActualTime]-[CreateDate])", false)
                .HasComment("EstimateTime+CreateDate")
                .HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.EstimateTime).HasComment("thoi gian sinh vien ky vong");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.Kpitime)
                .HasColumnType("datetime")
                .HasColumnName("KPITime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(1)
                .HasDefaultValueSql("((1))");
            entity.Property(e => e.StatusTicketId).HasColumnName("StatusTicketID");
            entity.Property(e => e.Title).HasMaxLength(200);

            entity.HasOne(d => d.AccountIdCreateNavigation).WithMany(p => p.TblTicketAccountIdCreateNavigations)
                .HasForeignKey(d => d.AccountIdCreate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Tickets_tbl_Account");

            entity.HasOne(d => d.AccountIdbehaveCreateNavigation).WithMany(p => p.TblTicketAccountIdbehaveCreateNavigations)
                .HasForeignKey(d => d.AccountIdbehaveCreate)
                .HasConstraintName("FK_tbl_Tickets_tbl_Account1");

            entity.HasOne(d => d.AccountIdupdateNavigation).WithMany(p => p.TblTicketAccountIdupdateNavigations)
                .HasForeignKey(d => d.AccountIdupdate)
                .HasConstraintName("FK_tbl_Tickets_tbl_Account2");

            entity.HasOne(d => d.CategoryTicket).WithMany(p => p.TblTickets)
                .HasForeignKey(d => d.CategoryTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Tickets_tbl_CategoryTicket");

            entity.HasOne(d => d.StatusTicket).WithMany(p => p.TblTickets)
                .HasForeignKey(d => d.StatusTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_Tickets_tbl_StatusTickets");
        });

        modelBuilder.Entity<TblTicketAttachment>(entity =>
        {
            entity.HasKey(e => e.TicketAttachmentId);

            entity.ToTable("tbl_TicketAttachments");

            entity.Property(e => e.TicketAttachmentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketAttachmentID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.FileName).HasColumnType("ntext");
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketCommentId).HasColumnName("TicketCommentID");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");
            entity.Property(e => e.UrlPath).HasColumnType("ntext");

            entity.HasOne(d => d.TicketComment).WithMany(p => p.TblTicketAttachments)
                .HasForeignKey(d => d.TicketCommentId)
                .HasConstraintName("FK_tbl_TicketAttachments_tbl_TicketComments");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketAttachments)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketAttachments_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketComment>(entity =>
        {
            entity.HasKey(e => e.TicketCommentId).HasName("PK_ComplaintDetail");

            entity.ToTable("tbl_TicketComments");

            entity.Property(e => e.TicketCommentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketCommentID");
            entity.Property(e => e.AccountCreateId).HasColumnName("AccountCreateID");
            entity.Property(e => e.CategoryTicketId).HasColumnName("CategoryTicketID");
            entity.Property(e => e.Comment).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.IsDelete).HasDefaultValue(false);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");

            entity.HasOne(d => d.AccountCreate).WithMany(p => p.TblTicketComments)
                .HasForeignKey(d => d.AccountCreateId)
                .HasConstraintName("FK_tbl_TicketComments_tbl_Account");

            entity.HasOne(d => d.CategoryTicket).WithMany(p => p.TblTicketComments)
                .HasForeignKey(d => d.CategoryTicketId)
                .HasConstraintName("FK_tbl_TicketComments_tbl_CategoryTicket");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketComments)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketComments_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketDepartment>(entity =>
        {
            entity.HasKey(e => e.TicketDepartmentsId);

            entity.ToTable("tbl_TicketDepartments");

            entity.Property(e => e.TicketDepartmentsId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketDepartmentsID");
            entity.Property(e => e.AccountId).HasColumnName("AccountID");
            entity.Property(e => e.ActualTime).HasColumnType("datetime");
            entity.Property(e => e.CategoryTicketId).HasColumnName("CategoryTicketID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");
            entity.Property(e => e.Description).HasMaxLength(450);
            entity.Property(e => e.DurationTime).HasColumnType("datetime");
            entity.Property(e => e.EstimateTime).HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.IsDelete).HasDefaultValue(false);
            entity.Property(e => e.Kpitime)
                .HasColumnType("datetime")
                .HasColumnName("KPITime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Rate).HasMaxLength(1);
            entity.Property(e => e.Status).HasMaxLength(1);
            entity.Property(e => e.StatusTicketId).HasColumnName("StatusTicketID");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");
            entity.Property(e => e.Title).HasMaxLength(200);

            entity.HasOne(d => d.Account).WithMany(p => p.TblTicketDepartmentAccounts)
                .HasForeignKey(d => d.AccountId)
                .HasConstraintName("FK_tbl_TicketDepartments_tbl_Account");

            entity.HasOne(d => d.AccountIdCreateNavigation).WithMany(p => p.TblTicketDepartmentAccountIdCreateNavigations)
                .HasForeignKey(d => d.AccountIdCreate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartments_tbl_Account1");

            entity.HasOne(d => d.CategoryTicket).WithMany(p => p.TblTicketDepartments)
                .HasForeignKey(d => d.CategoryTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartments_tbl_CategoryTicket");

            entity.HasOne(d => d.Department).WithMany(p => p.TblTicketDepartments)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK_tbl_TicketDepartments_Tbl_Departments");

            entity.HasOne(d => d.StatusTicket).WithMany(p => p.TblTicketDepartments)
                .HasForeignKey(d => d.StatusTicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartments_tbl_StatusTickets");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketDepartments)
                .HasForeignKey(d => d.TicketId)
                .HasConstraintName("FK_tbl_TicketDepartments_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketDepartmentAttachment>(entity =>
        {
            entity.HasKey(e => e.TicketDepartmentAttachment);

            entity.ToTable("tbl_TicketDepartmentAttachment");

            entity.Property(e => e.TicketDepartmentAttachment).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.FileName).HasColumnType("ntext");
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketDepartmentCommentId).HasColumnName("TicketDepartmentCommentID");
            entity.Property(e => e.TicketDepartmentCommentsImportId).HasColumnName("TicketDepartmentCommentsImportID");
            entity.Property(e => e.TicketDepartmentsId).HasColumnName("TicketDepartmentsID");
            entity.Property(e => e.UrlPath).HasColumnType("ntext");

            entity.HasOne(d => d.TicketDepartmentComment).WithMany(p => p.TblTicketDepartmentAttachments)
                .HasForeignKey(d => d.TicketDepartmentCommentId)
                .HasConstraintName("FK_tbl_TicketDepartmentAttachment_tbl_TicketDepartmentComments");

            entity.HasOne(d => d.TicketDepartmentCommentsImport).WithMany(p => p.TblTicketDepartmentAttachments)
                .HasForeignKey(d => d.TicketDepartmentCommentsImportId)
                .HasConstraintName("FK_tbl_TicketDepartmentAttachment_tbl_TicketDepartmentCommentsImport");

            entity.HasOne(d => d.TicketDepartments).WithMany(p => p.TblTicketDepartmentAttachments)
                .HasForeignKey(d => d.TicketDepartmentsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartmentAttachment_tbl_TicketDepartments");
        });

        modelBuilder.Entity<TblTicketDepartmentComment>(entity =>
        {
            entity.HasKey(e => e.TicketDepartmentCommentId);

            entity.ToTable("tbl_TicketDepartmentComments");

            entity.Property(e => e.TicketDepartmentCommentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketDepartmentCommentID");
            entity.Property(e => e.AccountId).HasColumnName("AccountID");
            entity.Property(e => e.Comment).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Rate).HasMaxLength(1);
            entity.Property(e => e.TicketDepartmentsId).HasColumnName("TicketDepartmentsID");

            entity.HasOne(d => d.Account).WithMany(p => p.TblTicketDepartmentComments)
                .HasForeignKey(d => d.AccountId)
                .HasConstraintName("FK_tbl_TicketDepartmentComments_tbl_Account");

            entity.HasOne(d => d.TicketDepartments).WithMany(p => p.TblTicketDepartmentComments)
                .HasForeignKey(d => d.TicketDepartmentsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartmentComments_tbl_TicketDepartments");
        });

        modelBuilder.Entity<TblTicketDepartmentCommentsImport>(entity =>
        {
            entity.HasKey(e => e.TicketDepartmentCommentsImportId);

            entity.ToTable("tbl_TicketDepartmentCommentsImport");

            entity.Property(e => e.TicketDepartmentCommentsImportId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketDepartmentCommentsImportID");
            entity.Property(e => e.ColumView)
                .HasMaxLength(1)
                .HasDefaultValueSql("((1))");
            entity.Property(e => e.Comment).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.No).HasColumnName("no");
            entity.Property(e => e.Rate).HasMaxLength(1);
            entity.Property(e => e.TicketDepartmentsId).HasColumnName("TicketDepartmentsID");

            entity.HasOne(d => d.TicketDepartments).WithMany(p => p.TblTicketDepartmentCommentsImports)
                .HasForeignKey(d => d.TicketDepartmentsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketDepartmentCommentsImport_tbl_TicketDepartments");
        });

        modelBuilder.Entity<TblTicketFeedback>(entity =>
        {
            entity.HasKey(e => e.TicketFeedbackId);

            entity.ToTable("tbl_TicketFeedback");

            entity.Property(e => e.TicketFeedbackId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketFeedbackID");
            entity.Property(e => e.AccountIdStaff).HasComment("nhân viên đc đánh giá");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.Rate)
                .HasMaxLength(1)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.TicketFeedbackNegative).HasMaxLength(500);
            entity.Property(e => e.TicketFeedbackPositive).HasMaxLength(500);
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.AccountIdStaffNavigation).WithMany(p => p.TblTicketFeedbackAccountIdStaffNavigations)
                .HasForeignKey(d => d.AccountIdStaff)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketFeedback_tbl_Account");

            entity.HasOne(d => d.AccountIdUpdateNavigation).WithMany(p => p.TblTicketFeedbackAccountIdUpdateNavigations)
                .HasForeignKey(d => d.AccountIdUpdate)
                .HasConstraintName("FK_tbl_TicketFeedback_tbl_Account1");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketFeedbacks)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketFeedback_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketHandling>(entity =>
        {
            entity.HasKey(e => e.TicketHandlingId).HasName("PK_ComplaintHandling");

            entity.ToTable("tbl_TicketHandling");

            entity.Property(e => e.TicketHandlingId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketHandlingID");
            entity.Property(e => e.AccountManagerId).HasColumnName("AccountManagerID");
            entity.Property(e => e.Content).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EstimateTime).HasColumnType("datetime");
            entity.Property(e => e.ExecutionSequence).HasDefaultValue(0);
            entity.Property(e => e.IsAccpect).HasDefaultValue(false);
            entity.Property(e => e.Kpitime)
                .HasColumnType("datetime")
                .HasColumnName("KPITime");
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.TicketCommentId).HasColumnName("TicketCommentID");
            entity.Property(e => e.TicketHandlingParentId).HasColumnName("TicketHandlingParentID");
            entity.Property(e => e.TicketHandlingStatusId).HasColumnName("TicketHandlingStatusID");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.Role).WithMany(p => p.TblTicketHandlings)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK_tbl_TicketHandling_tbl_Role");

            entity.HasOne(d => d.TicketComment).WithMany(p => p.TblTicketHandlings)
                .HasForeignKey(d => d.TicketCommentId)
                .HasConstraintName("FK_tbl_TicketHandling_tbl_TicketComments");

            entity.HasOne(d => d.TicketHandlingParent).WithMany(p => p.InverseTicketHandlingParent)
                .HasForeignKey(d => d.TicketHandlingParentId)
                .HasConstraintName("FK_tbl_TicketHandling_tbl_TicketHandling");

            entity.HasOne(d => d.TicketHandlingStatus).WithMany(p => p.TblTicketHandlings)
                .HasForeignKey(d => d.TicketHandlingStatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketHandling_tblTicketHandlingStatus");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketHandlings)
                .HasForeignKey(d => d.TicketId)
                .HasConstraintName("FK_tbl_TicketHandling_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketHandlingStatus>(entity =>
        {
            entity.HasKey(e => e.TicketHandlingStatusId);

            entity.ToTable("tblTicketHandlingStatus");

            entity.Property(e => e.TicketHandlingStatusId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketHandlingStatusID");
            entity.Property(e => e.ColorStatus).HasMaxLength(50);
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifyUpdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TicketHandlingStatusName).HasMaxLength(200);
        });

        modelBuilder.Entity<TblTicketReport>(entity =>
        {
            entity.HasKey(e => e.TicketReportId);

            entity.ToTable("tbl_TicketReport");

            entity.Property(e => e.TicketReportId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketReportID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.ModifyUpdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TicketId).HasColumnName("TicketID");

            entity.HasOne(d => d.AccountIdStaffNavigation).WithMany(p => p.TblTicketReportAccountIdStaffNavigations)
                .HasForeignKey(d => d.AccountIdStaff)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketReport_tbl_Account");

            entity.HasOne(d => d.AccountIdUpdateNavigation).WithMany(p => p.TblTicketReportAccountIdUpdateNavigations)
                .HasForeignKey(d => d.AccountIdUpdate)
                .HasConstraintName("FK_tbl_TicketReport_tbl_Account1");

            entity.HasOne(d => d.Ticket).WithMany(p => p.TblTicketReports)
                .HasForeignKey(d => d.TicketId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketReport_tbl_Tickets");
        });

        modelBuilder.Entity<TblTicketReportAttachment>(entity =>
        {
            entity.HasKey(e => e.TicketReportAttachmentId);

            entity.ToTable("Tbl_TicketReportAttachments");

            entity.Property(e => e.TicketReportAttachmentId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketReportAttachmentID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.FileName).HasColumnType("ntext");
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.ModifyUpdate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TicketReportId).HasColumnName("TicketReportID");
            entity.Property(e => e.UrlPath).HasColumnType("ntext");

            entity.HasOne(d => d.TicketReport).WithMany(p => p.TblTicketReportAttachments)
                .HasForeignKey(d => d.TicketReportId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Tbl_TicketReportAttachments_tbl_TicketReport");
        });

        modelBuilder.Entity<TblTicketSuggestion>(entity =>
        {
            entity.HasKey(e => e.TicketSuggestionId).HasName("PK_ComplaintSuggestion");

            entity.ToTable("tbl_TicketSuggestion");

            entity.Property(e => e.TicketSuggestionId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketSuggestionID");
            entity.Property(e => e.AccountCreatorId).HasColumnName("AccountCreatorID");
            entity.Property(e => e.AccountUpdateId).HasColumnName("AccountUpdateID");
            entity.Property(e => e.CategoryTicketId).HasColumnName("CategoryTicketID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.RequestUpdateId).HasColumnName("RequestUpdateID");

            entity.HasOne(d => d.AccountCreator).WithMany(p => p.TblTicketSuggestionAccountCreators)
                .HasForeignKey(d => d.AccountCreatorId)
                .HasConstraintName("FK_tbl_TicketSuggestion_tbl_Account1");

            entity.HasOne(d => d.AccountUpdate).WithMany(p => p.TblTicketSuggestionAccountUpdates)
                .HasForeignKey(d => d.AccountUpdateId)
                .HasConstraintName("FK_tbl_TicketSuggestion_tbl_Account");

            entity.HasOne(d => d.CategoryTicket).WithMany(p => p.TblTicketSuggestions)
                .HasForeignKey(d => d.CategoryTicketId)
                .HasConstraintName("FK_tbl_TicketSuggestion_tbl_CategoryTicket");

            entity.HasOne(d => d.RequestUpdate).WithMany(p => p.InverseRequestUpdate)
                .HasForeignKey(d => d.RequestUpdateId)
                .HasConstraintName("FK_tbl_TicketSuggestion_tbl_TicketSuggestion");
        });

        modelBuilder.Entity<TblTicketSuggestionAttachment>(entity =>
        {
            entity.HasKey(e => e.TicketSuggestionAttachmentsId);

            entity.ToTable("Tbl_TicketSuggestionAttachments");

            entity.Property(e => e.TicketSuggestionAttachmentsId)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("TicketSuggestionAttachmentsID");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.FileName).HasColumnType("ntext");
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.TicketSuggestionId).HasColumnName("TicketSuggestionID");
            entity.Property(e => e.UrlPath).HasColumnType("ntext");

            entity.HasOne(d => d.TicketSuggestionDetail).WithMany(p => p.TblTicketSuggestionAttachments)
                .HasForeignKey(d => d.TicketSuggestionDetailId)
                .HasConstraintName("FK_Tbl_TicketSuggestionAttachments_tbl_TicketSuggestionDetail");

            entity.HasOne(d => d.TicketSuggestion).WithMany(p => p.TblTicketSuggestionAttachments)
                .HasForeignKey(d => d.TicketSuggestionId)
                .HasConstraintName("FK_Tbl_TicketSuggestionAttachments_tbl_TicketSuggestion");
        });

        modelBuilder.Entity<TblTicketSuggestionDetail>(entity =>
        {
            entity.HasKey(e => e.TicketSuggestionDetailId).HasName("PK_ComplaintSuggestionDetail");

            entity.ToTable("tbl_TicketSuggestionDetail");

            entity.Property(e => e.TicketSuggestionDetailId).HasDefaultValueSql("(newid())");
            entity.Property(e => e.ColumView)
                .HasMaxLength(1)
                .HasDefaultValueSql("((1))")
                .HasColumnName("columView");
            entity.Property(e => e.Comment).HasColumnType("ntext");
            entity.Property(e => e.CreateDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileId).HasMaxLength(200);
            entity.Property(e => e.ModifyUpdate).HasColumnType("datetime");
            entity.Property(e => e.No)
                .HasDefaultValue((byte)0)
                .HasColumnName("no");
            entity.Property(e => e.Rate).HasMaxLength(10);
            entity.Property(e => e.RequestUpdateId).HasColumnName("RequestUpdateID");
            entity.Property(e => e.TicketSuggestionId).HasColumnName("TicketSuggestionID");

            entity.HasOne(d => d.RequestUpdate).WithMany(p => p.InverseRequestUpdate)
                .HasForeignKey(d => d.RequestUpdateId)
                .HasConstraintName("FK_tbl_TicketSuggestionDetail_tbl_TicketSuggestionDetail");

            entity.HasOne(d => d.TicketSuggestion).WithMany(p => p.TblTicketSuggestionDetails)
                .HasForeignKey(d => d.TicketSuggestionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbl_TicketSuggestionDetail_tbl_TicketSuggestion");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
