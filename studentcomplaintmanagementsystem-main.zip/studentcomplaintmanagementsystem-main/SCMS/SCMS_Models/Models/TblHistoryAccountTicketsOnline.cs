﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblHistoryAccountTicketsOnline
{
    public Guid HistoryAccountTicketsOnlineId { get; set; }

    public Guid? TicketId { get; set; }

    public Guid? AccountId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public DateTime? EndDate { get; set; }

    public virtual TblAccount? Account { get; set; }

    public virtual TblTicket? Ticket { get; set; }
}
