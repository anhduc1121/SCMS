﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketReportAttachment
{
    public Guid TicketReportAttachmentId { get; set; }

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public Guid TicketReportId { get; set; }

    public string? FileType { get; set; }

    public string? FileName { get; set; }

    public string UrlPath { get; set; } = null!;

    public string? FileId { get; set; }

    public virtual TblTicketReport TicketReport { get; set; } = null!;
}
