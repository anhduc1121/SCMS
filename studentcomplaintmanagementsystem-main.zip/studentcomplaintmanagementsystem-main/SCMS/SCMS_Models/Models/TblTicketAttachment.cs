﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblTicketAttachment
{
    public Guid TicketAttachmentId { get; set; }

    public string? Description { get; set; }

    public string UrlPath { get; set; } = null!;

    public DateTime? ModifyUpdate { get; set; }

    public DateTime CreateDate { get; set; }

    public bool IsDelete { get; set; }

    public Guid TicketId { get; set; }

    public Guid? TicketCommentId { get; set; }

    public string? FileName { get; set; }

    public string? FileType { get; set; }

    public string? FileId { get; set; }

    public virtual TblTicket Ticket { get; set; } = null!;

    public virtual TblTicketComment? TicketComment { get; set; }
}
