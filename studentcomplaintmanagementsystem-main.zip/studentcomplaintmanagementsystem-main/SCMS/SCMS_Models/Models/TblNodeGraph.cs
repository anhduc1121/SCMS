﻿using System;
using System.Collections.Generic;

namespace SCMS_Models.Models;

public partial class TblNodeGraph
{
    public Guid? NodeGraphId { get; set; }
}
