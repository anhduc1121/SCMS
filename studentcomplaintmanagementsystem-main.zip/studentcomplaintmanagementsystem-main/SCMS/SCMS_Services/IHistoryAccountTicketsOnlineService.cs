﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IHistoryAccountTicketsOnlineService
    {
        public Task<ApiResponse> GetAll(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline);
        public Task<ApiResponse> Add(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline);
        public Task<ApiResponse> Remove(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline);
    }
}
