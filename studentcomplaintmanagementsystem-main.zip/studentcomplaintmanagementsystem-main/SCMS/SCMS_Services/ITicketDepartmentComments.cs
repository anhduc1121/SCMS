﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITicketDepartmentCommentsService
    {
        public Task<ApiResponse> ReplyTicket(TicketDepartmentCommentRequestReplyVM ticketDepartmentCommentRequest, bool v);
        public Task<ApiResponse> ReplyTickets(TicketDepartmentCommentReplyRequestVMs ticketDepartmentCommentRequest, bool v);
        public Task<ApiResponse> TicketDepartmentCommentsByTicketDepartmentID(Guid ticketDepartmentId, Guid userId, Guid? accountLogin);
    }
}
