﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ICategoryTicketService
    {
        public Task<ApiResponse> GetCategories();
        public Task<ApiResponse> GetParentCategory();
        public Task<ApiResponse> GetCategorysByIdParentCategory(Guid? IdParentCategory, Guid? categorySelected);
        public Task<ApiResponse> GetAllCategorysByIdParentCategory(Guid? IdParentCategory);
        public Task<ApiResponse> CreateCategoryTicket(CategoryTicketRequestVM categoryTicketVM);
        public Task<ApiResponse> UpdateCategoryTicket(CategoryTicketRequestVM categoryTicket);
        public Task<ApiResponse> DeteleCategoryTicket(Guid categoryTicketId);
        public Task<ApiResponse> GetCategoryById(Guid? categoryId);
    }
}
