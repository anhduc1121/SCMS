﻿using SCMS_Repository.Helpers;

namespace SCMS_Services
{
    public interface IReportService
    {
        public Task<ApiResponse> DailyReport(DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> DailyReport2(DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> RatingReport(DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> ReportForEachAccount(Guid userID, DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> ReportForEachAccount2(Guid userID, DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> ReportTicketReport(DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> SynthesisReport(DateTime fromDate, DateTime toDate);
        public Task<ApiResponse> SynthesisReport2(DateTime fromDate, DateTime toDate);
    }
}
