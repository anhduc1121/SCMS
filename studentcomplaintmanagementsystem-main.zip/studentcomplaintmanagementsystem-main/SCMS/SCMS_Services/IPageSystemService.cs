﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IPageSystemService
    {
        public Task<ApiResponse> GetAll(PageRequestVM pageRequestVM);
        public Task<ApiResponse> Add(PageRequestVM pageRequestVM);
        public Task<ApiResponse> Update(PageRequestVM pageRequestVM);
        public Task<ApiResponse> Delete(PageRequestVM pageRequestVM);
    }
}
