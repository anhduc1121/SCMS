﻿namespace SCMS_Services
{
    public class IPageService
    {
    }
}
