﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCMS_Repository.Helpers;

namespace SCMS_Services
{
    public interface IEducationService
    {
        public Task<ApiResponse> GetAll();
    }
}
