﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IPageCrudSystemService
    {
        public Task<ApiResponse> GetAllByPage(Guid pageId);
        public Task<ApiResponse> Add(PageCrudRequestVM pageCrudRequestVM);
        public Task<ApiResponse> Update(PageCrudRequestVM pageCrudRequestVM);
        public Task<ApiResponse> Delete(PageCrudRequestVM pageCrudRequestVM);
        public Task<ApiResponse> GetRoleByPageCrudId(Guid? id);
    }
}
