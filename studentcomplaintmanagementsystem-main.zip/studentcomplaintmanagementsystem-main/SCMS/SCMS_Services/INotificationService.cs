﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface INotificationService
    {
        public Task<ApiResponse> AddNotification(NotificationVM notification);
        public Task<ApiResponse> MarkAsRead(Guid notificationId);
        public Task<ApiResponse> MarkAllAsRead(Guid notificationId);
        public Task<ApiResponse> ViewNotification(Guid accountId, string? statusView, int pageIndex = 1,
            int pageSize = 5, int sortDate = 0, int sortTitle = 0);
    }
}
