﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITicketFeedbackService
    {
        public Task<ApiResponse> AddFeedback(TicketFeedbackRequestAddVM ticket);
        public Task<ApiResponse> GetAll(TicketFeedbackRequestGetDataVM ticket);
    }
}
