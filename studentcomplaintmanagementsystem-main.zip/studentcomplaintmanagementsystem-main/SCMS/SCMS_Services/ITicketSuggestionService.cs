﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITicketSuggestionService
    {
        public Task<ApiResponse> CreateTicketSuggestion(TicketSuggestionRequestVM ticketSuggestionRequestVM);
        public Task<ApiResponse> DeleteTicketSuggestion(Guid ticketSuggestionId);
        public Task<ApiResponse> GetAllById();
        public Task<ApiResponse> GetAllTicketSuggestion(string? question, Guid? cateId, DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortQuestion = 0, int sortDate = 0);
        public Task<ApiResponse> GetById(Guid? id);

        public Task<ApiResponse> UpdateTicketSuggestion(TicketSuggestionRequestVM ticketSuggestionVM);
        public Task<ApiResponse> GetAllTicketSuggestionForCreateTicket(Guid? cateId, string? title);
    }
}
