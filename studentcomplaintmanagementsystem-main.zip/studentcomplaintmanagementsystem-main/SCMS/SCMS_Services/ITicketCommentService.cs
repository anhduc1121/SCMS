﻿using SCMS_Repository.Helpers;

namespace SCMS_Services
{
    public interface ITicketCommentService
    {
        public Task<ApiResponse> TicketCommentsByTicketID(Guid ticketId, Guid userId, Guid? accountLogin);
    }
}
