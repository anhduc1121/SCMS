﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITagTicketService
    {
        public Task<ApiResponse> CheckUserTag(Guid ticketId, string gmail);
        public Task<ApiResponse> UpdateUserTag(Guid ticketId, string status);
        public Task<ApiResponse> ViewUserTag(Guid ticketId);
        public Task<ApiResponse> AddTag(TagTicketRequestVM tagTicketRequestVM);
    }
}
