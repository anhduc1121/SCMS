﻿using AutoMapper;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class CategoryTicketService : ICategoryTicketService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public class CategoryDto
        {
            public Guid Id { get; set; }
            public string Label { get; set; }
            public List<CategoryDto> Children { get; set; }
        }
        public class CategoryChildDto
        {
            public Guid Id { get; set; }
            public string Label { get; set; }
        }
        public CategoryTicketService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<ApiResponse> GetCategories()
        {
            List<TblCategoryTicket> categories = _unitOfWork.CategoryTicketRepository.GetAll().ToList();
            var categoriesVM = _mapper.Map<List<CategoryTicketVM>>(categories);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoriesVM,
            };
        }
        public async Task<ApiResponse> GetCategorysByIdParentCategory(Guid? IdParentCategory, Guid? categorySelected)
        {
            List<TblCategoryTicket> categories = new List<TblCategoryTicket>();
            List<CategoryTicketVM> categoryTicketVM = new List<CategoryTicketVM>();

            if (IdParentCategory != null)
            {
                categories = _unitOfWork.CategoryTicketRepository.GetCategorysByIdParentCategory(IdParentCategory);
                categoryTicketVM = _mapper.Map<List<CategoryTicketVM>>(categories);

                int countTblCategoryTicket = categories.Count();
                for (int i = 0; i < countTblCategoryTicket; i++)
                {
                    categoryTicketVM[i].Stt = (i + 1).ToString();
                    categoryTicketVM[i].IsHaveChild = categories[i].InverseCategoryTicketParent.Count > 0;
                };
            }
            else
            {
                categories = _unitOfWork.CategoryTicketRepository.GetParentCategory();
                categoryTicketVM = _mapper.Map<List<CategoryTicketVM>>(categories);

                int countTblCategoryTicket = categories.Count();
                for (int i = 0; i < countTblCategoryTicket; i++)
                {
                    categoryTicketVM[i].Stt = (i + 1).ToString();
                    categoryTicketVM[i].IsHaveChild = categories[i].InverseCategoryTicketParent.Count > 0;
                };
            }

            if (categorySelected != null)
            {
                TblCategoryTicket categoryTicket =
                 _unitOfWork.CategoryTicketRepository.GetCategorysByIdCategory(categorySelected);

                if (!String.IsNullOrEmpty(categoryTicket.FullPath))
                {
                    List<Guid> categoryIds = categoryTicket.FullPath.Trim().Split(' ').Select(Guid.Parse).ToList();
                    List<TblCategoryTicket> tblCategoryTicketsParent = _unitOfWork.CategoryTicketRepository.GetCategoryByPath(categoryIds);

                    categoryTicketVM = GetList(categoryTicketVM, tblCategoryTicketsParent).ToList();
                }
            }

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketVM
            };
        }

        private List<CategoryTicketVM> GetList(List<CategoryTicketVM> categoryTicketVM, List<TblCategoryTicket> categoryTickets)
        {
            if (categoryTickets.Count == 0)
            {
                return categoryTicketVM;
            }

            int index = categoryTicketVM.FindIndex(x => x.CategoryTicketId == categoryTickets[0].CategoryTicketId);
            if (index == -1)
            {
                return categoryTicketVM;
            }

            categoryTicketVM[index].IsShow = true;

            List<TblCategoryTicket> categoriesSub = new List<TblCategoryTicket>();
            List<CategoryTicketVM> categoryTicketSubVM = new List<CategoryTicketVM>();

            categoriesSub = _unitOfWork.CategoryTicketRepository.GetCategorysByIdParentCategory(categoryTickets[0].CategoryTicketId);
            categoryTicketSubVM = _mapper.Map<List<CategoryTicketVM>>(categoriesSub);

            if (categoryTicketSubVM.Count == 0)
            {
                return categoryTicketVM;
            }

            int countTblCategoryTicket = categoriesSub.Count();
            for (int i = 0; i < countTblCategoryTicket; i++)
            {
                categoryTicketSubVM[i].Stt = categoryTicketVM[index].Stt + "." + (i + 1).ToString();
                categoryTicketSubVM[i].IsHaveChild = categoriesSub[i].InverseCategoryTicketParent.Count > 0;
                categoryTicketSubVM[i].ParentIds = categoriesSub[i].FullPath.Trim().Split(' ').Select(Guid.Parse).ToList();
            };

            categoryTicketSubVM[categoryTicketSubVM.Count - 1].IsEnd = true;
            categoryTicketVM.InsertRange(index + 1, categoryTicketSubVM);
            categoryTickets.RemoveAt(0);
            return GetList(categoryTicketVM, categoryTickets);
        }


        public async Task<ApiResponse> GetAllCategorysByIdParentCategory(Guid? IdParentCategory)
        {
            List<TblCategoryTicket> categories = _unitOfWork.CategoryTicketRepository.GetAllCategorysByIdParentCategory(IdParentCategory);
            var categoryTicketVM = _mapper.Map<List<CategoryTicketVM>>(categories);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketVM
            };
        }

        public async Task<ApiResponse> GetParentCategory()
        {
            List<TblCategoryTicket> categories = _unitOfWork.CategoryTicketRepository.GetParentCategory();
            var categoryTicketVM = _mapper.Map<List<CategoryTicketVM>>(categories);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketVM
            };
        }

        public async Task<ApiResponse> CreateCategoryTicket(CategoryTicketRequestVM categoryTicketVM)
        {
            TblCategoryTicket categoryTicket = _mapper.Map<TblCategoryTicket>(categoryTicketVM);
            if (categoryTicket.CategoryTicketParentId != null)
            {
                var categoryTicketParent = _unitOfWork.CategoryTicketRepository.GetCategorysByIdCategory(categoryTicket.CategoryTicketParentId ?? new Guid());
                if (categoryTicketParent != null)
                {
                    categoryTicket.FullPath = categoryTicketParent.FullPath + " " + categoryTicket.CategoryTicketParentId;
                }
            }
            categoryTicket.ResponseHours = categoryTicket.ResponseTime / 60;
            var categoryTicketEntity = _unitOfWork.CategoryTicketRepository.CreateCategoryTicket(categoryTicket);
            var categoryTicketMapped = _mapper.Map<CategoryTicketVM>(categoryTicketEntity);

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketMapped
            };
        }
        public async Task<ApiResponse> UpdateCategoryTicket(CategoryTicketRequestVM category)
        {
            TblCategoryTicket categoryTicket = _mapper.Map<TblCategoryTicket>(category);
            var categoryTicketEntity = _unitOfWork.CategoryTicketRepository.UpdateCategoryTicket(categoryTicket);
            var categoryTicketMapped = _mapper.Map<CategoryTicketVM>(categoryTicketEntity);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketMapped
            };
        }
        public async Task<ApiResponse> DeteleCategoryTicket(Guid categoryTicketId)
        {
            TblCategoryTicket categoryTicket = _unitOfWork.CategoryTicketRepository.DeteleCategoryTicket(categoryTicketId);
            var categoryTicketVM = _mapper.Map<CategoryTicketVM>(categoryTicket);

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketVM
            };
        }

        public async Task<ApiResponse> GetCategoryById(Guid? categoryId)
        {
            TblCategoryTicket categoryTicket = _unitOfWork.CategoryTicketRepository.GetCategorysByIdCategory(categoryId);
            if (categoryTicket == null)
            {
                throw new Exception();
            }

            CategoryTicketReponseVM categoryTicketReponseVM = _mapper.Map<CategoryTicketReponseVM>(categoryTicket);
            categoryTicketReponseVM.CategoryName = _unitOfWork.CategoryTicketRepository.GetCategoryName(categoryTicketReponseVM.CategoryTicketId);

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = categoryTicketReponseVM,
            };
        }
    }
}
