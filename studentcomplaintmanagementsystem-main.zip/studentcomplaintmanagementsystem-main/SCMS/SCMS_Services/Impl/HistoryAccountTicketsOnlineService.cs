﻿using AutoMapper;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class HistoryAccountTicketsOnlineService : IHistoryAccountTicketsOnlineService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public HistoryAccountTicketsOnlineService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<ApiResponse> Add(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline)
        {
            //check
            TblHistoryAccountTicketsOnline tblHistoryAccountTicketsOnlineCheck = _unitOfWork.HistoryAccountTicketsOnline.GetByTicketIDUserId(historyAccountTicketsOnline.TicketId, historyAccountTicketsOnline.UserId);
            if (tblHistoryAccountTicketsOnlineCheck == null)
            {
                TblHistoryAccountTicketsOnline tblHistoryAccountTicketsOnline = new TblHistoryAccountTicketsOnline();
                tblHistoryAccountTicketsOnline.TicketId = historyAccountTicketsOnline.TicketId;
                tblHistoryAccountTicketsOnline.AccountId = historyAccountTicketsOnline.UserId;
                tblHistoryAccountTicketsOnline.CreateDate = DateTime.Now;

                _unitOfWork.HistoryAccountTicketsOnline.Create(tblHistoryAccountTicketsOnline);
            }
            else
            {
                tblHistoryAccountTicketsOnlineCheck.ModifyUpdate = DateTime.Now;
                tblHistoryAccountTicketsOnlineCheck.EndDate = null;
                _unitOfWork.HistoryAccountTicketsOnline.Update(tblHistoryAccountTicketsOnlineCheck);
            }


            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
            };
        }

        public async Task<ApiResponse> GetAll(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline)
        {
            List<TblHistoryAccountTicketsOnline> historyAccountTicketsOnlines = _unitOfWork.HistoryAccountTicketsOnline.GetAllByTicketID(historyAccountTicketsOnline.TicketId);

            List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = historyAccountTicketsOnlines.ToList().Select(x => new HistoryAccountTicketsOnlineResponseVM()
            {
                Emaill = x.Account.Email,
                Picture = x.Account.Picture,
                UserId = x.AccountId
            }).ToList();

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = historyAccountTicketsOnlineResponseVMs
            };
        }

        public async Task<ApiResponse> Remove(HistoryAccountTicketsOnlineRequestVM historyAccountTicketsOnline)
        {
            TblHistoryAccountTicketsOnline tblHistoryAccountTicketsOnline = _unitOfWork.HistoryAccountTicketsOnline.GetByTicketIDUserId(historyAccountTicketsOnline.TicketId, historyAccountTicketsOnline.UserId);
            if (tblHistoryAccountTicketsOnline != null)
            {
                tblHistoryAccountTicketsOnline.EndDate = DateTime.Now;
                _unitOfWork.HistoryAccountTicketsOnline.Update(tblHistoryAccountTicketsOnline);
            }

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString()
            };
        }
    }
}
