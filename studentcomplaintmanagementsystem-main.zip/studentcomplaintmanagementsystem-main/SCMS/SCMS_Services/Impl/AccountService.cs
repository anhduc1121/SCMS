﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using SCMS_Repository.Ultils;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class AccountService : IAccountService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _config;
        private readonly AppSettings _appSettings;
        private readonly IMapper _mapper;

        public AccountService(IOptionsMonitor<AppSettings> optionsMonitor, IConfiguration config, IMapper mapper = null, IUnitOfWork unitOfWork = null)
        {
            _unitOfWork = unitOfWork ?? new UnitOfWork();
            _appSettings = optionsMonitor.CurrentValue;
            _config = config;
            _mapper = mapper;
        }

        public async Task<ApiResponse> GetUserByID(Guid id)
        {
            TblAccount tblAccount = _unitOfWork.AccountRepository.GetAccountById(id);
            var accountVM = _mapper.Map<AccountProfileVM>(tblAccount);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = accountVM
            };
        }

        public async Task<ApiResponse> ListEmployee(string searchEmail, int sortDate, int pageIndex, int pageSize)
        {
            List<ExEmployee> exEmployees = _unitOfWork.AccountRepository.GetEmployees(searchEmail, sortDate, pageIndex, pageSize).Item2;
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = exEmployees
            };
        }

        public async Task<ApiResponse> GetAllStatusAccount()
        {
            List<ExStatusAccount> statusAccounts = _unitOfWork.AccountRepository.GetAllStatusAccount();
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = statusAccounts
            };
        }

        public async Task<ApiResponse> UpdateEmployee(ExEmployeeRespon employee_update)
        {
            TblAccount account = _mapper.Map<TblAccount>(employee_update.ExEmployee);
            List<TblRole> responRoles = _mapper.Map<List<TblRole>>(employee_update.Roles);
            bool updateSuccess = _unitOfWork.AccountRepository.UpdateEmployee(employee_update.ExEmployee, responRoles);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = updateSuccess
            };
        }

        public async Task<ApiResponse> AddEmployee(ExEmployeeRespon employee_update)
        {
            TblAccount account = _mapper.Map<TblAccount>(employee_update.ExEmployee);
            List<TblRole> responRoles = _mapper.Map<List<TblRole>>(employee_update.Roles);
            bool addSuccess = _unitOfWork.AccountRepository.AddEmployee(employee_update.ExEmployee, responRoles);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = addSuccess
            };
        }

        public async Task<ApiResponse> ListEmployeeSize(string searchEmail, int sortDate, int pageIndex, int pageSize)
        {
            int count = _unitOfWork.AccountRepository.GetEmployees(searchEmail, sortDate, pageIndex, pageSize).Item1;
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = count
            };
        }

        public async Task<ApiResponse> ListStaff(Guid? roleId)
        {
            List<TblAccount> accounts = _unitOfWork.AccountRepository.GetStaff(roleId);
            var accountVM = _mapper.Map<List<AccountVM>>(accounts);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = accountVM
            };
        }

        public async Task<ApiResponse> login(RequestLogin requestLogin)
        {
            Jwt jwt = new Jwt(_appSettings, _config);
            TokenModel token = null;
            TblAccount account = _unitOfWork.AccountRepository.GetAccountByEmaill(requestLogin.Email);

            TblHistoryLogin tblHistoryLogin = new TblHistoryLogin();
            tblHistoryLogin.Token = requestLogin.Token;

            if (account != null // co tai khoan
                &&
                ((requestLogin.IsGoogle == true && account.IsGoogle && (account.CampusId != requestLogin.CampusId || account.EducationId != requestLogin.EducationId)) ||
                account.StatusAccountId == Guid.Parse("21842BCB-FAE8-4C00-9C33-DE997D4E8103")) // Block
                )
            {
                throw new Exception();
            }

            if (account == null)
            {
                account = new TblAccount();
                account.Email = requestLogin.Email;
                account.EducationId = requestLogin.EducationId;
                account.CampusId = requestLogin.CampusId;
                if (!requestLogin.IsFEID)
                {
                    account.FirstName = requestLogin.FirstName;
                    account.LastName = requestLogin.LastName;
                    account.Picture = requestLogin.Picture;
                    account.IsGoogle = requestLogin.IsGoogle;
                }
                account.StatusAccountId = Guid.Parse("32702791-81CE-492C-A89E-F642729AABD4"); // Active
                account.Address = requestLogin.Address;
                account.RoleNameFeid = requestLogin.RoleFeid;
                account.UserFeidId = requestLogin.UserFeid;
                account.CampusFeidId = requestLogin.CampusFeidId;
                account.IsFeid = requestLogin.IsFEID;
                account.DepartmentId = Guid.Parse("EF16F7D5-9DB3-481E-9BAF-28C67E7A890F"); // sinh viên

                if (account.IsFeid)
                {
                    TblRoleFeid roleFeid = _unitOfWork.RoleFeidRepository.GetRoleByName(account.RoleNameFeid);
                    if (roleFeid != null)
                    {
                        List<TblRole> tblRoles = _unitOfWork.RoleRepository.GetRoleByRoleFeid(roleFeid.RoleFeidId);
                        foreach (TblRole tblRole in tblRoles)
                        {
                            TblAccountRole tblAccountRole = new TblAccountRole();
                            tblAccountRole.RoleId = tblRole.RoleId;
                            account.TblAccountRoles.Add(tblAccountRole);
                        }
                    }
                    else
                    {
                        roleFeid = new TblRoleFeid();
                        roleFeid.RoleFeidName = account.RoleNameFeid;
                        _unitOfWork.RoleFeidRepository.Create(roleFeid);
                    }
                }

                if (account.TblAccountRoles.Count == 0)
                {
                    TblSystemSetting tblSystemSetting = _unitOfWork.SystemSettingRepository.GetSystemById(Guid.Parse("241FF6D9-A183-4F27-8AB3-16A2826090EC")); // get role defaut
                    if (tblSystemSetting != null)
                    {
                        TblAccountRole tblAccountRole = new TblAccountRole();
                        tblAccountRole.RoleId = tblSystemSetting.RoleId ?? new Guid();
                        account.TblAccountRoles.Add(tblAccountRole);
                    }
                }

                _unitOfWork.AccountRepository.Create(account);

                //Cấp token
                token = jwt.GenerateToken(account);
            }
            else
            {
                if ((bool)account.IsDelete)
                {
                    return new ApiResponse
                    {
                        Message = MessageE.BLOCK_USER.ToString(),
                    };
                }
                else
                {
                    //Cấp token
                    token = jwt.GenerateToken(account);
                }
            }

            tblHistoryLogin.IsFeid = account.IsFeid;
            tblHistoryLogin.IsGoogle = account.IsGoogle;
            tblHistoryLogin.AccountId = account.AccountId;

            _unitOfWork.HistoryLoginRepository.Create(tblHistoryLogin);

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = token,
            };
        }

        public async Task<ApiResponse> SearchUserByName(string name)
        {
            List<TblAccount> accounts = _unitOfWork.AccountRepository.GetAccountByName(name);
            var accountVM = _mapper.Map<List<AccountVM>>(accounts);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = accountVM
            };
        }

        public async Task<ApiResponse> GetViewAuthority(Guid pageCrudId, Guid accountId)
        {
            TblAccount account = _unitOfWork.AccountRepository.GetViewAuthority(pageCrudId, accountId);

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = account != null
            };
        }

        public async Task<ApiResponse> GetPageAuthority(string name, Guid userId)
        {
            TblAccount account = _unitOfWork.AccountRepository.GetPageAuthority(name, userId);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = account != null
            };
        }

        public async Task<ApiResponse> GetRolesByAccount(Guid? userId)
        {
            List<TblRole> role = _unitOfWork.RoleRepository.GetRoles();
            TblAccount account = _unitOfWork.AccountRepository.GetAccountById(userId);

            var res = role.Select(x => new
            {
                id = x.RoleId,
                name = x.RoleName,
                isSelected = account.TblAccountRoles.Any(z => z.RoleId == x.RoleId)
            });

            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = res
            };
        }

        public async Task<ApiResponse> DeleteAccountByAccountId(Guid accountId)
        {

            bool deleted = _unitOfWork.AccountRepository.DeleteAccountByAccountId(accountId);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = deleted
            };
        }

        public async Task<ApiResponse> GetEmailByRole(Guid userID, string? gmail)
        {
            var email = _unitOfWork.AccountRepository.GetEmailByRole(userID, gmail).Select(x => new
            {
                Email = x.Email,
            }).ToList();
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = email
            };
        }

        public async Task<ApiResponse> GetInforUser(Guid userId)
        {
            var inforUser = _unitOfWork.AccountRepository.GetInforUser(userId);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = inforUser
            };
        }
    }
}

