﻿using AutoMapper;
using Microsoft.Extensions.Options;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using SCMS_Repository.Ultils;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly UpdateFileDriver updateFileDriver;
        private readonly AppSettings _appSettings;

        public DepartmentService(IOptionsMonitor<AppSettings> optionsMonitor, IUnitOfWork unitOfWork = null, IMapper mapper = null)
        {
            _appSettings = optionsMonitor.CurrentValue;
            _unitOfWork = unitOfWork ?? new UnitOfWork();
            _mapper = mapper;
            updateFileDriver = new UpdateFileDriver(_appSettings);
        }

        public async Task<ApiResponse> CreateDepartment(DepartmentVM departmentVM)
        {
            var departments = _unitOfWork.DepartmentRepository.CreateDepartment(departmentVM);
            var departmentVMs = _mapper.Map<DepartmentVM>(departments);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = departmentVMs
            };
        }

        public async Task<ApiResponse> DeleteDepartment(Guid departmentId)
        {
            var departments = _unitOfWork.DepartmentRepository.DeleteDepartment(departmentId);
            var departmentVM = _mapper.Map<DepartmentVM>(departments);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = departmentVM
            };
        }

        public async Task<ApiResponse> UpdateDepartment(DepartmentVM departmentVM)
        {
            var departments = _unitOfWork.DepartmentRepository.UpdateDepartment(departmentVM);
            var departmentVMs = _mapper.Map<DepartmentVM>(departments);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = departmentVMs
            };
        }

        public async Task<ApiResponse> GetListDepartment()
        {
            var departments = _unitOfWork.DepartmentRepository.GetAllDepartment();
            var departmentVM = _mapper.Map<List<DepartmentVM>>(departments);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = departmentVM
            };
        }
    }
}
