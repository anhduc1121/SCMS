﻿using AutoMapper;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class NotificationService : INotificationService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public NotificationService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<ApiResponse> AddNotification(NotificationVM notification)
        {
            var notifications = _unitOfWork.NotificationRepository.AddNotification(notification);
            var notificationVM = _mapper.Map<NotificationVM>(notifications);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = notificationVM
            };
        }

        public async Task<ApiResponse> MarkAsRead(Guid notificationId)
        {
            var notification = _unitOfWork.NotificationRepository.MarkAsRead(notificationId);
            var notificationVM = _mapper.Map<NotificationVM>(notification);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = notificationVM
            };
        }

        public async Task<ApiResponse> MarkAllAsRead(Guid accountId)
        {
            var notification = _unitOfWork.NotificationRepository.MarkAllAsRead(accountId);
            var notificationVM = _mapper.Map<List<NotificationVM>>(notification);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = notificationVM
            };
        }

        public async Task<ApiResponse> ViewNotification(Guid accountId, string? statusView, int pageIndex = 1,
            int pageSize = 5, int sortDate = 0, int sortTitle = 0)
        {

            (int count, List<TblNotification> notifications) = _unitOfWork.NotificationRepository
                .ViewNotification(accountId, statusView, pageIndex, pageSize, sortDate, sortTitle);

            var notificationVM = _mapper.Map<List<NotificationVM>>(notifications);


            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = notificationVM,
                NumberOfRecords = count
            };
        }
    }
}
