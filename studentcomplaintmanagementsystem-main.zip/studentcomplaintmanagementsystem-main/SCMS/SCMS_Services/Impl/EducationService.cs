﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_Services.Impl
{
    public class EducationService : IEducationService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public EducationService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<ApiResponse> GetAll()
        {
            List<TblEducation> tblEducations = (List < TblEducation >) _unitOfWork.EducationRepository.GetAll();

            var educationResponses = _mapper.Map<List<EducationResponse>>(tblEducations);
            return new ApiResponse
            {
                Message = MessageE.SUCCESS.ToString(),
                Data = educationResponses
            };
        }
    }
}
