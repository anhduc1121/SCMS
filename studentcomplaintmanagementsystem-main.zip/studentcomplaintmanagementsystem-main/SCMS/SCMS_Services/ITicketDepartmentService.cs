﻿
using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITicketDepartmentService
    {
        public Task<ApiResponse> CreateNew(TicketDepartmentRequestAddVM ticketDepartmentRequestAdd);
        public Task<ApiResponse> GetTicketDepartmentByTicketId(Guid ticketDepartmentId, Guid? userId);
        public Task<ApiResponse> ViewStaffWithStaffOther(TicketDepartmentRequestGetsVM ticketDepartment, bool isStaff);
        public Task<ApiResponse> UpdateTicketDepartmentByTicketId(Guid TicketDepartmentId, Guid StatusTicketId);

    }
}
