﻿using SCMS_Repository.Helpers;

namespace SCMS_Services
{
    public interface ITicketHandlingService
    {
        public Task<ApiResponse> ViewNode(Guid ticketId);
    }
}
