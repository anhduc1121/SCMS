﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IDepartmentService
    {
        public Task<ApiResponse> DeleteDepartment(Guid departmentId);
        public Task<ApiResponse> GetListDepartment();
        public Task<ApiResponse> CreateDepartment(DepartmentVM departmentVM);

        public Task<ApiResponse> UpdateDepartment(DepartmentVM departmentVM);
    }
}
