﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface ITicketService
    {
        public Task<ApiResponse> ReplyTicket(TicketCommentReplyVM ticket, Guid userID, bool isStaff);
        public Task<ApiResponse> ReplyTickets(TicketCommentReplyRequestVMs ticketCommentReplyRequestVMs, Guid userID, bool isStaff);
        public Task<ApiResponse> EndTicket(Guid ticketId, string positive, string negative, string rate);
        public Task<ApiResponse> GetTicketByTicketId(Guid ticketId, Guid? userId);

        /// <summary>
        /// for staff
        /// </summary>
        /// <param name="ticketId"></param>
        /// <param name="categoryTicketId"></param>
        /// <returns></returns>
        public Task<ApiResponse> UpdateCategorysOfTicketId(Guid ticketId, Guid categoryTicketId);
        public Task<ApiResponse> CreatePinTicket(Guid ticketId, Guid accountId);
        public Task<ApiResponse> DeletePinTicket(Guid pinTicketId, Guid userID);
        public Task<ApiResponse> CreateNewTicket(TicketCreateVM ticketCreateVM);
        public Task<ApiResponse> GetAllTicket(Guid userID, Guid? cateId, Guid? statusTicketId,
             Guid? accountIdCreate, Guid? accountIDBehaveCreate, Guid? tagAccountId,
              string? accountGmaillCreate, string? accountGmaillBehaveCreate, string? accountGmaillTag, string? status, string? title,
            DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortDate = 0, int sortTitle = 1, int sortStatusTicket = 0, bool isPin = false);
        public Task<ApiResponse> ViewStatusTicket();
        public Task<ApiResponse> GetTicketByAccountId(string? status, string? title, Guid? cateId, DateTime? createDate, Guid accountId, int pageIndex = 1, int pageSize = 5, int sortDate = 0);
        public Task<ApiResponse> GetListUserByTicket(Guid ticketId);
        public Task<ApiResponse> AddReportTicket(TicketReportRequestVM ticketReportsVM);
        public Task<ApiResponse> ViewReport(Guid? categoryId, string? titleTicket, Guid? studentId, string? status, DateTime? createDate, int sortDate, int sortTitle, int pageIndex, int pageSize);
    }
}
