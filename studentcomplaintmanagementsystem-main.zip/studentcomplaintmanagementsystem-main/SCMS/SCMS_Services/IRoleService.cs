﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IRoleService
    {
        Task<bool> CheckAuthorization(Guid userId, string controller, string action);
        public Task<ApiResponse> GetListRole(RoleRequestVM roleRequestVM);
        public Task<ApiResponse> GetListFunctionAPIByRole(Guid roleId);
        public Task<ApiResponse> CreateRole(RoleRequestVM role);
        public Task<ApiResponse> UpdateRole(RoleRequestVM role);
        public Task<ApiResponse> DeleteRole(RoleRequestVM role);
        public Task<ApiResponse> GetRolesByAccountId(Guid accountId);
    }
}
