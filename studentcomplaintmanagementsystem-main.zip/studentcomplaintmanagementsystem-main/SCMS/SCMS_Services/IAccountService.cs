﻿using SCMS_Repository.Helpers;
using ViewModel;

namespace SCMS_Services
{
    public interface IAccountService
    {
        public Task<ApiResponse> login(RequestLogin emailLogin);
        public Task<ApiResponse> SearchUserByName(string name);
        public Task<ApiResponse> ListStaff(Guid? roleId);
        public Task<ApiResponse> GetUserByID(Guid id);
        public Task<ApiResponse> ListEmployee(string searchEmail, int sortDate, int pageIndex, int pageSize);
        public Task<ApiResponse> ListEmployeeSize(string searchEmail, int sortDate, int pageIndex, int pageSize);
        public Task<ApiResponse> UpdateEmployee(ExEmployeeRespon employee_update);
        public Task<ApiResponse> GetAllStatusAccount();
        public Task<ApiResponse> GetViewAuthority(Guid pageCrudId, Guid accountId);
        public Task<ApiResponse> GetPageAuthority(string name, Guid userId);
        public Task<ApiResponse> GetRolesByAccount(Guid? userId);
        public Task<ApiResponse> DeleteAccountByAccountId(Guid accountId);
        public Task<ApiResponse> AddEmployee(ExEmployeeRespon employee_update);
        public Task<ApiResponse> GetEmailByRole(Guid userID, string? gmail);
        public Task<ApiResponse> GetInforUser(Guid userId);
    }
}
