﻿using SCMS_Repository.Helpers;

namespace SCMS_Services
{
    public interface ICampusService
    {
        public Task<ApiResponse> GetListCampus();
    }
}
