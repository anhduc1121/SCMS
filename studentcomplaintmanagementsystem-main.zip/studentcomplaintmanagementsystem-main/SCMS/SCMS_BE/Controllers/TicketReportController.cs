﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketReportController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ITicketService _ticketService;

        public TicketReportController(IMapper mapper, ITicketService ticketService)
        {
            _mapper = mapper;
            _ticketService = ticketService;
        }

        [HttpPost("GetListUserByTicket")]
        public async Task<IActionResult> GetListUserByTicket(Guid ticketId)
        {
            try
            {
                var apiResponse = await _ticketService.GetListUserByTicket(ticketId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("AddReportTicket")]
        public async Task<IActionResult> AddReportTicket([FromForm] TicketReportRequestVM ticketReportVM)
        {
            try
            {
                var apiResponse = await _ticketService.AddReportTicket(ticketReportVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("ViewReport")]
        public async Task<IActionResult> ViewReport(Guid? categoryId, string? titleTicket, Guid? studentId, string? status,
                                            DateTime? createDate, int sortDate = 0, int sortTitle = 0,
                                            int pageIndex = 1, int pageSize = 5)
        {
            try
            {
                var apiResponse = await _ticketService.ViewReport(categoryId, titleTicket, studentId, status, createDate, sortDate, sortTitle, pageIndex, pageSize);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage
                {
                    Message = MessageE.ERROR.ToString()
                });
            }
        }
    }
}
