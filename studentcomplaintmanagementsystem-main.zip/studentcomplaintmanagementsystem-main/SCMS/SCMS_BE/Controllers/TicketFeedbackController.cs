﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.AuthorService;
using SCMS_BE.HubConnext;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketFeedbackController : ControllerBase
    {
        private readonly ITicketFeedbackService _ticketFeedbackService;
        private readonly IHistoryAccountTicketsOnlineService _historyAccountTicketsOnlineService;
        private IHubContext<ChatHub> _hubContext;

        public TicketFeedbackController(ITicketFeedbackService ticketFeedbackService, IHubContext<ChatHub> hubContext, IHistoryAccountTicketsOnlineService historyAccountTicketsOnlineService)
        {
            _ticketFeedbackService = ticketFeedbackService;
            _historyAccountTicketsOnlineService = historyAccountTicketsOnlineService;
            _hubContext = hubContext;
        }
        [HttpPost("AddFeedback")]
        public async Task<IActionResult> AddFeedback([FromForm] TicketFeedbackRequestAddVM ticket)
        {
            try
            {
                ticket.AccountCreatedId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                #region Hàm xử lý save
                // Add cho người nhận TagTicket có IsAccpect là '1'
                // Add ko cần trả về data chỉ cần trả về message = 'SUCCESS' 
                #endregion
                var apiResponse = await _ticketFeedbackService.AddFeedback(ticket);

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = ticket.TicketId });
                    if (list.Data != null)
                    {
                        List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                        if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                        {
                            await _hubContext.Clients.Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray()).SendAsync("complaint/details/__chat" + ticket.TicketId.ToString().ToLower(), "Hello, selected users!");
                        }
                    }
                }
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }



        [HttpPost("GetAll")]
        public async Task<IActionResult> GetAll([FromForm] TicketFeedbackRequestGetDataVM ticket)
        {
            try
            {
                #region Hàm xử lý lấy danh sách feedback
                // Tham khảo cách viết hàm _ticketService.GetAllTicket trả về số lượng bản ghi tổng và danh sách data
                //Data trả về: TicketFeedbackResponseGetDataVM
                TicketFeedbackResponseGetDataVM ticketFeedbackResponseGetDataVM = new TicketFeedbackResponseGetDataVM();
                #endregion

                var apiResponse = await _ticketFeedbackService.GetAll(ticket);
                return Ok();
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}