﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.HubConnext;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private IHubContext<ChatHub> _hubContext;

        public TestController(IHubContext<ChatHub> hubContext)
        {
            _hubContext = hubContext;
        }

        //[DynamicAuthorize]
        //[HttpGet("TestA")]
        //public async Task<IActionResult> TestB(string page)
        //{
        //    try
        //    {
        //        return Ok("apiResponse");
        //    }
        //    catch
        //    {
        //        return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
        //    }
        //}
        [HttpGet("TestA")]
        public async Task<IActionResult> TestA(string mess, string user, string method)
        {
            await _hubContext.Clients
                .User(user.ToLower()).SendAsync(method, mess);
            return Ok("apiResponse");
            //         var userIds = new[] { "user1", "user2", "user3" };
            //       await _hubContext.Clients.Users(userIds).SendAsync("ReceiveMessage", "Hello, selected users!");
        }

        [HttpGet("TestB")]
        public async Task<IActionResult> TestB(string page)
        {
            await _hubContext.Clients
                .All
                .SendAsync("a", page);
            return Ok("apiResponse");
        }
    }
}
