﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketCommentController : Controller
    {
        private readonly ITicketCommentService _ticketCommentService;
        private readonly IMapper _mapper;

        public TicketCommentController(ITicketCommentService ticketCommentService, IMapper mapper)
        {
            _ticketCommentService = ticketCommentService;
            _mapper = mapper;
        }

        [HttpPost("ViewTicketCommentsChatStudent")]
        public async Task<IActionResult> ViewTicketCommentsChat(Guid tichketId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketCommentService.TicketCommentsByTicketID(tichketId, userId, userId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("ViewTicketCommentsChatStaff")]
        public async Task<IActionResult> ViewTicketCommentsChatStaff(Guid tichketId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketCommentService.TicketCommentsByTicketID(tichketId, userId, null);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
