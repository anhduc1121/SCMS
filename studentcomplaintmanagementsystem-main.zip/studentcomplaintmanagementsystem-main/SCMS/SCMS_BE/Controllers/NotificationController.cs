﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class NotificationController : Controller
    {
        private readonly INotificationService _notificationService;
        private readonly IMapper _mapper;

        public NotificationController(INotificationService notificationService, IMapper mapper)
        {
            _notificationService = notificationService;
            _mapper = mapper;
        }

        [HttpPost("ViewNotification")]
        public async Task<IActionResult> ViewNotification([FromForm] NotificationRequestVM notificationRequestVM)
        {
            try
            {
                Guid accountId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _notificationService.ViewNotification(accountId,
                    notificationRequestVM.statusView, notificationRequestVM.pageIndex, notificationRequestVM.pageSize,
                    notificationRequestVM.sortDate, notificationRequestVM.sortTitle);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("AddNotification")]
        public async Task<IActionResult> AddNotification([FromForm] NotificationVM notification)
        {
            try
            {
                var apiResponse = await _notificationService.AddNotification(notification);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }


        [HttpPut("MarkAllAsRead")]
        public async Task<IActionResult> MarkAllAsRead()
        {
            try
            {
                Guid accountId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _notificationService.MarkAllAsRead(accountId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("MarkAsRead")]
        public async Task<IActionResult> markAsRead(Guid notificationId)
        {
            try
            {
                var apiResponse = await _notificationService.MarkAsRead(notificationId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
