﻿using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[DynamicAuthorize]
    public class RoleController : Controller
    {
        private readonly IRoleService _roleService;

        public RoleController(IRoleService roleService)
        {
            _roleService = roleService;
        }

        [HttpPost("GetListRole")]
        public async Task<IActionResult> GetListRole([FromForm] RoleRequestVM roleRequestVM)
        {
            try
            {
                var apiResponse = await _roleService.GetListRole(roleRequestVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetRolesByAccountId")]
        public async Task<IActionResult> GetRolesByAccountId(string? accountId)
        {
            try
            {
                Guid accId = Guid.Parse(accountId);
                var apiResponse = await _roleService.GetRolesByAccountId(accId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetListFunctionAPIByRole")]
        public async Task<IActionResult> GetListFunctionAPIByRole(Guid roleId)
        {
            try
            {
                var apiResponse = await _roleService.GetListFunctionAPIByRole(roleId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("CreateRole")]
        public async Task<IActionResult> CreateRole([FromForm] RoleRequestVM role)
        {
            try
            {
                if (role != null && !String.IsNullOrEmpty(role.RoleName))
                {
                    var apiResponse = await _roleService.CreateRole(role);
                    return Ok(apiResponse);
                }
                else
                {
                    throw new Exception("Name is not blank");
                }
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("UpdateRole")]
        public async Task<IActionResult> UpdateRole([FromForm] RoleRequestVM role)
        {
            try
            {
                if (role != null && !String.IsNullOrEmpty(role.RoleName))
                {
                    var apiResponse = await _roleService.UpdateRole(role);
                    return Ok(apiResponse);
                }
                else
                {
                    throw new Exception("Name is not blank");
                }
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("DeleteRole")]
        public async Task<IActionResult> DeleteRole([FromForm] RoleRequestVM role)
        {
            try
            {
                var apiResponse = await _roleService.DeleteRole(role);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
