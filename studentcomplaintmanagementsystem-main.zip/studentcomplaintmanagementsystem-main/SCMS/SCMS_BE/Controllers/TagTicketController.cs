﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TagTicketController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ITagTicketService _tagTicketService;

        public TagTicketController(IMapper mapper, ITagTicketService tagTicketService)
        {
            _mapper = mapper;
            _tagTicketService = tagTicketService;
        }

        [HttpPost("ViewUserTag")]
        public async Task<IActionResult> ViewUserTag(Guid ticketId)
        {
            try
            {
                var apiResponse = await _tagTicketService.ViewUserTag(ticketId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("UpdateUserTag")]
        public async Task<IActionResult> UpdateUserTag(Guid tagTicketId, string status)
        {
            try
            {
                var apiResponse = await _tagTicketService.UpdateUserTag(tagTicketId, status);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        //[HttpPost("CheckUserTag")]
        //public async Task<IActionResult> checkUserTag(Guid tagTicketId, string gmail)
        //{
        //    try
        //    {
        //        var apiResponse = await _tagTicketService.CheckUserTag(tagTicketId, gmail);
        //        return Ok(apiResponse);
        //    }
        //    catch
        //    {
        //        return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
        //    }
        //}

        [HttpPost("CheckUserTag")]
        public async Task<IActionResult> CheckUserTag(Guid ticketId, string gmail)
        {
            try
            {
                var apiResponse = await _tagTicketService.CheckUserTag(ticketId, gmail);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
            //}
        }

        [HttpPost("AddTag")]
        [Authorize]
        public async Task<IActionResult> AddTag([FromForm] TagTicketRequestVM tagTicketRequestVM)
        {
            try
            {
                tagTicketRequestVM.AccountCreateId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _tagTicketService.AddTag(tagTicketRequestVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
            //}
        }
    }
}
