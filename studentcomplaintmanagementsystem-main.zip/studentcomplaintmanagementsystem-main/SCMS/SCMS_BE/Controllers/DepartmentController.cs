﻿using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class DepartmentController : Controller
    {
        private readonly IDepartmentService _departmentService;

        public DepartmentController(IDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }

        [HttpPost("GetListDepartment")]
        public async Task<IActionResult> GetListDepartment()
        {
            try
            {
                var apiResponse = await _departmentService.GetListDepartment();
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("CreateDepartment")]
        public async Task<IActionResult> CreateDepartment([FromForm] DepartmentVM departmentVM)
        {
            try
            {
                departmentVM.AccountCreateId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _departmentService.CreateDepartment(departmentVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("UpdateDepartment")]
        public async Task<IActionResult> UpdateDepartment([FromForm] DepartmentVM departmentVM)
        {
            try
            {
                departmentVM.AccountUpdateId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _departmentService.UpdateDepartment(departmentVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("DeleteDepartment")]
        public async Task<IActionResult> DeleteDepartment(Guid departmentId)
        {
            try
            {
                var apiResponse = await _departmentService.DeleteDepartment(departmentId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
