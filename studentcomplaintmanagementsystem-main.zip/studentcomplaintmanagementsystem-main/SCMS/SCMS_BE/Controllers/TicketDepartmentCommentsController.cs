﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.AuthorService;
using SCMS_BE.HubConnext;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Net.Sockets;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketDepartmentCommentsController : ControllerBase
    {
        private readonly ITicketDepartmentCommentsService _ticketDepartmentComments;
        private IHubContext<ChatHub> _hubContext;

        public TicketDepartmentCommentsController(IHubContext<ChatHub> hubContext, ITicketDepartmentCommentsService ticketDepartmentComments)
        {
            _hubContext = hubContext;
            this._ticketDepartmentComments = ticketDepartmentComments;
        }

        [HttpPost("ViewTicketCommentsChatStaff")]
        public async Task<IActionResult> ViewTicketCommentsChatStaff(Guid tichketDepartmentId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentComments.TicketDepartmentCommentsByTicketDepartmentID(tichketDepartmentId, userId, null);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("ViewTicketCommentsChatStaffOther")]
        public async Task<IActionResult> ViewTicketCommentsChatStaffOther(Guid tichketDepartmentId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentComments.TicketDepartmentCommentsByTicketDepartmentID(tichketDepartmentId, userId, userId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("ReplyTicketStaff")]
        public async Task<IActionResult> ReplyTicketStaff([FromForm] TicketDepartmentCommentRequestReplyVM ticketDepartmentCommentRequest)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                ticketDepartmentCommentRequest.AccountId = userID;
                var apiResponse = await _ticketDepartmentComments.ReplyTicket(ticketDepartmentCommentRequest, false);

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    await _hubContext.Clients.All.SendAsync("department-complaint/details/__chat" + ticketDepartmentCommentRequest.TicketDepartmentsId.ToString(), "ok?");
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPost("ReplyTicketStaffs")]
        public async Task<IActionResult> ReplyTicketStaffs([FromForm] TicketDepartmentCommentReplyRequestVMs ticketDepartmentCommentReply)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                ticketDepartmentCommentReply.AccountId = userID;
                var apiResponse = await _ticketDepartmentComments.ReplyTickets(ticketDepartmentCommentReply, false);

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    await _hubContext.Clients.All.SendAsync("department-complaint/details/__chat" + ticketDepartmentCommentReply.TicketDepartmentId.ToString(), "ok?");
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPost("ReplyTicketStaffOther")]
        public async Task<IActionResult> ReplyTicketStaffOther([FromForm] TicketDepartmentCommentRequestReplyVM ticketDepartmentCommentRequest)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                ticketDepartmentCommentRequest.AccountId = userID;
                var apiResponse = await _ticketDepartmentComments.ReplyTicket(ticketDepartmentCommentRequest, true);
                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    await _hubContext.Clients.All.SendAsync("department-complaint/details/__chat" + ticketDepartmentCommentRequest.TicketDepartmentsId.ToString(), "ok?");
                }
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
