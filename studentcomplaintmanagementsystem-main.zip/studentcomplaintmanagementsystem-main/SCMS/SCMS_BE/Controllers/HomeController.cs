﻿using AutoMapper;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : Controller
    {
        private readonly IAccountService _accountService;
        private readonly ICategoryTicketService _categoryTicketService;
        private readonly IMapper _mapper;

        public HomeController(IAccountService accountService, ICategoryTicketService categoryTicketService, IMapper mapper = null)
        {
            _mapper = mapper;
            _accountService = accountService;
            _categoryTicketService = categoryTicketService;
        }

        [HttpPost("verify-google-token")]
        public async Task<IActionResult> VerifyGoogleToken(string idToken, Guid CampusId, Guid EducationId)
        {
            try
            {
                // Xác minh mã token với Google
                var payload = await GoogleJsonWebSignature.ValidateAsync(idToken);

                if (!payload.Email.EndsWith("@fpt.edu.vn"))
                {
                    return BadRequest("Only email fpt login the system");
                }

                RequestLogin requestLogin = new RequestLogin();
                requestLogin.Email = payload.Email;
                requestLogin.Picture = payload.Picture;
                if (string.IsNullOrEmpty(requestLogin.Picture))
                {
                    requestLogin.Picture = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAAjVBMVEXaJR3//wDZFB7qkxTYAB7aIB3ZGx3qlhPYCx799ALfSxrZEh7dORvbJxzzwg3++QDiXxjjZxjuqBHldxbiYhjgUhneRRv43QjqkBT42AncMxvoixT20Av1ywzzxg3lcxfyvQ7wsxD77QXsnhPnghXxtw/65QblcxbhWBn42wnsnBLurBDmfBbohRX54wjsDvU8AAAEKUlEQVR4nO3d61biMBQFYFpPQkqt3OQiiAoIOoP6/o83BSy0NIUUmFVysr+/o7PaIzumyUmt1QAAAAAAAAAAAAAAAAAAAAAAAABgL6r6Am6PelNVX8KtEX2vL6q+iBsT1r16WPVF3BgaeAOq+iJui7j3PO8e4Unzh3FNhn7Vl3FT6CmuyRPCkyJG3toI4dnzx5uajBGevU10EJ40EXlbEcKT8L9/a/KN8CTo+bcmzwhPQnoJWfWl3Ar/fVeTd4Rniya7mkwQni3y9lCTDdlN1eQLI8oavaRq8oIPypry0rACGZOvmZp8IDxxdB4yNXlAeOLZSTNTkyZmKDXZ9rLaCA+9HdTkDeGRwUFNAuc/J7noIDw1tcjVZOH6FCUXHYRHtnIl8byW20VRU01Npm6HJ5xpajJzejNdfmpK4nmfLodHrbQ1WbkcHqWLThweh2tSEB2e4RG+EeoU1KRDZv+BRduGoj2/MzHWRycOz9jo++dtm4oyLbjZ61pUfZ+lULt5+pYu1Gxbtqrg155P39VFniLrVuQE3f3XktTJorFkRzWKhtDLzXqW5SYhKb84ch1vZO8Ehrqn7+8MX5Z+SLbC0Z+rV+TPyPLnZkHzK5ekY+XgmkWt/PLi+YKW1blJSPFy+l4NTYR1kxI9QeMrlWTMIDcJ1fi5QkWWDVbrKlK7GF3OIrR3UqJHr5c9FTY/WAyuWX70dEFJLHziMyGofnZJ/jIaXLNU47ypSmDrE58JqQ67TUw8sBtcs+irdEneGX9IttR9uafCQZ/VpERPqKIdDJ2V4jq4ZlHbdKgNbFuGPh+ZPhS602kuItMpbdOZA4LSfEWyy/u38J5xdBwKjzB/Gmw6kp2DgxjHvboRnoODGMc5ckxD0xJbzI1m2VLRcSQ8uYMYxzlxTCMst4YSWL7pZ0JzEOM4B45paA5iHOfAMQ0qu/wYsB9Q5GPRvRcOvY/cw1O09xX0qFfQ1sT+mEZBdB6ULFzA5h4e7RmmXeNRQVsT8zNO2oMYg/tkDhKOBpp/Z35MgzRjxiq1xyd0Lfgz1uERvfxocbAMTY/5EafHeRUlv40xye2N+9Hk8Is6nMOTi85QszcuaOhQeEQ/e6/Lnv4DoBrL7Bcyfi1zmI3Owi/6JSvDaTY8fB+OKfPj7x5LRLatack2PJsXLCcG0fGfvR+l99rZvpY5TLVUz082HmU6sOdcw0O7htDg0yQM1NtNVX6YhmcfnRdp9gQj/d2OIdPwhEmL37dxw56g5PWYTP8gAG0HzZ9SjUeqv30q5PkHAX6jsyrZsCd+H6VZhidcn5lsvpb/eW/P5d5xDM/63eTndUP70TPPd5qvo3NuN/SmA5thePz6Jd3Q8VSlzq/hXg7FJcuqUowZrspeeksMSwIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDMP763LveHf/gOAAAAAElFTkSuQmCC";
                }
                requestLogin.FirstName = payload.FamilyName;
                requestLogin.LastName = payload.GivenName;
                requestLogin.Address = payload.Locale ?? "";
                requestLogin.CampusId = CampusId;
                requestLogin.EducationId = EducationId;
                requestLogin.IsGoogle = true;
                requestLogin.Token = idToken;
                var apiResponse = await _accountService.login(requestLogin);
                // Nếu mã token hợp lệ, bạn có thể tạo một đối tượng người dùng
                // và lưu thông tin vào cơ sở dữ liệu hoặc tạo một token JWT để trả về client

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("oidc")]
        [Authorize(AuthenticationSchemes = "OidcProvider")]
        public async Task<IActionResult> GetProfileWithOidc()
        {
            try
            {
                RequestLogin requestLogin = new RequestLogin();

                // Xử lý thông tin người dùng từ nhà cung cấp OIDC
                var claims = User.Claims.Select(c => new { c.Type, c.Value });

                requestLogin.Email = User.FindFirstValue(ClaimTypes.Email);
                var authHeader = HttpContext.Request.Headers["Authorization"];
                if (!string.IsNullOrEmpty(authHeader))
                {
                    requestLogin.Token = authHeader.ToString().Split(' ')[1];
                }

                //Fix data
                requestLogin.CampusId = Guid.Parse("22223143-DBA9-4391-9506-68940D9BC7FF");
                requestLogin.EducationId = Guid.Parse("A9B8B975-E5F1-4578-A069-0BFB329DF4C0");

                requestLogin.RoleFeid = User.FindFirstValue(ClaimTypes.Role);
                requestLogin.UserFeid = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                requestLogin.CampusFeidId = Guid.Parse(User.FindFirstValue("campusId"));
                requestLogin.IsFEID = true;
                if (string.IsNullOrEmpty(requestLogin.Picture))
                {
                    requestLogin.Picture = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAAjVBMVEXaJR3//wDZFB7qkxTYAB7aIB3ZGx3qlhPYCx799ALfSxrZEh7dORvbJxzzwg3++QDiXxjjZxjuqBHldxbiYhjgUhneRRv43QjqkBT42AncMxvoixT20Av1ywzzxg3lcxfyvQ7wsxD77QXsnhPnghXxtw/65QblcxbhWBn42wnsnBLurBDmfBbohRX54wjsDvU8AAAEKUlEQVR4nO3d61biMBQFYFpPQkqt3OQiiAoIOoP6/o83BSy0NIUUmFVysr+/o7PaIzumyUmt1QAAAAAAAAAAAAAAAAAAAAAAAABgL6r6Am6PelNVX8KtEX2vL6q+iBsT1r16WPVF3BgaeAOq+iJui7j3PO8e4Unzh3FNhn7Vl3FT6CmuyRPCkyJG3toI4dnzx5uajBGevU10EJ40EXlbEcKT8L9/a/KN8CTo+bcmzwhPQnoJWfWl3Ar/fVeTd4Rniya7mkwQni3y9lCTDdlN1eQLI8oavaRq8oIPypry0rACGZOvmZp8IDxxdB4yNXlAeOLZSTNTkyZmKDXZ9rLaCA+9HdTkDeGRwUFNAuc/J7noIDw1tcjVZOH6FCUXHYRHtnIl8byW20VRU01Npm6HJ5xpajJzejNdfmpK4nmfLodHrbQ1WbkcHqWLThweh2tSEB2e4RG+EeoU1KRDZv+BRduGoj2/MzHWRycOz9jo++dtm4oyLbjZ61pUfZ+lULt5+pYu1Gxbtqrg155P39VFniLrVuQE3f3XktTJorFkRzWKhtDLzXqW5SYhKb84ch1vZO8Ehrqn7+8MX5Z+SLbC0Z+rV+TPyPLnZkHzK5ekY+XgmkWt/PLi+YKW1blJSPFy+l4NTYR1kxI9QeMrlWTMIDcJ1fi5QkWWDVbrKlK7GF3OIrR3UqJHr5c9FTY/WAyuWX70dEFJLHziMyGofnZJ/jIaXLNU47ypSmDrE58JqQ67TUw8sBtcs+irdEneGX9IttR9uafCQZ/VpERPqKIdDJ2V4jq4ZlHbdKgNbFuGPh+ZPhS602kuItMpbdOZA4LSfEWyy/u38J5xdBwKjzB/Gmw6kp2DgxjHvboRnoODGMc5ckxD0xJbzI1m2VLRcSQ8uYMYxzlxTCMst4YSWL7pZ0JzEOM4B45paA5iHOfAMQ0qu/wYsB9Q5GPRvRcOvY/cw1O09xX0qFfQ1sT+mEZBdB6ULFzA5h4e7RmmXeNRQVsT8zNO2oMYg/tkDhKOBpp/Z35MgzRjxiq1xyd0Lfgz1uERvfxocbAMTY/5EafHeRUlv40xye2N+9Hk8Is6nMOTi85QszcuaOhQeEQ/e6/Lnv4DoBrL7Bcyfi1zmI3Owi/6JSvDaTY8fB+OKfPj7x5LRLatack2PJsXLCcG0fGfvR+l99rZvpY5TLVUz082HmU6sOdcw0O7htDg0yQM1NtNVX6YhmcfnRdp9gQj/d2OIdPwhEmL37dxw56g5PWYTP8gAG0HzZ9SjUeqv30q5PkHAX6jsyrZsCd+H6VZhidcn5lsvpb/eW/P5d5xDM/63eTndUP70TPPd5qvo3NuN/SmA5thePz6Jd3Q8VSlzq/hXg7FJcuqUowZrspeeksMSwIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDMP763LveHf/gOAAAAAElFTkSuQmCC";
                }

                var apiResponse = await _accountService.login(requestLogin);

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost("GetUser")]
        public async Task<IActionResult> GetUser()
        {
            Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var apiResponse = await _accountService.GetUserByID(userId);
            return Ok(apiResponse);
        }
        [Authorize]
        [HttpPost("GetInforUser")]
        public async Task<IActionResult> GetInforUser()
        {
            Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var apiResponse = await _accountService.GetInforUser(userId);
            return Ok(apiResponse);
        }

        [HttpGet("TestA")]
        public async Task<IActionResult> TestB()
        {
            try
            {
                RequestLogin emailLogin = new RequestLogin();
                emailLogin.Email = "vietldhe153395@fpt.edu.vn";
                emailLogin.Picture = "payload.Picture";
                emailLogin.FirstName = "viet";
                emailLogin.LastName = "viet";
                emailLogin.Address = "";
                emailLogin.CampusId = Guid.Parse("22223143-DBA9-4391-9506-68940D9BC7FF");
                emailLogin.EducationId = Guid.Parse("A9B8B975-E5F1-4578-A069-0BFB329DF4C0");
                emailLogin.IsGoogle = true;
                var apiResponse = await _accountService.login(emailLogin);
                // Nếu mã token hợp lệ, bạn có thể tạo một đối tượng người dùng
                // và lưu thông tin vào cơ sở dữ liệu hoặc tạo một token JWT để trả về client

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("GetViewAuthority")]
        [Authorize]
        public async Task<IActionResult> GetViewAuthority(Guid pageCrudId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _accountService.GetViewAuthority(pageCrudId, userId);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Chua kiem duyet dc page do bi xoa hay chua van lay het
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        [HttpPost("GetPageAuthority")]
        [Authorize]
        public async Task<IActionResult> GetPageAuthority(string name)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _accountService.GetPageAuthority(name, userId);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi
                return BadRequest(ex.Message);
            }
        }
    }
}
