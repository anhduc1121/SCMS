﻿using System.Security.Claims;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Services;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class ReportController : Controller
    {
        private readonly IReportService _reportService;
        private readonly IMapper _mapper;

        public ReportController(IReportService reportService, IMapper mapper)
        {
            _reportService = reportService;
            _mapper = mapper;
        }
        /// <summary>
        /// report 2
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        //[HttpPost("GetTicketCountsByStatus")]
        //public async Task<IActionResult> GetTicketCountsByStatus([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        //{
        //    var result = await _reportService.GetTicketCountsByStatus(fromDate, toDate);
        //    return Ok(result);
        //}
        /// <summary>
        /// report1
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("ReportForEachAccount")]
        [Authorize]
        public async Task<IActionResult> ReportForEachAccount([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _reportService.ReportForEachAccount(userID, fromDate, toDate);
            return Ok(result);

        }

        /// <summary>
        /// report2
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("DailyReport")]
        [Authorize]
        public async Task<IActionResult> DailyReport([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.DailyReport(fromDate, toDate);
            return Ok(result);

        }
        /// <summary>
        /// report3
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("SynthesisReport")]
        [Authorize]
        public async Task<IActionResult> SynthesisReport([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.SynthesisReport(fromDate, toDate);
            return Ok(result);

        }
        /// <summary>
        /// report4
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("RatingReport")]
        [Authorize]
        public async Task<IActionResult> RatingReport([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.RatingReport(fromDate, toDate);
            return Ok(result);

        }
        /// <summary>
        /// report5
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("ReportTicketReport")]
        [Authorize]
        public async Task<IActionResult> ReportTicketReport([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.ReportTicketReport(fromDate, toDate);
            return Ok(result);

        }
        /// <summary>
        /// report2 bang 2
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("DailyReport2")]
        [Authorize]
        public async Task<IActionResult> DailyReport2([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.DailyReport2(fromDate, toDate);
            return Ok(result);

        }
        /// <summary>
        /// report1 bang 2
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("ReportForEachAccount2")]
        [Authorize]
        public async Task<IActionResult> ReportForEachAccount2([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _reportService.ReportForEachAccount2(userID, fromDate, toDate);
            return Ok(result);
        }

        /// <summary>
        /// report3 bang 2
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost("SynthesisReport2")]
        [Authorize]
        public async Task<IActionResult> SynthesisReport2([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
        {
            var result = await _reportService.SynthesisReport2(fromDate, toDate);
            return Ok(result);

        }
    }
}
