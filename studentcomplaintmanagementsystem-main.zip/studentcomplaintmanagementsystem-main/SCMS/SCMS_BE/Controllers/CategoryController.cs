﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class CategoryController : ControllerBase
    {
        private readonly IAccountService _accountService;
        private readonly ICategoryTicketService _categoryTicketService;
        private readonly IMapper _mapper;
        private ICategoryTicketService @object;
        private object value;
        private IMapper mapper;

        public CategoryController(IAccountService accountService, ICategoryTicketService categoryTicketService, IMapper mapper = null)
        {
            _mapper = mapper;
            _accountService = accountService;
            _categoryTicketService = categoryTicketService;
        }

        [HttpPost("GetCategory")]
        public async Task<IActionResult> GetCategory()
        {
            try
            {
                var apiResponse = await _categoryTicketService.GetCategories();
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        /// <summary>
        /// getCategorysByIdParentCategory
        /// </summary>
        /// <returns>list category by parent category with isdelete = true</returns>
        [HttpPost("GetCategorysByIdParentCategory")]
        public async Task<IActionResult> GetCategorysByIdParentCategory(Guid? IdParentCategory, Guid? categorySelected)
        {
            try
            {
                // lấy tất cả category theo id cha category
                var apiResponse = await _categoryTicketService.GetCategorysByIdParentCategory(IdParentCategory, categorySelected);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        /// <summary>
        /// getAllCategorysByIdParentCategory
        /// </summary>
        /// <returns>list all category by parent category </returns>
        [HttpPost("GetAllCategorysByIdParentCategory")]
        public async Task<IActionResult> GetAllCategorysByIdParentCategory(Guid? IdParentCategory)
        {
            try
            {
                if (IdParentCategory == null)
                {
                    var apiResponse = await _categoryTicketService.GetParentCategory();
                    return Ok(apiResponse);
                }
                else
                {
                    // lấy tất cả category theo id cha category
                    var apiResponse = await _categoryTicketService.GetAllCategorysByIdParentCategory(IdParentCategory);
                    return Ok(apiResponse);
                }
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        /// <summary>
        /// createCategory
        /// </summary>
        /// <returns></returns>
        [HttpPost("CreateCategoryTicket")]
        [Authorize]
        public async Task<IActionResult> CreateCategoryTicket([FromForm] CategoryTicketRequestVM categoryTicketVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                categoryTicketVM.AccountIdCreate = userID;
                var apiResponse = await _categoryTicketService.CreateCategoryTicket(categoryTicketVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("UpdateCategoryTicket")]
        [Authorize]
        public async Task<IActionResult> UpdateCategoryTicket([FromForm] CategoryTicketRequestVM categoryTicket)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                categoryTicket.AccountIdCreate = userID;
                var apiResponse = await _categoryTicketService.UpdateCategoryTicket(categoryTicket);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("DeleteCategoryTicket")]
        public async Task<IActionResult> DeleteCategoryTicket(Guid categoryTicketId)
        {
            try
            {
                var apiResponse = await _categoryTicketService.DeteleCategoryTicket(categoryTicketId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }



        [HttpPost("GetCategoryById")]
        public async Task<IActionResult> GetCategoryById(Guid? categoryId)
        {
            try
            {
                var apiResponse = await _categoryTicketService.GetCategoryById(categoryId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
