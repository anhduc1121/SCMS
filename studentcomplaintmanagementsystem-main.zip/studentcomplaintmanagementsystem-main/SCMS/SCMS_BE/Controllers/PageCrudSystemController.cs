﻿using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class PageCrudSystemController : ControllerBase
    {
        private readonly IPageCrudSystemService pageCrudSystemService;

        public PageCrudSystemController(IPageCrudSystemService pageCrudSystemService)
        {
            this.pageCrudSystemService = pageCrudSystemService;
        }

        [HttpPost("GetAllByPage")]
        public async Task<IActionResult> GetAllByPage([FromForm] Guid pageCrudId)
        {
            try
            {
                var apiResponse = await pageCrudSystemService.GetAllByPage(pageCrudId);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("AddPageCrud")]
        public async Task<IActionResult> AddPageCrud([FromForm] PageCrudRequestVM pageCrudRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageCrudRequestVM.AccountCreateId = userID;
                var apiResponse = await pageCrudSystemService.Add(pageCrudRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("UpdatePageCrud")]
        public async Task<IActionResult> UpdatePageCrud([FromForm] PageCrudRequestVM pageCrudRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageCrudRequestVM.AccountCreateId = userID;
                var apiResponse = await pageCrudSystemService.Update(pageCrudRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("DeletePageCrud")]
        public async Task<IActionResult> DeletePageCrud([FromForm] PageCrudRequestVM pageCrudRequestVM)
        {
            try
            {
                var apiResponse = await pageCrudSystemService.Delete(pageCrudRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetRoleByPageCrudId")]
        public async Task<IActionResult> GetRoleByPageCrudId([FromForm] Guid? id)
        {
            try
            {
                var apiResponse = await pageCrudSystemService.GetRoleByPageCrudId(id);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
