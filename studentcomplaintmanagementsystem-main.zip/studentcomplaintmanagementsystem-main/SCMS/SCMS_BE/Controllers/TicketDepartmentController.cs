﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.AuthorService;
using SCMS_BE.HubConnext;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketDepartmentController : ControllerBase
    {
        private readonly ITicketDepartmentService _ticketDepartmentService;
        private IHubContext<ChatHub> _hubContext;

        public TicketDepartmentController(IHubContext<ChatHub> hubContext, ITicketDepartmentService ticketDepartmentService)
        {
            _ticketDepartmentService = ticketDepartmentService;
            _hubContext = hubContext;
        }


        [HttpPost("GetAllForStaff")]
        public async Task<IActionResult> GetALLStaff([FromForm] TicketDepartmentRequestGetsVM ticketDepartment)
        {
            try
            {
                ticketDepartment.AccountIdCreate = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentService.ViewStaffWithStaffOther(ticketDepartment, true);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("GetAllForStaffOther")]
        public async Task<IActionResult> GetALLStaffOther([FromForm] TicketDepartmentRequestGetsVM ticketDepartment)
        {
            try
            {
                ticketDepartment.AccountIdCreate = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentService.ViewStaffWithStaffOther(ticketDepartment, false);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("CreateNewTicket")]
        public async Task<IActionResult> CreateNewTicket([FromForm] TicketDepartmentRequestAddVM ticketDepartmentRequestAdd)
        {
            try
            {
                ticketDepartmentRequestAdd.AccountIdCreate = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentService.CreateNew(ticketDepartmentRequestAdd);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }



        [HttpPost("GetTicketDepartmentByTicketStaff")]
        public async Task<IActionResult> GetTicketDepartmentByTicketStaff(Guid ticketDepartmentId)
        {
            try
            {
                var apiResponse = await _ticketDepartmentService.GetTicketDepartmentByTicketId(ticketDepartmentId, null);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("GetTicketDepartmentByTicketStaffOther")]
        public async Task<IActionResult> GetTicketDepartmentByTicketStaffOther(Guid ticketDepartmentId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketDepartmentService.GetTicketDepartmentByTicketId(ticketDepartmentId, userId);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("EndTicketDepartment")]
        public async Task<IActionResult> EndTicketDepartment(Guid ticketDepartmentId)
        {
            try
            {
                var apiResponse = await _ticketDepartmentService.UpdateTicketDepartmentByTicketId(ticketDepartmentId, Guid.Parse("FD6E17B5-C63D-42B6-BD10-40FB98629C50"));

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    await _hubContext.Clients.All.SendAsync("department-complaint/details/__chat" + ticketDepartmentId.ToString(), "ok?");
                }
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
