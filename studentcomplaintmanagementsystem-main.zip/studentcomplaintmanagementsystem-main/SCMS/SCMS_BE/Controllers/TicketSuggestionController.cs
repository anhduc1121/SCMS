﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketSuggestionController : Controller
    {
        private readonly ITicketSuggestionService _ticketSuggestionService;
        private readonly IMapper _mapper;

        public TicketSuggestionController(ITicketSuggestionService ticketSuggestionService, IMapper mapper)
        {
            _ticketSuggestionService = ticketSuggestionService;
            _mapper = mapper;
        }

        /// <summary>
        /// Get return view ticket sussgetsion
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("GetTicketSuggestionsByID")]
        public async Task<IActionResult> GetTicketSuggestionsByID(Guid? id)
        {
            try
            {
                var apiResponse = await _ticketSuggestionService.GetById(id);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }



        [Authorize]
        [HttpPost("CreateTicketSuggestion")]
        public async Task<IActionResult> CreateTicketSuggestion([FromForm] TicketSuggestionRequestVM ticketSuggestionRequestVM)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                ticketSuggestionRequestVM.AccountCreatorId = userId;
                var apiResponse = await _ticketSuggestionService.CreateTicketSuggestion(ticketSuggestionRequestVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("UpdateTicketSuggestion")]
        public async Task<IActionResult> UpdateTicketSuggestion([FromForm] TicketSuggestionRequestVM ticketSuggestionVM)
        {
            try
            {
                var apiResponse = await _ticketSuggestionService.UpdateTicketSuggestion(ticketSuggestionVM);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("DeleteTicketSuggestion")]
        public async Task<IActionResult> DeleteTicketSuggestion(Guid ticketSuggestionId)
        {
            try
            {
                var apiResponse = await _ticketSuggestionService.DeleteTicketSuggestion(ticketSuggestionId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetAllTicketSuggestion")]
        public async Task<IActionResult> GetAllTicketSuggestion(string? question, Guid? cateId, DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortQuestion = 0, int sortDate = 0)
        {
            try
            {
                var apiResponse = await _ticketSuggestionService.GetAllTicketSuggestion(question, cateId, createDate, pageIndex, pageSize, sortQuestion, sortDate);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetAllTicketSuggestionForCreateTicket")]
        [Authorize]
        public async Task<IActionResult> GetTicketForStudent(Guid? categoryId, string? title)
        {
            try
            {
                var apiResponse = await _ticketSuggestionService.GetAllTicketSuggestionForCreateTicket(categoryId, title);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

    }
}
