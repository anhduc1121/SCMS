﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketHandlingController : Controller
    {
        private readonly ITicketHandlingService _ticketHandlingService;
        private readonly IMapper _mapper;

        public TicketHandlingController(ITicketHandlingService ticketHandlingService, IMapper mapper)
        {
            _ticketHandlingService = ticketHandlingService;
            _mapper = mapper;
        }

        [HttpPost("ViewNode")]
        public async Task<IActionResult> ViewNode(Guid ticketId)
        {
            try
            {
                var apiResponse = await _ticketHandlingService.ViewNode(ticketId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
