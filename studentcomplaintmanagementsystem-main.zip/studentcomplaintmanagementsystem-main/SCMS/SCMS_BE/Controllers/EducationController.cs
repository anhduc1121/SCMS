﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SCMS_Repository.Helpers;
using SCMS_Services;
using SCMS_Services.Impl;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EducationController : ControllerBase
    {
        private readonly IEducationService _educationService;
        private readonly IMapper _mapper;
        public EducationController(IEducationService educationService, ICategoryTicketService categoryTicketService, IMapper mapper = null)
        {
            _mapper = mapper;
            _educationService = educationService;
        }

        [HttpPost("GetEducation")]
        public async Task<IActionResult> GetEducation()
        {
            try
            {
                var apiResponse = await _educationService.GetAll();
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
