﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SCMS_Repository.Helpers;
using SCMS_Services;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CampusController : ControllerBase
    {
        private readonly ICampusService _campusService;
        private readonly ICategoryTicketService _categoryTicketService;
        private readonly IMapper _mapper;

        public CampusController(ICampusService campusService, ICategoryTicketService categoryTicketService, IMapper mapper = null)
        {
            _mapper = mapper;
            _campusService = campusService;
            _categoryTicketService = categoryTicketService;
        }

        [HttpPost("GetListCampus")]
        public async Task<IActionResult> GetListCampus()
        {
            try
            {
                var apiResponse = await _campusService.GetListCampus();
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
