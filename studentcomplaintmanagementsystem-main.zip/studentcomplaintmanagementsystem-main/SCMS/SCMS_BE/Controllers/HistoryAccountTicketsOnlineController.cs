﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.AuthorService;
using SCMS_BE.HubConnext;
using SCMS_Services;
using System.Net.Sockets;
using System.Security.Claims;
using ViewModel;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class HistoryAccountTicketsOnlineController : ControllerBase
    {
        private readonly IHistoryAccountTicketsOnlineService _historyAccountTicketsOnlineService;
        private IHubContext<ChatHub> _hubContext;

        public HistoryAccountTicketsOnlineController(IHistoryAccountTicketsOnlineService historyAccountTicketsOnlineService, IHubContext<ChatHub> hubContext)
        {
            _historyAccountTicketsOnlineService = historyAccountTicketsOnlineService;
            _hubContext = hubContext;
        }

        [HttpPost("GetAllByTicket")]
        public async Task<IActionResult> GetAllByTicket([FromForm] HistoryAccountTicketsOnlineRequestVM historyAccount)
        {
            Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            historyAccount.UserId = userId;

            var apiResponse = await _historyAccountTicketsOnlineService.GetAll(historyAccount);
            return Ok(apiResponse);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Add([FromForm] HistoryAccountTicketsOnlineRequestVM historyAccount)
        {
            Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            historyAccount.UserId = userId;

            var apiResponse = await _historyAccountTicketsOnlineService.Add(historyAccount);

            var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = historyAccount.TicketId });
            if (list.Data != null)
            {
                List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                {
                    await _hubContext.Clients
                        .Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray())
                        .SendAsync("complaint/details/__userOnlineChat" + historyAccount.TicketId.ToString().ToLower(), "Hello, selected users!");
                }
            }
            return Ok(apiResponse);
        }

        [HttpPost("Remove")]
        public async Task<IActionResult> Remove([FromForm] HistoryAccountTicketsOnlineRequestVM historyAccount)
        {
            Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            historyAccount.UserId = userId;

            var apiResponse = await _historyAccountTicketsOnlineService.Remove(historyAccount);
            var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = historyAccount.TicketId });
            if (list.Data != null)
            {
                List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                {
                    await _hubContext.Clients
                        .Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray())
                        .SendAsync("complaint/details/__userOnlineChat" + historyAccount.TicketId.ToString().ToLower(), "Hello, selected users!");
                }
            }
            return Ok(apiResponse);
        }
    }
}
