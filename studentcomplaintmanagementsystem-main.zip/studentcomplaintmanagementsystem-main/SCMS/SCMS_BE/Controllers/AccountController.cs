﻿using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        /// <summary>
        /// get all category for the combobox for user
        /// </summary>
        /// <returns>list of category ticket publish</returns>
        //[Authorize(Roles = $"{RoleUnit.Role_Admin}, {RoleUnit.Role_Staff}")]
        [HttpPost("GetListAccountByRole")]
        public async Task<IActionResult> GetListAccountByRole(Guid? roleId)
        {
            try
            {
                var apiResponse = await _accountService.ListStaff(roleId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetListEmployee")]
        public async Task<IActionResult> GetAllEmployeesWithFilters(string? searchEmail, int sortDate, int pageIndex, int pageSize)
        {
            try
            {
                if (searchEmail == null)
                {
                    searchEmail = "";
                }
                else
                {
                    searchEmail = searchEmail.Trim();
                }
                var apiResponse = await _accountService.ListEmployee(searchEmail, sortDate, pageIndex, pageSize);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPost("GetListEmployeeSize")]
        public async Task<IActionResult> GetListEmployeesSize(string? searchEmail, int sortDate, int pageIndex, int pageSize)
        {
            try
            {
                if (searchEmail == null)
                {
                    searchEmail = "";
                }
                else
                {
                    searchEmail = searchEmail.Trim();
                }
                var apiResponse = await _accountService.ListEmployeeSize(searchEmail, sortDate, pageIndex, pageSize);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("UpdateEmployee")]
        public async Task<IActionResult> UpdateEmployee(ExEmployeeRespon employee_update)
        {

            try
            {
                var apiResponse = await _accountService.UpdateEmployee(employee_update);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }


        [HttpPost("AddEmployee")]
        public async Task<IActionResult> AddEmployee(ExEmployeeRespon employee_update)
        {

            try
            {
                var apiResponse = await _accountService.AddEmployee(employee_update);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpGet("GetAllStatusAccount")]
        public async Task<IActionResult> GetAllStatusAccount()
        {
            try
            {
                var apiResponse = await _accountService.GetAllStatusAccount();
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetRolesByAccount")]
        public async Task<IActionResult> GetRolesByAccount(Guid? accountId)
        {
            try
            {
                var apiResponse = await _accountService.GetRolesByAccount(accountId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("DeleteAccountByAccountId")]
        public async Task<IActionResult> DeleteAccountByAccountId(string? accountId)
        {
            try
            {
                var apiResponse = await _accountService.DeleteAccountByAccountId(Guid.Parse(accountId));
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("GetEmailByRole")]
        public async Task<IActionResult> GetEmailByRole(string? gmail)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _accountService.GetEmailByRole(userID, gmail);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
    }
}
