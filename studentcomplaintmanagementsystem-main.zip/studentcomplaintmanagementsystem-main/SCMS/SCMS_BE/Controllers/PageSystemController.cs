﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class PageSystemController : ControllerBase
    {
        private readonly IPageSystemService _pageSystemService;

        public PageSystemController(IPageSystemService pageSystemService)
        {
            _pageSystemService = pageSystemService;
        }

        [HttpPost("GetAllPageSystem")]

        public async Task<IActionResult> GetAllPageSystem([FromForm] PageRequestVM pageRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageRequestVM.AccountCreateId = userID;
                var apiResponse = await _pageSystemService.GetAll(pageRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("AddPageSystem")]
        public async Task<IActionResult> AddPageSystem([FromForm] PageRequestVM pageRequestVM)
        {
            try
            {
                if (String.IsNullOrEmpty((pageRequestVM.PageName ?? "").Trim()))
                {
                    throw new Exception("Page Name is not blank");
                }
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageRequestVM.AccountCreateId = userID;
                var apiResponse = await _pageSystemService.Add(pageRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("UpdatePageSystem")]
        public async Task<IActionResult> UpdatePageSystem([FromForm] PageRequestVM pageRequestVM)
        {
            try
            {
                if (String.IsNullOrEmpty((pageRequestVM.PageName ?? "").Trim()))
                {
                    throw new Exception("Page Name is not blank");
                }
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageRequestVM.AccountCreateId = userID;
                var apiResponse = await _pageSystemService.Update(pageRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPut("DeletePageSystem")]
        public async Task<IActionResult> DeletePageSystem([FromForm] PageRequestVM pageRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                pageRequestVM.AccountCreateId = userID;
                var apiResponse = await _pageSystemService.Delete(pageRequestVM);

                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }


    }
}
