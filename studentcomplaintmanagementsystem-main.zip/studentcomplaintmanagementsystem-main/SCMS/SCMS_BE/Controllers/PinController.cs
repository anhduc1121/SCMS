﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SCMS_BE.AuthorService;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class PinController : ControllerBase
    {
        private readonly ITicketService _ticketService;
        private readonly ICategoryTicketService _categoryTicketService;
        private readonly IMapper _mapper;

        public PinController(ITicketService ticketService, ICategoryTicketService categoryTicketService, IMapper mapper)
        {
            _ticketService = ticketService;
            _categoryTicketService = categoryTicketService;
            _mapper = mapper;
        }

        [HttpPost("CreatePinTicket")]
        public async Task<IActionResult> CreatePinTicket(Guid ticketId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var apiResponse = await _ticketService.CreatePinTicket(ticketId, userId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }
        [HttpPut("DeletePinTicket")]
        public async Task<IActionResult> DeletePinTicket(Guid pinTicketId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                var apiResponse = await _ticketService.DeletePinTicket(pinTicketId, userId);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

    }
}
