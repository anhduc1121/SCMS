using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SCMS_BE.AuthorService;
using SCMS_BE.HubConnext;
using SCMS_Repository.Helpers;
using SCMS_Services;
using System.Security.Claims;
using ViewModel;
using static SCMS_Repository.Helpers.EnumVariable;

namespace SCMS_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DynamicAuthorize]
    public class TicketController : Controller
    {
        private readonly ITicketService _ticketService;
        private readonly ITicketHandlingService _ticketHandlingService;
        private IHubContext<ChatHub> _hubContext;
        private readonly IHistoryAccountTicketsOnlineService _historyAccountTicketsOnlineService;

        public TicketController(ITicketService ticketService, ITicketHandlingService ticketHandlingService,
            IHubContext<ChatHub> hubContext, IHistoryAccountTicketsOnlineService historyAccountTicketsOnlineService)
        {
            _ticketService = ticketService;
            _ticketHandlingService = ticketHandlingService;
            _hubContext = hubContext;
            _historyAccountTicketsOnlineService = historyAccountTicketsOnlineService;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cateId"></param>
        /// <param name="statusTicketId"></param>
        /// <param name="accountIDBehaveCreate"></param>
        /// <param name="tagAccountId"></param>
        /// <param name="accountGmaillBehaveCreate"></param>
        /// <param name="accountGmaillTag"></param>
        /// <param name="status"></param>
        /// <param name="title"></param>
        /// <param name="createDate"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortDate"></param>
        /// <param name="sortTitle"></param>
        /// <param name="sortStatusTicket"></param>
        /// <param name="isPin"></param>
        /// <returns></returns>
        [HttpPost("GetTicketForStudent")]
        public async Task<IActionResult> GetTicketForStudent([FromForm] TicketRequestVM ticketRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.GetAllTicket(userID, ticketRequestVM.cateId, ticketRequestVM.statusTicketId,
              userID, ticketRequestVM.accountIDBehaveCreate, ticketRequestVM.tagAccountId,
            ticketRequestVM.accountGmaillCreate, ticketRequestVM.accountGmaillBehaveCreate, ticketRequestVM.accountGmaillTag, ticketRequestVM.status, ticketRequestVM.title,
            ticketRequestVM.createDate, ticketRequestVM.pageIndex, ticketRequestVM.pageSize, ticketRequestVM.sortDate, ticketRequestVM.sortTitle, ticketRequestVM.sortStatusTicket, ticketRequestVM.isPin);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="cateId"></param>
        /// <param name="statusTicketId"></param>
        /// <param name="accountIdCreate"></param>
        /// <param name="accountIDBehaveCreate"></param>
        /// <param name="tagAccountId"></param>
        /// <param name="accountGmaillBehaveCreate"></param>
        /// <param name="accountGmaillTag"></param>
        /// <param name="status"></param>
        /// <param name="title"></param>
        /// <param name="createDate"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortDate"></param>
        /// <param name="sortTitle"></param>
        /// <param name="sortStatusTicket"></param>
        /// <param name="isPin"></param>
        /// <returns></returns>
        [HttpPost("GetAllTicket")]
        public async Task<IActionResult> GetAllTicket([FromForm] TicketRequestVM ticketRequestVM)
        {
            try
            {
                Guid userID = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.GetAllTicket(userID, ticketRequestVM.cateId, ticketRequestVM.statusTicketId,
              ticketRequestVM.accountIdCreate, ticketRequestVM.accountIDBehaveCreate, ticketRequestVM.tagAccountId,
              ticketRequestVM.accountGmaillCreate, ticketRequestVM.accountGmaillBehaveCreate, ticketRequestVM.accountGmaillTag, ticketRequestVM.status, ticketRequestVM.title,
            ticketRequestVM.createDate, ticketRequestVM.pageIndex, ticketRequestVM.pageSize, ticketRequestVM.sortDate, ticketRequestVM.sortTitle, ticketRequestVM.sortStatusTicket, ticketRequestVM.isPin);
                return Ok(apiResponse);
            }
            catch
            {
                return BadRequest(new ApiMessage { Message = MessageE.ERROR.ToString() });
            }
        }

        [HttpPost("ReplyTicketStaff")]
        public async Task<IActionResult> ReplyTicketStaff([FromForm] TicketCommentReplyVM ticket)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.ReplyTicket(ticket, userId, true);

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = ticket.TicketId });
                    if (list.Data != null)
                    {
                        List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                        if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                        {
                            await _hubContext.Clients.Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray()).SendAsync("complaint/details/__chat" + ticket.TicketId.ToString().ToLower(), "Hello, selected users!");
                        }
                    }
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }
        [HttpPost("ReplyTicketStaffs")]
        public async Task<IActionResult> ReplyTicketStaffs([FromForm] TicketCommentReplyRequestVMs ticketCommentReplyRequestVMs)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.ReplyTickets(ticketCommentReplyRequestVMs, userId, true);

                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = ticketCommentReplyRequestVMs.TicketId });
                    if (list.Data != null)
                    {
                        List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                        if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                        {
                            await _hubContext.Clients.Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray()).SendAsync("complaint/details/__chat" + ticketCommentReplyRequestVMs.TicketId.ToString().ToLower(), "Hello, selected users!");
                        }
                    }
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }
        [HttpPost("ReplyTicketStudent")]
        public async Task<IActionResult> ReplyTicketStudent([FromForm] TicketCommentReplyVM ticket)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.ReplyTicket(ticket, userId, false);
                if (apiResponse != null && apiResponse.Message == MessageE.CREATE_SUCCESS.ToString())
                {
                    var list = await _historyAccountTicketsOnlineService.GetAll(new HistoryAccountTicketsOnlineRequestVM { TicketId = ticket.TicketId });
                    if (list.Data != null)
                    {
                        List<HistoryAccountTicketsOnlineResponseVM> historyAccountTicketsOnlineResponseVMs = (List<HistoryAccountTicketsOnlineResponseVM>)list.Data;
                        if (historyAccountTicketsOnlineResponseVMs != null && historyAccountTicketsOnlineResponseVMs.Count > 0)
                        {
                            await _hubContext.Clients.Users(historyAccountTicketsOnlineResponseVMs.Select(x => x.UserId.ToString()).ToArray()).SendAsync("complaint/details/__chat" + ticket.TicketId.ToString().ToLower(), "Hello, selected users!");
                        }
                    }
                }
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }
        [HttpPost("GetTicketByTicketStudent")]
        public async Task<IActionResult> GetTicketByTicketStudent(Guid ticketId)
        {
            try
            {
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var apiResponse = await _ticketService.GetTicketByTicketId(ticketId, userId);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }
        [HttpPost("GetTicketByTicketStaff")]
        public async Task<IActionResult> GetTicketByTicketStaff(Guid ticketId)
        {
            try
            {
                var apiResponse = await _ticketService.GetTicketByTicketId(ticketId, null);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPost("GetTicketByAccountId")]
        public async Task<IActionResult> GetTicketByAccountId(string? status, string? title, Guid? cateId, DateTime? createDate, Guid accountId, int pageIndex = 1, int pageSize = 5, int sortDate = 0)
        {
            try
            {
                var apiResponse = await _ticketService.GetTicketByAccountId(status, title, cateId, createDate, accountId, pageIndex, pageSize, sortDate);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPut("UpdateCategorysOfTicketId")]
        public async Task<IActionResult> UpdateCategorysOfTicketId(Guid tickketId, Guid categoryTicketId)
        {
            try
            {
                var apiResponse = await _ticketService.UpdateCategorysOfTicketId(tickketId, categoryTicketId);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPost("CreateNewTicket")]
        public async Task<IActionResult> CreateNewTicket([FromForm] TicketCreateVM ticketCreate)
        {
            try
            {
                if (ticketCreate.AccountIdCreate == null)
                {
                    ticketCreate.AccountIdCreate = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                }
                var apiResponse = await _ticketService.CreateNewTicket(ticketCreate);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPut("EndTicket")]
        public async Task<IActionResult> EndTicket(Guid ticketId, string positive, string negative, string rate)
        {
            try
            {
                var apiResponse = await _ticketService.EndTicket(ticketId, positive, negative, rate);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }

        [HttpPost("ViewStatusTicket")]
        public async Task<IActionResult> ViewStatusTicket()
        {
            try
            {
                var apiResponse = await _ticketService.ViewStatusTicket();
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiMessage { Message = ex.Message });
            }
        }
    }
}
