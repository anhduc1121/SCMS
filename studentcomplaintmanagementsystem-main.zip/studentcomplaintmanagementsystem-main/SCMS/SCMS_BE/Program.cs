﻿using Microsoft.AspNetCore.OData;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SCMS_BE.HubConnext;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using SCMS_Repository.IUnitOfWorks;
using SCMS_Services;
using SCMS_Services.Impl;
using Swashbuckle.AspNetCore.Filters;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var connectionString = builder.Configuration.GetConnectionString("MyCnn");
builder.Services.AddDbContext<ScmsContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddCors(p => p.AddPolicy("BTP_CORS", build =>
{
    build.WithOrigins("http://localhost:8696").AllowAnyMethod().AllowAnyHeader().AllowCredentials();
}));

builder.Services.AddHttpContextAccessor();
builder.Services.AddAutoMapper(typeof(ApplicationMapper));
builder.Services.AddScoped<IAccountService, AccountService>();
builder.Services.AddScoped<ICategoryTicketService, CategoryTicketService>();
builder.Services.AddScoped<ITicketService, TicketService>();
builder.Services.AddScoped<ITicketSuggestionService, TicketSuggestionService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<ITicketCommentService, TicketCommentService>();
builder.Services.AddScoped<ITicketHandlingService, TicketHandlingService>();
builder.Services.AddScoped<INotificationService, NotificationService>();
builder.Services.AddScoped<ITagTicketService, TagTicketService>();
builder.Services.AddScoped<ICampusService, CampusService>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped<IEducationService, EducationService>();
builder.Services.AddScoped<IPageSystemService, PageSystemService>();
builder.Services.AddScoped<IPageCrudSystemService, PageCrudSystemService>();
builder.Services.AddScoped<ITicketDepartmentService, TicketDepartmentService>();
builder.Services.AddSingleton<IUserIdProvider, CustomUserIdProvider>();
builder.Services.AddScoped<ITicketFeedbackService, TicketFeedbackService>();
builder.Services.AddScoped<IDepartmentService, DepartmentService>();
builder.Services.AddScoped<ITicketDepartmentCommentsService, TicketDepartmentCommentsService>();
builder.Services.AddScoped<IHistoryAccountTicketsOnlineService, HistoryAccountTicketsOnlineService>();

builder.Services.AddControllers
    (
     config =>
     {
         config.RespectBrowserAcceptHeader = true;
         config.ReturnHttpNotAcceptable = false;
     }
    )
    .AddJsonOptions
    (
    options =>
    {
        options.JsonSerializerOptions.Converters.Add(new DateOnlyJsonConverter());
    })
    .AddXmlDataContractSerializerFormatters()
    .AddOData(x => x.Select().Filter().Count().OrderBy()
    .Expand().SetMaxTop(100));
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(
    opt =>
    {
        opt.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
        {
            Description = "Standard Authorization header using the Bearer scheme (\"bearer {token}\")",
            In = ParameterLocation.Header,
            Name = "Authorization",
            Type = SecuritySchemeType.ApiKey
        });
        opt.OperationFilter<SecurityRequirementsOperationFilter>();
    }
);
builder.Services.AddSignalR(options =>
{
    options.EnableDetailedErrors = true;
});

builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));

var secretKey = builder.Configuration["AppSettings:SecretKey"];
var secretKeyBytes = Encoding.UTF8.GetBytes(secretKey);

string IdentityServerUrl = builder.Configuration.GetValue<string>("IdentityServer:url");

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = "YourJwtProvider";
    options.DefaultChallengeScheme = "YourJwtProvider";
})
.AddJwtBearer("YourJwtProvider", options =>
{
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = false,
        ValidateAudience = false,

        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(secretKeyBytes),
        ClockSkew = TimeSpan.Zero,
    };
})
.AddJwtBearer("OidcProvider", options =>
{
    options.Authority = IdentityServerUrl;

    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateAudience = false
    };
});
var app = builder.Build();
app.UseCors("BTP_CORS");
// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseODataBatching();

app.UseRouting();
app.UseAuthentication();

app.UseAuthorization();
app.MapControllers();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapHub<ChatHub>("/chat");
});
app.Run();
