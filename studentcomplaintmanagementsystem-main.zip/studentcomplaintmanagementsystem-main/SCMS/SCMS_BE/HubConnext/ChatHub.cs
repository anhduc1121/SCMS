﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace SCMS_BE.HubConnext
{
    [Authorize]
    public class ChatHub : Hub
    {

        public ChatHub()
        {
        }

        public async Task BroadcastChatData(MessageDetails data)
            => await Clients.All.SendAsync("new_mess", data);

        public async Task SendAll()
        {
            var data = Context;
            await Clients.All.SendAsync("new_mess", "ok?");
            await Clients.User("100").SendAsync("new_mess", "send to user_id = 100");
        }

        public async override Task OnConnectedAsync()
        {
            Guid userId = Guid.Parse(Context.User.FindFirstValue(ClaimTypes.NameIdentifier));
            await Clients.User("09119967-168C-45BA-8FF1-07D2BBD3267C").SendAsync("a", "s");
        }

        public List<Guid> Users = new List<Guid>();

        public override Task OnDisconnectedAsync(Exception? exception)
        {
            Guid userId = Guid.Parse(Context.User.FindFirstValue(ClaimTypes.NameIdentifier));
            return base.OnDisconnectedAsync(exception);
        }
    }
}
