﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using SCMS_Services;
using System.Security.Claims;
using System.Web;

namespace SCMS_BE.AuthorService
{
    public class DynamicAuthorizeAttribute : AuthorizeAttribute, IAsyncAuthorizationFilter
    {

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var roleService = context.HttpContext.RequestServices.GetService<IRoleService>();
            Guid userId = Guid.Parse(context.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier));
            string actionDescriptorDisplayName = context.ActionDescriptor.DisplayName;
            var (controller, action) = GetFunctionIdFromAction(actionDescriptorDisplayName);

            var path = context.HttpContext.Request.Path.Value;
            var queryString = context.HttpContext.Request.QueryString.Value;
            var page = HttpUtility.ParseQueryString(queryString).Get("page");

            var authorized = await roleService.CheckAuthorization(userId, controller, action);

            //if (!authorized)
            //{
            //    context.Result = new ForbidResult();
            //    return;
            //}

        }

        private (string, string) GetFunctionIdFromAction(string actionName)
        {
            // actionName = SCMS_BE.Controllers.HomeController.TestB (SCMS_BE)

            var parts = actionName.Split('.');
            if (parts.Length >= 2)
            {
                return (parts[2], parts[3].ToString().Trim().Split(' ')[0].ToString().Trim());
            }

            return (null, null); // Không tìm thấy FunctionActionAPI
        }
    }
}
