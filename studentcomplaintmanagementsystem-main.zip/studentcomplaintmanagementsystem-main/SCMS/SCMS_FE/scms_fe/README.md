# Step 1

npm i

# Step 2

npm run serve


## How to login: 

FEID: 

----------------

student --> 
user: truong98hiro@gmail.com
password: Tt7@Km4!


Take care staff --> 
user: ducta0333@gmail.com 
password: Wv7*Rd2#

user: anht01@gmail.com
password: Mf6!Hi3#

Admin --> 
user: ducta02@gmail.com
password: Eg7!So2#

Take care Manager -->
user: levietaqviet1@gmail.com 
password: Xw3!Jv9$

Employee -->
user: ducta032@gmail.com
password:  Mr7$Fr9&


--- error
ducta0333@gmail.com Fc7@Sr9&
 
----------------

# Note: Just login only localhost 8696