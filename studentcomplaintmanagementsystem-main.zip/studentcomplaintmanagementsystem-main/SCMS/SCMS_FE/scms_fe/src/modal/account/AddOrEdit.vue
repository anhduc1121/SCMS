<template>
  <div id="edit-employee-modal" class="edit-employee-modal">
    <div v-if="isSuccess != null" class="notification-span">
      <span>{{ isSuccess }}</span>
    </div>
    <div class="section-detail">
      <span style="color: red" v-if="emailError">{{ emailError }}</span>
      <div class="line-info" style="margin-top: 60px">
        <div class="field-name">Email</div>
        <div class="field-box">
          <div class="field-content">
            <input
              v-if="isAdd"
              required
              class="input-content"
              type="email"
              v-model="employee.employeeEmail"
              @input="validateEmail"
            />
            <input
              v-else
              readonly
              class="input-content"
              type="email"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.employeeEmail"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.firstName") }}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              required
              class="input-content input-firstname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.firstname"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.lastName") }}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              required
              class="input-content input-lastname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.lastname"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.phone") }}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              required
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.phone"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.address") }}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              required
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.address"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.campus") }}</div>
        <div class="field-box">
          <div class="field-content">
            <div>
              <select class="select-campus" name="" v-model="employee.campusId">
                <option
                  v-for="item in listCampus"
                  :key="item.campusId"
                  :value="item.campusId"
                >
                  {{ item.campusName }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.department") }}</div>
        <div class="field-box">
          <div class="field-content">
            <div>
              <select
                class="select-campus"
                name=""
                v-model="employee.departmentId"
              >
                <option
                  v-for="depart in listDepartment"
                  :key="depart.departmentId"
                  :value="depart.departmentId"
                >
                  {{ depart.departmentName }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.status") }}</div>
        <div class="field-box">
          <div class="field-content">
            <div>
              <select class="select-campus" name="" v-model="employee.statusId">
                <option
                  v-for="statusAccount in listStatusAccount"
                  :key="statusAccount.statusId"
                  :value="statusAccount.statusId"
                >
                  {{ statusAccount.statusName }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="item">
          <div class="label">{{ $t("label.role") }}</div>
          <div class="value have-loading">
            <div class="role-list">
              <template v-for="(role, index) in roles" :key="index">
                <div class="role" @click="toogleRole(role, $event)">
                  <div class="name">{{ role.name }}</div>
                  <div class="selected">
                    <input
                      type="checkbox"
                      :checked="Checked(role.id)"
                      @change="modifyRole(role)"
                    />
                  </div>
                </div>
              </template>
            </div>
            <Loading v-if="loadingSections.roleAccpect" :isFullScreen="false" />
          </div>
        </div>
      </div>
    </div>

    <div class="btn-close-edit">
      <button class="submit" @click="onSubmit(isAdd)">
        <span>{{ $t("button.submit") }}</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import EmployeeAPIService from "@/script/services/EmployeeAPIService";
import CampusAPIService from "@/script/services/CampusAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import PageSystemAPIService from "@/script/services/PageSystemAPIService";

export default defineComponent({
  name: "employee-detail-popup",
  components: { Loading },

  data() {
    return {
      employee: {
        employeeId: "00000000-0000-0000-0000-000000000000", //default
        employeeEmail: "",
        firstname: "",
        lastname: "",
        createDate: "2024-03-31T17:10:46.013",
        phone: "",
        address: "",
        campusId: "22223143-dba9-4391-9506-68940d9bc7ff",
        campusName: "Hoa Lac",
        statusId: "21842bcb-fae8-4c00-9c33-de997d4e8103",
        statusName: "Block",
        departmentId: "ef16f7d5-9db3-481e-9baf-28c67e7a890f",
        departmentName: "Sinh vien",
      },
      isSuccess: null,
      status: false,
      listCampus: [],
      campusName: "",
      listStatusAccount: [],
      listDepartment: [],
      roles: [],
      employeeRoles: [],
      loadingSections: {
        section1: false,
        roleAccpect: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      emailError: null,
    };
  },
  props: {
    employeeSelected: Object,
    isAdd: Boolean,
  },
  async created() {
    this.toast = useToast();
    this.getAllCampus();
    this.getAllDepartment();
    this.getStatusAccount();
    if (this.employeeSelected != null && !this.isAdd) {
      this.employee = this.employeeSelected;
      this.getRolesByAccountId();
    }

    this.getRoleFunction();
  },
  methods: {
    validateEmail() {
      if (!this.employee.employeeEmail) {
        this.emailError = "Email is required.";
      } else if (!this.isValidEmail(this.employee.employeeEmail)) {
        this.emailError = "Invalid email format.";
      } else {
        this.emailError = null;
      }
    },
    isValidEmail(email) {
      // You can use a regular expression or any other email validation method here
      // This is a basic example using a regular expression
      const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
      return emailRegex.test(email);
    },

    modifyRole(role) {
      var convertRole = {
        roleId: role.id,
        roleName: role.name,
        createDate: "2024-03-31T17:10:46.013",
      };
      if (
        this.employeeRoles.some((role) => role.roleId === convertRole.roleId)
      ) {
        this.employeeRoles = this.employeeRoles.filter(
          (item) => item.roleId !== convertRole.roleId
        );
      } else {
        this.employeeRoles.push(convertRole);
      }
    },

    Checked(id) {
      return this.employeeRoles.some((role) => role.roleId === id);
    },

    async getRolesByAccountId() {
      if (this.employee.employeeId != "") {
        const respon = await EmployeeAPIService.getRolesByAccountId(
          this.employee.employeeId
        );
        if (respon != null) {
          this.employeeRoles = respon;
        }
      }
    },

    async getAllDepartment() {
      const respon = await EmployeeAPIService.getAllDepartment();
      if (respon != null) {
        this.listDepartment = respon;
      }
    },

    async getRoleFunction() {
      this.loadingSections.roleAccpect = true;
      const formData = new FormData();
      formData.append("id", "40342688-5A61-42C9-B3EA-E4D8A9D59DE0");

      const res = await PageSystemAPIService.getRoleAccpect(formData);
      if (res != null) {
        this.toast("load data  successfully", {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });
        this.roles = res.data;
        this.loadingSections.roleAccpect = false;
      } else {
        this.toast("load data error", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.roleAccpect = false;
      }
    },
    toogleRole(role, event) {
      event.stopPropagation();
      role.isSelected = !role.isSelected;
    },
    async getStatusAccount() {
      const respon = await EmployeeAPIService.getStatusAccount();
      if (respon != null) {
        this.listStatusAccount = respon;
        if (
          this.employeeSelected == null &&
          this.listStatusAccount.length > 0
        ) {
          this.employee.statusId = this.listStatusAccount[0].statusId;
        }
      }
    },

    async getAllCampus() {
      const respon = await CampusAPIService.getCampus();
      if (respon != null) {
        this.listCampus = respon;
        if (this.employeeSelected == null && this.listCampus.length > 0) {
          this.employee.campusId = this.listCampus[0].campusId;
        }
      }
    },

    async onSubmit(isAdd) {
      this.submitEdit(isAdd);
    },
    async submitEdit(isAdd) {
      if (
        this.employeeRoles == null ||
        (this.employeeRoles != null && this.employeeRoles.length == 0)
      ) {
        this.toast("You must choose at least 1 role", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      if (this.emailError != null) {
        this.toast(this.emailError, {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      var respon = null;
      if (!isAdd) {
        const data = {
          employee_update: {
            exEmployee: this.employee,
            roles: this.employeeRoles,
          },
          url: "/Account/UpdateEmployee",
        };
        respon = await EmployeeAPIService.updateEmployee(data);
        if (respon != null) {
          this.isSuccess = respon;
        }
      } else {
        const data = {
          employee_update: {
            exEmployee: this.employee,
            roles: this.employeeRoles,
          },
          url: "/Account/AddEmployee",
        };
        respon = await EmployeeAPIService.addEmployee(data);
        if (respon != null) {
          if (respon.data) {
            this.toast(this.$t("toast.Common.mess2"), {
              type: TYPE.error, // or "success", "error", "default", "info" and "warning"
            });
          }else{
            this.toast(this.$t("toast.Common.mess3"), {
              type: TYPE.error, // or "success", "error", "default", "info" and "warning"
            });
          }
        }
      }
    },

    closeModal() {
      this.$emit("close-modal");
    },
  },
});
</script>
  
<style lang="scss">
@import "@/assets/scss/modal/account/employee-edit-add";
</style>

<style>
.section-detail {
  border: 3px solid rgb(0, 155, 160);
  height: 780px;
}
.line-info {
  display: block;
  /* background-color: aquamarine; */
  width: 80%;
  margin-top: 10px;
  margin-left: 10%;
  height: 50px;
}
.field-name {
  display: block;
  width: 15%;
  float: left;
  height: 50px;
  line-height: 50px;
  font-weight: 600;
  font-size: 18px;
}
.field-box {
  display: block;
  width: 83%;
  float: right;
  height: 50px;
  line-height: 50px;
  border: 1px solid rgb(211, 201, 201);
  border-radius: 10px;
  padding: 0;
}
.field-content {
  margin-left: 30px;
  font-weight: 400;
  font-size: 18px;
  position: relative;
}
.input-content {
  height: 46px;
  line-height: 46px;
  border: none;
  padding: 0;
  margin: 0;
  width: 95%;
  outline: none;
  position: absolute;
  top: 1px;
}
.btn-close-edit {
  /* background: orange; */
  width: 100%;
  height: 50px;
  display: block;
  margin-top: 10px;
  text-align: center;
}
.submit {
  background: rgb(248, 44, 37);
  border: 1px solid rgb(211, 201, 201);
  width: 140px;
  height: 50px;
  border-radius: 10px;
  font-size: 18px;
  font-weight: 600;
  color: white;
}
.edit-detail {
  width: 30px;
  height: 30px;
  float: right;
  margin-right: 10px;
  margin-top: 10px;
}
.edit-detail:hover {
  cursor: pointer;
}
.notification-span {
  display: block;
}
.select-campus {
  outline: none;
  border: none;
}
</style>