<template>
  <div
    id="faqs-help-add-edit-modal-content"
    class="faqs-help-add-edit-modal-content"
  >
    <div class="top">
      <div class="title">
        <div class="label">Title</div>
        <div class="value">
          <input
            v-model="dataFill.title"
            type="text"
            autocomplete="off"
            spellcheck="false"
            placeholder="Enter title..."
          />
        </div>
      </div>
    </div>
    <div class="description-view">
      <div class="label">Description</div>
      <div class="value">
        <Editor v-model="dataFill.description" placeholder="Enter text..."
          editorStyle="height: 100%" />
      </div>
    </div>
    <div class="actions">
      <button class="save">
        <span>Save</span>
      </button>
      <button class="cancel" @click="close()">
        <span>Cancel</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Editor from "primevue/editor";

export default defineComponent({
  name: "faqs-help-add-edit-modal-content",
  components: {
    Editor
  },
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      dataFill:
        this.isAdd == true
          ? {
              title: "",
              description: null,
            }
          : {
              title: this.data.title,
              description: this.data.description,
            },
    };
  },
  methods: {
    addFile() {
      this.$refs.inputFile.click();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      files.forEach((e) => {
        this.dataFill.fileData.push(e);
      });
      event.target.value = null;
    },
    removeFile(file) {
      const index = this.dataFill.fileData.indexOf(file);
      if (index >= 0) {
        this.dataFill.fileData.splice(index, 1);
      }
    },
    close() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/help/add-edit.scss";
</style>
