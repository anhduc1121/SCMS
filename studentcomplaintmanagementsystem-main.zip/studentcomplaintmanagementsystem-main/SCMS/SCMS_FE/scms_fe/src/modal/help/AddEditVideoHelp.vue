<template>
  <div
    id="faqs-help-add-edit-modal-content"
    class="faqs-help-add-edit-modal-content video-content"
  >
    <div class="ctn">
      <div class="top">
        <div class="title">
          <div class="label">Title</div>
          <div class="value">
            <input
              v-model="dataFill.title"
              type="text"
              autocomplete="off"
              spellcheck="false"
              placeholder="Enter title..."
            />
          </div>
        </div>
      </div>
      <div class="description-view">
        <div class="label">Description</div>
        <div class="value">
          <Editor
            v-model="dataFill.description"
            placeholder="Enter text..."
            editorStyle="height: 100%"
          />
        </div>
      </div>
      <div class="top">
        <div class="title">
          <div class="label">Youtube</div>
          <div class="value">
            <input
              v-model="dataFill.youtubeUrl"
              type="text"
              autocomplete="off"
              spellcheck="false"
              placeholder="Enter title..."
            />
          </div>
        </div>
      </div>
      <div class="video">
        <iframe
          width="560"
          height="315"
          :src="'https://www.youtube.com/embed/' + dataFill.youtubeUrl"
          title="YouTube video player"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerpolicy="strict-origin-when-cross-origin"
          allowfullscreen
        ></iframe>
      </div>
    </div>
    <div class="actions">
      <button class="save">
        <span>Save</span>
      </button>
      <button class="cancel" @click="close()">
        <span>Cancel</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Editor from "primevue/editor";

export default defineComponent({
  name: "faqs-help-add-edit-modal-content",
  components: {
    Editor,
  },
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      dataFill:
        this.isAdd == true
          ? {
              title: "",
              description: null,
              youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
            }
          : {
              title: this.data.title,
              description: this.data.description,
              youtubeUrl: this.data.youtubeUrl,
            },
    };
  },
  methods: {
    addFile() {
      this.$refs.inputFile.click();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      files.forEach((e) => {
        this.dataFill.fileData.push(e);
      });
      event.target.value = null;
    },
    removeFile(file) {
      const index = this.dataFill.fileData.indexOf(file);
      if (index >= 0) {
        this.dataFill.fileData.splice(index, 1);
      }
    },
    close() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/help/add-edit.scss";
</style>
