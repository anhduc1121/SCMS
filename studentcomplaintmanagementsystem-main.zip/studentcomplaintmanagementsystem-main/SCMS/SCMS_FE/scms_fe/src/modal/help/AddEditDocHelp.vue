<template>
  <div
    id="doc-help-add-edit-modal-content"
    class="doc-help-add-edit-modal-content"
  >
    <div class="top">
      <div class="title">
        <div class="label">Title</div>
        <div class="value">
          <input
            v-model="dataFill.title"
            type="text"
            autocomplete="off"
            spellcheck="false"
            placeholder="Enter title..."
          />
        </div>
      </div>
      <div class="add">
        <div class="label">&nbsp;</div>
        <button @click="addFile">
          <span>Add File</span>
        </button>
        <input
          ref="inputFile"
          type="file"
          multiple
          hidden
          @change="choosenAttachment($event)"
        />
      </div>
    </div>
    <div class="file-list">
      <div class="label">File</div>
      <div class="value">
        <template v-for="(item, index) in dataFill.fileData" :key="index">
          <div class="item" :class="{ 'bg-color': index % 2 != 0 }">
            <div class="remove" @click="removeFile(item)">
              <i class="fa-solid fa-xmark"></i>
            </div>
            <div class="name">{{ item.name }}</div>
          </div>
        </template>
      </div>
    </div>
    <div class="actions">
      <button class="save">
        <span>Save</span>
      </button>
      <button class="cancel" @click="close()">
        <span>Cancel</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "doc-help-add-edit-modal-content",
  components: {},
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      dataFill:
        this.isAdd == true
          ? {
              title: "",
              fileData: [],
            }
          : {
              title: this.data.title,
              fileData: [],
            },
    };
  },
  methods: {
    addFile() {
      this.$refs.inputFile.click();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      files.forEach((e) => {
        this.dataFill.fileData.push(e);
      });
      event.target.value = null;
    },
    removeFile(file) {
      const index = this.dataFill.fileData.indexOf(file);
      if (index >= 0) {
        this.dataFill.fileData.splice(index, 1);
      }
    },
    close() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/help/add-edit.scss";
</style>
