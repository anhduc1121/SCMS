<template>
  <div
    id="support-help-add-edit-modal-content"
    class="support-help-add-edit-modal-content"
  >
    <div class="top top-1">
      <div class="title">
        <div class="label">Contact</div>
        <div class="value">
          <input
            v-model="dataFill.title"
            type="text"
            autocomplete="off"
            spellcheck="false"
            placeholder="Enter title..."
          />
        </div>
      </div>
    </div>
    <div class="top top-2">
      <div class="title">
        <div class="label">Type</div>
        <div class="value">
          <select>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
            <option value="1">Type 1</option>
          </select>
        </div>
      </div>
    </div>
    <div class="actions">
      <button class="save">
        <span>Save</span>
      </button>
      <button class="cancel" @click="close()">
        <span>Cancel</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "support-help-add-edit-modal-content",
  components: {},
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      dataFill:
        this.isAdd == true
          ? {
              title: "",
              type: null,
            }
          : {
              title: this.data.title,
              type: this.data.type,
            },
    };
  },
  methods: {
    addFile() {
      this.$refs.inputFile.click();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      files.forEach((e) => {
        this.dataFill.fileData.push(e);
      });
      event.target.value = null;
    },
    removeFile(file) {
      const index = this.dataFill.fileData.indexOf(file);
      if (index >= 0) {
        this.dataFill.fileData.splice(index, 1);
      }
    },
    close() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/help/add-edit.scss";
</style>
