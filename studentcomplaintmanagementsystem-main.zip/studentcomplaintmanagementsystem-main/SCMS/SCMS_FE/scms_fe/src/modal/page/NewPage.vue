<template>
  <div class="new-page-modal-content have-loading">
    <div class="info">
      <div class="item">
        <div class="label">
          {{ $t("pageSystem.name") }} <span class="text-red">*</span>
        </div>
        <div class="value">
          <input
            v-model="pageSelect.pageName"
            type="text"
            autocomplete="off"
            spellcheck="false"
          />
        </div>
      </div>
      <div class="add-func-btn" v-if="!isAdd">
        <button @click="addFunction()">
          <span>{{ $t("button.addNewFunction") }}</span>
        </button>
      </div>
    </div>
    <!--   v-if="listFunction.length"  -->
    <div v-if="listFunction.length" class="functions have-loading">
      <div class="label">{{ $t("label.listFunction") }}</div>
      <div class="value">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="name">
              <div class="th-sort" @click="toogleSort('name')">
                <span class="label">{{ $t("table.name") }}</span>
              </div>
            </th>
            <th class="description">
              <div class="th-sort" @click="toogleSort('description')">
                <span class="label">{{ $t("table.description") }}</span>
              </div>
            </th>
            <th class="role">
              <div class="th-sort" @click="toogleSort('role')">
                <span class="label">{{ $t("table.role") }}</span>
              </div>
            </th>
            <th class="item-actions"></th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in listFunction" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td class="text-start">{{ item.pageCrudName }}</td>
              <!-- <td class="text-start">{{ item.pageCrudDescription }}</td> -->
              <td class="text-start">{{ item.pageCrudId }}</td>
              <td class="text-start">{{ item.roleNames.join(", ") }}</td>
              <td class="star-item item-actions">
                <button class="edit" @click="editFunction(item, $event)">
                  <i style="color: #fff !important" class="fa-solid fa-pen"></i>
                </button>
                <!-- <button class="delete">
                  <i
                    style="color: #fff !important"
                    class="fa-solid fa-xmark"
                  ></i>
                </button> -->
              </td>
            </tr>
          </template>
        </table>
      </div>
      <Loading v-if="loadingSections.loadFunction" :isFullScreen="false" />
    </div>
    <div class="actions">
      <button class="save" @click="onsubmit()">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button class="cancel" @click="cancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
// import { SORT } from "@/core/const/app.const.js";
// import { FUNCTIONS } from "@/mock/functions.mock.js";
import PageSystemAPIService from "@/script/services/PageSystemAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";

export default defineComponent({
  name: "new-page-modal-content",
  components: { Loading },
  props: { data: Object, isAdd: Boolean, isReload: Boolean },
  data() {
    return {
      listFunction: [],
      pageSelect: {
        pageId: "",
        pageName: "",
        createDate: "",
      },
      loadingSections: {
        section1: false,
        loadFunction: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      pageData: this.isAdd
        ? {
            title: "",
            functions: [],
          }
        : {
            title: this.data.title,
            functions: [],
          },
    };
  },
  watch: {
    isReload(newValue, oldValue) {
      console.log("Message changed from", oldValue, "to", newValue);
      this.getFuntionPage();
    },
  },
  async created() {
    this.toast = useToast();
    if (this.data != null) {
      this.pageSelect = this.data;
      this.getListFunction();
    }
    this.getFuntionPage();
  },
  methods: {
    getListFunction() {},
    async onsubmit() {
      if (this.isAdd) {
        this.onSubmitAdd();
      } else {
        this.onSubmitEdit();
      }
    },

    async getFuntionPage() {
      if (!this.isAdd) {
        this.loadingSections.loadFunction = true;

        const formData = new FormData();
        formData.append("pageCrudId", this.pageSelect.pageId);

        const res = await PageSystemAPIService.loadFunctionPageCrud(formData);
        if (res != null) {
          // this.toast("Update data successfully", {
          //   type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          // });
          this.listFunction = res.data;
          // console.log(res)
          this.loadingSections.loadFunction = false;
        } else {
          // this.toast("Update data error", {
          //   type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          // });
          this.loadingSections.loadFunction = false;
        }
      }
    },
    async onSubmitEdit() {
      this.loadingSections.section1 = true;
      const formData = new FormData();
      formData.append("PageName", this.pageSelect.pageName.trim());
      formData.append("PageId", this.pageSelect.pageId.trim());

      const res = await PageSystemAPIService.updatePages(formData);
      if (res != null) {
        this.toast(this.$t("toast.Common.mess8"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });
        this.$emit("cancel");
        this.loadingSections.section1 = false;
      } else {
        this.toast(this.$t("toast.Common.mess9"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },
    async onSubmitAdd() {
      this.loadingSections.section1 = true;
      const formData = new FormData();
      formData.append("PageName", this.pageSelect.pageName.trim());
      formData.append("PageId", this.pageSelect.pageId.trim());

      const res = await PageSystemAPIService.addPage(formData);
      if (res != null) {
        this.toast(this.$t("toast.Common.mess2"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });
        this.$emit("cancel");
        this.loadingSections.section1 = false;
      } else {
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },
    addFunction() {
      this.$emit("add-function", this.pageSelect);
    },
    editFunction(item, event) {
      event.stopPropagation();
      this.$emit("edit-function", item);
    },
    cancel() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/page/new-page";
</style>
