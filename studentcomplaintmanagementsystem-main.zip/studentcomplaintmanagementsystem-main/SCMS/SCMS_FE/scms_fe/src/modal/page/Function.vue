<template>
  <div class="function-modal-content have-loading">
    <div class="item">
      <div class="label">{{ $t("label.name") }}</div>
      <div class="value">
        <input
          v-model="functionData.name"
          type="text"
          autocomplete="off"
          spellcheck="false"
        />
      </div>
    </div>
    <div class="item">
      <div class="label">{{ $t("label.description") }}</div>
      <div class="value">
        <textarea
          v-model="functionData.description"
          autocomplete="off"
          spellcheck="false"
        ></textarea>
      </div>
    </div>
    <div class="item">
      <div class="label">{{ $t("label.roleAccepted") }}</div>
      <div class="value have-loading">
        <div class="role-list">
          <template v-for="(role, index) in functionData.roles" :key="index">
            <div class="role" @click="toogleRole(role, $event)">
              <div class="name">{{ role.name }}</div>
              <div class="selected">
                <input
                  type="checkbox"
                  v-model="role.isSelected"
                  @click="toogleRole(role, $event)"
                />
              </div>
            </div>
          </template>
        </div>
        <Loading v-if="loadingSections.roleAccpect" :isFullScreen="false" />
      </div>
    </div>
    <div class="actions">
      <button class="save" @click="onSubmit()">
        <span>{{ $t("button.save") }}</span>
      </button>
      <button class="cancel" @click="cancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import PageSystemAPIService from "@/script/services/PageSystemAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";

export default defineComponent({
  name: "function-modal",
  components: { Loading },
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      functionData: {
        pageId: "",
        pageCrudId: "",
        name: "",
        description: "",
        roles: [],
      },
      loadingSections: {
        section1: false,
        roleAccpect: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    if (this.data != null) {
      if (this.isAdd) {
        this.functionData.pageId = this.data.pageId;
      } else {
        this.functionData.pageCrudId = this.data.pageCrudId;
        this.functionData.name = this.data.pageCrudName;
        this.functionData.description = this.data.pageCrudDescription;
      }
    }

    this.getRoleFunction();
  },
  methods: {
    async onSubmit() {
      if (this.isAdd) {
        this.onSubmitAdd();
      }else{
        this.onSubmitEdit();
      }
    },
    async onSubmitEdit() {
      this.loadingSections.section1 = true;

      const formData = new FormData();
      formData.append("PageCrudId", this.functionData.pageCrudId);
      formData.append("PageCrudName", this.functionData.name);
      formData.append("PageCrudDescription", this.functionData.description);

      if (this.functionData.roles.length > 0) {
        var count =0;
        this.functionData.roles.forEach((role) => {
          // Thực hiện các hành động với từng role trong this.functionData.roles
          if (role.isSelected) { 
            formData.append(`RoleIds[${count}]`, role.id);
            count = count +1;
          }
        });
      }

      const res = await PageSystemAPIService.updatePageCrud(formData);
      if (res != null) {
        this.toast(this.$t("toast.Common.mess8"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });

        this.loadingSections.section1 = false;

        this.$emit("reloadPageDetail", null);
      } else {
        this.toast(this.$t("toast.Common.mess9"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },

    async onSubmitAdd() {
      this.loadingSections.section1 = true;
      const formData = new FormData();
      formData.append("PageId", this.functionData.pageId);
      formData.append("PageCrudName", this.functionData.name);
      formData.append("PageCrudDescription", this.functionData.description);

      if (this.functionData.roles.length > 0) {
        var count =0;
        this.functionData.roles.forEach((role) => {
          // Thực hiện các hành động với từng role trong this.functionData.roles
          if (role.isSelected) { 
            formData.append(`RoleIds[${count}]`, role.id);
            count = count +1;
          }
        });
      }

      const res = await PageSystemAPIService.createPageCrud(formData);
      if (res != null) {
        this.toast(this.$t("toast.Common.mess2"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });

        this.loadingSections.section1 = false;

        this.$emit("reloadPageDetail", null);
      } else {
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }

    },
    async getRoleFunction() {
      this.loadingSections.roleAccpect = true;
      const formData = new FormData();
      formData.append("id", this.functionData.pageCrudId);

      const res = await PageSystemAPIService.getRoleAccpect(formData);
      if (res != null) {
        // this.toast(this.$t("toast.Common.mess3"), {
        //   type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        // });
        this.functionData.roles = res.data;
        this.loadingSections.roleAccpect = false;
      } else {
        this.toast(this.$t("toast.Common.mess10"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.roleAccpect = false;
      }
    },
    toogleRole(role, event) {
      event.stopPropagation();
      role.isSelected = !role.isSelected;
    },
    cancel() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/page/function";
</style>
