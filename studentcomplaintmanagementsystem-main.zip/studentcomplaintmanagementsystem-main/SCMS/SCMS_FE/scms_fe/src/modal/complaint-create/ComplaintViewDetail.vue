<template>
  <div
    id="complaint-view-only-modal-content"
    class="complaint-view-only-modal-content have-loading"
  >
    <div class="category">
      <span>{{ this.complaintSuggestData.categoryName }}</span>
    </div>
    <div class="title">
      <div class="tt-content" >{{ this.complaintSuggestData.title }}</div>
    </div>
    <div class="question">
      <div v-html="this.complaintSuggestData.description"></div>
    </div>
    <div class="chat">
      <template v-for="(item, i) in data" :key="i">
        <div v-if="item.columView == 1" class="chat-item">
          <div class="chat-content">
            <div
              v-if="item.attachments && item.attachments.length > 0"
              class="attachments"
            >
              <template v-for="(file, f) in item.attachments" :key="f">
                <div class="file">
                  <div class="icon">
                    <i class="fa-regular fa-file"></i>
                  </div>
                  <div class="name"> <a target="_blank" :href="file.link">{{ file.name }}</a></div>
                </div>
              </template>
            </div>
            <div class="text">{{ item.content }}</div>
          </div>
        </div>
        <div v-else class="chat-item right">
          <div class="chat-content">
            <div
              v-if="item.attachments && item.attachments.length > 0"
              class="attachments"
            >
              <template v-for="(file, f) in item.attachments" :key="f">
                <div class="file">
                  <div class="icon">
                    <i class="fa-regular fa-file"></i>
                  </div>
                  <div class="name"> <a target="_blank" :href="file.link">{{ file.name }}</a></div>
                </div>
              </template>
            </div>
            <div class="text">{{ item.content }}</div>
          </div>
        </div>
      </template>
    </div>
    <div class="actions">
      <button @click="close()">
        <span>{{ $t("button.close") }}</span>
      </button>
    </div>
    <Loading v-if="this.loadingSections.section1" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
// import { CHAT_DATA_MOCK } from "@/mock/chat-data.mock.js";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import SuggestionAPIService from "@/script/services/SuggestionAPIService";

export default defineComponent({
  name: "complaint-view-only-modal-content",
  components: { Loading },
  props: {
    complaintSuggest: Object,
    category: String,
  },
  data() {
    return {
      data: [],
      categoryData: "",
      complaintSuggestData: {
        title: "",
        description: "",
        categoryName: ""
      },
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    if (this.complaintSuggest != null && this.complaintSuggest != undefined) {
      this.getSuggest();
    }
  },

  methods: {
    async getSuggest() {
      this.loadingSections.section1 = true;
      const res = await SuggestionAPIService.getSuggestDetailById(
        this.complaintSuggest.ticketSuggestionId
      );
      if (res != null) {
        // console.log(res);
        this.complaintSuggestData = {
          title: res.data.title,
          description: res.data.description,
          categoryName: res.data.categoryName
        };

        this.data = res.data.ticketSuggestionDetailReponVMs;

        this.loadingSections.section1 = false;
      } else {
        this.toast(this.$t("toast.Common.mess5"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },
    close() {
      this.$emit("close");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/complaint-create/complaint-view-only";
</style>
