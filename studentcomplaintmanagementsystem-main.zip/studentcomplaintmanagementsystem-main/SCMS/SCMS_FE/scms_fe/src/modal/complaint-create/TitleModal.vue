<template>
  <div id="title-modal-complaint" class="title-modal-complaint">
    <div class="title">{{ $t("mess.messCreateComplaint1")}} {{ this.data.length }} {{$t("mess.messCreateComplain2")}}</div>
    <div class="content">
      <table>
        <tr class="header">
          <th class="no">{{ $t('table.no') }}</th>
          <th>{{ $t('table.title') }}</th>
          <th class="created-date">{{ $t('table.createDate') }}</th>
          <th class="eye"></th>
        </tr>
        <template v-for="(item, i) in data" :key="i">
          <tr>
            <td>{{ i + 1 }}</td>
            <td class="text-start">{{ item.title }}</td>
            <td>{{ this.formatDateFull(item.createDate)}}</td>
            <td class="eye" @click="viewComplaintDetails(item)">
              <i class="fa-solid fa-eye"></i>
            </td>
          </tr>
        </template>
      </table>
    </div>
    <!-- <div class="message">{{ $t('span.continue') }}</div> -->
    <div class="actions">
      <button class="no" @click="cancel()">
        <span>{{ $t('button.cancel') }}</span>
      </button>
      <!-- <button class="yes" @click="submit()">
        <span>{{ $t('button.continue') }}</span>
      </button> -->
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { TITLE_RESULT_MOCK_DATA } from "@/mock/title-result.mock.js";
import ComplaintSuggestionAPIService from "@/script/services/ComplaintSuggestionAPIService";

export default defineComponent({
  name: "title-modal-complaint",
  components: {},
  props: {
    categoryId: String,
    title: String
  },
  data() {
    return {
      data: TITLE_RESULT_MOCK_DATA,
      categoryDataId: '',
      titleData: ''
    };
  },
  async created() {
    if (this.categoryId != null && this.categoryId != undefined) {
      this.categoryDataId = this.categoryId;
    }

    if (this.title != null && this.title != undefined) {
      this.titleData = this.title;
    }

    this.getComplaintSuggest();
  },
  methods: {
    formatDateFull(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },

    async getComplaintSuggest() {
      const res = await ComplaintSuggestionAPIService.getComplaintByCategoryAndTitle(this.categoryDataId, this.titleData.trim())
      if (res != null) {
        this.data = res.data
      }
    },
    submit() {
      this.$emit("submit");
    },
    cancel() {
      this.$emit("cancel");
    },
    viewComplaintDetails(item) {
      this.$emit("view-details", item);
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/complaint-create/title-modal";
</style>
