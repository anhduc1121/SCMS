<template>
  <div
    id="complaint-view-only-modal-content"
    class="complaint-view-only-modal-content"
  >
  
    <div class="chat">
      <template v-for="(item, i) in this.complaintSuggestData.dataMock" :key="i">
        <div v-if="item.columView == '1'" class="chat-item">
          <div class="chat-content">
            <div
              v-if="item.attachments && item.attachments.length > 0"
              class="attachments"
            >
              <template v-for="(file, f) in item.attachments" :key="f">
                <div class="file">
                  <div class="icon">
                    <i class="fa-regular fa-file"></i>
                  </div>
                  <div class="name"><a target="_blank" :href="file.link">{{ file.name }}</a></div>
                </div>
              </template>
            </div>
            <div class="text">{{ item.comment }}</div>
          </div>
        </div>
        <div v-else class="chat-item right">
          <div class="chat-content">
            <div
              v-if="item.attachments && item.attachments.length > 0"
              class="attachments"
            >
              <template v-for="(file, f) in item.attachments" :key="f">
                <div class="file">
                  <div class="icon">
                    <i class="fa-regular fa-file"></i>
                  </div>
                  <div class="name"><a target="_blank" :href="file.link">{{ file.name }}</a></div>
                </div>
              </template>
            </div>
            <div class="text">{{ item.comment }}</div>
          </div>
          
        </div>
      </template>
    </div>
    <div class="actions">
      <button @click="close()">
        <span>{{ $t("button.close")}}</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { CHAT_DATA_MOCK } from "@/mock/chat-data.mock.js";

export default defineComponent({
  name: "complaint-view-only-modal-content",
  components: {},
  props: {
    complaintSuggest: Object,
    category: String
  },
  data() {
    return {
      yourId: "2acfa539-86ca-4963-a0de-b3df65d39e59",
      data: CHAT_DATA_MOCK,
      categoryData: '',
      complaintSuggestData: null
    };
  },
  async created() {
    if(this.category != null && this.category != undefined){
      this.categoryData = this.category
    }
    if(this.complaintSuggest != null && this.complaintSuggest != undefined){
      this.complaintSuggestData = this.complaintSuggest
    }
  },
  methods: {
    close() {
      this.$emit("close");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/complaint-create/complaint-view-only";
</style>
