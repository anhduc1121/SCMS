<template>
  <div class="chat-edit-modal-content have-loading">
    <div id="suggestion-chat-edit-modal" class="suggestion-chat-edit-modal">
      <draggable
        v-model="data"
        class="drag-area"
        group="suggestions"
        @start="dragging = true"
        @end="dragging = false"
        item-key="id"
      >
        <template #item="{ element, index }">
          <div class="drag-item">
            <!--other-->
            <!--your message-->
            <!--with out attachment-->
            <div
              class="chat-line chat-right"
              v-if="element.attachments.length == 0"
              :class="{
                'content-only': checkShowAvatar(index, element.id) == false,
              }"
            >
              <div
                class="chat-content"
                :class="{ editting: element.editStatus }"
              >
                <!--Không ở chế độ chỉnh sửa-->
                <template v-if="!element.editStatus">
                  <span>{{ element.content }}</span>
                  <div class="edit-btn" @click="element.editStatus = true">
                    <button>
                      <i class="fa-solid fa-pen"></i>
                    </button>
                  </div>
                </template>
                <!--Ở chế độ chỉnh sửa-->
                <template v-if="element.editStatus">
                  <textarea
                    type="text"
                    v-model="element.content"
                    rows="3"
                    autocomplete="off"
                    spellcheck="false"
                  >
                  </textarea>
                  <div class="save-btn" @click="handleSaveClick(element)">
                    <button>
                      <i class="fa-solid fa-floppy-disk"></i>
                    </button>
                  </div>
                </template>
                <!--Add attachment-->
                <div class="attach-btns">
                  <button @click="addAttachment(element)">
                    <i class="fa-solid fa-paperclip"></i>
                  </button>
                </div>
                <div class="remove-btn">
                  <button @click="removeSuggestIndex(element)">
                    <i class="fa-solid fa-xmark"></i>
                  </button>
                </div>
              </div>
            </div>
            <!--with attachment-->
            <div
              v-else
              :class="{
                'content-only': checkShowAvatar(index, element.id) == false,
              }"
              class="chat-line chat-right"
            >
              <div
                class="chat-content have-attachment"
                :class="{ editting: element.editStatus }"
              >
                <!--Attachments-->
                <template v-for="(attach, i) in element.attachments" :key="i">
                  <span class="content-attachment">
                    <button
                      class="file-delete"
                      @click="removeFile(element, attach)"
                    >
                      <i class="dl-right fa-solid fa-xmark"></i>
                    </button>
                    <div class="file-view" @click="downloadFile(attach.link)">
                      <i class="fa-regular fa-file"></i>
                      {{ showAttachName(attach.name) }}
                    </div>
                  </span>
                </template>
                <!--Không ở chế độ chỉnh sửa-->
                <template v-if="!element.editStatus">
                  <span class="mess">{{ element.content }}</span>
                  <div class="edit-btn" @click="element.editStatus = true">
                    <button>
                      <i class="fa-solid fa-pen"></i>
                    </button>
                  </div>
                </template>
                <!--Ở chế độ chỉnh sửa-->
                <template v-if="element.editStatus">
                  <textarea
                    type="text"
                    v-model="element.content"
                    rows="3"
                    autocomplete="off"
                    spellcheck="false"
                  >
                  </textarea>
                  <div class="save-btn" @click="element.editStatus = false">
                    <button>
                      <i class="fa-solid fa-floppy-disk"></i>
                    </button>
                  </div>
                </template>

                <!--Add attachment-->
                <div class="attach-btns">
                  <button @click="addAttachment(element)">
                    <i class="fa-solid fa-paperclip"></i>
                  </button>
                </div>
                <div class="remove-btn">
                  <button @click="removeSuggestIndex(element)">
                    <i class="fa-solid fa-xmark"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </template>
      </draggable>
    </div>
    <!--Thêm mới Suggestion-->
    <div v-if="isAddSuggestion" class="add-suggestion">
      <div class="text">
        <textarea
          v-model="newSuggestion.content"
          autocomplate="off"
          spellcheck="false"
          :placeholder="$t('placeholder.message')"
        ></textarea>
      </div>
      <template v-if="newSuggestion.attachments.length > 0">
        <div class="file">
          <template v-for="(file, i) in newSuggestion.attachments" :key="i">
            <div v-if="i < 2" class="file-item">
              <div class="file-remove">
                <button @click="removeFileForNewSugg(file)">
                  <i class="fa-solid fa-xmark"></i>
                </button>
              </div>
              <div class="file-name">{{ file.name }}</div>
            </div>
            <div v-if="i == 2" class="file-item">
              <div class="file-name more">
                ...(+{{ newSuggestion.attachments.length - 2 }})
              </div>
            </div>
          </template>
          <button class="add-file">
            <i class="fa-solid fa-paperclip"></i>
          </button>
        </div>
      </template>
    </div>
    <!--Hành động-->
    <div class="edit-mess-actions">
      <div class="add-sugg">
        <!--Bật thêm mới Suggestion-->
        <template v-if="!isAddSuggestion">
          <button class="add-sug-btn" @click="addSuggestion()">
            <i class="fa-solid fa-plus"></i>
            <span>{{ $t("button.addConversation") }}</span>
          </button>
        </template>
        <!--Hủy thêm mới Suggestion-->
        <template v-if="isAddSuggestion">
          <button
            class="add-sug-btn cancel-sug-btn"
            @click="cancelSuggestion()"
          >
            <span>{{ $t("button.cancel") }}</span>
          </button>
          <button class="add-sug-btn" @click="selectNewSuggestionFiles()">
            <span>{{ $t("button.uploadFile") }}</span>
          </button>
          <input
            type="file"
            multiple
            hidden
            ref="inputFileForAddSugg"
            @change="choosenAttachmentForNewSugg($event)"
          />
          <button
            class="add-sug-btn add-cfr-sug-btn"
            @click="submitNewSuggestion()"
          >
            <span>{{ $t("button.add") }}</span>
          </button>
        </template>
      </div>
      <button v-if="!isAddSuggestion" class="close" @click="closeModal()">
        <span>{{ $t("button.close") }}</span>
      </button>
      <button v-if="!isAddSuggestion" class="add" @click="onSubmit()">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button v-if="!isAddSuggestion" class="clear" @click="clearSuggest()">
        <span>{{ $t("button.clear") }}</span>
      </button>
    </div>
    <input
      ref="fileInput"
      type="file"
      multiple
      hidden
      @change="choosenAttachment($event)"
    />
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>

  <b-modal
    v-model="isShowDepartmentListModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.departmentList')"
    class="department-list-modal"
  >
    <DepartmentList
      v-if="isShowDepartmentListModal"
      :complaintId="this.id"
      :isChoice="isChoice"
      @select-complaint-department="submitForwardStaffOther"
      @cancel="closeDepartmentListModal"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import ComplaintAPIService from "@/script/services/ComplaintAPIService";
import draggable from "vuedraggable";
import DepartmentList from "@/modal/complaint-details/DepartmentList.vue";
import { BModal } from "bootstrap-vue-next";
import ComplaintDepartmentAPIService from "@/script/services/ComplaintDepartmentAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "suggestion-chat-edit-modal",
  components: {
    draggable,
    DepartmentList,
    BModal,
    Loading,
  },
  props: { dataMess: Array, id: String, isForwordDep: Boolean },
  data() {
    return {
      dragging: false,
      yourId: null,
      isForwardDepartment: false,
      isAddSuggestion: false,
      newSuggestion: {
        id: "",
        columView: "2",
        userIDChat: null,
        avatar: "",
        content: "",
        attachments: [],
      },
      data: [],
      isChoice: false,
      itemAddAttachment: null,
      category: null,
      description: "",
      isShowDepartmentListModal: false,
      complaintDepartmentId: "",
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      totalFilesSize: 0,
    };
  },
  watch: {},
  created() {
    this.toast = useToast();
    //this.data = [...this.dataMess];
    this.data = JSON.parse(JSON.stringify(this.dataMess));
    this.data.forEach((e) => {
      e.editStatus = false;
    });
    this.data.sort((a, b) => a.orderNumber - b.orderNumber);

    if (this.isForwordDep != null) {
      this.isForwardDepartment = this.isForwordDep;
    }
  },
  methods: {
    handleSaveClick(element) {
      // Gọi hàm filterData để lọc mảng this.data
      this.filterData();

      // Xử lý các bước tiếp theo
      element.editStatus = false;
      // Các xử lý khác (nếu có)
    },
    closeDepartmentListModal() {
      this.isShowDepartmentListModal = false;
    },

    //Begin:: Top
    // openSelectCategoryModal() {
    //   this.$emit("select-category");
    // },
    //End:: Top

    //Begin:: Add Suggestion
    addSuggestion() {
      this.isAddSuggestion = true;
    },
    clearSuggest() {
      this.data = [];
    },
    cancelSuggestion() {
      this.isAddSuggestion = false;
    },
    selectNewSuggestionFiles() {
      this.$refs.inputFileForAddSugg.click();
    },
    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    choosenAttachmentForNewSugg(event) {
      const files = event.target.files;
      this.totalFilesSize = 0;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.newSuggestion.attachments.push({
              id: "",
              name: file.name,
              link: "",
              type: file.type,
              file: file,
              description: "",
              fileId: "",
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },
    removeFileForNewSugg(item) {
      const index = this.newSuggestion.attachments.indexOf(item);
      if (index >= 0) {
        this.newSuggestion.attachments.splice(index, 1);
      }
      this.filterData();
    },
    submitNewSuggestion() {
      if (
        this.newSuggestion.content == "" &&
        this.newSuggestion.attachments.length == 0
      ) {
        return;
      }

      this.data.push(this.newSuggestion);
      //Reset dữ liệu của suggestion mới
      this.newSuggestion = {
        id: "",
        columView: "2",
        userIDChat: null,
        avatar: "",
        content: "",
        attachments: [],
      };
      this.isAddSuggestion = false;
    },
    //End:: Add Suggestion

    showAttachName(name) {
      if (!name) return name;
      if (name.length > 30) return `${name.substring(0, 30)}...`;
      return name;
    },
    checkShowAvatar(index, id) {
      //nếu 2 tin nhắn liên tiếp đến từ 1 người thì chỉ hiện ảnh dại diện ở tin đầu tiên
      if (index == 0) return true;
      if (this.data[index - 1].id == id) return false;
      return true;
    },
    removeFile(item, file) {
      const index = item.attachments.indexOf(file);
      if (index >= 0) {
        item.attachments.splice(index, 1);
      }
      this.filterData();
    },
    addAttachment(item) {
      this.itemAddAttachment = item;
      this.$refs.fileInput.click();
    },
    removeSuggestIndex(item) {
      // Tìm vị trí của phần tử cần xóa trong mảng
      const index = this.data.indexOf(item);

      // Nếu phần tử được tìm thấy trong mảng
      if (index !== -1) {
        // Xóa 1 phần tử từ vị trí index
        this.data.splice(index, 1);
      }
      this.filterData();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      this.totalFilesSize = 0;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.itemAddAttachment.attachments.push({
              id: "",
              name: file.name,
              link: "",
              type: file.type,
              file: file,
              description: "",
              fileId: "",
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },
    downloadFile(id) {
      //chỉ có thể tải tệp khi không ở chế độ chọn Suggestion
      if (this.addSuggestionStatus) return;
      if (id == null || id == undefined) {
        this.toast("Open file error. Cannot open the just uploaded file ", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }
      window.location.href = `${id}`;
    },
    closeModal() {
      this.$emit("close");
    },
    filterData() {
      // Tạo một mảng mới lưu trữ các object đã lọc
      const filteredData = this.data.filter((item) => {
        // Kiểm tra nếu comment không rỗng hoặc attachments không rỗng
        if (
          item.content !== "" ||
          (item.attachments && item.attachments.length > 0)
        ) {
          return true; // Giữ lại object này
        }
        return false; // Loại bỏ object này
      });

      // Gán lại mảng đã lọc cho this.data
      this.data = filteredData;
    },
    async onSubmit() {
      if (this.data == null) {
        this.toast(this.$t("toast.Common.mess1"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      this.filterData();

      if (this.data != null && this.data.length === 0) {
        this.toast(this.$t("toast.Common.mess1"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      // sent student
      if (!this.isForwardDepartment) {
        this.forwardStudent();
      } else {
        this.forwardStaffOther();
      }
    },
    async forwardStudent() {
      const formData = new FormData();
      formData.append("TicketId", this.id);

      this.data.forEach((item, index) => {
        if (item.content != null) {
          formData.append(
            `ticketCommentReplyVMs[${index}].comment`,
            item.content
          );
        }
        formData.append(`ticketCommentReplyVMs[${index}].ticketId`, this.id);

        if (item.attachments != null && item.attachments.length > 0) {
          item.attachments.forEach((attachment, indexAttachment) => {
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].description`,
              attachment.description
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].file`,
              attachment.file
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].id`,
              attachment.id
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].link`,
              attachment.link
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].name`,
              attachment.name
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].type`,
              attachment.type
            );
            formData.append(
              `ticketCommentReplyVMs[${index}].attachments[${indexAttachment}].fileId`,
              attachment.fileId
            );
          });
        }
      });
      this.loadingSections.section1 = true;
      const res = await ComplaintAPIService.replyComplaintStaffs(formData);

      if (res != null && res.message == "CREATE_SUCCESS") {
        this.toast(this.$t("toast.Common.mess2"), {
          type: TYPE.success, // or "success", "error", "default", "info" and "warning"
        });

        this.$emit("close-reloadData");

        this.$router.push(`/complaint/details/${this.id}`);
      } else {
        this.loadingSections.section1 = false;
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },

    async forwardStaffOther() {
      this.isChoice = true;
      this.isShowDepartmentListModal = true;
    },

    async submitForwardStaffOther(id) {
      this.isShowDepartmentListModal = false;

      const formData = new FormData();
      formData.append("TicketDepartmentId", id);

      // console.log(this.data);
      this.data.forEach((item, index) => {
        // console.log(item.comment, "s" + index);
        if (item.content != null) {
          formData.append(
            `ticketDepartmentCommentReplyVMs[${index}].comment`,
            item.content
          );
        }

        formData.append(
          `ticketDepartmentCommentReplyVMs[${index}].ticketId`,
          this.id
        );

        if (item.attachments != null && item.attachments.length > 0) {
          item.attachments.forEach((attachment, indexAttachment) => {
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].description`,
              attachment.description
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].file`,
              attachment.file
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].id`,
              attachment.id
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].link`,
              attachment.link
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].name`,
              attachment.name
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].type`,
              attachment.type
            );
            formData.append(
              `ticketDepartmentCommentReplyVMs[${index}].attachments[${indexAttachment}].fileId`,
              attachment.fileId
            );
          });
        }
      });
      this.loadingSections.section1 = true;

      const res = await ComplaintDepartmentAPIService.replyTicketStaffs(
        formData
      );
      // console.log(res);
      if (res != null) {
        this.loadingSections.section1 = false;
        if (res.message == "CREATE_SUCCESS") {
          this.toast(this.$t("toast.Common.mess2"), {
            type: TYPE.success, // or "success", "error", "default", "info" and "warning"
          });

          // this.$emit("close-reloadData");
          this.$router.push(`/department-complaint/details/${id}`);
        }
      } else {
        this.loadingSections.section1 = false;
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },
  },
  computed: {},
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/forward-chat-edit.scss";
</style>
