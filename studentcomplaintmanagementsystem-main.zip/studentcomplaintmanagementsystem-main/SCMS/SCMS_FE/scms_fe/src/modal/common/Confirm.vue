<template>
  <div id="confirm-common-modal" class="confirm-common-modal">
    <div class="content">
      {{ config.content }}
    </div>
    <div class="actions">
      <button class="cancel" @click="cancel()">
        <span>{{$t('button.cancel')}}</span>
      </button>
      <button class="submit" @click="submit()">
        <span>{{$t('button.submit')}}</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "confirm-common-modal",
  components: {},
  props: {
    config: Object,
  },
  methods: {
    cancel() {
      this.$emit('cancel');
    },
    submit() {
      this.$emit('submit');
    }
  }
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/common/confirm.scss";
</style>
