<template>
  <div id="emp-permiss-modal" class="emp-permiss-modal">
    <table>
      <tr class="header">
        <th></th>
        <template v-for="(item, index) in dataPL" :key="index">
          <th>{{ item.label }}</th>
        </template>
      </tr>
      <template v-for="(item, index) in dataCL" :key="index">
        <tr>
          <td>{{ item.label }}</td>
          <template v-for="(pl, i) in dataPL" :key="i">
            <td>
              <div v-if="!isEditting" class="view">
                <i
                  v-if="isHavePermiss(item.id, pl.id)"
                  class="fa-solid fa-check"
                ></i>
              </div>
              <div
                v-else
                class="per-edit"
                @click="tooglePermission(item.id, pl.id, $event)"
              >
                <input
                  type="checkbox"
                  :checked="isHavePermiss(item.id, pl.id)"
                  @click="tooglePermission(item.id, pl.id, $event)"
                />
              </div>
            </td>
          </template>
        </tr>
      </template>
    </table>
    <div class="actions">
      <button class="cancel" @click="close()">
        <span>Cancel</span>
      </button>
      <button v-if="!isEditting" class="edit" @click="isEditting = true">
        <span>Edit</span>
      </button>
      <button v-if="isEditting" class="edit" @click="submit()">
        <span>Submit</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { DATA_PL, DATA_CL } from "@/mock/emp-permission.mock"

export default defineComponent({
  name: "emp-permiss-modal",
  props: { userId: String },
  data() {
    return {
      isEditting: false,
      dataPL: DATA_PL,
      dataCL: DATA_CL,
    };
  },
  methods: {
    isHavePermiss(clId, plId) {
      const cl = this.dataCL.find((f) => f.id == clId);
      if (cl) {
        const pl = cl.data.find((f) => f.id == plId);
        if (pl) {
          return pl.value;
        }
      }
      return false;
    },
    tooglePermission(clId, plId, event) {
      event.stopPropagation();
      const cl = this.dataCL.find((f) => f.id == clId);
      if (cl) {
        const pl = cl.data.find((f) => f.id == plId);
        if (pl) {
          pl.value = !pl.value;
        }
      }
    },
    close() {
      this.$emit("close");
    },
    submit() {
      //Submit
      //this.$emit("close");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/permission/emp-permission-modal.scss";
</style>
