<template>
  <div class="department-list-modal-content">
    <div class="table-view">
      <table>
        <!--Table: Header-->
        <tr class="header">
          <th class="no">{{ $t("table.no") }}</th>
          <th class="">
            <div class="th-sort" @click="toogleSort('name')">
              <span class="label">{{ $t("label.department") }}</span>
            </div>
          </th>
          <th class="">{{ $t("label.staff") }}</th>
          <th class="">{{ $t("table.otherStaff") }}</th>
          <th class="">{{ $t("label.createdDate") }}</th>
          <th class="">{{ $t("label.status") }}</th>
          <th class="table-action"></th>
        </tr>
        <!--Table: Body-->
        <template v-for="(item, index) in tableData" :key="index">
          <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
            <td>{{ index + 1 }}</td>
            <td>{{ item.departmentName }}</td>
            <td>{{ item.accountStaff }}</td>
            <td>{{ item.accountStaffOther }}</td>
            <td>{{ this.formatDateFull(item.createDate) }}</td>
            <td>{{ item.statusTicketName }}</td>
            <td>
              <div class="table-action">
                <button
                  class="edit"
                  @click="openMove(item.ticketDepartmentsId)"
                >
                  <span>{{ $t("button.move") }}</span>
                </button>
              </div>
            </td>
          </tr>
        </template>
      </table>
    </div>

    <div class="actions">
      <button class="cancel" @click="cancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Loading from "@/core/components/Loading.vue";
import ComplaintDepartmentAPIService from "@/script/services/ComplaintDepartmentAPIService";

export default defineComponent({
  name: "department-list-modal-content",
  components: { Loading },
  props: { complaintId: String, isChoice: Boolean },
  data() {
    return {
      tableData: [],
      loadingSections: {
        loadDepartment: false,
      },
    };
  },
  async mounted() {
    if (this.complaintId != null) {
      await this.getDepatment();
    }
  },
  methods: {
    formatDateFull(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },
    openMove(id) {
      if (!this.isChoice) {
        this.$router.push(`/department-complaint/details/${id}`);
      } else {
        this.$emit("select-complaint-department", id);
      }
    },
    async getDepatment() {
      this.loadingSections.loadDepartment = true;

      const formData = new FormData();
      formData.append("ticketId", this.complaintId);
      formData.append("sortTitle", 0);
      formData.append("sortDate", 0);
      formData.append("pageIndex", 0);
      formData.append("pageSize", 0);

      const respon =
        await ComplaintDepartmentAPIService.getComplaintDepartmentForStaff(
          formData
        );
      if (respon != null) {
        this.loadingSections.loadDepartment = false;
        this.tableData = respon.data;
      } else {
        this.loadingSections.loadDepartment = false;
      }
    },
    cancel() {
      this.$emit("cancel");
    },
  },
  computed: {
    loadingSectionPage() {
      const { loadDepartment } = this.loadingSections;
      return loadDepartment;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/complaint/department-list";
</style>