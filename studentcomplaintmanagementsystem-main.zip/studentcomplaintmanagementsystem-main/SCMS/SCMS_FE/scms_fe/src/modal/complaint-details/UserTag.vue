<template>
  <div id="user-tag-modal" class="user-tag-modal have-loading">
    <div
      class="top-table"
      v-if="this.userData != null && this.userData.length > 0"
    >
      <table>
        <tr class="table-header">
          <th class="from">
            <span>{{ $t("table.from") }}</span>
          </th>
          <th class="to">
            <span>{{ $t("table.to") }}</span>
          </th>
          <th class="des">
            <span>{{ $t("table.description") }}</span>
          </th>
          <th class="date">
            <span>{{ $t("table.date") }}</span>
          </th>
          <th class="status">
            <span>{{ $t("table.status") }}</span>
          </th>
        </tr>
        <template v-for="(item, i) in userData" :key="i">
          <tr>
            <td class="from">{{ item.from }}</td>
            <td class="to">{{ item.to }}</td>
            <td class="text-center des" @click="viewDescription(item)">
              <i class="fa-solid fa-eye"></i>
            </td>
            <td class="text-center date">{{ this.formatDate(item.date) }}</td>
            <td class="text-center status">
              <span v-if="item.status === '1'">{{ $t("value.received") }}</span>
              <span v-else-if="item.status === '2'">{{
                $t("value.transferred")
              }}</span>
              <span v-else-if="item.status === '3'">{{
                $t("value.refuse")
              }}</span>
              <span v-else>{{ $t("value.waiting") }}</span>
            </td>
          </tr>
        </template>
      </table>
    </div>
    <div class="errorUser">
      <span>{{ errorTag }} </span>
    </div>
    <div class="search">
      <input
        type="search"
        @input="handleChangeEnterUser"
        :placeholder="$t('placeholder.user')"
        autocomplete="off"
        spellcheck="false"
        v-model="user"
      />
      <!--Gợi ý-->
      <div
        class="sug-btn"
        :class="{ 'show-user-suggestion': isShowSuggestion }"
      >
        <!-- <div class="sugg-close" @click="closeUserSuggestion($event)">
          <i class="fa-solid fa-xmark"></i>
        </div> -->
      </div>
      <ul :class="{ 'show-user-suggestion': isShowSuggestion }">
        <template v-for="(user, index) in userSuggestion" :key="index">
          <li @click="selectedUser(user)">{{ user.email }}</li>
        </template>
      </ul>
      <!-- <button>
        <i class="fa-solid fa-magnifying-glass"></i>
      </button> -->
    </div>
    <template v-if="files.length > 0">
      <div class="files">
        <template v-for="(item, index) in reverseFiles" :key="index">
          <template v-if="index < 3">
            <div class="item">
              <div class="delete" @click="removeFile(item)">
                <i class="fa-solid fa-xmark"></i>
              </div>
              <div class="file-type">
                <template v-if="item.type.indexOf('image') >= 0">
                  <i class="fa-solid fa-image"></i>
                </template>
                <template v-else>
                  <i class="fa-solid fa-file"></i>
                </template>
              </div>
              <div class="file-name">{{ item.name }}</div>
            </div>
          </template>
          <template v-if="index == 3">
            <div class="item-more item">
              <div class="file-name">... (+{{ files.length - 3 }})</div>
            </div>
          </template>
        </template>
      </div>
    </template>
    <div class="description">
      <Editor
        v-model="description"
        :placeholder="$t('placeholder.text')"
        editorStyle="height: 100%"
      ></Editor>
    </div>
    <div class="actions">
      <button class="submit" @click="submitUser()">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button class="upload" @click="uploadFile()">
        <span>{{ $t("button.uploadFile") }}</span>
      </button>
      <input
        ref="inputFiles"
        type="file"
        multiple
        hidden
        @change="handleFileChange($event)"
      />
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { USER_TAG_MOCK } from "@/mock/user-tag.mock.js";
import Editor from "primevue/editor";
import ComplaintTagAPIService from "@/script/services/ComplaintTagAPIService";
import { useToast } from "vue-toastification";
import { TYPE } from "vue-toastification";
import UserApiService from "@/script/services/UserApiService";
import Loading from "@/core/components/Loading.vue";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "user-tag-modal",
  components: {
    Editor,
    Loading,
  },
  data() {
    return {
      fromUser: "A@gmail.com",
      userData: USER_TAG_MOCK,
      isShowSuggestion: false,
      userSuggestion: [
        {
          email: "user-1@mail.com",
        },
        {
          email: "user-2@mail.com",
        },
        {
          email: "user-3@mail.com",
        },
      ],
      user: "",
      description: "",
      files: [],
      errorTag: "",
      loadingSections: {
        section1: false,
      },
      totalFilesSize: 0,
    };
  },
  props: {
    complaintId: null,
    isReload: Boolean,
  },
  watch: {
    isReload(newVal) {
      console.log(newVal, "aaaaaaaaa");
      this.getListTag();
    },
  },
  async created() {
    this.toast = useToast();
    this.getListTag();
  },
  methods: {
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },
    async getListTag() {
      this.userData = await ComplaintTagAPIService.getComplaintTag(
        this.complaintId
      );
    },

    uploadFile() {
      this.$refs.inputFiles.click();
    },

    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    handleFileChange(event) {
      const files = event.target.files;
      this.totalFilesSize = 0;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.files.push(file);
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },

    removeFile(item) {
      const index = this.files.indexOf(item);
      this.files.splice(index, 1);
    },
    async submitUser() {
      if (this.isShowSuggestion || this.user == "") {
        this.toast(this.$t("toast.UserTag.mess2"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }
      this.user = this.user.trim();
      if (this.user && this.user != "") {
        const formData = new FormData();
        formData.append("Description", this.description);
        formData.append("EmailTo", this.user);
        formData.append("TicketId", this.complaintId);
        if (this.files.length > 0) {
          for (const file of this.files) {
            formData.append("fileTag", file);
          }
        }
        this.loadingSections.section1 = true;

        const res = await ComplaintTagAPIService.create(formData);
        if (res != null && res.message == "CREATE_SUCCESS") {
          this.toast(this.$t("toast.UserTag.mess1"), {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
          this.getListTag();
          this.files = [];
          this.user = "";
          this.description = "";
          this.loadingSections.section1 = false;
        } else {
          this.toast(this.$t("toast.UserTag.mess3"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.section1 = false;
        }

        return;
      }
      // this.$emit("submit-user", { data: [this.userData[0]] });
    },
    viewDescription(item) {
      this.$emit("show-user-tag-detail", item);
    },
    async handleChangeEnterUser() {
      //Call API để lấy thông tin gợi ý;
      await this.getUserSearch();
      await Promise.all([
        (this.isShowSuggestion = !(!this.user || this.user === "")),
      ]);
    },
    async getUserSearch() {
      const res = await UserApiService.getEmailByRole(this.user);
      if (res != null) {
        this.userSuggestion = res.data;
      }
    },
    selectedUser(item) {
      this.user = item.email;
      this.isShowSuggestion = false;
    },
    closeUserSuggestion(event) {
      event.stopPropagation();
      this.isShowSuggestion = false;
    },
  },
  computed: {
    reverseFiles() {
      return this.files.slice().reverse();
    },
    loadingSectionPage() {
      const { section1 } = this.loadingSections;
      return section1;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/user-tag.scss";
</style>
