<template>
  <div class="chat-edit-modal-content have-loading">
    <!--Title-->
    <div class="top">
      <div class="left top-item-view">
        <div class="title">
          <div class="label">{{ $t("search.title") }}</div>
          <input
            type="text"
            autocomplete="off"
            spellcheck="false"
            v-model="this.Complaintt.title"
            :placeholder="$t('placeholder.title')"
          />
        </div>
        <div class="category-select">
          <div class="label">{{ $t("label.category") }}</div>
          <div class="cate-value" @click="changeCategory()">
            <span v-if="this.Category == null" class="_placeholder">{{
              $t("span.selectACategory")
            }}</span>
            <div v-elde class="value">{{ this.Category.categoryName }}</div>
            <div class="icon">
              <i class="fa-solid fa-caret-down"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="deapartment top-item-view">
        <div class="label">{{ $t("label.department") }}</div>
        <div class="value">
          <select v-model="this.departmentSelect">
            <option
              v-for="(item, index) in departments"
              :key="item.departmentName"
              :value="item.departmentId"
              :selected="index === 0"
            >
              {{ item.departmentName }}
            </option>
          </select>
        </div>
      </div>

      <div class="des top-item-view">
        <div class="label">{{ $t("label.description") }}</div>
        <Editor
          v-model="this.Complaintt.description"
          placeholder="Enter description..."
          editorStyle="height: 100%"
        >
        </Editor>
      </div>
    </div>
    <div id="suggestion-chat-edit-modal" class="suggestion-chat-edit-modal">
      <draggable
        v-model="data"
        class="drag-area"
        group="suggestions"
        @start="dragging = true"
        @end="dragging = false"
        item-key="id"
      >
        <template #item="{ element, index }">
          <div class="drag-item">
            <!--other-->
            <template v-if="element.columView == '1'">
              <!--with out attachment-->
              <div
                v-if="element.attachments.length == 0"
                :class="{
                  'content-only': checkShowAvatar(index, element.id) == false,
                }"
                class="chat-line chat-left"
              >
                <!-- <div class="avatar">
                <img :src="element.avatar" alt="" />
              </div> -->
                <div
                  class="chat-content"
                  :class="{ editting: element.editStatus }"
                >
                  <!--Không ở chế độ chỉnh sửa-->
                  <template v-if="!element.editStatus">
                    <span>{{ element.content }}</span>
                    <div class="edit-btn" @click="element.editStatus = true">
                      <button>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                    </div>
                  </template>
                  <!--Ở chế độ chỉnh sửa-->
                  <template v-if="element.editStatus">
                    <textarea
                      type="text"
                      v-model="element.content"
                      rows="3"
                      autocomplete="off"
                      spellcheck="false"
                    ></textarea>
                    <div class="save-btn" @click="element.editStatus = false">
                      <button>
                        <i class="fa-solid fa-floppy-disk"></i>
                      </button>
                    </div>
                  </template>
                  <!--Nút chuyển sang trái/ phải-->
                  <div class="move-btns">
                    <button @click="element.columView = 2">
                      <i class="fa-solid fa-arrow-right"></i>
                    </button>
                  </div>
                  <!--Add attachment-->
                  <div class="attach-btns">
                    <button @click="addAttachment(element)">
                      <i class="fa-solid fa-paperclip"></i>
                    </button>
                  </div>
                  <div class="remove-btn">
                    <button @click="removeSuggestIndex(element)">
                      <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                </div>
              </div>
              <!--with attachment-->
              <div
                v-else
                :class="{
                  'content-only': checkShowAvatar(index, element.id) == false,
                }"
                class="chat-line chat-left"
              >
                <!-- <div class="avatar">
                <img :src="element.avatar" alt="" />
              </div> -->
                <div
                  class="chat-content have-attachment"
                  :class="{ editting: element.editStatus }"
                >
                  <!--Attachments-->
                  <template v-for="(attach, i) in element.attachments" :key="i">
                    <span class="content-attachment">
                      <button
                        class="file-delete"
                        @click="removeFile(item, attach)"
                      >
                        <i class="fa-solid fa-xmark"></i>
                      </button>
                      <div class="file-view" @click="downloadFile(attach.link)">
                        <i class="fa-regular fa-file"></i>
                        {{ showAttachName(attach.name) }}
                      </div>
                    </span>
                  </template>
                  <!--Không ở chế độ chỉnh sửa-->
                  <template v-if="!element.editStatus">
                    <span class="mess">{{ element.content }}</span>
                    <div class="edit-btn" @click="element.editStatus = true">
                      <button>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                    </div>
                  </template>
                  <!--Ở chế độ chỉnh sửa-->
                  <template v-if="element.editStatus">
                    <textarea
                      type="text"
                      v-model="element.content"
                      rows="3"
                      autocomplete="off"
                      spellcheck="false"
                    >
                    </textarea>
                    <div class="save-btn" @click="element.editStatus = false">
                      <button>
                        <i class="fa-solid fa-floppy-disk"></i>
                      </button>
                    </div>
                  </template>
                  <!--Nút chuyển sang trái/ phải-->
                  <div class="move-btns">
                    <button @click="element.columView = 2">
                      <i class="fa-solid fa-arrow-right"></i>
                    </button>
                  </div>
                  <!--Add attachment-->
                  <div class="attach-btns">
                    <button @click="addAttachment(element)">
                      <i class="fa-solid fa-paperclip"></i>
                    </button>
                  </div>
                  <div class="remove-btn">
                    <button @click="removeSuggestIndex(element)">
                      <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                </div>
              </div>
            </template>
            <!--your message-->
            <template v-else>
              <!--with out attachment-->
              <div
                class="chat-line chat-right"
                v-if="element.attachments.length == 0"
                :class="{
                  'content-only': checkShowAvatar(index, element.id) == false,
                }"
              >
                <div
                  class="chat-content"
                  :class="{ editting: element.editStatus }"
                >
                  <!--Không ở chế độ chỉnh sửa-->
                  <template v-if="!element.editStatus">
                    <span>{{ element.content }}</span>
                    <div class="edit-btn" @click="element.editStatus = true">
                      <button>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                    </div>
                  </template>
                  <!--Ở chế độ chỉnh sửa-->
                  <template v-if="element.editStatus">
                    <textarea
                      type="text"
                      v-model="element.content"
                      rows="3"
                      autocomplete="off"
                      spellcheck="false"
                    >
                    </textarea>
                    <div class="save-btn" @click="element.editStatus = false">
                      <button>
                        <i class="fa-solid fa-floppy-disk"></i>
                      </button>
                    </div>
                  </template>
                  <!--Nút chuyển sang trái/ phải-->
                  <div class="move-btns">
                    <button @click="element.columView = 1">
                      <i class="fa-solid fa-arrow-left"></i>
                    </button>
                  </div>
                  <!--Add attachment-->
                  <div class="attach-btns">
                    <button @click="addAttachment(element)">
                      <i class="fa-solid fa-paperclip"></i>
                    </button>
                  </div>
                  <div class="remove-btn">
                    <button @click="removeSuggestIndex(element)">
                      <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                </div>
                <!-- <div class="avatar">
                <img :src="element.avatar" alt="" />
              </div> -->
              </div>
              <!--with attachment-->
              <div
                v-else
                :class="{
                  'content-only': checkShowAvatar(index, element.id) == false,
                }"
                class="chat-line chat-right"
              >
                <div
                  class="chat-content have-attachment"
                  :class="{ editting: element.editStatus }"
                >
                  <!--Attachments-->
                  <template v-for="(attach, i) in element.attachments" :key="i">
                    <span class="content-attachment">
                      <button
                        class="file-delete"
                        @click="removeFile(item, attach)"
                      >
                        <i class="dl-right fa-solid fa-xmark"></i>
                      </button>
                      <div class="file-view" @click="downloadFile(attach.link)">
                        <i class="fa-regular fa-file"></i>
                        {{ showAttachName(attach.name) }}
                      </div>
                    </span>
                  </template>
                  <!--Không ở chế độ chỉnh sửa-->
                  <template v-if="!element.editStatus">
                    <span class="mess">{{ element.content }}</span>
                    <div class="edit-btn" @click="element.editStatus = true">
                      <button>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                    </div>
                  </template>
                  <!--Ở chế độ chỉnh sửa-->
                  <template v-if="element.editStatus">
                    <textarea
                      type="text"
                      v-model="element.content"
                      rows="3"
                      autocomplete="off"
                      spellcheck="false"
                    >
                    </textarea>
                    <div class="save-btn" @click="element.editStatus = false">
                      <button>
                        <i class="fa-solid fa-floppy-disk"></i>
                      </button>
                    </div>
                  </template>
                  <!--Nút chuyển sang trái/ phải-->
                  <div class="move-btns">
                    <button @click="element.columView = 1">
                      <i class="fa-solid fa-arrow-left"></i>
                    </button>
                  </div>
                  <!--Add attachment-->
                  <div class="attach-btns">
                    <button @click="addAttachment(element)">
                      <i class="fa-solid fa-paperclip"></i>
                    </button>
                  </div>
                  <div class="remove-btn">
                    <button @click="removeSuggestIndex(element)">
                      <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                </div>
                <!-- <div class="avatar">
                <img :src="element.avatar" alt="" />
              </div> -->
              </div>
            </template>
          </div>
        </template>
      </draggable>
    </div>
    <!--Thêm mới Suggestion-->
    <div v-if="isAddSuggestion" class="add-suggestion">
      <div class="text">
        <textarea
          v-model="newSuggestion.content"
          autocomplate="off"
          spellcheck="false"
          :placeholder="$t('placeholder.message')"
        ></textarea>
      </div>
      <template v-if="newSuggestion.attachments.length > 0">
        <div class="file">
          <template v-for="(file, i) in newSuggestion.attachments" :key="i">
            <div v-if="i < 2" class="file-item">
              <div class="file-remove">
                <button @click="removeFileForNewSugg(file)">
                  <i class="fa-solid fa-xmark"></i>
                </button>
              </div>
              <div class="file-name">{{ file.name }}</div>
            </div>
            <div v-if="i == 2" class="file-item">
              <div class="file-name more">
                ...(+{{ newSuggestion.attachments.length - 2 }})
              </div>
            </div>
          </template>
          <button class="add-file">
            <i class="fa-solid fa-paperclip"></i>
          </button>
        </div>
      </template>
    </div>
    <!--Hành động-->
    <div class="edit-mess-actions">
      <div class="add-sugg">
        <!--Bật thêm mới Suggestion-->
        <template v-if="!isAddSuggestion">
          <button class="add-sug-btn" @click="addSuggestion()">
            <i class="fa-solid fa-plus"></i>
            <span>{{ $t("button.addConversation") }}</span>
          </button>
        </template>
        <!--Hủy thêm mới Suggestion-->
        <template v-if="isAddSuggestion">
          <button
            class="add-sug-btn cancel-sug-btn"
            @click="cancelSuggestion()"
          >
            <span>{{ $t("button.cancel") }}</span>
          </button>
          <button class="add-sug-btn" @click="selectNewSuggestionFiles()">
            <span>{{ $t("button.uploadFile") }}</span>
          </button>
          <input
            type="file"
            multiple
            hidden
            ref="inputFileForAddSugg"
            @change="choosenAttachmentForNewSugg($event)"
          />
          <button
            class="add-sug-btn add-cfr-sug-btn"
            @click="submitNewSuggestion()"
          >
            <span>{{ $t("button.add") }}</span>
          </button>
          <!--Trái || Phải-->
          <div class="options-view">
            <div class="opt">
              <input
                v-model="newSuggestion.columView"
                value="1"
                type="radio"
                name="column"
              />
              <span @click="newSuggestion.columView = '1'">{{
                $t("span.leftColumn")
              }}</span>
            </div>
            <div class="opt">
              <input
                v-model="newSuggestion.columView"
                value="2"
                type="radio"
                name="column"
              />
              <span @click="newSuggestion.columView = '2'">{{
                $t("span.rightColumn")
              }}</span>
            </div>
          </div>
        </template>
      </div>
      <button v-if="!isAddSuggestion" class="close" @click="closeModal()">
        <span>{{ $t("button.close") }}</span>
      </button>
      <button
        v-if="!isAddSuggestion"
        class="add"
        @click="addDepartmentComplaint()"
      >
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button v-if="!isAddSuggestion" class="clear" @click="clearSuggest()">
        <span>{{ $t("button.clear") }}</span>
      </button>
    </div>
    <input
      ref="fileInput"
      type="file"
      multiple
      hidden
      @change="choosenAttachment($event)"
    />
    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
  <!-- Category Modal-->
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    :title="$t('placeholder.category')"
    class="select-category-modal"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :selected-data-id="this.Category.categoryTicketId"
      :source="'suggestion modal'"
      @change-category="selectNewCategory($event)"
      @change-category-all="selectNewCategoryAll()"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import ComplaintDepartmentAPIService from "@/script/services/ComplaintDepartmentAPIService";
import draggable from "vuedraggable";
import Editor from "primevue/editor";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import { BModal } from "bootstrap-vue-next";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import DepartmentAPIService from "@/script/services/DepartmentAPIService";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "department-chat-edit-modal",
  components: {
    draggable,
    Editor,
    EditCategory,
    BModal,
    Loading,
  },
  props: {
    dataMess: Array,
    userId: Number,
    complaint: Object,
    complaintId: String,
  },
  data() {
    return {
      dragging: false,
      yourId: null,
      isAddSuggestion: false,
      isShowCategoryModal: false,
      newSuggestion: {
        id: "",
        columView: "2",
        userId: "",
        userIDChat: null,
        avatar: "",
        content: "",
        attachments: [],
      },
      data: [],
      itemAddAttachment: null,
      category: null,
      description: "",
      Complaintt: {
        title: "",
        description: "",
      },
      ComplaintIdItem: "",
      Category: {
        categoryTicketId: "",
        categoryName: "",
        fullPath: "",
      },
      loadingSections: {
        section1: false,
        loadDepatment: false,
        loadCategory: false,
        loadDepartment: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      departments: [],
      departmentSelect: "",
      totalFilesSize: 0,
    };
  },
  watch: {},
  created() {
    this.toast = useToast();
    this.yourId = this.userId;
    if (this.complaint != null) {
      this.Category.categoryName = this.complaint.category.categoryTicketName;
      this.Category.categoryTicketId = this.complaint.category.categoryTicketId;
      this.Complaintt.title = this.complaint.title;
      this.Complaintt.description = this.complaint.description;
    }
    if (this.complaintId != null) {
      this.ComplaintIdItem = this.complaintId;
    }
    this.getDepatment();

    //this.data = [...this.dataMess];
    this.data = JSON.parse(JSON.stringify(this.dataMess));
    this.data.forEach((e) => {
      e.editStatus = false;
    });
    this.data.sort((a, b) => a.orderNumber - b.orderNumber);
  },
  methods: {
    async getDepatment() {
      this.loadingSections.loadDepartment = true;
      const res = await DepartmentAPIService.getDepartments();
      if (res != null) {
        this.loadingSections.loadDepartment = false;
        this.departments = res.data;
        if (this.departments != null && this.departments.length > 0) {
          this.departmentSelect = this.departments[0].departmentId;
        }
      } else {
        this.loadingSections.loadDepartment = false;
      }
    },
    selectNewCategory(data) {
      this.isShowCategoryModal = false;
      this.Category.categoryTicketId = data.item;
      this.getCategory();
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    async getCategory() {
      this.loadingSections.loadCategory = true;
      const respon = await CategoryAPIService.GetCategoryById(
        this.Category.categoryTicketId
      );
      if (respon != null) {
        this.loadingSections.loadCategory = false;
        this.Category.categoryTicketId = respon.categoryTicketId;
        this.Category.categoryName = respon.categoryName;
        // this.filter.categoryType = respon[0]["id"];
      } else {
        this.loadingSections.loadCategory = false;
      }
    },
    changeCategory() {
      this.isShowCategoryModal = true;
    },

    //Begin:: Add Suggestion
    addSuggestion() {
      this.isAddSuggestion = true;
      // const newId = this.data.length + 1;
      // this.newSuggestion.id = `${newId}`; //Id gen để mock data
      this.newSuggestion.userId = this.userId; //mặc định là bên phải => id = user Id
    },
    clearSuggest() {
      this.data = [];
    },
    cancelSuggestion() {
      this.isAddSuggestion = false;
    },
    selectNewSuggestionFiles() {
      this.$refs.inputFileForAddSugg.click();
    },

    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    choosenAttachmentForNewSugg(event) {
      const files = event.target.files;
      this.totalFilesSize = 0;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.newSuggestion.attachments.push({
              id: "",
              name: file.name,
              link: "",
              type: file.type,
              file: file,
              description: "",
              fileId: "",
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },

    removeFileForNewSugg(item) {
      const index = this.newSuggestion.attachments.indexOf(item);
      if (index >= 0) {
        this.newSuggestion.attachments.splice(index, 1);
      }
    },
    submitNewSuggestion() {
      if (
        this.newSuggestion.content == "" &&
        this.newSuggestion.attachments.length == 0
      ) {
        return;
      }

      this.data.push(this.newSuggestion);
      //Reset dữ liệu của suggestion mới
      this.newSuggestion = {
        id: "",
        columView: "2",
        userId: "",
        userIDChat: null,
        avatar: "",
        content: "",
        attachments: [],
      };
      this.isAddSuggestion = false;

      this.filterData();
    },
    //End:: Add Suggestion

    showAttachName(name) {
      if (!name) return name;
      if (name.length > 30) return `${name.substring(0, 30)}...`;
      return name;
    },
    checkShowAvatar(index, id) {
      //nếu 2 tin nhắn liên tiếp đến từ 1 người thì chỉ hiện ảnh dại diện ở tin đầu tiên
      if (index == 0) return true;
      if (this.data[index - 1].id == id) return false;
      return true;
    },
    removeFile(item, file) {
      const index = item.attachments.indexOf(file);
      if (index >= 0) {
        item.attachments.splice(index, 1);
      }

      this.filterData();
    },
    addAttachment(item) {
      this.itemAddAttachment = item;
      this.$refs.fileInput.click();
    },
    removeSuggestIndex(item) {
      // Tìm vị trí của phần tử cần xóa trong mảng
      const index = this.data.indexOf(item);

      // Nếu phần tử được tìm thấy trong mảng
      if (index !== -1) {
        // Xóa 1 phần tử từ vị trí index
        this.data.splice(index, 1);
      }

      this.filterData();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      this.totalFilesSize = 0;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.itemAddAttachment.attachments.push({
              id: "",
              name: file.name,
              link: "",
              type: file.type,
              file: file,
              description: "",
              fileId: "",
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },
    downloadFile(id) {
      //chỉ có thể tải tệp khi không ở chế độ chọn Suggestion
      if (this.addSuggestionStatus) return;
      if (id == null || id == undefined) {
        this.toast("Open file error. Cannot open the just uploaded file ", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }
      window.location.href = `${id}`;
    },
    closeModal() {
      this.$emit("close", this.data);
    },

    filterData() {
      // Tạo một mảng mới lưu trữ các object đã lọc
      const filteredData = this.data.filter((item) => {
        // Kiểm tra nếu comment không rỗng hoặc attachments không rỗng
        if (
          item.content.trim() !== "" ||
          (item.attachments && item.attachments.length > 0)
        ) {
          return true; // Giữ lại object này
        }
        return false; // Loại bỏ object này
      });

      // Gán lại mảng đã lọc cho this.data
      this.data = filteredData;
    },

    async addDepartmentComplaint() {
      const formData = new FormData();
      formData.append("Title", this.Complaintt.title);
      formData.append("Description", this.Complaintt.description);
      formData.append("CategoryTicketId", this.Category.categoryTicketId);
      formData.append("TicketId", this.ComplaintIdItem);
      formData.append("DepartmentId", this.departmentSelect);

      this.filterData();

      console.log(this.data);
      this.data.forEach((item, index) => {
        console.log(item.comment, "s" + index);
        formData.append(
          `commentsImportsRequestAddVMs[${index}].comment`,
          item.content
        );
        formData.append(
          `commentsImportsRequestAddVMs[${index}].columView`,
          item.columView
        );
        if (item.attachments != null && item.attachments.length > 0) {
          item.attachments.forEach((attachment, indexAttachment) => {
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].description`,
              attachment.description
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].file`,
              attachment.file
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].id`,
              attachment.id
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].link`,
              attachment.link
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].name`,
              attachment.name
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].type`,
              attachment.type
            );
            formData.append(
              `commentsImportsRequestAddVMs[${index}].attachments[${indexAttachment}].fileId`,
              attachment.fileId
            );
          });
        }
      });
      this.loadingSections.section1 = true;
      const res = await ComplaintDepartmentAPIService.create(formData);
      console.log(res);
      if (res != null) {
        this.loadingSections.section1 = false;
        if (res.message == "CREATE_SUCCESS") {
          this.toast(this.$t("toast.Common.mess2"), {
            type: TYPE.success, // or "success", "error", "default", "info" and "warning"
          });

          this.$emit("reloadData");
        }
      } else {
        this.loadingSections.section1 = false;
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },
  },
  computed: {
    loadingSectionPage() {
      const { section1, loadDepatment, loadDepartment, loadCategory } =
        this.loadingSections;
      return section1 || loadDepatment || loadDepartment || loadCategory;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/department-chat-edit";
</style>
