<template>
  <div id="edit-category-modal" class="edit-category-modal">
    <!-- <div class="search">
      <input type="search" autocomplete="off" spellcheck="false" :placeholder="Enter text..."/>
      <button>
        <span>Search</span>
      </button>
    </div> -->
    <CategoryList
      :dataList="data"
      :config="listConfig"
      :selectedDataId="selectedId"
      @select-category="selectTempCategory($event)"
    />
    <div class="buttons">
      <button v-if="isShowSelectAllCategoryModal" class="select-all" 
      @click="selectCategoryAll()">
        <span>{{$t('button.selectAll')}}</span>
      </button>
      <button class="select" @click="selectCategory()">
        <span>{{$t('button.selectCategory')}}</span>
      </button>
      <button class="close" @click="closeModal()">
        <span>{{$t('button.close')}}</span>
      </button>
    </div>
  </div>
</template>

<script>
// import { notify } from "@kyvg/vue3-notification";
import { defineComponent } from "vue";
import CategoryList from "@/components/category/CategoryList.vue";
import { CATEGORY_DATA_MOCK } from "@/mock/category-data.mock.js";

export default defineComponent({
  name: "edit-category-modal",
  components: {
    CategoryList,
  },
  props: {
    selectedDataId: null,
    source: String,
    isShowSelectAllCategoryModal: Boolean
  },
  data() {
    return {
      openFrom: "",
      data: CATEGORY_DATA_MOCK,
      itemSelected: null,
      selectedId: null,
      listConfig: {
        isShowAction: false,
        isShowSelect: true,
      },
    };
  },
  watch: {
    selectedDataId(newVal) {
      this.selectedId = newVal;
    }
  },
  created() {
    this.selectedId = this.selectedDataId;
    //openFrom dùng để xác định xem modal được mở từ nguồn nào để gán data cho phù hợp
    this.openFrom = this.source;
    console.log(this.openFrom, "open from...");
  },
  methods: {
    selectTempCategory(item) {
      this.itemSelected = item.item;
    },
    selectCategory() {
      if (!this.itemSelected) return;
      this.$emit("change-category", {
        item: this.itemSelected,
      });
    },
    selectCategoryAll() {
      // if (!this.itemSelected) return;
      this.$emit("change-category-all", null);
    },

    closeModal() {
      (this.itemSelected = null), (this.selectedId = null);
      this.$emit("close-modal");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/edit-category.scss";
</style>
