<template>
  <div id="report-modal" class="report-modal have-loading">
    <div class="staff">
      <div class="label">{{ $t("span.staff") }}:</div>
      <select class="staff-select">
        <option
          v-for="(item, index) in users"
          :key="item.email"
          :value="item.accountId"
          :selected="index === 0"
        >
          {{ item.email }}
        </option>
      </select>
    </div>
    <template v-if="files.length > 0">
      <div class="files">
        <template v-for="(item, index) in reverseFiles" :key="index">
          <template v-if="index < 3">
            <div class="item">
              <div class="delete" @click="removeFile(item)">
                <i class="fa-solid fa-xmark"></i>
              </div>
              <div class="file-type">
                <template v-if="item.type.indexOf('image') >= 0">
                  <i class="fa-solid fa-image"></i>
                </template>
                <template v-else>
                  <i class="fa-solid fa-file"></i>
                </template>
              </div>
              <div class="file-name">{{ item.name }}</div>
            </div>
          </template>
          <template v-if="index == 3">
            <div class="item-more item">
              <div class="file-name">... (+{{ files.length - 3 }})</div>
            </div>
          </template>
        </template>
      </div>
    </template>
    <div class="description">
      <Editor
        v-model="description"
        :placeholder="$t('placeholder.text')"
        editorStyle="height: 100%"
      ></Editor>
    </div>
    <div class="actions">
      <button class="submit" @click="submit()">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button class="upload" @click="uploadFile()">
        <span>{{ $t("button.uploadFile") }}</span>
      </button>
      <input
        ref="inputFiles"
        type="file"
        multiple
        hidden
        @change="handleFileChange($event)"
      />
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Editor from "primevue/editor";
import ComplaintReportAPIService from "@/script/services/ComplaintReportAPIService";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import { TYPE } from "vue-toastification";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "report-modal",
  components: {
    Editor,
    Loading,
  },
  props: {
    idComplaint: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      fromUser: "A@gmail.com",
      description: "",
      files: [],
      users: [],
      userSelect: "",
      totalFilesSize: 0
    };
  },
  async created() {
    this.toast = useToast();
    this.getUsers();
  },
  methods: {
    uploadFile() {
      this.$refs.inputFiles.click();
    },
    async getUsers() {
      this.users = await ComplaintReportAPIService.getUserReportOfComplaint(
        this.idComplaint
      );
      if (this.users != null && this.users.length > 0) {
        this.userSelect = this.users[0].accountId;
      } else {
        this.toast("No ministries have responded to you yet", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.$emit("close");
      }
    },
    handleFileChange(event) {
      const files = event.target.files;

      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.files.push(file);
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
 
    },
    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    removeFile(item) {
      const index = this.files.indexOf(item);
      this.files.splice(index, 1);
    },
    async submit() {
      const formData = new FormData();
      this.description = this.description.trim();
      console.log(this.description);
      if (this.description == "") {
        this.toast("Description is not blank", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      formData.append("AccountIdStaff", this.userSelect);
      formData.append("TicketId", this.idComplaint);
      formData.append("Description", this.description);
      if (this.files.length > 0) {
        for (const file of this.files) {
          formData.append("TicketReportAttachments", file);
        }
      }

      const res = await ComplaintReportAPIService.add(formData);
      if (res != null && res.message == "CREATE_SUCCESS") {
        this.toast(this.$t("toast.Common.mess2"), {
          type: TYPE.success, // or "success", "error", "default", "info" and "warning"
        });
        this.description = "";
        this.files = [];
      }
    },
  },
  computed: {
    reverseFiles() {
      return this.files.slice().reverse();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/report.scss";
</style>
