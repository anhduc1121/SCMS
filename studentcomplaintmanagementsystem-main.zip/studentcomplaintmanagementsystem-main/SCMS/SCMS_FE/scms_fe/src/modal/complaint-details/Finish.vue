<template>
  <div
    id="complaint-finish-modal-content"
    class="complaint-finish-modal-content have-loading"
  >
    <div class="line">
      <div class="item item-end rate">
        <div class="label">{{ $t("label.rate") }}</div>
        <div class="value star-value">
          <div class="stars">
            <div class="star-item 1-star" @click="selectStar(1)">
              <div v-if="stars >= 1" class="star">
                <i class="fa-solid fa-star"></i>
              </div>
            </div>
            <div class="star-item 2-star" @click="selectStar(2)">
              <div v-if="stars >= 2" class="star">
                <i class="fa-solid fa-star"></i>
              </div>
              <div v-else class="blank-star">
                <i class="fa-regular fa-star"></i>
              </div>
            </div>
            <div class="star-item 3-star" @click="selectStar(3)">
              <div v-if="stars >= 3" class="star">
                <i class="fa-solid fa-star"></i>
              </div>
              <div v-else class="blank-star">
                <i class="fa-regular fa-star"></i>
              </div>
            </div>
            <div class="star-item 4-star" @click="selectStar(4)">
              <div v-if="stars >= 4" class="star">
                <i class="fa-solid fa-star"></i>
              </div>
              <div v-else class="blank-star">
                <i class="fa-regular fa-star"></i>
              </div>
            </div>
            <div class="star-item 5-star" @click="selectStar(5)">
              <div v-if="stars >= 5" class="star">
                <i class="fa-solid fa-star"></i>
              </div>
              <div v-else class="blank-star">
                <i class="fa-regular fa-star"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="line line-end">
      <div class="positive">
        <div class="label">{{ $t("label.positive") }}</div>
        <div class="value">
          <Editor
            v-model="positive"
            :placeholder="$t('placeholder.text')"
            editorStyle="height: 100%"
          ></Editor>
        </div>
      </div>
      <div class="negative">
        <div class="label">{{ $t("label.negative") }}</div>
        <div class="value">
          <Editor
            v-model="negative"
            :placeholder="$t('placeholder.text')"
            editorStyle="height: 100%"
          ></Editor>
        </div>
      </div>
    </div>
    <div class="actions">
      <button @click="onSubmit()" class="submit">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button class="cancel" @click="cancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Editor from "primevue/editor";
import ComplaintFeedbackAPIService from "@/script/services/ComplaintFeedbackAPIService";
import Loading from "@/core/components/Loading.vue";
import { useToast } from "vue-toastification";
import { TYPE } from "vue-toastification";
export default defineComponent({
  name: "complaint-finish-modal-content",
  components: {
    Editor,
    Loading,
  },
  props: {
    ticketId: String,
  },
  data() {
    return {
      stars: 5,
      positive: null,
      negative: null,
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },

  async created() {
    this.toast = useToast();
  },
  methods: {
    selectStar(stars) {
      this.stars = stars;
    },
    cancel() {
      this.$emit("cancel");
    },
    async onSubmit() {
      const formData = new FormData();
      formData.append("Rate", this.stars);
      formData.append("Positive", this.positive);
      formData.append("Negative", this.negative);
      formData.append("TicketId", this.ticketId);

      this.loadingSections.section1 = true;

      const res = await ComplaintFeedbackAPIService.replyComplaintStudent(
        formData
      );
      if (res != null) {
        this.toast(this.$t("toast.Common.mess6"), {
          type: TYPE.success, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
        this.$emit("reloadDone");
      } else {
        this.toast(this.$t("toast.Common.mess7"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/complaint/finish.scss";
</style>
