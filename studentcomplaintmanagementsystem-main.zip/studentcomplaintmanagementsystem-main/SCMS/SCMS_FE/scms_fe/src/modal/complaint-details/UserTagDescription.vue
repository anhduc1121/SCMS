<template>
  <div
    id="user-tag-description-modal"
    class="user-tag-description-modal have-loading"
  >
    <div class="data-view">
      <div class="part-view">
        <div class="item">
          <div class="label">{{ $t("search.from") }}:</div>
          <div class="value">{{ data.from }}</div>
        </div>
        <div class="item">
          <div class="label">{{ $t("search.to") }}:</div>
          <div class="value">{{ data.to }}</div>
        </div>
      </div>
      <div class="part-view">
        <div class="item">
          <div class="label">{{ $t("label.date") }}</div>
          <div class="value">{{ this.formatDate(data.date) }}</div>
        </div>
        <div class="item">
          <div class="label">{{ $t("label.status") }}</div>
          <div class="value">
            <span v-if="data.status === '1'">{{ $t("value.received") }}</span>
            <span v-else-if="data.status === '2'">{{
              $t("value.transferred")
            }}</span>
            <span v-else-if="data.status === 3">{{ $t("value.refuse") }}</span>
            <span v-else>{{ $t("value.waiting") }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="description">
      <div class="label">{{ $t("label.note") }}</div>
      <div class="value" v-html="data.note"></div>
    </div>

    <div class="files" v-if="data.tagTicketAttachment.length > 0">
      <div class="label">{{ $t("label.attachments") }}</div>
      <div class="value">
        <template v-for="(item, i) in data.tagTicketAttachment" :key="i">
          <div class="file">
            <div class="no">{{ i + 1 }}.</div>
            <div class="icon">
              <i class="fa-regular fa-file"></i>
            </div>
            <a class="name" :href="item.link">{{ item.name }}</a>
          </div>
        </template>
      </div>
    </div>
    <div class="actions">
      <button
        v-if="this.idUser == data.requiredAccountId && data.status !== '1'"
        class="submit"
        @click="submitUser('1')"
      >
        <span>{{ $t("button.accept") }}</span>
      </button>
      <button
        class="reject"
        style="color: aliceblue"
        @click="submitUser('3')"
        v-if="this.idUser == data.requiredAccountId && data.status !== '3'"
      >
        <span>{{ $t("button.reject") }}</span>
      </button>
      <button @click="close()" class="cancel">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import ComplaintTagAPIService from "@/script/services/ComplaintTagAPIService";
import Loading from "@/core/components/Loading.vue";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";

export default defineComponent({
  name: "user-tag-description-modal",
  components: { Loading },
  props: {
    data: {
      type: Object,
      required: true,
    },
    idUser: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      // id
      loadingSections: {
        updateTag: false,
      },
      tag: {
        tagTicketId: "",
        accountCreateId: "",
        from: "",
        requiredAccountId: "",
        to: "",
        date: "",
        status: "",
        ticketId: "",
        note: "",
        tagTicketAttachment: [],
      },
    };
  },
  created() {
    this.toast = useToast();
    if (this.data != null) {
      this.tag = this.data;
    }
  },
  computed: {
    loadingSectionPage() {
      const { updateTag } = this.loadingSections;
      return updateTag;
    },
  },
  methods: {
    async submitUser(data) {
      this.loadingSections.updateTag = true;
      const res = await ComplaintTagAPIService.updateStatus(
        this.tag.tagTicketId,
        data
      );
      if (res != null && res.message == "SUCCESS") {
        this.loadingSections.updateTag = false;
        this.toast(this.$t("toast.Common.mess8"), {
          type: TYPE.success, // or "success", "error", "default", "info" and "warning"
        });
        this.$emit("reload-userTag", null);
      } else {
        this.loadingSections.updateTag = false;
      }
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },
    close() {
      this.$emit("close-userTagDescription", null);
      return;
    },
    async update() {},
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/user-tag-details.scss";
</style>
