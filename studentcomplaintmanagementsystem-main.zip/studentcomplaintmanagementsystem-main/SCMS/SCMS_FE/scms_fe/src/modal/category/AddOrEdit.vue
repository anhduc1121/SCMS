<template>
  <div
    id="category-add-md-content"
    class="category-add-md-content have-loading"
  >
    <div class="item">
      <div class="label">
        {{ $t("category.name") }} <span class="text-red">*</span>
      </div>
      <div class="value">
        <input
          v-model="this.itemData.name"
          type="text"
          autocomplete="off"
          spellcheck="false"
        />
      </div>
    </div>
    <div class="item">
      <div class="label">{{ $t("category.description") }}</div>
      <div class="value">
        <textarea
          v-model="this.itemData.description"
          autocomplete="off"
          spellcheck="false"
        ></textarea>
      </div>
    </div>
    <div class="item">
      <div class="label">
        {{ $t("category.emailReponsible") }} <span class="text-red">*</span>
      </div>
      <div class="value">
        <input
          v-model="this.itemData.email"
          type="email"
          autocomplete="off"
          spellcheck="false"
        />
      </div>
    </div>
    <div class="item">
      <div class="label">
        {{ $t("category.time") }} <span class="text-red">*</span>
      </div>
      <div class="value">
        <div class="_input">
          <input
            v-model="this.itemData.day"
            type="number"
            autocomplete="off"
            spellcheck="false"
          />
          <span>{{ $t("time.day") }}</span>
        </div>
        <div class="_input">
          <input
            v-model="this.itemData.hour"
            type="number"
            autocomplete="off"
            spellcheck="false"
          />
          <span>{{ $t("time.hour") }}</span>
        </div>
      </div>
    </div>
    <div class="actions">
      <button class="submit" @click="onSubmit()">
        <span>{{ $t("button.submit") }}</span>
      </button>
      <button class="cancel" @click="onCancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Loading from "@/core/components/Loading.vue";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";

export default defineComponent({
  name: "category-add-md-content",
  props: { modalData: Object },
  components: { Loading },
  data() {
    return {
      itemData: {
        isAdd: true,
        name: "",
        description: "",
        email: "",
        day: 0,
        hour: 0,
      },
      dataItem: null,
      //Lưu ý, các funcs call bất đồng bộ cùng 1 thời điểm thì không được dùng chung 1 section loading
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    if (!this.modalData.isAdd) {
      this.loadingSections.section1 = true;
      if (this.modalData.item != null) {
        (this.itemData.isAdd = false),
          (this.itemData.name = this.modalData.item.categoryName) == null
            ? ""
            : this.modalData.item.categoryName,
          (this.itemData.description = this.modalData.item.description) == null
            ? ""
            : this.modalData.item.description,
          (this.itemData.email = this.modalData.item.responsiblePersonEmail) ==
          null
            ? ""
            : this.modalData.item.responsiblePersonEmail,
          (this.itemData.day = Math.floor(
            this.modalData.item.responseHours / 24
          )),
          (this.itemData.hour = this.modalData.item.responseHours % 24);
        this.loadingSections.section1 = false;
      }
    } else {
      this.dataItem = this.modalData;
    }
  },
  methods: {
    async onSubmit() {
      this.itemData.name = this.itemData.name.trim();
      // Validate
      // if (this.itemData.name == "") {
      //   this.toast("Add data successfully", {
      //     type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
      //   });
      //   return;
      // }

      this.loadingSections.section1 = true;

      // set up data
      const formData = new FormData();
      formData.append("CategoryName", this.itemData.name.trim());
      if (this.itemData.description != null) {
        this.itemData.description = this.itemData.description.trim();
        formData.append("Description", this.itemData.description.trim());
      }
      const responseTime = this.itemData.day * 24 + this.itemData.hour;
      formData.append("ResponseTime", responseTime);

      formData.append("ResponsiblePersonEmail", this.itemData.email);

      if (this.itemData.isAdd) {
        if (
          this.modalData.item != null &&
          (this.modalData.item.categoryTicketId != undefined ||
            this.modalData.item.categoryTicketId != null)
        ) {
          formData.append(
            "CategoryTicketParentId",
            this.modalData.item.categoryTicketId
          );
        }

        const res = await CategoryAPIService.createCategory(formData);
        if (res != null) {
          this.toast("Add data successfully", {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
          this.$emit("reload-add", res);
          this.loadingSections.section1 = false;
        } else {
          this.toast("Add data error", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.section1 = false;
        }
      } else {
        formData.append(
          "CategoryTicketId",
          this.modalData.item.categoryTicketId
        );

        const res = await CategoryAPIService.updateCategory(formData);
        if (res != null) {
          this.toast("Update data successfully", {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
          this.$emit("reload-edit", res);
          this.loadingSections.section1 = false;
        } else {
          this.toast("Update data error", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.section1 = false;
        }
      }
    },

    onCancel() {
      this.$emit("cancel-add-or-edit", null);
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/category/add-or-edit.scss";
</style>
