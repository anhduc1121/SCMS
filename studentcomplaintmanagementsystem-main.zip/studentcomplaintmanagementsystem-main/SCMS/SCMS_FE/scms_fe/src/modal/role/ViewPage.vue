<template>
  <div id="view-page-modal-content" class="view-page-modal-content">
    <div class="value">
      <table>
        <!--Table: Header-->
        <tr class="header">
          <th colspan="2"></th>
          <template v-for="(item, index) in dataHeader" :key="index">
            <th class="name">{{ item.name }}</th>
          </template>
        </tr>
        <!--Table: Body-->
        <template v-for="(item, index) in dataRows" :key="index">
          <tr class="data-item">
            <td class="text-start" :rowspan="item.data.length">
              {{ item.name }}
            </td>
            <td class="text-start">
              {{ item.data[0].name }}
            </td>
            <template v-for="(child, j) in item.data[0].data" :key="j">
              <td class="check" @click="child.isSelected = !child.isSelected">
                <input type="checkbox" v-model="child.isSelected" />
              </td>
            </template>
          </tr>
          <template v-for="(child, j) in item.data" :key="j">
            <tr v-if="j > 0">
              <td class="text-start">
                {{ child.name }}
              </td>
              <template v-for="(child_2, j) in child.data" :key="j">
                <td
                  class="check"
                  @click="child_2.isSelected = !child_2.isSelected"
                >
                  <input type="checkbox" v-model="child_2.isSelected" />
                </td>
              </template>
            </tr>
          </template>
        </template>
      </table>
    </div>
    <div class="actions">
      <button class="save">
        <span>Save</span>
      </button>
      <button class="cancel" @click="cancel()">
        <span>Cancel</span>
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { VIEW_PAGE_HEADER, VIEW_PAGE_ROWS } from "@/mock/view-page.mock.js";

export default defineComponent({
  name: "view-page-modal-content",
  components: {},
  props: {},
  data() {
    return {
      dataHeader: VIEW_PAGE_HEADER,
      dataRows: VIEW_PAGE_ROWS,
    };
  },
  methods: {
    cancel() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/role/view-page";
</style>
