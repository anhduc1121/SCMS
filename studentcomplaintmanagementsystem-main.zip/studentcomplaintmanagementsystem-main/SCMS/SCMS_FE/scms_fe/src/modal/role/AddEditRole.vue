<template>
  <div
    id="add-edit-role-modal-content"
    class="add-edit-role-modal-content have-loading"
  >
    <div class="info">
      <div class="item">
        <div class="label">{{ $t("label.name") }}</div>
        <div class="value">
          <input
            v-model="roleData.name"
            type="text"
            autocomplete="off"
            spellcheck="false"
          />
        </div>
      </div>
      <!-- <div class="item-view" @click="viewPage">
        <div class="icon">
          <i class="fa-solid fa-eye"></i>
        </div>
        <div class="label">{{ $t("role.viewPage") }}</div>
      </div> -->
    </div>
    <div class="view-api">
      <div class="label">
        {{ $t("role.viewAPI") }}
      </div>
      <div class="checknox-all">
        <input
          type="checkbox"
          v-model="selectAll"
          @click="selectAllRole()"
          class="selected"
        />
      </div>
      <div class="value have-loading">
        <div class="api-list">
          <template v-for="(api, index) in roleData.viewApis" :key="index">
            <div class="api" @click="toogleViewAPI(api, $event)">
              <div class="name">{{ api.name }}</div>
              <div class="selected">
                <input
                  type="checkbox"
                  v-model="api.isSelected"
                  @click="toogleViewAPI(api, $event)"
                />
              </div>
            </div>
          </template>
        </div>
        <Loading v-if="loadingSections.loadViewAPI" :isFullScreen="false" />
      </div>
    </div>
    <div class="actions">
      <button class="save" @click="onSubmit()">
        <span>{{ $t("button.save") }}</span>
      </button>
      <button class="cancel" @click="cancel()">
        <span>{{ $t("button.cancel") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { VIEW_API } from "@/mock/view-api.mock.js";
import RoleAPIService from "@/script/services/RoleAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";

export default defineComponent({
  name: "add-edit-role-modal-content",
  components: { Loading },
  props: { data: Object, isAdd: Boolean },
  data() {
    return {
      roleData: {
        name: "",
        viewApis: VIEW_API,
        roleId: "00000000-0000-0000-0000-000000000000",
      },
      loadingSections: {
        loadViewAPI: false,
        section1: false,
      },
      selectAll: false,
    };
  },
  async created() {
    this.toast = useToast();
    if (!this.isAdd) {
      this.roleData.name = this.data.roleName;
      this.roleData.roleId = this.data.roleId;
    }
    this.getViewAPI();
  },
  methods: {
    async onSubmit() {

      this.roleData.name = this.roleData.name.trim();

      if(this.roleData.name == ''){
        this.toast(this.$t('toast.Role.mess1'), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      if (this.isAdd) {
        this.onSubmitAdd();
      } else {
        this.onSubmitEdit();
      }
    },
    selectAllRole() {
      this.roleData.viewApis.forEach((api) => {
        api.isSelected = !this.selectAll;
      });
    },
    async onSubmitEdit() {
      // console.log(this.roleData.viewApis);
      this.loadingSections.section1 = true;

      const formData = new FormData();
      formData.append("RoleId", this.roleData.roleId);
      formData.append("RoleName", this.roleData.name);

      if (this.roleData.viewApis.length > 0) {
        var count = 0;
        this.roleData.viewApis.forEach((item) => {
          // Thực hiện các hành động với từng role trong this.functionData.roles
          if (item.isSelected) {
            formData.append(`FunctionIds[${count}]`, item.id);
            count = count + 1;
          }
        });
      }

      const res = await RoleAPIService.update(formData);
      if (res != null) {
        this.toast("Update data  successfully", {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });

        this.loadingSections.section1 = false;

        this.$emit("reLoadData");
      } else {
        this.toast("Update data error", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },

    async onSubmitAdd() {
      this.loadingSections.section1 = true;

      const formData = new FormData();
      formData.append("RoleId", this.roleData.roleId);
      formData.append("RoleName", this.roleData.name);

      if (this.roleData.viewApis.length > 0) {
        var count = 0;
        this.roleData.viewApis.forEach((item) => {
          // Thực hiện các hành động với từng role trong this.functionData.roles
          if (item.isSelected) {
            formData.append(`FunctionIds[${count}]`, item.id);
            count = count + 1;
          }
        });
      }

      const res = await RoleAPIService.add(formData);
      if (res != null &&  res.message == 'SUCCESS') {
        this.toast(this.$t('toast.Common.mess2'), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });

        this.loadingSections.section1 = false;

        this.$emit("reLoadData");
      } else {
        this.toast(this.$t('toast.Common.mess3'), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },

    toogleViewAPI(api, event) {
      event.stopPropagation();
      api.isSelected = !api.isSelected;
    },
    async getViewAPI() {
      this.loadingSections.loadViewAPI = true;
      const res = await RoleAPIService.GetListFunctionByRoles(
        this.roleData.roleId
      );
      if (res != null) {
        this.roleData.viewApis = res.data;
        this.loadingSections.loadViewAPI = false;
      } else {
        this.toast("Load data API error", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.loadViewAPI = false;
      }
    },
    viewPage() {
      this.$emit("view-page");
    },
    cancel() {
      this.$emit("cancel");
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/modal/role/add-edit";
</style>
