<template>
  <div class="app-main">
    <div class="page-header">
      <Header />
    </div>
    <div class="page-content">
      <div class="page-menu" :class="{ 'small-left-menu': isSmallLeftMenu }">
        <LeftMenu :isSmall="isSmallLeftMenu" @toogle-menu="toogleMenu" />
      </div>
      <div class="page-view">
        <PageTitle />
        <router-view />
        <!--TODO: footer-->
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, watch } from "vue";
import { useRoute } from "vue-router";
import LeftMenu from "@/layout/left-menu/LeftMenu.vue";
import Header from "@/layout/header/Header.vue";
import PageTitle from "@/core/components/PageTitle.vue";

export default defineComponent({
  name: "default-layout",
  components: {
    LeftMenu,
    Header,
    PageTitle,
  },
  data() {
    return {
      isSmallLeftMenu: false,
    };
  },
  setup() {
    const route = useRoute();
    watch(() => route.path);
  },
  methods: {
    toogleMenu() {
      this.isSmallLeftMenu = !this.isSmallLeftMenu;
    },
  },
});
</script>
