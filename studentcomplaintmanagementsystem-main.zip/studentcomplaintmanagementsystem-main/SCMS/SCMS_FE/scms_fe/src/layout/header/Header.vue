<template>
  <div id="app-header" class="app-header">
    <div class="app-logo">
      <router-link to="/">
        <img src="@/assets/logo/scms_fill.png" alt=""
      /></router-link>
    </div>
    <div class="header-menu">
      <div class="ques" @click=" this.$router.push(`/user-help`)">
        <img src="@/assets/svg-icon/question.svg" alt="" />
      </div>
      <div class="lang-flag item-border">
        <b-dropdown class="lang-dropdown" end>
          <template #button-content>
            <img v-if="lang == 'en'" src="@/assets/flag/en.svg" alt="" />
            <img v-if="lang == 'vi'" src="@/assets/flag/vi.svg" alt="" />
          </template>
          <b-dropdown-item @click="changeLanguage('en')">
            <img src="@/assets/flag/en.svg" alt="" />
            English
          </b-dropdown-item>
          <b-dropdown-item @click="changeLanguage('vi')">
            <img src="@/assets/flag/vi.svg" alt="" />
            Tiếng Việt
          </b-dropdown-item>
        </b-dropdown>
      </div>
      <div class="user-info">
        <div class="avatar">
          <img :src=this.user.picture alt="" @click="toogleUserMenu" />
        </div>
        <div class="name" @click="toogleUserMenu">{{ this.user.email }}</div>
        ({{this.user.role.join(', ')  }})
        <div
          v-if="isShowUserMenu == true"
          ref="userMenu"
          class="user-menu-view"
        >
          <ul>
            <li v-if="this.user.firstName  != null || this.user.lastName != null">
              <div class="label">{{ $t("table.name") }}:</div>
              <div class="value">{{ this.user.firstName }} {{ this.user.lastName }} </div>
            </li>
            <li>
              <div class="label">{{ $t("table.email") }}:</div>
              <div class="value">{{ this.user.email }}</div>
            </li>
            <li>
              <div class="label">{{$t("span.usersRole") }}:</div>
              <div class="value">{{ this.user.role.join(', ') }}</div>
            </li>
            <li>
              <div class="label">{{ $t("span.campus") }}:</div>
              <div class="value">{{ this.user.campus }}</div>
            </li>
            <li>
              <div class="label">{{ $t("span.education") }}:</div>
              <div class="value">{{ this.user.education }}</div>
            </li>
            <li>
              <div class="label">{{ $t("span.department") }}:</div>
              <div class="value">{{ this.user.department }}</div>
            </li>
            <!-- <li class="border-top">
              <button>Sign out FLM</button>
            </li> -->
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { BDropdown, BDropdownItem } from "bootstrap-vue-next";
// import ApiService from "@/script/api.service";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "app-header",
  data() {
    return {
      lang: "en",
      isShowUserMenu: false,
      user: {
        firstName: "",
        lastName: "",
        picture: "",
        email: "",
        phone: "",
        address: "",
        createDate: "",
        campus: "",
        education: "",
        department: "",
        role: [],
      },
      // apiService: new ApiService(),
    };
  },
  components: {
    BDropdown,
    BDropdownItem,
  },
  async created() {
    this.lang = this.$i18n.locale;
    const user = await UserApiService.getInforUser();
    if (user != null) {
      this.user = user.data;
    }
  },
  methods: {
    changeLanguage(lang) {
      this.$i18n.locale = lang;
      this.lang = lang;
    },
    toogleUserMenu() {
      this.isShowUserMenu = !this.isShowUserMenu;
    },
  },
});
</script>
