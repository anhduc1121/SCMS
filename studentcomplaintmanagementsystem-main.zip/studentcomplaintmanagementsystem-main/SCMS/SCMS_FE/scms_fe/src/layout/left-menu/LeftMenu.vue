<template>
  <div id="left-menu" class="left-menu have-loading">
    <div class="menu">
      <template v-for="menu in menuConfig" :key="menu.id">
        <Menu
          :menuItem="menu"
          :isSmallView="isSmallView"
          @toogle-menu="toogleViewMenu($event)"
        />
      </template>
      <div class="menu-item" @click="logout()">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
        <span v-if="!isSmallView">Log out</span>
      </div>
    </div>
    <div class="toogle-left-menu" @click="toogleLeftMenu()">
      <button>
        <i v-if="!isSmallView" class="fa-solid fa-arrow-left"></i>
        <i v-if="isSmallView" class="fa-solid fa-arrow-right"></i>
      </button>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { MENU_CONFIG } from "@/core/const/menu.const.js";
import ApiService from "@/script/api.service";
import Menu from "./Menu.vue";
import Loading from "@/core/components/Loading.vue";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "left-menu",
  components: {
    Menu,
    Loading,
  },
  props: { isSmall: Boolean },
  data() {
    return {
      isSmallView: false,
      menuConfig: [],
      apiService: new ApiService(),
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  watch: {
    isSmall(newVal) {
      this.isSmallView = newVal;
    },
  },
  async created() {
    try {
      this.loadingSections.section1 = true;

      //Note: mới kiểm tra đến 2 bậc menu cha-con
      const authorizedMenuItems = await Promise.all(
        MENU_CONFIG.map(async (item) => {
          // Xử lý trường hợp có sub-menu
          if (item.children && item.children.length > 0) {
            const authorizedChildren = await Promise.all(
              item.children.map(async (child) => {
                const isChildAuthorized = await UserApiService.getPageAuthority(
                  child.nameAuthority
                );
                return isChildAuthorized ? child : null;
              })
            );
            const hasAuthorizedChildren = authorizedChildren.filter(
              (child) => child !== null
            );
            if (hasAuthorizedChildren != null && hasAuthorizedChildren.length > 0) {
              item.children = hasAuthorizedChildren;
              return item;
            } else {
              return null;
            }
          } else {
            const isAuthorized = await UserApiService.getPageAuthority(
              item.nameAuthority
            );
            return isAuthorized ? item : null;
          }
        })
      );
      this.menuConfig = authorizedMenuItems.filter((item) => item !== null);
      this.isSmallView = this.isSmall;

      // if (this.menuConfig.length > 0) {
      //   this.loadingSections.section1 = false;
      // }

      this.loadingSections.section1 = false;
    } catch (error) {
      console.error("Error fetching authorized menu items:", error);
    }
  },
  methods: {
    logout() {
      this.apiService.removeToken();
    },
    toogleLeftMenu() {
      this.$emit("toogle-menu");
    },
    toogleViewMenu(menu) {
      menu.isOpen = !menu.isOpen;
    },
  },
});
</script>
