<template>
  <div id="left-menu-item" class="left-menu-item">
    <!--menu 1 cấp-->
    <router-link
      :style="childStyle"
      v-if="menuItem.link"
      :class="{
        'menu-active': checkRouteName(menuItem.nameConfig),
        'child-menu-end': menuItem.isChildEnd,
        'child-menu-start': menuItem.id == 1,
      }"
      :to="menuItem.link"
      class="menu-item"
    >
      <i :class="menuItem.icon"></i>
      <span v-if="!isSmallView" class="label">{{ $t(menuItem.key) }}</span>
    </router-link>
    <!--Begin:: menu đa cấp-->
    <div
      v-else
      class="menu-item"
      @click="toogleMenu(menuItem)"
      :style="childStyle"
      :class="{
        'menu-active': checkRouteName(menuItem.nameConfig),
        'child-menu-end': menuItem.isChildEnd,
        'child-menu-start': menuItem.id == 1,
      }"
    >
      <i :class="menuItem.icon"></i>
      <span v-if="!isSmallView">{{ $t(menuItem.key) }}</span>
      <i
        v-if="!menuItem.isOpen"
        class="fa-solid fa-chevron-down menu-arr-icon arr-closed"
      ></i>
      <i
        v-if="menuItem.isOpen"
        class="fa-solid fa-chevron-up menu-arr-icon arr-opened"
      ></i>
    </div>
    <!--Begin:: children -->
    <template
      v-if="
        menuItem.children && menuItem.children.length > 0 && menuItem.isOpen
      "
    >
      <template v-for="subMenu in menuItem.children" :key="subMenu.id">
        <Menu
          :menuItem="subMenu"
          :childStyle="menuItem.childStyle"
          :isSmallView="isSmallView"
          @toogle-menu="toogleMenu($event)"
        />
      </template>
    </template>
    <!--End:: children -->
    <!--End:: menu đa cấp-->
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { useRoute } from "vue-router";
import Menu from "./Menu.vue";

export default defineComponent({
  name: "left-menu-item",
  components: { Menu },
  props: { menuItem: Object, childStyle: Object, isSmallView: Boolean },
  setup() {
    const route = useRoute();
    const checkRouteName = (_routerName) => {
      return _routerName.indexOf(route.name) >= 0;
    };

    return {
      checkRouteName,
    };
  },
  methods: {
    toogleMenu(menu) {
      this.$emit("toogle-menu", menu);
    },
  },
});
</script>
