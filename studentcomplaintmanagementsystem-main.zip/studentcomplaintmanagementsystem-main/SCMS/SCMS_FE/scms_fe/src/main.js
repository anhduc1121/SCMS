import VNetworkGraph from "v-network-graph";
import { createApp } from 'vue'
import App from './App.vue'
import Vue3GoogleLogin from 'vue3-google-login'
import router from "./router/index";
import VueCookies from 'vue-cookies';
import { createI18n } from "vue-i18n";
import { UserManager } from 'oidc-client'
import en from "@/assets/locales/en.json";
import vi from "@/assets/locales/vi.json";
import VueAwesomePaginate from "vue-awesome-paginate";
import Notifications from '@kyvg/vue3-notification';
import {createBootstrap} from 'bootstrap-vue-next';
import Toast, { POSITION } from "vue-toastification";
// import UtillSystem from "@/script/UtillSystem"

import "@/assets/scss/yourMainScssFile.scss";

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue-next/dist/bootstrap-vue-next.css'
import "vue-awesome-paginate/dist/style.css";

const CLIENT_ID="215267008513-rokt9i1n5eju9u1sk8ulelkr1f6k3rph.apps.googleusercontent.com"

const oidcConfig = {
authority: 'https://feid.ptudev.net',
client_id: 'cms-front-end',
redirect_uri: 'http://localhost:8696', // URL mà OIDC Provider sẽ redirect lại sau khi xác thực
response_type: 'code',
scope: 'openid profile email',
automaticSilentRenew: true,
post_logout_redirect_uri:'http://localhost:8696', // URL mà ứng dụng sẽ redirect tới sau khi người dùng logout
filterProtocolClaims: false,
}

const userManager = new UserManager(oidcConfig)

const app = createApp(App);
app.use(Notifications);
app.use(createBootstrap());

app.config.globalProperties.$userManager = userManager;



app.use(Toast, {
    // Setting the global default position
    position: POSITION.TOP_RIGHT
  });
  app.use(VueAwesomePaginate);
  app.use(Vue3GoogleLogin, {
    clientId: CLIENT_ID,
  });
  app.use(VueCookies);
  // app.use(UtillSystem);
  app.use(router, VNetworkGraph).mount("#app");
  
  const i18n = createI18n({
    locale: "en", // Mặc định
    fallbackLocale: "en",
    messages: {
      en, // Tiếng Anh
      vi, // Tiếng Việt
    },
  });
  app.use(i18n);
  