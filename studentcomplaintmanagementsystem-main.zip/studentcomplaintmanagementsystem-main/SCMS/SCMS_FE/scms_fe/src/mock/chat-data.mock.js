export const CHAT_DATA_MOCK = [
  {
    id: "bc770b9b-353a-411a-9641-30fd28291801",
    userId: "12c6be9c-1d14-436a-8eb7-4765628965d4",
    userIDChat: null,
    avatar:
      "https://lh3.googleusercontent.com/a/ACg8ocIVhzDjzqNG1zuFZG7pFkL0UDGeER15_pIfgKdfvN56PpKR=s96-c",
    content: "Em muốn đăng ký học",
    attachments: [],
  },
  {
    id: "1527ac89-36e8-4ef6-b6cc-3c7dc72c65b0",
    userId: "2acfa539-86ca-4963-a0de-b3df65d39e59",
    userIDChat: null,
    avatar:
      "https://lh3.googleusercontent.com/a/ACg8ocKlu2jBOesDiVWWq6iqe2ZahVQzTBgbMbVw_8mUrHAN=s96-c",
    content: "Em xem tài liệu tham khảo",
    attachments: [
      {
        id: "a8290289-6276-4fbf-9ed7-0d84b84572b1",
        name: "tl.docs",
        type: null,
        link: "https://drive.google.com/uc?id=1ks5pueWsUeJrD8Ofk7DumGnBN4XEoDT3&export=view",
        file: null,
        description: null,
      },
    ],
  },
  {
    id: "078b4e22-5bf3-4b9b-979c-c1448aa7c903",
    userId: "12c6be9c-1d14-436a-8eb7-4765628965d4",
    userIDChat: null,
    avatar:
      "https://lh3.googleusercontent.com/a/ACg8ocIVhzDjzqNG1zuFZG7pFkL0UDGeER15_pIfgKdfvN56PpKR=s96-c",
    content: "da vang",
    attachments: [],
  },
  {
    id: "078b4e22-5bf3-4b9b-979c-c1448aa7c903",
    userId: "12c6be9c-1d14-436a-8eb7-4765628965d4",
    userIDChat: null,
    avatar:
      "https://lh3.googleusercontent.com/a/ACg8ocIVhzDjzqNG1zuFZG7pFkL0UDGeER15_pIfgKdfvN56PpKR=s96-c",
    content: "Ngoài ra bên IT trường có hỗ trợ đào tạo thêm không ạ",
    attachments: [],
  },
];
