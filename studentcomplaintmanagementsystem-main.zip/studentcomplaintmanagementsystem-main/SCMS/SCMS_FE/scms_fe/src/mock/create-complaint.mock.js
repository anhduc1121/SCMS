export const CATEGORY_TREE_MOCK = [
  {
    "id": "0547cd70-9b84-4201-98bb-59bfd163bfe5",
    "label": "Xin cấp chứng chỉ",
    "children": []
  },
  {
    "id": "03b661c2-e0c6-4fc0-98f3-7e3d46e308b6",
    "label": "Nghỉ học",
    "children": [
      {
        "id": "21842bcb-fae8-4c00-9c33-de997d4e8103",
        "label": "Kí túc xã",
        "children": []
      }
    ]
  }
];