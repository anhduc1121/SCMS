export const REPORT_1_STATISTICS_DATA = [
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
    {
        total: 12,
        solved: 5,
        processing: 4,
        expired: 3,
        avgProcessTime: 20,
    },
];