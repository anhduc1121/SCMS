export const DOC_HELP_LIST = [
  {
    title: "Title",
    description: "Des",
    type: "Type",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
    description: "Des",
    type: "Type",
  },
  {
    title: "Title",
    type: "Type",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
    type: "Type",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
    description: "Des",
  },
  {
    title: "Title",
    type: "Type",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
    type: "Type",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
    description: "Des",
    type: "Type",
  },
  {
    title: "Title",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
    description: "Des",
    youtubeUrl: "FSY2AL-u0oA?si=ZkjWjapjEeZVPa7V",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
    description: "Des",
    type: "Type",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
  },
  {
    title: "Title",
    type: "Type",
  },
  {
    title: "Title",
    description: "Des",
  },
  {
    title: "Title 1",
    description: "Des",
    type: "Type",
  },
];
