export const VIEW_API = [
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
  {
    name: "View API",
    isSelected: true,
  },
];
