export const VIEW_PAGE_HEADER = [
  {
    id: 1,
    name: "Role A",
  },
  {
    id: 2,
    name: "Role B",
  },
  {
    id: 3,
    name: "Role C",
  },
  {
    id: 3,
    name: "Role D",
  },
];

export const VIEW_PAGE_ROWS = [
  {
    name: "Complaint",
    data: [
      {
        name: "Line 1",
        data: [
          {
            id: 1,
            name: "Role A",
            isSelected: false,
          },
          {
            id: 2,
            name: "Role B",
            isSelected: true,
          },
          {
            id: 3,
            name: "Role C",
            isSelected: false,
          },
          {
            id: 3,
            name: "Role D",
            isSelected: false,
          },
        ],
      },
      {
        name: "Line 2",
        data: [
          {
            id: 1,
            name: "Role A",
            isSelected: true,
          },
          {
            id: 2,
            name: "Role B",
            isSelected: false,
          },
          {
            id: 3,
            name: "Role C",
            isSelected: true,
          },
          {
            id: 3,
            name: "Role D",
            isSelected: false,
          },
        ],
      },
    ],
  },
  {
    name: "Complaint 2",
    data: [
      {
        name: "Line 21",
        data: [
          {
            id: 1,
            name: "Role A",
            isSelected: true,
          },
          {
            id: 2,
            name: "Role B",
            isSelected: true,
          },
          {
            id: 3,
            name: "Role C",
            isSelected: true,
          },
          {
            id: 4,
            name: "Role D",
            isSelected: true,
          },
        ],
      },
      {
        name: "Line 22",
        data: [
          {
            id: 1,
            name: "Role A",
            isSelected: true,
          },
          {
            id: 2,
            name: "Role B",
            isSelected: true,
          },
          {
            id: 3,
            name: "Role C",
            isSelected: false,
          },
          {
            id: 4,
            name: "Role D",
            isSelected: false,
          },
        ],
      },
      {
        name: "Line 23",
        data: [
          {
            id: 1,
            name: "Role A",
            isSelected: false,
          },
          {
            id: 2,
            name: "Role B",
            isSelected: true,
          },
          {
            id: 3,
            name: "Role C",
            isSelected: false,
          },
          {
            id: 4,
            name: "Role D",
            isSelected: false,
          },
        ],
      },
    ],
  },
];
