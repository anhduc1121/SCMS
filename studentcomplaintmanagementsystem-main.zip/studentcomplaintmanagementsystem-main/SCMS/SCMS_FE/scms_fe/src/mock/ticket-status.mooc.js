export const TICKET_STATUS_DATA = [
    {
      "statusTicketId": "7d2d2ebe-bc30-4631-a679-12a238ea2f45",
      "statusTicketName": "Đang chờ",
      "modifyUpdate": null,
      "createDate": "2024-03-28T02:09:06.36",
      "isDelete": false
    },
    {
      "statusTicketId": "810b802f-b503-4b5c-a929-7da50385234c",
      "statusTicketName": "Đang kiểm tra",
      "modifyUpdate": null,
      "createDate": "2024-03-28T02:09:06.36",
      "isDelete": false
    },
    {
      "statusTicketId": "411c603f-3f61-40d1-802b-d1811d4f3aa7",
      "statusTicketName": "Hoàn thành",
      "modifyUpdate": null,
      "createDate": "2024-03-28T02:09:06.36",
      "isDelete": false
    }
  ]