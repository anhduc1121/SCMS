export const SUGGESTION_DATA = [
    {
      "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f45",
      "description": "description...",
      
      "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
      "categoryName": " http://localhost:8696/",
      "createDate": "2024-03-28T02:09:06.36",
      "modifyUpdate": null,
      "isDelete": false,
      "isAccept": true,
      "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
    },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f46",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f47",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f48",
        "description": "description...",
        
        "categoryTicketID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f49",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f50",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f51",
        "description": "description...",
        
        "categoryTicketID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f52",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f53",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },{
        "ticketSuggestionID": "7d2d2ebe-bc30-4631-a679-12a238ea2f54",
        "description": "description...",
        
        "categoryTicketID": "03B661C2-E0C6-4FC0-98F3-7E3D46E308B6",
        "categoryName": "Le Duc Viet",
        "createDate": "2024-03-28T02:09:06.36",
        "modifyUpdate": null,
        "isDelete": false,
        "isAccept": true,
        "requestUpdateID": "21842BCB-FAE8-4C00-9C33-DE997D4E8103"
      },
  ]