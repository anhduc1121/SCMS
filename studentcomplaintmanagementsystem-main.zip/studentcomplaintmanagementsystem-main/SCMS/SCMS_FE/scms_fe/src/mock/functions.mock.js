export const FUNCTIONS = [
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
  {
    name: "Name 1",
    description: "Description 1",
    role: "Role 1",
  },
];
