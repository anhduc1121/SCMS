export const EMPLOYEE_DETAIL = {
    employeeId: "1",
    employeeEmail: "leducviet@gmail.com",
    firstname: "",
    lastname: "",
    createDate: "04-09-2024",
    phone: "0944444444",
    address: "Ha Noi",
    campusId: "",
    campusName: "Hoa Lac",
    statusId: "",
    statusName: "Block",
    departmentId: "1",
    departmentName: "Phong IT",
};

export const LIST_ROLE_BY_ACCOUNT_ID = [
    
        {
          roleId: "0ea8c451-1e3c-4a44-afc4-23904332d460",
          roleName: "Admin",
          createDate: "2024-03-31T17:10:46.013"
        },
        {
          roleId: "21842bcb-fae8-4c00-9c33-de997d4e8103",
          roleName: "Student",
          createDate: "2024-03-31T17:10:46.013"
        }
      
];

