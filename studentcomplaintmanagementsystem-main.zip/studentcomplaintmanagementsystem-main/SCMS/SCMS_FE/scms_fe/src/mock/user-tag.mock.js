export const USER_TAG_MOCK = [
  {
    id: 1,
    from: "A@gmail.com",
    to: "B1@gmail.com",
    date: "2024-12-12 12:00",
    status: "Accept",
    file: [],
  }
];
