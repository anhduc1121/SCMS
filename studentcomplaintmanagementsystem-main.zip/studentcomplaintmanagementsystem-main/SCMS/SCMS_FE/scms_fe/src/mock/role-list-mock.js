export const ROLEE_LIST = [
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
    {
        name: 'Role 1',
        isSelected: true
    },
]