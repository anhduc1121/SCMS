export const TITLE_RESULT_MOCK_DATA = [
  {
    no: 1,
    title: "Title ",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 2,
    title: "Title 2",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 3,
    title: "Title 3",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 4,
    title: "Title 4",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 5,
    title: "Title 5",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 6,
    title: "Title 6",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 7,
    title: "Title 7",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 8,
    title: "Title 8",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 9,
    title: "Title 9",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 10,
    title: "Title 10",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 11,
    title: "Title 11",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 12,
    title: "Title 12",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 13,
    title: "Title 13",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 14,
    title: "Title 14",
    createdDate: "12-12-2024 13:50",
  },
  {
    no: 15,
    title: "Title 15",
    createdDate: "12-12-2024 13:50",
  },
];
