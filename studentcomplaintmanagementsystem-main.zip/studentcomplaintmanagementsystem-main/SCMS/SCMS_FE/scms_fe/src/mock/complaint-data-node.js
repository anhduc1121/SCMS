export const COMPLAINT_DATA_NODE = {
  "nodes": {
    "node1": {
      "name": "A",
      "size": 16,
      "color":'#ff0000',
      "ticketHandlingId": "ee58fa77-78ea-40d6-93d8-03f7a27b035c"
    },
    "node2": {
      "name": "B",
      "size": 16,
      "color": "green",
      "ticketHandlingId": "a3473191-e7f1-4e43-b023-04793698a922"
    },
    "node3": {
      "name": "C",
      "size": 16,
      "color": "blue",
      "ticketHandlingId": "150db287-263e-427f-b8dc-2cb7b6eb0e72"
    }
  },
  "edges": {
    "edge1": {
      "source": "node1",
      "target": "node3"
    },
    "edge2": {
      "source": "node3",
      "target": "node2"
    }
  },
  "layouts": {
    "node1": {
      "x": 0,
      "y": 0
    },
    "node3": {
      "x": 50,
      "y": 50
    },
    "node2": {
      "x": 100,
      "y": 0
    }
  }
};

