export const DATA_PL = [
  {
    id: 1,
    label: "PL01",
  },
  {
    id: 2,
    label: "PL02",
  },
  {
    id: 3,
    label: "PL03",
  },
  {
    id: 4,
    label: "PL04",
  },
  {
    id: 5,
    label: "PL05",
  },
  {
    id: 6,
    label: "PL06",
  },
  {
    id: 7,
    label: "PL07",
  },
  {
    id: 8,
    label: "PL08",
  },
  {
    id: 9,
    label: "PL09",
  },
  {
    id: 10,
    label: "PL10",
  },
  {
    id: 11,
    label: "PL11",
  },
  {
    id: 12,
    label: "PL12",
  },
  {
    id: 13,
    label: "PL13",
  },
  {
    id: 14,
    label: "PL14",
  },
  {
    id: 15,
    label: "PL15",
  },
  {
    id: 16,
    label: "PL16",
  },
  {
    id: 17,
    label: "PL17",
  },
  {
    id: 18,
    label: "PL18",
  },
];
export const DATA_CL = [
  {
    id: 1,
    label: "CL01",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: true,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: true,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: true,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: true,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: true,
      },
    ],
  },
  {
    id: 2,
    label: "CL02",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: true,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: true,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: true,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 3,
    label: "CL03",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: true,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: true,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: true,
      },
    ],
  },
  {
    id: 4,
    label: "CL04",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: true,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: true,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: true,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 5,
    label: "CL05",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: true,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: true,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 6,
    label: "CL06",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: true,
      },
      {
        id: 10,
        value: true,
      },
      {
        id: 11,
        value: true,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 7,
    label: "CL07",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: true,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: true,
      },
      {
        id: 18,
        value: true,
      },
    ],
  },
  {
    id: 8,
    label: "CL08",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: true,
      },
      {
        id: 8,
        value: true,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 9,
    label: "CL09",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: true,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: true,
      },
      {
        id: 16,
        value: true,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 10,
    label: "CL10",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: true,
      },
      {
        id: 6,
        value: true,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 11,
    label: "CL11",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: true,
      },
      {
        id: 8,
        value: true,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 12,
    label: "CL12",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: true,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: true,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 13,
    label: "CL13",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: true,
      },
      {
        id: 11,
        value: true,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 14,
    label: "CL14",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: true,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: true,
      },
    ],
  },
  {
    id: 15,
    label: "CL15",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: true,
      },
      {
        id: 8,
        value: true,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 16,
    label: "CL16",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: true,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: true,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: false,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
  {
    id: 17,
    label: "CL17",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: false,
      },
      {
        id: 10,
        value: false,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: false,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: true,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: true,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: true,
      },
    ],
  },
  {
    id: 18,
    label: "CL18",
    data: [
      {
        id: 1,
        value: true,
      },
      {
        id: 2,
        value: false,
      },
      {
        id: 3,
        value: false,
      },
      {
        id: 4,
        value: false,
      },
      {
        id: 5,
        value: false,
      },
      {
        id: 6,
        value: false,
      },
      {
        id: 7,
        value: false,
      },
      {
        id: 8,
        value: false,
      },
      {
        id: 9,
        value: true,
      },
      {
        id: 10,
        value: true,
      },
      {
        id: 11,
        value: false,
      },
      {
        id: 12,
        value: true,
      },
      {
        id: 13,
        value: false,
      },
      {
        id: 14,
        value: true,
      },
      {
        id: 15,
        value: false,
      },
      {
        id: 16,
        value: false,
      },
      {
        id: 17,
        value: false,
      },
      {
        id: 18,
        value: false,
      },
    ],
  },
];
