export const REPORT_2_DAILY_REPORT_DATA = [
    {
        accountIdCreate: "1",
        email: "lecucviet1@gmail.com",
        totalTicket: 12,
        created: 5,
        assigned: 4,
        received: 3,
        solved: 3,
        expired: 3,
        averageProcessingTime: 30.0,
        averageRating: 0.75,
    },
];

export const REPORT_2_DAILY_REPORT_TABLE_2_DATA = [
    {
        "categoryName": "Vệ sinh giường",
        "account": [
          {
            "email": "vietldhe153395@fpt.edu.vn",
            "count": 0
          },
          {
            "email": "vietldhe15339f5@fpt.edu.vn",
            "count": 0
          },
        ],
    },
];



