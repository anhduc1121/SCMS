export const SYNTHESIS_REPORT_DATA = [
    {
        "categoryParenName": "Nội",
        "categoryChild": [
            {
                "categoryChildName": "Bác B",
                "reportParameters":
                {
                    "totalTicket": 0,
                    "completedTicket": 0,
                    "ticketsProcessing": 0,
                    "expiredTicket": 0,
                    "averageProcessingTime": 0,
                    "averageRating": 0
                },

            },
            
        ]
    }
]