<template>
  <div id="page-complaint" class="page-complaint have-loading">
    <div class="page-complaint-content">
      <div class="page-complaint-search">
        <div class="search-title">
          <div class="label">{{ $t("search.title") }}</div>
          <div class="value">
            <input
              v-model="this.filter.title"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.title')"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-filter">
        <!--{{$t('search.category')}}-->
        <div class="filter-item">
          <div class="label">{{ $t("search.category") }}</div>
          <div class="value">
            <select
              v-model="filter.categoryType.categoryName"
              @click="changeCategory()"
            >
              <option hidden>{{ filter.categoryType.categoryName }}</option>
            </select>
          </div>
        </div>
        <div class="filter-item" v-if="this.authority.is.ViewStaff">
          <div class="label">{{ $t("search.department") }}</div>
          <div class="value">
            <select
              v-model="this.departmentSelect"
              @change="this.toogleSort('x')"
            >
              <option value="" selected>{{ $t("label.All") }}</option>
              <option
                v-for="(item, index) in departments"
                :key="item.departmentName"
                :value="item.departmentId"
                :selected="index === 0"
              >
                {{ item.departmentName }}
              </option>
            </select>
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.status") }}</div>
          <div class="value">
            <select v-model="filter.statusType" @change="this.toogleSort('x')">
              <option value="" selected>{{ $t("label.All") }}</option>
              <option
                v-for="status in this.statusData"
                :key="status.statusTicketId"
                :value="status.statusTicketId"
              >
                {{ status.statusTicketName }}
              </option>
            </select>
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.student") }}</div>
          <div class="value">
            <input
              v-model="this.filter.student"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.staff") }}</div>
          <div class="value">
            <input
              v-model="this.filter.staff"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.otherStaff") }}</div>
          <div class="value">
            <input
              v-model="this.filter.otherStaff"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.createDate") }}</div>
          <div class="value">
            <input
              v-model="this.filter.createDate"
              type="date"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.date')"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="title">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.title == sortConst.A_Z ||
                      filter.sort.title == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  >
                  </i>
                  <i
                    v-if="filter.sort.title == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  >
                  </i>
                </span>
                <span class="label">{{ $t("table.title") }}</span>
              </div>
            </th>
            <th class="from">{{ $t("table.student") }}</th>
            <th class="tag">{{ $t("table.staff") }}</th>
            <th class="tag">{{ $t("table.category") }}</th>
            <th class="tag" v-if="this.authority.is.ViewStaff">
              {{ $t("table.department") }}
            </th>
            <th class="status">
              <div class="th-sort" @click="toogleSort('status')">
                <span class="icon"> </span>
                <span class="label">{{ $t("table.status") }}</span>
              </div>
            </th>
            <th class="creator">{{ $t("table.otherStaff") }}</th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td>
                <router-link
                  :to="`/department-complaint/details/${item.ticketDepartmentsId}`"
                  class="text-decoration-none link-primary"
                >
                  {{ item.title }}
                </router-link>
              </td>
              <td>
                {{ item.accountStudent }}
                <!-- vietldhe153395@fpt.edu.vn -->
              </td>
              <td>{{ item.accountStaff }}</td>
              <td>
                {{ item.categoryTicketName }}
              </td>
              <td v-if="this.authority.is.ViewStaff">
                {{ item.departmentName }}
              </td>
              <td>{{ item.statusTicketName }}</td>
              <!-- <td>{{ item.emailBehaveCreate }}</td> -->
              <td>{{ item.accountStaffOther }}</td>
              <td>{{ this.formatDate(item.createDate) }}</td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
  <!-- Category Modal-->
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    :title="$t('placeholder.category')"
    class="select-category-modal"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :isShowSelectAllCategoryModal="true"
      :selected-data-id="this.filter.categoryType.categoryTicketId"
      :source="'create-complaint'"
      @change-category="selectNewCategory($event)"
      @change-category-all="selectNewCategoryAll()"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import TicketStatusAPIService from "@/script/services/TicketStatusAPIService";
import { BModal } from "bootstrap-vue-next";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import UserApiService from "@/script/services/UserApiService";
import ComplaintDepartmentAPIService from "@/script/services/ComplaintDepartmentAPIService";
import DepartmentAPIService from "@/script/services/DepartmentAPIService";
import Loading from "@/core/components/Loading.vue";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";

export default defineComponent({
  name: "page-complaint",
  components: {
    Pagination,
    BModal,
    EditCategory,
    Loading,
    // Treeselect,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      isShowCategoryModal: false,
      sortConst: SORT,
      filter: {
        title: "",
        categoryType: {
          categoryTicketId: "",
          categoryName: "",
          fullPath: "",
        },
        statusType: "",
        sort: {
          title: SORT.A_Z,
          status: SORT.A_Z,
          createdDate: SORT.Z_A,
          pin: SORT.A_Z,
        },
        student: "",
        staff: "",
        otherStaff: "",
        createDate: "",
      },
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      categories: [],
      tableData: [],
      statusData: [],
      loadingSections: {
        section1: false,
        loadStatus: false,
        loadCategory: false,
        loadDepartment: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },

      departments: [],
      departmentSelect: "",
      authority: {
        code: {
          ViewStaffOther: "976816fc-713e-4721-bebe-4cc2b6fcc2de",
          ViewStaff: "3bd4065d-a903-47b2-91d3-7b60f48442bc",
        },
        is: {
          ViewStaffOther: false,
          ViewStaff: false,
        },
      },
    };
  },
  async created() {
    this.toast = useToast();
    const res = await UserApiService.isChildAuthorized("/department-complaint");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([
      await this.loadAuthority(),

      await Promise.all([
        this.getCategorys(),
        this.getStatus(),
        this.getComplaint(),
        this,
        this.getDepatment(),
      ]),
    ]);
  },
  methods: {
    async loadAuthority() {
      this.authority.is.ViewStaffOther = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaffOther
      );
      this.authority.is.ViewStaff = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaff
      );
    },
    changeCategory() {
      this.isShowCategoryModal = true;
    },
    selectNewCategory(data) {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = data.item;
      this.getCategorys();
      this.toogleSort("x");
    },

    selectNewCategoryAll() {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = "";
      this.filter.categoryType.categoryName = "All";
      this.toogleSort("x");
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },

    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },
    async getStatus() {
      const respon = await TicketStatusAPIService.getStatus();
      if (respon != null) {
        this.statusData = respon;
      }
    },
    async getCategorys() {
      if (this.filter.categoryType.categoryTicketId == "") {
        this.filter.categoryType.categoryName = "All";
      } else {
        this.loadingSections.loadCategory = true;
        const respon = await CategoryAPIService.GetCategoryById(
          this.filter.categoryType.categoryTicketId
        );
        if (respon != null) {
          this.filter.categoryType = respon;
          this.loadingSections.loadCategory = false;
        } else {
          this.toast("Load data category error", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });

          this.loadingSections.loadCategory = false;
        }
      }
    },
    async getDepatment() {
      this.loadingSections.loadDepartment = true;
      const res = await DepartmentAPIService.getDepartments();
      if (res != null) {
        this.loadingSections.loadDepartment = false;
        this.departments = res.data;
      } else {
        this.loadingSections.loadDepartment = false;
      }
    },
    async getComplaint() {
      // console.log(this.filter)

      const formData = new FormData();
      formData.append("title", this.filter.title);
      formData.append(
        "categoryTicketId",
        this.filter.categoryType.categoryTicketId
      );
      formData.append("departmentId", this.departmentSelect);
      formData.append("accountGmaillStudent", this.filter.student);
      formData.append("accountGmaillStaff", this.filter.staff);
      formData.append("accountGmaillOtherStaff", this.filter.otherStaff);
      formData.append("statusTicketId", this.filter.statusType);
      formData.append("createDate", this.filter.createDate);
      formData.append("sortTitle", this.filter.sort.title);
      formData.append("sortDate", this.filter.sort.createdDate);
      formData.append("pageIndex", this.pageData.currentPage);
      formData.append("pageSize", this.pageSize);

      this.loadingSections.section1 = true;
      if (this.authority.is.ViewStaff) {
        const respon =
          await ComplaintDepartmentAPIService.getComplaintDepartmentForStaff(
            formData
          );
        if (respon != null) {
          this.loadingSections.section1 = false;
          this.tableData = respon.data;
          // console.log(respon.data)
          const total = respon.numberOfRecords;
          this.pageData = {
            totalItem: total,
            itemPerPage: parseInt(this.pageSize),
            maxPageShow: 5,
            currentPage: this.pageData.currentPage,
          };
        } else {
          this.loadingSections.section1 = false;
        }
      }
      if (this.authority.is.ViewStaffOther) {
        const respon =
          await ComplaintDepartmentAPIService.getComplaintDepartmentForStaffOther(
            formData
          );
        if (respon != null) {
          this.loadingSections.section1 = false;
          this.tableData = respon.data;
          // console.log(respon.data)
          const total = respon.numberOfRecords;
          this.pageData = {
            totalItem: total,
            itemPerPage: parseInt(this.pageSize),
            maxPageShow: 5,
            currentPage: this.pageData.currentPage,
          };
        } else {
          this.loadingSections.section1 = false;
        }
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "title":
          this.filter.sort.title =
            this.filter.sort.title == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "status":
          this.filter.sort.status =
            this.filter.sort.status == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "pin":
          this.filter.sort.pin =
            this.filter.sort.pin == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          break;
      }
      this.getComplaint();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getComplaint();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getComplaint();
    },
  },
  computed: {
    loadingSectionPage() {
      const { section1, loadStatus, loadDepartment, loadCategory } =
        this.loadingSections;
      return section1 || loadStatus || loadDepartment || loadCategory;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";
</style>