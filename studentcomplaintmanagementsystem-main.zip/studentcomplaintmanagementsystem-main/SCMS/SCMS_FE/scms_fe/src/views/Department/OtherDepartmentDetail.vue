<template>
  <div id="app-complaint-details" class="app-complaint-details have-loading">
    <div class="left-menu-flow"></div>
    <div class="content-data">
      <div class="info">
        <div class="centered">
          <div class="category">
            <div class="title">
              {{ this.complaintDetail.category.categoryTicketName }}
            </div>
          </div>
          <div class="title">
            <h2 style="max-width: 11000px">{{ this.complaintDetail.title }}</h2>

            <div class="datetime">
              <span class="time">{{
                this.formatTime(this.complaintDetail.createDate)
              }}</span>
              <span class="date">{{
                this.formatDate(this.complaintDetail.createDate)
              }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="question">
        <div class="label" v-html="this.complaintDetail.description"></div>
        <div class="question-eye" @click="viewComplaintDetails()">
          <button>
            <i class="fa-solid fa-eye"></i>
          </button>
        </div>
      </div>
      <div v-if="addSuggestionStatus" class="note">
        <span>{{ $t("span.forward") }}</span>
      </div>
      <div ref="scrollContainer" class="chat chat-height">
        <template v-for="(item, index) in chatData" :key="index">
          <!--other-->
          <template v-if="item.columView == '1'">
            <!--with out attachment-->

            <div class="conten-user-chat">
              {{ item.email }}
            </div>

            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length == 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-left"
            >
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
              <div
                class="chat-content"
                :class="{ 'chat-content-user': item.isCreatedTicket }"
              >
                <span>{{ item.content }}</span>
              </div>
            </div>
            <!--with attachment-->
            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length > 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-left"
            >
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
              <div class="chat-content have-attachment">
                <!--Attachments-->
                <template v-for="(attach, i) in item.attachments" :key="i">
                  <span
                    class="content-attachment"
                    @click="downloadFile(attach.link)"
                  >
                    <i class="fa-regular fa-file"></i>
                    {{ attach.name }}
                  </span></template
                >
                <span class="mess">{{ item.content }}</span>
              </div>
            </div>
          </template>
          <!--your message-->
          <template v-if="item.columView == '2'">
            <!--with out attachment-->
            <div
              @click="selectMessenger(item.id)"
              class="chat-line chat-right"
              v-if="item.attachments.length == 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
            >
              <div class="chat-content">
                <span>{{ item.content }}</span>
              </div>
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
            </div>
            <!--with attachment-->
            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length > 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-right"
            >
              <div class="chat-content have-attachment">
                <!--Attachments-->
                <template v-for="(attach, i) in item.attachments" :key="i">
                  <span
                    class="content-attachment"
                    @click="downloadFile(attach.link)"
                  >
                    <i class="fa-regular fa-file"></i>
                    {{ attach.name }}
                  </span></template
                >
                <span class="mess">{{ item.content }}</span>
              </div>
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
            </div> </template
        ></template>
      </div>
      <div v-if="messageAttachment.length > 0" class="attachment-selected">
        <template v-for="(item, i) in reverseFiles" :key="i">
          <div v-if="i < 3" class="attach-item">
            <div class="delete" @click="removeAttachment(item.id)">
              <i class="fa-solid fa-xmark"></i>
            </div>
            <div class="icon">
              <template v-if="item.type.indexOf('image') >= 0">
                <i class="fa-solid fa-image"></i>
              </template>
              <template v-else>
                <i class="fa-solid fa-file"></i>
              </template>
            </div>
            <div class="name">{{ item.name }}</div>
          </div>
          <div v-if="i == 3" class="attach-item">
            <div class="name">...(+{{ messageAttachment.length - 3 }})</div>
          </div>
        </template>
      </div>
      <div class="chat-input" v-if="this.isContinue">
        <input
          type="text"
          autocomplete="off"
          spellcheck="false"
          :placeholder="$t('placeholder.message')"
          v-model="messengerContent"
          @keyup.enter="sendMessenger()"
        />
        <input
          hidden
          ref="selectAttachmentRef"
          type="file"
          multiple
          @change="choosenAttachment($event)"
        />
        <button class="attach-btn" @click="selectAttachment()">
          <i class="fa-solid fa-paperclip"></i>
        </button>
        <button class="send-btn" @click="sendMessenger()">
          <i class="fa-solid fa-paper-plane"></i>
        </button>
      </div>
    </div>
    <div
      :class="{ 'maximun-rm': isShowRightMenu, 'minimun-rm': !isShowRightMenu }"
      class="right-menu"
    >
      <div
        v-if="!isShowRightMenu"
        class="min-rm"
        @click="isShowRightMenu = !isShowRightMenu"
      >
        <i class="min-icon fa-solid fa-angles-left"></i>
      </div>

      <div v-if="isShowRightMenu && this.authority.is.ViewStaff" class="max-rm">
        <div class="close-menu">
          <button @click="isShowRightMenu = !isShowRightMenu">
            <i class="fa-solid fa-angles-right"></i>
          </button>
          <div class="blank"></div>
        </div>
        <div class="rm-content">
          <div class="actions">
            <button
              class="save"
              @click="feedback()"
              v-if="this.authority.is.ViewStaff && this.isContinue"
            >
              <span>{{ $t("span.finish") }}</span>
            </button>
            <button
              class="add"
              v-if="this.authority.is.ViewStaff"
              @click="
                this.$router.push(
                  `/complaint/details/${this.complaintDetail.ticketID}`
                )
              "
            >
              <span>{{ $t("button.backComplaint") }}</span>
            </button>
            <button
              class="add"
              @click="openAddSUggestionModal()"
              v-if="this.authority.is.ViewStaff && this.isContinueForward"
            >
              <span
                >{{ $t("button.forward") }}
                <span v-if="addSuggestionStatus"
                  >({{ messageSelected.length }})</span
                >
              </span>
            </button>
            <button
              v-if="addSuggestionStatus"
              class="cancel"
              @click="cancelAddSUggestionModal()"
            >
              <span>{{ $t("button.cancelForward") }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>

  <b-modal
    v-model="isShowAddSuggestModal"
    centered
    hideFooter="true"
    :title="this.$t('span.updateMessengerBeforeForward')"
    class="select-category-modal"
  >
    <SentComplaintModal
      v-if="isShowAddSuggestModal"
      :dataMess="messageSelected"
      :id="this.complaintDetail.ticketID"
      @close="closeSuggestModal"
      @close-reloadData="closeSuggestModalDone"
      @add-suggest="addSuggestAfterEdit($event)"
    />
  </b-modal>

  <!-- Title modal -->
  <b-modal
    v-model="isShowComplaintDetailModal"
    centered
    hideFooter="true"
    :title="$t('label.complaintDetail')"
    class="complaint-view-only-modal"
  >
    <ComplaintViewDetail
      :complaintSuggest="this.complaintDetail"
      :category="this.complaintDetail.category.categoryTicketName"
      v-if="isShowComplaintDetailModal"
      @close="isShowComplaintDetailModal = !isShowComplaintDetailModal"
    />
  </b-modal>

  <!-- Finish Modal-->
  <b-modal
    v-model="isShowFinishModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.feedback')"
    class="complaint-finish-modal"
  >
    <Finish @cancel="closeFinishModal" />
  </b-modal>
</template>

<script>
import Loading from "@/core/components/Loading.vue";
import { defineComponent } from "vue";
import { BModal } from "bootstrap-vue-next";
import ComplaintDepartmentAPIService from "@/script/services/ComplaintDepartmentAPIService";
import UserApiService from "@/script/services/UserApiService";
import { useToast } from "vue-toastification";
import { COMPLAINT_DATA_NODE } from "@/mock/complaint-data-node";
import { TYPE } from "vue-toastification";
import Finish from "@/modal/complaint-details/Finish.vue";
import SentComplaintModal from "@/modal/department-details/SentComplaintModal.vue";
import ComplaintViewDetail from "@/modal/department-details/ComplaintViewDetail.vue";
import SignalRService from "@/script/signalr.service";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "system-department-detail",
  components: {
    BModal,
    Finish,
    Loading,
    SentComplaintModal,
    ComplaintViewDetail,
  },

  data() {
    return {
      ticketID: "352201ED-9347-4FD8-8F47-634AE178DB35",

      //phục vụ biểu đồ
      dataGraph: COMPLAINT_DATA_NODE,
      nodes: null,
      edges: null,
      layouts: null,
      configs: null,
      loadingSections: {
        section1: false,
        loadViewChat: false,
        loadViewDetail: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      id: null,
      isShowTitleModal: false,
      isShowRightMenu: true,
      isShowLeftMenu: false,
      isShowUserTagModal: false,
      isShowAddSuggestModal: false,
      isShowAddDepartmentModal: false,
      isShowCategoryModal: false,
      categoryModalOpenFrom: "",
      dataUserTagDetail: null,
      isShowReportModal: false,
      isShowFinishModal: false,
      complaintSuggestion: {
        ticketSuggestionId: "",
        title: "",
        description: "",
        createDate: "",
      },
      isShowComplaintDetailModal: false,
      // online user
      userData: [1],
      yourId: 2, //id của user đang đăng nhập, dùng để kiểm tra xem tin nhắn có đến từ user đang đăng nhập không
      chatData: [],
      complaintDetail: {
        category: {
          categoryTicketId: 3,
          categoryTicketName: "Category 3",
          description: "Desccription for Category 3",
          isHaveChild: false,
          isShow: false,
          parentIds: [],
        },
        title: "",
        description: "",
        createDate: "",
        dataMock: [],
        ticketID: "",
      },
      tagUsers: [],
      addSuggestionStatus: false, // mặc định chế độ chọn tin nhắn Suggestion là false
      messageSelected: [],
      messengerContent: "",
      messageAttachment: [],
      toast: null,
      authority: {
        code: {
          ViewStaffOther: "976816fc-713e-4721-bebe-4cc2b6fcc2de",
          ViewStaff: "3bd4065d-a903-47b2-91d3-7b60f48442bc",
        },
        is: {
          ViewStaffOther: false,
          ViewStaff: false,
        },
      },
      signalRConnection: new SignalRService(),
      isContinue: true,
      isContinueForward: true,
      totalFilesSize: 0
    };
  },

  async created() {
    await this.signalRConnection.start();

    const res = await UserApiService.isChildAuthorized("department-complaint");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([
      await this.loadAuthority(),
      (this.toast = useToast()),
      (this.id = this.$route.params.id),
      (this.yourId = UserApiService.getUserSession().nameid),
      await Promise.all([
        this.getComplaintDetail(),
        this.getComplaintChatDetail(),
        this.reloadChatSignalR(this.id),
      ]),
    ]);
    this.scrollMessAreaToBottom();
  },
  mounted() {
    this.scrollMessAreaToBottom();
    window.addEventListener("beforeunload", this.handleBeforeUnload);
  },
  async beforeRouteLeave(to, from, next) {
    // await this.signalRConnection.stop();
    await this.signalRConnection.stop();
    next();
  },
  computed: {
    reverseFiles() {
      return this.messageAttachment.slice().reverse();
    },
  },
  methods: {
    //event khi thoat trang
    async handleBeforeUnload() {
      // Thực hiện các hành động trước khi rời khỏi trang
      // await this.signalRConnection.stop();

      // Có thể cung cấp một thông báo để hỏi người dùng có muốn rời khỏi hay không
      // event.returnValue = "Bạn có chắc chắn muốn rời khỏi trang?";
      await this.signalRConnection.stop();
    },

    //start: SignalR
    reloadChatSignalR(method) {
      // Đăng ký phương thức nhận dữ liệu từ server
      this.signalRConnection.connection.on(
        "department-complaint/details/__chat" + method.toLowerCase(),
        (message) => {
          console.log("Received message:", message);
          this.getComplaintDetail(),
            this.getComplaintChatDetail(),
            //kéo xuống tin nhắn mới nhất
            this.scrollMessAreaToBottom();
        }
      );
    },
    //End: SignalR

    closeSuggestModal() {
      this.isShowAddSuggestModal = false;
      this.isShowComplaintDetailModal = false;
    },
    closeSuggestModalDone() {
      this.isShowAddSuggestModal = false;
      this.messageSelected = [];
      this.addSuggestionStatus = false;
    },
    viewComplaintDetails() {
      this.isShowComplaintDetailModal = true;
    },
    async loadAuthority() {
      this.authority.is.ViewStaffOther = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaffOther
      );
      this.authority.is.ViewStaff = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaff
      );
    },

    async getComplaintDetail() {
      if (this.authority.is.ViewStaff) {
        this.loadingSections.loadViewDetail = true;
        const res =
          await ComplaintDepartmentAPIService.getTicketDepartmentByTicketStaff(
            this.id
          );
        if (res != null) {
          this.loadingSections.loadViewDetail = false;
          this.complaintDetail.category.categoryTicketName =
            res.data.categoryTicketName;
          this.complaintDetail.category.categoryTicketId =
            res.data.categoryTicketId;
          this.complaintDetail.title = res.data.title;
          this.complaintDetail.description = res.data.description;
          this.complaintDetail.createDate = res.data.createDate;
          this.complaintDetail.dataMock = res.data.ticketDepartmentCommentsVM;
          this.complaintDetail.ticketID = res.data.ticketId;
          this.isContinue =
            res.data.statusTicketId !== "fd6e17b5-c63d-42b6-bd10-40fb98629c50";

          this.isContinueForward =
            res.data.statusTicketStudentId !==
            "fd6e17b5-c63d-42b6-bd10-40fb98629c50";
        } else {
          this.loadingSections.loadViewDetail = false;
        }
      }

      if (
        this.authority.is.ViewStaffOther &&
        this.authority.is.ViewStaffOthe != this.authority.is.ViewStaffOther
      ) {
        this.loadingSections.loadViewDetail = true;
        const res =
          await ComplaintDepartmentAPIService.getTicketDepartmentByTicketStaffOther(
            this.id
          );
        if (res != null) {
          this.loadingSections.loadViewDetail = false;
          this.complaintDetail.category.categoryTicketName =
            res.data.categoryTicketName;
          this.complaintDetail.category.categoryTicketId =
            res.data.categoryTicketId;
          this.complaintDetail.title = res.data.title;
          this.complaintDetail.description = res.data.description;
          this.complaintDetail.createDate = res.data.createDate;
          this.complaintDetail.ticketID = res.data.ticketId;
          this.isContinue =
            res.data.statusTicketId !== "fd6e17b5-c63d-42b6-bd10-40fb98629c50";
          this.isContinueForward =
            res.data.statusTicketStudentId !==
            "fd6e17b5-c63d-42b6-bd10-40fb98629c50";
        } else {
          this.loadingSections.loadViewDetail = false;
        }
      }
    },

    async getComplaintChatDetail() {
      if (this.authority.is.ViewStaff) {
        this.loadingSections.loadViewChat = true;
        const res =
          await ComplaintDepartmentAPIService.getViewTicketCommentsChatStaff(
            this.id
          );
        if (res != null && res.message == "SUCCESS") {
          this.chatData = res.data;
          this.loadingSections.loadViewChat = false;
        } else {
          this.toast("You do not have permission to view the application!!!", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.$router.push("/department-complaint");
          this.loadingSections.loadViewChat = false;
        }
      }

      if (this.authority.is.ViewStaffOther) {
        this.loadingSections.loadViewChat = true;
        const res =
          await ComplaintDepartmentAPIService.getViewTicketCommentsChatStaffOther(
            this.id
          );
        if (res != null && res.message == "SUCCESS") {
          this.chatData = res.data;
          this.loadingSections.loadViewChat = false;
        } else {
          this.toast("You do not have permission to view the application!!!", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.$router.push("/department-complaint");
          this.loadingSections.loadViewChat = false;
          return;
        }
      }

      this.scrollMessAreaToBottom();
    },

    formatTime(dateString) {
      const date = new Date(dateString);
      const options = {
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23", // Hiển thị theo định dạng 24 giờ
      };
      const formattedTime = date
        .toLocaleString("en-US", options)
        .replace(/:/g, ":");
      return formattedTime;
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      };
      const formattedDate = date
        .toLocaleString("en-US", options)
        .replace(/\//g, "/");
      return formattedDate;
    },

    //Begin:: Feedback
    async feedback() {
      // this.isShowFinishModal = true;

      const response = await ComplaintDepartmentAPIService.endTicketDepartment(
        this.id
      );
      if (response != null) {
        this.toast(this.$t("toast.Common.mess2"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
        this.getComplaintDetail();
      } else {
        this.loadingSections.section1 = false;
        this.toast(this.$t("toast.Common.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.getComplaintDetail();
      }
    },
    closeFinishModal() {
      this.isShowFinishModal = false;
    },
    //End:: Feedback

    //Begin:: Add Suggestion
    openAddSUggestionModal() {
      if (this.addSuggestionStatus) {
        // if (this.messageSelected.length == 0) return;
        //nếu ở chế độ chọn Suggestion => show modal
        this.isShowAddSuggestModal = true;
        return;
      }
      this.addSuggestionStatus = !this.addSuggestionStatus;
    },
    cancelAddSUggestionModal() {
      this.messageSelected = [];
      this.addSuggestionStatus = false;
    },
    selectMessenger(id) {
      if (!this.addSuggestionStatus) return;
      const isExisting = this.messageSelected.find((f) => f.id == id);

      if (isExisting) {
        //gỡ tin nhắn khỏi list tin nhắn đã chọn
        const index = this.messageSelected.indexOf(isExisting);

        this.messageSelected.splice(index, 1);
        return;
      }
      const messSelected = this.chatData.find((f) => f.id == id);
      if (messSelected) {
        // console.log(messSelected);
        //thêm tin nhắn vào list được chọn
        this.messageSelected.push(messSelected);
        return;
      }
    },

    addSuggestAfterEdit(data) {
      console.log(data.data, "sugguest messages");
      this.isShowAddSuggestModal = false;
    },
    //End:: Add Suggestion

    //Begin: Report
    showReport() {
      this.isShowReportModal = true;
    },
    //End: Report

    async scrollMessAreaToBottom() {
      // Cuộn xuống tin nhắn mới nhất
      //nextTick để chắc chắn DOM đã render xong
      if (this.authority.is.ViewStaff || this.authority.is.ViewStudent) {
        this.$nextTick(() => {
          this.$refs.scrollContainer.scrollTop =
            this.$refs.scrollContainer.scrollHeight;
        });
      }
    },
    checkShowAvatar(index, id) {
      //nếu 2 tin nhắn liên tiếp đến từ 1 người thì chỉ hiện ảnh dại diện ở tin đầu tiên
      if (index == 0) return true;
      if (this.chatData[index - 1].id == id) return false;
      return true;
    },
    isMessSelected(id) {
      //kiểm tra xem tin nhắn có được chọn hay không
      return this.messageSelected.find((f) => f.id == id) ? true : false;
    },
    downloadFile(id) {
      //chỉ có thể tải tệp khi không ở chế độ chọn Suggestion
      if (this.addSuggestionStatus) return;
      window.location.href = `${id}`;
      // alert(`Download file id: ${id}`);
    },
    selectAttachment() {
      this.$refs.selectAttachmentRef.click();
    },
    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    choosenAttachment(event) {
      const files = event.target.files;

      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.messageAttachment.push({
              id: this.messageAttachment.length + 1,
              name: file.name,
              link: "",
              type: file.type,
              file: file,
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },
    removeAttachment(id) {
      if (this.messageAttachment.length == 0) return;
      const fileSelected = this.messageAttachment.find((f) => f.id == id);
      if (fileSelected) {
        const index = this.messageAttachment.indexOf(fileSelected);
        this.messageAttachment.splice(index, 1);
      }
    },
    async sendMessenger() {
      //kiểm tra nếu chưa có tin nhắn và attaschment thì k gửi
      if (this.messengerContent == "" && this.messageAttachment.length == 0)
        return;

      const formData = new FormData();
      formData.append("comment", this.messengerContent);
      formData.append("ticketDepartmentsId", this.id);

      if (this.messageAttachment.length > 0) {
        for (const item of this.messageAttachment) {
          formData.append("ticketAttachments", item.file);
        }
      }
      if (this.authority.is.ViewStaff) {
        this.loadingSections.section1 = true;
        const response = await ComplaintDepartmentAPIService.replyTicketStaff(
          formData
        );
        if ((response != null) & (response.message == "CREATE_SUCCESS")) {
          this.toast(this.$t("toast.Common.mess2"), {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.section1 = false;
        } else {
          this.loadingSections.section1 = false;
          this.toast(this.$t("toast.Common.mess3"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      }

      if (this.authority.is.ViewStaffOther) {
        this.loadingSections.section1 = true;
        const response =
          await ComplaintDepartmentAPIService.replyTicketStaffOther(formData);
        if ((response != null) & (response.message == "CREATE_SUCCESS")) {
          this.toast(this.$t("toast.Common.mess2"), {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.section1 = false;
        } else {
          this.loadingSections.section1 = false;
          this.toast(this.$t("toast.Common.mess3"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      }

      this.getComplaintChatDetail();
      // this.chatData.push(newMess);
      //xóa dữ liệu tin nhắn và attachments sau khi gửi xong
      this.messengerContent = "";
      this.messageAttachment = [];
      //kéo xuống tin nhắn mới nhất
      this.scrollMessAreaToBottom();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint-details.scss";
</style>