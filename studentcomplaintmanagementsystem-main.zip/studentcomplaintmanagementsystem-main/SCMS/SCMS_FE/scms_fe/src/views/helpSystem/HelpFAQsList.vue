<template>
  <div id="help-doc-list" class="help-doc-list have-pagination">
    <div class="top">
      <div class="title">
        <div class="label">Title</div>
        <div class="value">
          <input
            type="text"
            autocomplete="off"
            spellcheck="false"
            placeholder="Enter title..."
          />
        </div>
      </div>
      <div class="add">
        <button @click="addNew">
          <span>Add New</span>
        </button>
      </div>
    </div>
    <div class="data">
      <table>
        <tr class="header">
          <th class="no">No</th>
          <th>
            <div class="th-sort" @click="toogleSort()">
              <span class="icon">
                <i
                  v-if="
                    titleSort == sortConst.A_Z || titleSort == sortConst.A_A
                  "
                  class="fa-solid fa-arrow-down"
                ></i>
                <i
                  v-if="titleSort == sortConst.Z_A"
                  class="fa-solid fa-arrow-up"
                ></i>
              </span>
              <span class="label">Title</span>
            </div>
          </th>
          <th class="des">Description</th>
          <th class="action"></th>
        </tr>
        <template v-for="(item, index) in tableData" :key="index">
          <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
            <td>{{ index + 1 }}</td>
            <td class="text-start">{{ item.title }}</td>
            <td class="text-start">
              <span v-html="item.description"></span>
            </td>
            <td class="item-actions">
              <button class="edit" @click="editDoc(item, $event)">
                <i style="color: #fff !important" class="fa-solid fa-pen"></i>
              </button>
              <button class="delete">
                <i style="color: #fff !important" class="fa-solid fa-xmark"></i>
              </button>
            </td>
          </tr>
        </template>
      </table>
    </div>
    <div class="pagination">
      <div class="page-ct">
        <div class="_page-size">
          <div class="label">{{ $t("label.pageSize") }}</div>
          <select v-model="pageSize">
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <div class="_page-view">
          <Pagination v-model:dataInput="pageData" />
        </div>
      </div>
    </div>
  </div>
  <!-- Add/Edit Modal-->
  <b-modal
    v-model="isShowModal"
    centered
    hideFooter="true"
    :title="modalTitleKey"
    class="doc-help-add-edit-modal"
  >
    <AddEditFaqsHelp
      v-if="isShowModal"
      :data="itemSelected"
      :isAdd="isAdd"
      @cancel="closeModal"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import { SORT } from "@/core/const/app.const.js";
import Pagination from "@/core/components/Pagination.vue";
import { DOC_HELP_LIST } from "@/mock/doc-help.mock.js";
import AddEditFaqsHelp from "@/modal/help/AddEditFaqsHelp.vue";
import { BModal } from "bootstrap-vue-next";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "help-doc-list",
  components: {
    Pagination,
    AddEditFaqsHelp,
    BModal,
  },
  data() {
    return {
      modalTitleKey: "",
      isShowModal: false,
      itemSelected: null,
      isAdd: true,
      sortConst: SORT,
      titleSort: SORT.A_Z,
      tableData: DOC_HELP_LIST,
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/manager-help-faqs-list");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
  },
  methods: {
    toogleSort() {
      this.titleSort = this.titleSort == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
    },
    addNew() {
      this.isAdd = true;
      this.modalTitleKey = "Add";
      this.itemSelected = null;
      this.isShowModal = true;
    },
    editDoc(item, event) {
      event.stopPropagation();
      this.isAdd = false;
      this.itemSelected = item;
      this.modalTitleKey = "Edit";
      this.isShowModal = true;
    },
    closeModal() {
      (this.itemSelected = null), (this.modalTitleKey = "");
      this.isShowModal = false;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/help/document-list.scss";
@import "@/assets/scss/views/page";
@import "@/assets/scss/views/common/pagination.scss";
</style>
