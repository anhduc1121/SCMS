<template>
  <div id="user-help" class="user-help">
    <div class="left" :class="{ 'left-hide': !isViewLeft }">
      <div class="content">
        <LeftView
          v-if="isViewLeft"
          :menuActive="menuActive"
          @select="selectMenu($event)"
        />
        <div class="support-team">
          <div class="s-title">Đội hỗ trợ</div>
          <div class="user">
            <div class="u-item">
              <i class="fa-solid fa-user"></i>
              <span>HangNTT21@fe.edu.vn </span>
            </div>
            <!-- <div class="u-item">
              <i class="fa-solid fa-user"></i>
              <span>user2@fpt.com</span>
            </div>
            <div class="u-item">
              <i class="fa-solid fa-user"></i>
              <span>user3@fpt.com</span>
            </div>
            <div class="u-item">
              <i class="fa-solid fa-user"></i>
              <span>user4@fpt.com</span>
            </div>
            <div class="u-item">
              <i class="fa-solid fa-user"></i>
              <span>user5@fpt.com</span>
            </div> -->
          </div>
          <div class="s-title tt-2">Hotline</div>
          <div class="user">
            <div class="u-item">
              <i class="fa-solid fa-phone"></i>
              <span>02473081313</span>
            </div>
          </div>
          <!-- <div class="s-title tt-2">
            <router-link to="/about">
                <span>About Us</span>
              </router-link>
          </div> -->

        </div>
      </div>
      <div class="close" @click="isViewLeft = !isViewLeft">
        <i v-if="isViewLeft" class="fa-solid fa-angle-left"></i>
        <i v-if="!isViewLeft" class="fa-solid fa-angle-right"></i>
      </div>
    </div>
    <div class="help-content">
      <div class="content-item">
        <div v-if="menuActive == 1" class="video-help">
          <div class="title">Video hướng dẫn</div>
          <!-- <template v-for="(item, index) in videoData" :key="index">
            <div class="video-item">
              <div class="video">
                <iframe
                  width="560"
                  height="315"
                  src="https://www.youtube.com/embed/tmiNgebd1zw?si=i1GA-PNh1Y13ErRB"
                  title="YouTube video player"
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerpolicy="strict-origin-when-cross-origin"
                  allowfullscreen
                ></iframe>
              </div>
              <div class="video-title">Title</div>
              <div class="video-des">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo
                excepturi inventore eum sequi voluptates nobis rerum doloremque
                deleniti animi porro. Nam nisi maiores exercitationem harum esse
                voluptatibus reiciendis, odio expedita!
              </div>
            </div>
          </template> -->
        </div>
        <div v-if="menuActive == 2" class="video-help">
          <div class="title">Tài liệu hướng dẫn</div>
          <!-- <template v-for="(item, index) in videoData" :key="index">
            <div class="doc-item">
              <div class="icon">
                <i class="fa-solid fa-book"></i>
              </div>
              <div class="name">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.pdf
              </div>
            </div>
          </template> -->
        </div>
        <div v-if="menuActive == 3" class="version">
           <AboutUs2/>
        </div>
      </div>
    </div>
    <div class="right" :class="{ 'right-hide': !isViewRight }">
      <div v-if="isViewRight" class="title">FAQs</div>
      <div v-if="isViewRight" class="content">
        <FAQItem />
      </div>
      <div class="close" @click="isViewRight = !isViewRight">
        <i v-if="isViewRight" class="fa-solid fa-angle-right"></i>
        <i v-if="!isViewRight" class="fa-solid fa-angle-left"></i>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import LeftView from "@/components/help/LeftView.vue";
import FAQItem from "@/components/help/FAQItem.vue";
import UserApiService from "@/script/services/UserApiService";
import AboutUs2 from "@/views/common/AboutUs2.vue";

export default defineComponent({
  name: "user-help",
  components: {
    LeftView,
    FAQItem,
    AboutUs2
  },
  data() {
    return {
      isViewLeft: true,
      isViewRight: false,
      menuActive: 3,
      videoData: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/user-help");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
  },
  methods: {
    selectMenu(id) {
      this.menuActive = id;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/help/user-help.scss";
</style>
