<template>
  <div
    id="page-complaint"
    class="page-complaint have-loading"
    v-if="this.authority.is.ViewStaff || this.authority.is.ViewStudent"
  >
    <div class="page-complaint-content">
      <div class="page-complaint-search">
        <div class="search-title">
          <div class="label">{{ $t("search.title") }}</div>
          <div class="value">
            <input
              v-model="this.filter.title"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.title')"
            />
            <!-- <button class="search-btn">
              <span><i class="fa-solid fa-magnifying-glass"></i></span>
              <span>Search</span>
            </button> -->
            <button
              v-if="this.authority.is.ViewStudent"
              class="search-btn new-complaint-btn"
            >
              <router-link to="/complaint/create">
                <span><i class="fa-solid fa-plus"></i></span>
                <span>{{ $t("button.newComplaint") }}</span>
              </router-link>
            </button>
          </div>
        </div>
      </div>
      <div class="page-complaint-filter">
        <!--{{$t('search.category')}}-->
        <div class="filter-item">
          <div class="label">{{ $t("search.category") }}</div>
          <div class="value">
            <select
              v-model="filter.categoryType.categoryName"
              @click="changeCategory()"
            >
              <option hidden>{{ filter.categoryType.categoryName }}</option>
            </select>
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.status") }}</div>
          <div class="value">
            <select v-model="filter.statusType" @change="this.toogleSort('x')">
              <option value="" selected>{{ $t("label.All")}}</option>
              <option
                v-for="status in this.statusData"
                :key="status.statusTicketId"
                :value="status.statusTicketId"
              >
                {{ status.statusTicketName }}
              </option>
            </select>
          </div>
        </div>
        <div class="filter-item" v-if="this.authority.is.ViewStaff">
          <div class="label">{{ $t("search.student") }}</div>
          <div class="value">
            <input
              v-model="this.filter.from"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <!--Creator-->
        <div class="filter-item" v-if="this.authority.is.ViewStaff">
          <div class="label">{{ $t("search.creator") }}</div>
          <div class="value">
            <input
              v-model="this.filter.creator"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <!--Tag-->
        <div class="filter-item" v-if="this.authority.is.ViewStaff">
          <div class="label">{{ $t("search.tag") }}</div>
          <div class="value">
            <input
              v-model="this.filter.tag"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.createDate") }}</div>
          <div class="value">
            <input
              v-model="this.filter.createDate"
              type="date"
              @change="this.toogleSort('x')"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.date')"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th v-if="this.authority.is.ViewStaff" class="from">
              {{ $t("table.student") }}
            </th>
            <th class="title" style="max-width: 50px">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.title == sortConst.A_Z ||
                      filter.sort.title == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  >
                  </i>
                  <i
                    v-if="filter.sort.title == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  >
                  </i>
                </span>
                <span class="label">{{ $t("table.title") }}</span>
              </div>
            </th>

            <th class="tag">{{ $t("table.category") }}</th>
            <th class="created-date">
              <div class="th-sort">
                <span class="label">{{ $t("table.pic") }}</span>
              </div>
            </th>
            <th v-if="this.authority.is.ViewStaff" class="tag">
              {{ $t("table.tag") }}
            </th>
            <th class="status">
              <div class="th-sort" @click="toogleSort('status')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.status == sortConst.A_Z ||
                      filter.sort.status == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.status == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.status") }}</span>
              </div>
            </th>
            <th v-if="this.authority.is.ViewStaff" class="creator">
              {{ $t("table.creator") }}
            </th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th class="star">
              <div class="th-sort" @click="toogleSort('pin')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.pin == sortConst.A_Z ||
                      filter.sort.pin == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.pin == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.pin") }}</span>
              </div>
            </th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td v-if="this.authority.is.ViewStaff">{{ item.emailCreate }}</td>
              <td style="max-width: 50px; overflow: hidden;">
                <router-link
                  :to="`/complaint/details/${item.ticketId}`"
                  class="text-decoration-none link-primary"
                >
                  {{ item.title }}
                </router-link>
              </td>

              <td>
                {{ item.categoryTicketName }}
              </td>
              <td>{{  item.responsiblePersonEmail }}</td>
              <td v-if="this.authority.is.ViewStaff">
                {{
                  item.accountTagInfors && item.accountTagInfors.length > 0
                    ? item.accountTagInfors.map((x) => x.requiredAccountName)[0]
                    : "None"
                }}
              </td>
              <td>{{ item.statusTicketName }}</td>
              <td v-if="this.authority.is.ViewStaff">
                {{ item.emailBehaveCreate }}
              </td>
              <td>{{ this.formatDate(item.createDate) }}</td>
              <td class="star-item">
                <template v-if="!item.isPin">
                  <i
                    @click="addPinComplaint(item.ticketId)"
                    class="fa-regular fa-star"
                  ></i>
                </template>
                <template v-if="item.isPin">
                  <i
                    @click="deletePinComplaint(item.ticketId)"
                    class="fa-solid fa-star"
                  ></i>
                </template>
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="false" />
  </div>
  <!-- Category Modal-->
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    :title="$t('placeholder.category')"
    class="select-category-modal"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :isShowSelectAllCategoryModal="true"
      :selected-data-id="this.filter.categoryType.categoryTicketId"
      :source="'create-complaint'"
      @change-category="selectNewCategory($event)"
      @change-category-all="selectNewCategoryAll()"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import Loading from "@/core/components/Loading.vue";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import TicketStatusAPIService from "@/script/services/TicketStatusAPIService";
import ComplaintAPIService from "@/script/services/ComplaintAPIService";
import PinAPIService from "@/script/services/PinAPIService";
import { BModal } from "bootstrap-vue-next";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "page-complaint",
  components: {
    Pagination,
    BModal,
    EditCategory,
    Loading,
    // Treeselect,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      isShowCategoryModal: false,
      sortConst: SORT,
      filter: {
        title: "",
        categoryType: {
          categoryTicketId: "",
          categoryName: "",
          fullPath: "",
        },
        statusType: "",
        sort: {
          title: SORT.A_Z,
          status: SORT.A_Z,
          createdDate: SORT.Z_A,
          pin: SORT.A_Z,
        },
        from: "",
        creator: "",
        tag: "",
        createDate: "",
      },
      pageSize: 20,
      pageData: {
        totalItem: 1,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      categories: [],
      tableData: [],
      statusData: [],
      loadingSections: {
        loadCategory: false,
        loadStatus: false,
        loadComplaint: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },

      authority: {
        code: {
          ViewStudent: "36e888e0-1686-444c-ba8d-961ca8376d7c",
          ViewStaff: "4aea8cc7-bff1-445f-a8af-ddfd6e9d4896",
          CreateComplaint: "8c6e428c-2c96-4975-9e84-f76ea15ee459",
        },
        is: {
          ViewStudent: false,
          ViewStaff: false,
          CreateComplaint: false,
        },
      },
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/complaint");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }

    await Promise.all([
      await this.loadAuthority(),
      // this.loadingSections.loadCategory = true;
      (this.loadingSections.loadComplaint = true),
      await Promise.all([
        this.getCategorys(),
        this.getStatus(),
        this.getComplaint(),
      ]),
    ]);
  },

  computed: {
    loadingSectionPage() {
      const { loadCategory, loadStatus, loadComplaint } = this.loadingSections;
      return loadCategory || loadStatus || loadComplaint;
    },
  },
  methods: {
    async loadAuthority() {
      this.authority.is.ViewStudent = await UserApiService.getViewAuthority(
        this.authority.code.ViewStudent
      );
      this.authority.is.ViewStaff = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaff
      );
      this.authority.is.CreateComplaint = await UserApiService.getViewAuthority(
        this.authority.code.CreateComplaint
      );
    },
    changeCategory() {
      this.isShowCategoryModal = true;
    },
    selectNewCategory(data) {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = data.item;
      this.getCategorys();
      this.toogleSort("x");
    },

    selectNewCategoryAll() {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = "";
      this.filter.categoryType.categoryName = "All";
      this.toogleSort("x");
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    async addPinComplaint(id) {
      const res = await PinAPIService.add(id);
      if (res != null) {
        if (res.message == "SUCCESS") {
          this.getComplaint();
        }
      }
    },
    async deletePinComplaint(id) {
      const res = await PinAPIService.delete(id);
      if (res != null) {
        console.log(res);
        if (res.message == "SUCCESS") {
          this.getComplaint();
        }
      }
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },
    async getStatus() {
      this.loadingSections.loadStatus = true;
      const respon = await TicketStatusAPIService.getStatus();
      if (respon != null) {
        this.statusData = respon;
        this.loadingSections.loadStatus = false;
      }
    },
    async getCategorys() {
      if (this.filter.categoryType.categoryTicketId == "") {
        this.filter.categoryType.categoryName = "All";
      } else {
        this.loadingSections.loadCategory = true;
        const respon = await CategoryAPIService.GetCategoryById(
          this.filter.categoryType.categoryTicketId
        );
        if (respon != null) {
          this.filter.categoryType = respon;
          this.loadingSections.loadCategory = false;
          // this.filter.categoryType = respon[0]["id"];
        }
      }
    },

    async getComplaint() {
      this.loadingSections.loadComplaint = true;

      const formData = new FormData();
      formData.append("cateId", this.filter.categoryType.categoryTicketId);
      formData.append("statusTicketId", this.filter.statusType);
      formData.append("accountIDBehaveCreate", this.filter.creator);
      formData.append("tagAccountId", "");
      formData.append("accountIdCreate", "");
      formData.append("accountGmaillCreate", this.filter.from);
      formData.append("accountGmaillBehaveCreate", this.filter.creator);
      formData.append("accountGmaillTag", this.filter.tag);
      formData.append("status", "");
      formData.append("title", this.filter.title);
      formData.append("createDate", this.filter.createDate);
      formData.append("pageIndex", this.pageData.currentPage);
      formData.append("pageSize", this.pageSize);
      formData.append("sortDate", this.filter.sort.createdDate);
      formData.append("sortTitle", this.filter.sort.title);
      formData.append("sortStatusTicket", this.filter.sort.status);
      formData.append("isPin", this.filter.sort.pin == 1);

      if (this.authority.is.ViewStaff) {
        const respon = await ComplaintAPIService.getComplaints(formData);
        if (respon != null) {
          this.tableData = respon.data;
          const total = respon.numberOfRecords;
          this.pageData = {
            totalItem: total == 0 ? 1 : total,
            itemPerPage: parseInt(this.pageSize),
            maxPageShow: 5,
            currentPage: this.pageData.currentPage,
          };
          this.loadingSections.loadComplaint = false;
        }
      } else {
        const respon = await ComplaintAPIService.getComplaintsForStudent(
          formData
        );
        if (respon != null) {
          this.tableData = respon.data;
          const total = respon.numberOfRecords;
          this.pageData = {
            totalItem: total == 0 ? 1 : total,
            itemPerPage: parseInt(this.pageSize),
            maxPageShow: 5,
            currentPage: this.pageData.currentPage,
          };
          this.loadingSections.loadComplaint = false;
        }
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "title":
          this.filter.sort.title =
            this.filter.sort.title == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "status":
          this.filter.sort.status =
            this.filter.sort.status == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "pin":
          this.filter.sort.pin =
            this.filter.sort.pin == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          break;
      }
      this.getComplaint();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getComplaint();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getComplaint();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";
</style>