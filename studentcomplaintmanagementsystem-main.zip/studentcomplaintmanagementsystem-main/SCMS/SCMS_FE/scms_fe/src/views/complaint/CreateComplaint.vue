<template>
  <div id="create-complaint" class="create-complaint have-loading">
    <div class="content">
      <section class="request-action">
        <div class="category">
          <select v-model="ticketCreate.Category.categoryName" @click="changeCategory()">
            <option hidden>{{ ticketCreate.Category.categoryName }}</option>
          </select>
        </div>
        <div class="upload">
          <button @click="selectFile()">
            <span>{{ $t("button.uploadFile") }}</span>
            <span>
              <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <g id="Layer_2" data-name="Layer 2">
                  <path
                    d="m18 13a1 1 0 0 0 -1 1v3h-14v-3a1 1 0 0 0 -2 0v4a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-4a1 1 0 0 0 -1-1z" />
                  <path
                    d="m5.707 7.707 3.293-3.293v9.586a1 1 0 0 0 2 0v-9.586l3.293 3.293a1 1 0 0 0 1.414-1.414l-5-5a1 1 0 0 0 -1.414 0l-5 5a1 1 0 0 0 1.414 1.414z" />
                </g>
              </svg>
            </span>
          </button>
          <input multiple ref="selectFileRef" hidden type="file" @change="handleFileChange($event)" />
        </div>
        <div class="upload">
          <button @click="this.isShowTitleModal = !this.isShowTitleModal">
            <span>{{ $t("button.suggestion") }}</span>
          </button>
          <!--  -->
        </div>
        <template v-if="formData.files.length > 0">
          <div class="files">
            <template v-for="(item, index) in reverseFiles" :key="index">
              <template v-if="index < 3">
                <div class="item">
                  <div class="delete-file">
                    <button @click="removeFile(item)">
                      <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                  <div class="file-type">
                    <template v-if="item.type.indexOf('image') >= 0">
                      <i class="fa-solid fa-image"></i>
                    </template>
                    <template v-else>
                      <i class="fa-solid fa-file"></i>
                    </template>
                  </div>
                  <div class="file-name">{{ item.name }}</div>
                </div>
              </template>
              <template v-if="index == 3">
                <div class="item-more item">
                  <div class="file-name">
                    ... (+{{ formData.files.length - 3 }})
                  </div>
                </div>
              </template>
            </template>
          </div>
        </template>
      </section>
      <section class="question">
        <input class="title" autocomplete="off" spellcheck="false" v-model="ticketCreate.Title"
          :placeholder="$t('placeholder.title')" @keyup.enter="openTitleModal()" @change="openTitleModal" />
        <br />
        <Editor v-model="ticketCreate.Description" :placeholder="$t('placeholder.newquestion')"
          editorStyle="height: 100%">
        </Editor>
      </section>
      <section class="action">
        <button @click="confirmSubmit()">
          <span>{{ $t("button.submit") }}</span>
        </button>
      </section>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>

  <!--Category Modal-->
  <b-modal v-model="isShowCategoryModal" centered hideFooter="true" :title="$t('placeholder.category')"
    class="select-category-modal">
    <EditCategory v-if="isShowCategoryModal" :selected-data-id="this.ticketCreate.Category.categoryTicketId"
      :source="'create-complaint'" @change-category="selectNewCategory($event)" @close-modal="closeCategoryModal()" />
  </b-modal>

  <!--Title Modal-->
  <b-modal v-model="isShowTitleModal" centered hideFooter="true" :title="$t('search.titleSearch')"
    class="complaint-title-modal">
    <TitleModal v-if="isShowTitleModal" :category-id="this.ticketCreate.Category.categoryTicketId"
      :title="this.ticketCreate.Title" @view-details="viewComplaintDetails($event)" @submit="titleSubmit()"
      @cancel="titleCancel()" />
  </b-modal>

  <!--Complaint View Only Modal-->
  <b-modal v-model="isShowComplaintDetailModal" centered hideFooter="true" :title="$t('label.complaintDetail')"
    class="complaint-view-only-modal">
    <ComplaintViewDetail :complaintSuggest="this.complaintSuggestion"
      :category="this.ticketCreate.Category.categoryName" v-if="isShowComplaintDetailModal"
      @close="closeComplaintDetailModal()" />
  </b-modal>

  <!--Confirm Modal-->
  <b-modal v-model="isShowConfirmModal" centered hideFooter="true" :title="$t('confirm.confirm')" class="confirm-modal">
    <Confirm v-if="isShowConfirmModal" :config="confirmConfig" @submit="submitForm()" @cancel="closeConfirmModal()" />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Editor from "primevue/editor";
import { CATEGORY_TREE_MOCK } from "@/mock/create-complaint.mock.js";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";
import Loading from "@/core/components/Loading.vue";
import ComplaintAPIService from "@/script/services/ComplaintAPIService";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import TitleModal from "@/modal/complaint-create/TitleModal.vue";
import ComplaintViewDetail from "@/modal/complaint-create/ComplaintViewDetail.vue";
import Confirm from "@/modal/common/Confirm.vue";
import { BModal } from "bootstrap-vue-next";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "create-complaint",
  components: {
    // Treeselect,
    Editor,
    EditCategory,
    TitleModal,
    ComplaintViewDetail,
    Confirm,
    BModal,
    Loading,
  },
  async created() {
    this.toast = useToast();
    const res = await UserApiService.getPageAuthority("New Complaint");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }

    await Promise.all([await this.getCategorys()]);
  },
  data() {
    return {
      isShowConfirmModal: false,
      isShowCategoryModal: false,
      isShowTitleModal: false,
      isShowComplaintDetailModal: false,
      totalFilesSize: 0,
      formData: {
        category: null,
        files: [],
        title: null,
        question: "",
      },
      ticketCreate: {
        Title: "",
        Description: "",
        AccountIdCreate: null,
        AccountIdbehaveCreate: null,
        Category: {
          categoryTicketId: "",
          categoryName: "",
          fullPath: "",
        },
        AccountIdupdate: null,
        TicketAttachments: [],
      },
      categories: CATEGORY_TREE_MOCK,
      confirmConfig: {
        content: this.$t("span.confirmCreateTicket"),
      },
      complaintSuggestion: {
        ticketSuggestionId: "",
        title: "",
        description: "",
        createDate: "",
      },
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  methods: {
    //Begin:: Category Modal
    changeCategory() {
      this.isShowCategoryModal = true;
    },
    selectNewCategory(data) {
      this.isShowCategoryModal = false;
      this.ticketCreate.Category.categoryTicketId = data.item;
      this.getCategorys();
      this.ticketCreate.Title = this.ticketCreate.Title.trim();
      // this.isShowTitleModal = true;
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    //End:: Category Modal

    //Begin:: Title Modal
    openTitleModal() {
      this.ticketCreate.Title = this.ticketCreate.Title.trim();
      if (this.ticketCreate.Title && this.ticketCreate.Title.length > 0) {
        // this.isShowTitleModal = true;
      }
    },
    viewComplaintDetails(data) {
      console.log(data);
      this.complaintSuggestion = data;
      this.isShowComplaintDetailModal = true;
    },
    closeComplaintDetailModal() {
      this.isShowComplaintDetailModal = false;
    },
    titleSubmit() {
      this.isShowTitleModal = false;
    },
    titleCancel() {
      this.isShowTitleModal = false;
    },
    //End:: Title Modal

    async getCategorys() {
      const dataCategorys = await CategoryAPIService.GetCategoryById(
        this.ticketCreate.Category.categoryTicketId
      );
      if (dataCategorys != null) {
        this.ticketCreate.Category = dataCategorys;
        this.ticketCreate.Category.categoryName = this.limitedString(
          this.ticketCreate.Category.categoryName
        );
      }
    },

    limitedString(data) {
      if (data.length > 30) {
        const parts = data.split("/");
        if (parts.length == 0) {
          return data;
        }
        let result = "";

        for (let i = parts.length - 1; i >= 0; i--) {
          if (result.length > 30 || result.length + parts[i].length > 30) {
            break;
          }
          result = parts[i];
        }
        if (result.length == 0) {
          if (parts != null && parts.length > 0) {
            result = parts[parts.length-1];
          }
        }
        return "../" + result;
      }
      return data;
    },
    confirmSubmit() {
      this.ticketCreate.Title = this.ticketCreate.Title.trim()
      this.ticketCreate.Description = this.ticketCreate.Description.trim()

      if (this.ticketCreate.Title == "") {
        this.toast(this.$t("toast.Complaint.mess1"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }
      if (this.ticketCreate.Description == "") {
        this.toast(this.$t("toast.Complaint.mess3"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }
      if (this.ticketCreate.Category.categoryTicketId == null) {
        this.toast(this.$t("toast.Complaint.mess2"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return;
      }

      this.isShowConfirmModal = true;
    },
    closeConfirmModal() {
      this.isShowConfirmModal = false;
    },
    async submitForm() {
      this.isShowConfirmModal = false;
      // this.ticketCreate.Title = 'AVC'
      // this.ticketCreate.TicketAttachments = this.formData.files;
      try {

        const formData = new FormData();
        formData.append("Title", this.ticketCreate.Title);
        formData.append("Description", this.ticketCreate.Description);
        formData.append(
          "CategoryTicketId",
          this.ticketCreate.Category.categoryTicketId
        );

        if (this.formData.files.length > 0) {
          for (const file of this.formData.files) {
            formData.append("TicketAttachments", file);
          }
        }
        this.loadingSections.section1 = true;
        const response = await ComplaintAPIService.create(formData);
        console.log(response);
        if (response.message == "CREATE_SUCCESS") {
          this.ticketCreate.Title = "";
          this.ticketCreate.Description = "";
          this.formData.files = [];
          this.loadingSections.section1 = false;
          this.toast(this.$t("toast.Common.mess2"), {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
        } else {
          this.loadingSections.section1 = false;
          this.toast(response.message, {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      } catch (error) {
        this.toast(error, {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        console.error(error);
        this.loadingSections.section1 = false;
      }
    },
    selectFile() {
      this.$refs.selectFileRef.click();
    },
    handleFileChange(event) {
      const files = event.target.files;
      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.formData.files.push(file);
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },
    removeFile(file) {
      const index = this.formData.files.indexOf(file);
      if (index >= 0) {
        this.formData.files.splice(index, 1);
      }
    },
    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },
  },
  computed: {
    reverseFiles() {
      return this.formData.files.slice().reverse();
    },
  },
});
</script>

<style lang="scss">
@import "vue3-treeselect/dist/vue3-treeselect.css";
</style>
