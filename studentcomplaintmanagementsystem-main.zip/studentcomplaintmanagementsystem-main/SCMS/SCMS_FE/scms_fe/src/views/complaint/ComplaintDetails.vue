<template>
  <div
    id="app-complaint-details"
    class="app-complaint-details have-loading"
    v-if="
      this.authority.is.ViewStaff == true ||
      this.authority.is.ViewStudent == true
    "
  >
    <div
      :class="{
        'maximun-rm-left': isShowLeftMenu,
        'minimun-rm': !isShowLeftMenu,
      }"
      class="right-menu"
    >
      <div
        v-if="!isShowLeftMenu"
        class="min-rm min-rm-left"
        @click="isShowLeftMenu = !isShowLeftMenu"
      >
        <i class="min-icon fa-solid fa-angles-right"></i>
      </div>

      <div v-if="isShowLeftMenu" class="max-rm-clone">
        <div>
          <VNetworkGraph
            v-if="isShowLeftMenu"
            style="height: 1000px"
            :nodes="nodes"
            :edges="edges"
            :layouts="layouts"
            :configs="configs"
          />
        </div>
        <div class="close-menu">
          <button @click="isShowLeftMenu = !isShowLeftMenu">
            <i class="fa-solid fa-angles-left"></i>
          </button>
          <div class="blank"></div>
        </div>
      </div>
    </div>
    <div class="left-menu-flow"></div>
    <div class="content-data">
      <div class="info">
        <div class="centered">
          <div class="category">
            <div class="title">
              {{ this.complaintDetail.category.categoryTicketName }}
            </div>
          </div>
          <div class="title">
            <h2 style="max-width: 11000px">{{ this.complaintDetail.title }}</h2>

            <div class="datetime">
              <span class="time">{{
                this.formatTime(this.complaintDetail.createDate)
              }}</span>
              <span class="date">{{
                this.formatDate(this.complaintDetail.createDate)
              }}</span>
            </div>
          </div>
        </div>
        <div class="tag" v-if="this.authority.is.ViewStaff">
          <!--đã tag user-->
          <template v-if="tagUsers != null && tagUsers.email.length > 0">
            <!-- <template v-for="(item, i) in tagUsers" :key="i"> -->
            <div class="user-tag">
              <div
                class="name"
                @mouseover="isViewTagUser = true"
                @mouseout="isViewTagUser = false"
              >
                {{ tagUsers.email }}
                <div
                  class="copy-btn"
                  :class="{ 'copy-btn-showed': isViewTagUser == true }"
                  @click="copyTagUserEmail(tagUsers.email)"
                >
                  <i class="fa-solid fa-copy"></i>
                </div>
              </div>
              <div
                class="user-tag-details"
                :class="{ 'user-tag-details-view': isViewTagUser == true }"
              >
                {{ tagUsers.email }}
              </div>
            </div>
            <!-- </template> -->
          </template>
          <!--chưa tag user-->
          <template v-if="tagUsers == null || tagUsers.email.length == 0">
            <div class="user-tag-placeholder">
              <span>{{ $t("span.user") }}</span>
            </div>
          </template>
          <!--Nút add tag user-->
          <div
            class="tag-blank"
            v-if="this.authority.is.TagUser && this.isContinue"
          >
            <button @click="openUserTagModal()">
              <i class="fa-solid fa-plus"></i>
            </button>
          </div>
        </div>
      </div>
      <div class="question">
        <div class="label" v-html="this.complaintDetail.description"></div>
        <!-- <div class="question-eye">
          <button>
            <i class="fa-solid fa-eye"></i>
          </button>
        </div> -->
      </div>
      <div
        v-if="addSuggestionStatus && this.authority.is.ViewStaff"
        class="note"
      >
        <span>{{ $t("span.suggestion") }}</span>
      </div>
      <div ref="scrollContainer" class="chat chat-height">
        <template v-for="(item, index) in chatData" :key="index">
          <!--other-->
          <template v-if="item.columView == '1'">
            <!--with out attachment-->

            <div class="conten-user-chat">
              {{ item.email }}
            </div>

            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length == 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-left"
            >
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
              <div
                class="chat-content"
                :class="{ 'chat-content-user': item.isCreatedTicket }"
              >
                <span>{{ item.content }}</span>
              </div>
            </div>
            <!--with attachment-->
            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length > 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-left"
            >
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
              <div class="chat-content have-attachment">
                <!--Attachments-->
                <template v-for="(attach, i) in item.attachments" :key="i">
                  <div class="have-attachment-line" style="display: inline">
                    <span
                      class="content-attachment"
                      @click="downloadFile(attach.link)"
                    >
                      <i class="fa-regular fa-file"></i>
                      {{ attach.name }}
                    </span>
                  </div>
                </template>
                <span class="mess">{{ item.content }}</span>
              </div>
            </div>
          </template>
          <!--your message-->
          <template v-if="item.columView == '2'">
            <!--with out attachment-->
            <div
              @click="selectMessenger(item.id)"
              class="chat-line chat-right"
              v-if="item.attachments.length == 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
            >
              <div class="chat-content">
                <span>{{ item.content }}</span>
              </div>
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
            </div>
            <!--with attachment-->
            <div
              @click="selectMessenger(item.id)"
              v-if="item.attachments.length > 0"
              :class="{
                'content-only': checkShowAvatar(index, item.id) == false,
                'chat-content-can-select': addSuggestionStatus,
                'chat-content-selected': isMessSelected(item.id),
              }"
              class="chat-line chat-right"
            >
              <div class="chat-content have-attachment">
                <!--Attachments-->
                <template v-for="(attach, i) in item.attachments" :key="i">
                  <span
                    class="content-attachment"
                    @click="downloadFile(attach.link)"
                  >
                    <i class="fa-regular fa-file"></i>
                    {{ attach.name }}
                  </span></template
                >
                <span class="mess">{{ item.content }}</span>
              </div>
              <div class="avatar">
                <img :src="item.avatar" alt="" />
              </div>
            </div> </template
        ></template>
      </div>
      <div v-if="messageAttachment.length > 0" class="attachment-selected">
        <template v-for="(item, i) in reverseFiles" :key="i">
          <div v-if="i < 3" class="attach-item">
            <div class="delete" @click="removeAttachment(item.id)">
              <i class="fa-solid fa-xmark"></i>
            </div>
            <div class="icon">
              <template v-if="item.type.indexOf('image') >= 0">
                <i class="fa-solid fa-image"></i>
              </template>
              <template v-else>
                <i class="fa-solid fa-file"></i>
              </template>
            </div>
            <div class="name">{{ item.name }}</div>
          </div>
          <div v-if="i == 3" class="attach-item">
            <div class="name">...(+{{ messageAttachment.length - 3 }})</div>
          </div>
        </template>
      </div>
      <div class="chat-input" v-if="this.isContinue">
        <button
          v-if="this.authority.is.ViewStudent"
          class="report-btn"
          v-b-tooltip.hover.top
          title="Report"
          @click="showReport()"
        >
          <i class="fa-solid fa-flag"></i>
        </button>
        <input
          type="text"
          autocomplete="off"
          spellcheck="false"
          :placeholder="$t('placeholder.message')"
          v-model="messengerContent"
          @keyup.enter="sendMessenger()"
        />
        <input
          hidden
          ref="selectAttachmentRef"
          type="file"
          multiple
          @change="choosenAttachment($event)"
        />
        <button class="attach-btn" @click="selectAttachment()">
          <i class="fa-solid fa-paperclip"></i>
        </button>
        <button class="send-btn" @click="sendMessenger()">
          <i class="fa-solid fa-paper-plane"></i>
        </button>
      </div>
    </div>
    <div
      :class="{ 'maximun-rm': isShowRightMenu, 'minimun-rm': !isShowRightMenu }"
      class="right-menu"
    >
      <div
        v-if="!isShowRightMenu"
        class="min-rm"
        @click="isShowRightMenu = !isShowRightMenu"
      >
        <i class="min-icon fa-solid fa-angles-left"></i>
      </div>

      <div v-if="isShowRightMenu" class="max-rm">
        <div class="close-menu">
          <button @click="isShowRightMenu = !isShowRightMenu">
            <i class="fa-solid fa-angles-right"></i>
          </button>
          <div class="blank"></div>
        </div>
        <div class="rm-content">
          <div class="actions">
            <button
              class="save"
              @click="feedback()"
              v-if="this.authority.is.ViewStudent && this.isContinue"
            >
              <span>{{ $t("span.finish") }}</span>
            </button>
            <!-- <button class="cancel">
              <span>{{ $t("span.abandon") }}</span>
            </button> -->
            <button
              class="edit"
              v-if="
                this.authority.is.ViewStaff &&
                this.authority.is.EditCategory &&
                this.isContinue
              "
              @click="openCategoryModal('from-complaint-details')"
            >
              <span>{{ $t("span.editCategory") }}</span>
            </button>

            <button
              class="add"
              v-if="this.authority.is.ViewStaff && this.isContinue"
              @click="openAddSUggestionModal()"
            >
              <span
                >{{ $t("span.addSuggestion") }}
                <span v-if="addSuggestionStatus"
                  >({{ messageSelected.length }})</span
                >
              </span>
            </button>
            <button
              v-if="addSuggestionStatus && this.isContinue"
              class="cancel"
              @click="cancelAddSUggestionModal()"
            >
              <span>{{ $t("span.cancelAddSuggest") }}</span>
            </button>

            <button
              class="add"
              v-if="this.authority.is.ViewStaff && this.isContinue"
              @click="openAddDepartmentModal()"
            >
              <span
                >{{ $t("span.addDepartment") }}
                <span v-if="addDepartmentModalStatus"
                  >({{ messageSelected.length }})</span
                >
              </span>
            </button>
            <button
              v-if="addDepartmentModalStatus && this.isContinue"
              class="cancel"
              @click="cancelAddDepartmentModal()"
            >
              <span>{{ $t("span.cancelAddDepartment") }}</span>
            </button>
            <button
              class="department-list"
              v-if="this.authority.is.ViewStaff && this.isHaveDepartment"
              @click="openDepartmentListModal()"
            >
              <span>{{ $t("span.departmentList") }}</span>
            </button>
            <button
              class="department-list"
              @click="openAddForwordModal()"
              v-if="this.authority.is.ViewStaff && this.isHaveDepartment"
            >
              <span
                >{{ $t("button.forward") }}
                <span v-if="addForwordStatus"
                  >({{ messageSelected.length }})</span
                >
              </span>
            </button>
            <button
              v-if="
                addForwordStatus &&
                this.authority.is.ViewStaff &&
                this.isHaveDepartment
              "
              class="cancel"
              @click="cancelAddForwordModal()"
            >
              <span>{{ $t("button.cancelForward") }}</span>
            </button>
            <!-- <button class="suggest">
              <span>Suggestion</span>
            </button> -->
          </div>
          <div class="title" v-if="this.authority.is.ViewStaff">
            <div class="active">
              {{ $t("span.online") }}
              <i class="fa-solid fa-circle"></i>
            </div>
          </div>
          <div class="online-users" v-if="this.authority.is.ViewStaff">
            <template v-for="(item, i) in userDataOnline" :key="i">
              <div class="user">
                <div class="avatar">
                  <img :src="item.picture" alt="" />
                </div>
                <div class="u-inf">
                  <div class="email">{{ item.emaill }}</div>
                </div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>
  <!--User Tag Modal-->
  <b-modal
    v-model="isShowUserTagModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.userTag')"
    class="select-category-modal"
  >
    <UserTag
      v-if="isShowUserTagModal"
      :isReload="this.isReloadUserTag"
      @submit-user="submitUserTag($event)"
      :complaintId="this.id"
      @show-user-tag-detail="showUserTagDetail($event)"
    />
  </b-modal>
  <!--Edit Category Modal []-->
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.selectCategory')"
    class="select-category-modal"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :source="categoryModalOpenFrom"
      :selectedDataId="complaintDetail.category.categoryTicketId"
      @change-category="selectNewCategory($event)"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
  <!--Suggestion Modal-->
  <b-modal
    v-model="isShowAddSuggestModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.addSuggestMessages')"
    class="select-category-modal"
  >
    <SuggestionModal
      v-if="isShowAddSuggestModal"
      :dataMess="messageSelected"
      :complaint="complaintDetail"
      :isAdd="true"
      :userId="yourId"
      @close="closeSuggestModal($event)"
      @add-suggest="addSuggestAfterEdit($event)"
    />
  </b-modal>

  <!-- DepartmentModal  -->
  <b-modal
    v-model="isShowAddDepartmentModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.addDepartmentSelectedMessages')"
    class="select-category-modal"
  >
    <DepartmentModal
      v-if="isShowAddDepartmentModal"
      :dataMess="messageSelected"
      :complaint="complaintDetail"
      :userId="yourId"
      :complaintId="this.id"
      @close="closeDepartmentModal($event)"
      @reloadData="addDepartmentAfterEdit"
    />
  </b-modal>

  <!--User Tag Description Modal-->
  <b-modal
    v-model="isShowUserTagDetailModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.userTagDetails')"
    class="select-category-modal"
  >
    <UserTagDescription
      v-if="isShowUserTagDetailModal"
      @reload-userTag="reloadUserTag()"
      @close-userTagDescription="closeUserTagDescription()"
      :idUser="this.yourId"
      :data="dataUserTagDetail"
    />
  </b-modal>

  <!--Report Modal-->
  <b-modal
    v-model="isShowReportModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.report')"
    class="select-category-modal"
  >
    <Report
      @close="closeReportModal()"
      v-if="isShowReportModal"
      :idComplaint="this.id"
    />
  </b-modal>

  <!-- Finish Modal-->
  <b-modal
    v-model="isShowFinishModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.feedback')"
    class="complaint-finish-modal"
  >
    <Finish
      :ticketId="this.id"
      v-if="isShowFinishModal"
      @reloadDone="reloadComplaints"
      @cancel="closeFinishModal"
    />
  </b-modal>

  <!-- Department List Modal-->
  <b-modal
    v-model="isShowDepartmentListModal"
    centered
    hideFooter="true"
    :title="this.$t('modal.departmentList')"
    class="department-list-modal"
  >
    <DepartmentList
      v-if="isShowDepartmentListModal"
      :complaintId="this.id"
      @cancel="closeDepartmentListModal"
    />
  </b-modal>

  <!-- Forword Department -->
  <b-modal
    v-model="isShowAddForwordModal"
    centered
    hideFooter="true"
    :title="this.$t('span.updateMessengerBeforeForward')"
    class="select-category-modal"
  >
    <SentComplaintModal
      v-if="isShowAddForwordModal"
      :dataMess="messageSelected"
      :id="this.id"
      :isForwordDep="true"
      @close="closeForwordModal"
      @close-reloadData="closeForwordModalDone"
    />
  </b-modal>
</template>

<script>
import Loading from "@/core/components/Loading.vue";
import { VNetworkGraph } from "v-network-graph";
import * as vNG from "v-network-graph";
import { defineComponent } from "vue";
import { CHAT_DATA_MOCK } from "@/mock/chat-data.mock.js";
import { BModal } from "bootstrap-vue-next";
import SuggestionModal from "@/modal/complaint-details/SuggestionModal.vue";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import UserTag from "@/modal/complaint-details/UserTag.vue";
import UserTagDescription from "@/modal/complaint-details/UserTagDescription.vue";
import Report from "@/modal/complaint-details/Report.vue";
import ComplaintAPIService from "@/script/services/ComplaintAPIService";
import UserApiService from "@/script/services/UserApiService";
import { useToast } from "vue-toastification";
import SentComplaintModal from "@/modal/department-details/SentComplaintModal.vue";
import { TYPE } from "vue-toastification";
import Finish from "@/modal/complaint-details/Finish.vue";
import DepartmentModal from "@/modal/complaint-details/DepartmentModal.vue";
import DepartmentList from "@/modal/complaint-details/DepartmentList.vue";
import HistoryAccountTicketsOnlineAPIService from "@/script/services/HistoryAccountTicketsOnlineAPIService.js";
import SignalRService from "@/script/signalr.service";
import {
  FILE_SIZE_LIMIT,
  TOTAL_FILE_SIZE_LIMIT,
} from "@/core/const/app.const.js";

export default defineComponent({
  name: "complaint-details",
  components: {
    BModal,
    SuggestionModal,
    EditCategory,
    UserTag,
    VNetworkGraph,
    UserTagDescription,
    Report,
    Finish,
    Loading,
    DepartmentModal,
    DepartmentList,
    SentComplaintModal,
  },

  data() {
    return {
      ticketID: "352201ED-9347-4FD8-8F47-634AE178DB35",

      //phục vụ biểu đồ
      dataGraph: [],
      nodes: null,
      edges: null,
      layouts: null,
      configs: null,
      loadingSections: {
        section1: false,
        loadUserOnline: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      id: null,
      isShowRightMenu: true,
      isShowLeftMenu: false,
      isShowUserTagModal: false,
      isShowAddSuggestModal: false,
      isShowAddDepartmentModal: false,
      isShowCategoryModal: false,
      categoryModalOpenFrom: "",
      isShowUserTagDetailModal: false,
      dataUserTagDetail: null,
      isShowReportModal: false,
      isShowFinishModal: false,
      addForwordStatus: false,
      isShowAddForwordModal: false,
      totalFilesSize: 0,
      // online user
      userDataOnline: [],
      yourId: 2, //id của user đang đăng nhập, dùng để kiểm tra xem tin nhắn có đến từ user đang đăng nhập không
      chatData: CHAT_DATA_MOCK,
      complaintDetail: {
        category: {
          categoryTicketId: 3,
          categoryTicketName: "Category 3",
          description: "Desccription for Category 3",
          isHaveChild: false,
          isShow: false,
          parentIds: [],
        },
        title: "",
        description: "",
        createDate: "",
      },
      tagUsers: {
        email: "",
      },
      addSuggestionStatus: false, // mặc định chế độ chọn tin nhắn Suggestion là false
      addDepartmentModalStatus: false,
      messageSelected: [],
      messengerContent: "",
      messageAttachment: [],
      isReloadUserTag: true,
      toast: null,
      authority: {
        code: {
          ViewStudent: "20662f2c-27db-486d-a2c0-01dafc3e06ea",
          ViewStaff: "83a3989f-1ac3-41d5-8998-9833e12f5eb0",
          EditCategory: "7631e2ab-9d94-41b5-ad40-2b5b07e2ba5a",
          EditSuggest: "c8f17529-131e-405a-8d1d-0b70b1ced3ac",
          TagUser: "a0fa5af3-ad36-4129-938c-7d98465cf46a",
        },
        is: {
          ViewStudent: false,
          ViewStaff: false,
          EditCategory: false,
          EditSuggest: false,
          TagUser: false,
        },
      },
      isViewTagUser: false,
      isShowDepartmentListModal: false,
      isContinue: true,
      isHaveDepartment: false,
      signalRConnection: new SignalRService(),
    };
  },

  async created() {
    await this.signalRConnection.start();

    const res = await UserApiService.isChildAuthorized("/complaint");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([
      await this.loadAuthority(),
      (this.toast = useToast()),
      (this.id = this.$route.params.id),
      (this.yourId = UserApiService.getUserSession().nameid),
      await Promise.all([
        this.getComplaintDetail(),
        this.addUserOnline(),
        this.reloadChatSignalR(this.id),
        this.reloadUserOnline(this.id),
      ]),
    ]);

    //kéo xuống tin nhắn mới nhất
    this.scrollMessAreaToBottom();
    // console.log(this.authority.is.TagUser, "Tag");
  },
  mounted() {
    this.scrollMessAreaToBottom();
    window.addEventListener("beforeunload", this.handleBeforeUnload);
  },
  computed: {
    reverseFiles() {
      return this.messageAttachment.slice().reverse();
    },
  },
  async beforeRouteLeave(to, from, next) {
    // await this.signalRConnection.stop();
    await this.signalRConnection.stop();
    await this.removeUserOnline();
    next();
  },
  methods: {
    async loadAuthority() {
      this.authority.is.ViewStudent = await UserApiService.getViewAuthority(
        this.authority.code.ViewStudent
      );
      this.authority.is.ViewStaff = await UserApiService.getViewAuthority(
        this.authority.code.ViewStaff
      );
      this.authority.is.EditCategory = await UserApiService.getViewAuthority(
        this.authority.code.EditCategory
      );
      this.authority.is.EditSuggest = await UserApiService.getViewAuthority(
        this.authority.code.EditSuggest
      );
      this.authority.is.TagUser = await UserApiService.getViewAuthority(
        this.authority.code.TagUser
      );
    },

    //start SignalR
    reloadChatSignalR(method) {
      // Đăng ký phương thức nhận dữ liệu từ server
      this.signalRConnection.connection.on(
        "complaint/details/__chat" + method.toLowerCase(),
        (message) => {
          console.log("Received message:", message);
          this.getComplaintDetail();
          this.addUserOnline();

          //kéo xuống tin nhắn mới nhất
          this.scrollMessAreaToBottom();
        }
      );
    },

    reloadUserOnline(method) {
      // Đăng ký phương thức nhận dữ liệu từ server
      this.signalRConnection.connection.on(
        "complaint/details/__userOnlineChat" + method.toLowerCase(),
        (message) => {
          console.log("Received message:", message);
          this.getUserOnline();
        }
      );
    },
    //end SignalR

    //event khi thoat trang
    async handleBeforeUnload() {
      // Thực hiện các hành động trước khi rời khỏi trang
      // await this.signalRConnection.stop();

      // Có thể cung cấp một thông báo để hỏi người dùng có muốn rời khỏi hay không
      // event.returnValue = "Bạn có chắc chắn muốn rời khỏi trang?";
      await this.signalRConnection.stop();
      await this.removeUserOnline();
    },

    //start User Online

    async getUserOnline() {
      const formData = new FormData();
      formData.append("TicketId", this.id);

      this.loadingSections.loadUserOnline = true;
      const res = await HistoryAccountTicketsOnlineAPIService.getAllByTicket(
        formData
      );
      if (res != null) {
        console.log(res);
        this.userDataOnline = res.data;
        this.loadingSections.loadUserOnline = false;
      } else {
        this.loadingSections.loadUserOnline = false;
      }
    },

    async addUserOnline() {
      const formData = new FormData();
      formData.append("TicketId", this.id);

      this.loadingSections.loadUserOnline = true;
      const res = await HistoryAccountTicketsOnlineAPIService.add(formData);
      if (res != null) {
        this.loadingSections.loadUserOnline = false;
        await this.getUserOnline();
      } else {
        this.loadingSections.loadUserOnline = false;
        await this.getUserOnline();
      }
    },

    async removeUserOnline() {
      const formData = new FormData();
      formData.append("TicketId", this.id);

      this.loadingSections.loadUserOnline = true;
      const res = await HistoryAccountTicketsOnlineAPIService.remove(formData);
      if (res != null) {
        this.loadingSections.loadUserOnline = false;
      } else {
        this.loadingSections.loadUserOnline = false;
      }
    },

    // end User Online
    closeUserTagDescription() {
      this.isShowUserTagDetailModal = false;
    },
    async reloadUserTag() {
      this.isShowUserTagDetailModal = false;
      this.isReloadUserTag = !this.isReloadUserTag;
      await this.getComplaintDetail();
    },

    async reloadComplaints() {
      this.isShowFinishModal = false;
      await this.getComplaintDetail();
    },
    async getComplaintDetail() {
      this.loadingSections.section1 = true;
      const res = this.authority.is.ViewStaff
        ? await ComplaintAPIService.getComplaintCommentDetailStaff(this.id)
        : await ComplaintAPIService.getComplaintCommentDetailStudent(this.id);
      if (res != null) {
        console.log(res);
        this.loadingSections.section1 = false;
        this.complaintDetail.category.categoryTicketName =
          res.categoryTicketName;
        this.complaintDetail.category.categoryTicketId = res.categoryTicketId;
        this.complaintDetail.title = res.title;
        this.complaintDetail.description = res.description;
        this.complaintDetail.createDate = res.createDate;
        this.isContinue =
          res.statusTicketId !== "fd6e17b5-c63d-42b6-bd10-40fb98629c50";
        this.isHaveDepartment = res.isHaveDepartment;
        if (res.accountTagInfor.requiredAccountName != null) {
          this.tagUsers.email = res.accountTagInfor.requiredAccountName;
        } else {
          this.tagUsers.email = "";
        }
      } else {
        this.loadingSections.section1 = false;
        this.toast("Load Data Complaint detail error!!!", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.$router.push("/complaint");
      }

      this.loadingSections.section1 = true;
      const resComment = this.authority.is.ViewStaff
        ? await ComplaintAPIService.getComplaintCommentChatStaff(this.id)
        : await ComplaintAPIService.getComplaintCommentChatStudent(this.id);
      if (resComment != null) {
        this.loadingSections.section1 = false;
        this.chatData = resComment;
        // var data = this.jsonString;
      }
      this.getViewNodeGraph();

      //kéo xuống tin nhắn mới nhất
      this.scrollMessAreaToBottom();
    },
    async getViewNodeGraph() {
      const res = await ComplaintAPIService.getViewNode(this.id);
      if (res != null && res != "") {
        this.dataGraph = res;
      } else {
        this.loadingSections.section1 = false;
      }
      // const nodess = {
      //   node1: { x: 0, y: 0 },
      //   node2: { x: 50, y: 50 },
      //   node3: { x: 100, y: 0 },
      // };
      this.nodes = this.dataGraph.nodes;
      this.edges = this.dataGraph.edges;
      this.layouts = this.dataGraph.layout;
      this.configs = defineComponent(
        vNG.defineConfigs({
          view: {
            panEnabled: true, // thuộc tính di chuyển diagram
            zoomEnabled: true, // thuộc tính zoom diagram
            // layoutHandler: new ForceLayout(),
          },
          node: {
            draggable: true, // thuộc tính di chuyển nodes
            label: { visible: true },
            labelPosition: {
              x: -10, // Vị trí của label cách điểm node 10 đơn vị trên trục x (bên trái)
              y: 0, // Vị trí của label cùng trục y với điểm node
              alignment: "right", // Căn chỉnh bên phải của label với điểm (x, y)
            },
          },

          // nodeConfig: {
          //   labelPosition: "left",
          // },
        })
      );
    },
    formatTime(dateString) {
      const date = new Date(dateString);
      const options = {
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23", // Hiển thị theo định dạng 24 giờ
      };
      const formattedTime = date
        .toLocaleString("en-US", options)
        .replace(/:/g, ":");
      return formattedTime;
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      };
      const formattedDate = date
        .toLocaleString("en-US", options)
        .replace(/\//g, "/");
      return formattedDate;
    },
    //Begin:: User Tag
    openUserTagModal() {
      this.isShowUserTagModal = true;
    },
    showUserTagDetail(item) {
      this.dataUserTagDetail = item;
      this.isShowUserTagDetailModal = true;
    },
    //End:: User Tag

    //Begin:: Feedback
    feedback() {
      this.isShowFinishModal = true;
    },
    closeFinishModal() {
      this.isShowFinishModal = false;
    },
    //End:: Feedback

    //Begin:: Edit Category
    openCategoryModal(fromScreen) {
      this.categoryModalOpenFrom = fromScreen;
      this.isShowCategoryModal = true;
    },
    async selectNewCategory(item) {
      console.log(item);
      const res = await ComplaintAPIService.updateComplaintCategory(
        item.item,
        this.id
      );
      if (res != null) {
        if (res.message == "SUCCESS") {
          this.getComplaintDetail();
          this.toast("Update category successfully", {
            type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          });
        }
      } else {
        this.toast("Update category faild", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
      this.isShowCategoryModal = false;
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    //TODO: Chỗ này khi get data cần xử lý lấy Name thay vì Ids xho các Category cha của Category được chọn
    showCategoryTitle() {
      const tempTitle = this.complaintDetail.category.parentIds.join("/");
      if (tempTitle && tempTitle.length > 0) {
        return `${tempTitle}/${this.complaintDetail.category.name}`;
      }
      return this.complaintDetail.category.name;
    },
    //End:: Edit Category

    //Begin:: Add Department
    openAddDepartmentModal() {
      if (this.addDepartmentModalStatus) {
        // if (this.messageSelected.length == 0) return;
        //nếu ở chế độ chọn Suggestion => show modal
        this.isShowAddDepartmentModal = true;
        return;
      }
      this.addDepartmentModalStatus = !this.addDepartmentModalStatus;
    },
    cancelAddDepartmentModal() {
      this.messageSelected = [];
      this.addDepartmentModalStatus = false;
    },

    closeDepartmentModal(data) {
      this.messageSelected = data;
      this.isShowAddDepartmentModal = false;
    },
    async addDepartmentAfterEdit() {
      // this.isShowAddDepartmentModal = false;
      await this.getComplaintDetail();
      this.isShowAddDepartmentModal = false;
      this.addDepartmentModalStatus = false;
    },
    //End: Add Department

    //Begin:: Add Forward Department
    openAddForwordModal() {
      if (this.addForwordStatus) {
        this.isShowAddForwordModal = true;
        return;
      }
      this.addForwordStatus = !this.addForwordStatus;
    },
    cancelAddForwordModal() {
      this.messageSelected = [];
      this.addForwordStatus = false;
    },

    closeForwordModal() {
      this.isShowAddForwordModal = false;
    },

    closeForwordModalDone() {
      this.isShowAddSuggestModal = false;
      this.messageSelected = [];
      this.addForwordStatus = false;
    },

    //End: Add  Forward Department

    //Begin:: Add Suggestion
    openAddSUggestionModal() {
      if (this.addSuggestionStatus) {
        // if (this.messageSelected.length == 0) return;
        //nếu ở chế độ chọn Suggestion => show modal
        this.isShowAddSuggestModal = true;
        return;
      }
      this.addSuggestionStatus = !this.addSuggestionStatus;
    },
    cancelAddSUggestionModal() {
      this.messageSelected = [];
      this.addSuggestionStatus = false;
    },
    selectMessenger(id) {
      if (
        !this.addSuggestionStatus &&
        !this.addDepartmentModalStatus &&
        !this.addForwordStatus
      )
        return;
      const isExisting = this.messageSelected.find((f) => f.id == id);

      if (isExisting) {
        //gỡ tin nhắn khỏi list tin nhắn đã chọn
        const index = this.messageSelected.indexOf(isExisting);

        this.messageSelected.splice(index, 1);
        return;
      }
      const messSelected = this.chatData.find((f) => f.id == id);
      if (messSelected) {
        // console.log(messSelected);
        //thêm tin nhắn vào list được chọn
        this.messageSelected.push(messSelected);
        return;
      }
    },
    closeSuggestModal(data) {
      this.messageSelected = data;
      this.isShowAddSuggestModal = false;
    },
    addSuggestAfterEdit(data) {
      console.log(data.data, "sugguest messages");
      this.isShowAddSuggestModal = false;
    },
    //End:: Add Suggestion

    //Begin: Report
    showReport() {
      this.isShowReportModal = true;
    },
    closeReportModal() {
      this.isShowReportModal = false;
    },
    //End: Report

    async scrollMessAreaToBottom() {
      // Cuộn xuống tin nhắn mới nhất
      //nextTick để chắc chắn DOM đã render xong
      try {
        if (this.authority.is.ViewStaff || this.authority.is.ViewStudent) {
          this.$nextTick(() => {
            this.$refs.scrollContainer.scrollTop =
              this.$refs.scrollContainer.scrollHeight;
          });
        }
      } finally {
        console.log("scrollMessAreaToBottom");
      }
    },
    checkShowAvatar(index, id) {
      //nếu 2 tin nhắn liên tiếp đến từ 1 người thì chỉ hiện ảnh dại diện ở tin đầu tiên
      if (index == 0) return true;
      if (this.chatData[index - 1].id == id) return false;
      return true;
    },
    isMessSelected(id) {
      //kiểm tra xem tin nhắn có được chọn hay không
      return this.messageSelected.find((f) => f.id == id) ? true : false;
    },
    downloadFile(id) {
      //chỉ có thể tải tệp khi không ở chế độ chọn Suggestion
      if (this.addSuggestionStatus) return;
      window.location.href = `${id}`;
      // alert(`Download file id: ${id}`);
    },
    selectAttachment() {
      this.$refs.selectAttachmentRef.click();
    },

    checkFileSize(file) {
      if (file.size > FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess12"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      if (this.totalFilesSize > TOTAL_FILE_SIZE_LIMIT) {
        event.target.value = null;
        this.toast(this.$t("toast.Common.mess13"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        return false;
      }
      return true;
    },

    isValidFileType(fileName) {
      const validExtensions = [
        ".pdf",
        ".img",
        ".jpg",
        ".png",
        ".txt",
        ".pub",
        ".xlsx",
        ".docs",
        ".excel",
      ];
      const fileExtension = fileName
        .substr(fileName.lastIndexOf("."))
        .toLowerCase();
      return validExtensions.includes(fileExtension);
    },

    choosenAttachment(event) {
      const files = event.target.files;

      files.forEach((file) => {
        if (this.isValidFileType(file.name)) {
          if (this.checkFileSize(file)) {
            this.totalFilesSize += file.size;
            this.messageAttachment.push({
              id: this.messageAttachment.length + 1,
              name: file.name,
              link: "",
              type: file.type,
              file: file,
            });
          }
        } else {
          this.toast(this.$t("toast.Common.mess14"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      });
      event.target.value = null;
    },

    removeAttachment(id) {
      if (this.messageAttachment.length == 0) return;
      const fileSelected = this.messageAttachment.find((f) => f.id == id);
      if (fileSelected) {
        const index = this.messageAttachment.indexOf(fileSelected);
        this.messageAttachment.splice(index, 1);
      }
    },
    async sendMessenger() {


      if(this.messengerContent != null){
        this.messengerContent = this.messengerContent.trim()
      }

      //kiểm tra nếu chưa có tin nhắn và attaschment thì k gửi
      if (this.messengerContent == "" && this.messageAttachment.length == 0)
        return;

      const formData = new FormData();
      formData.append("Comment", this.messengerContent);
      formData.append("TicketId", this.id);
      formData.append(
        "CategoryTicketId",
        this.complaintDetail.category.categoryTicketId
      );

      if (this.messageAttachment.length > 0) {
        for (const item of this.messageAttachment) {
          formData.append("TicketAttachments", item.file);
        }
      }
      this.loadingSections.section1 = true;
      if (this.authority.is.ViewStaff) {
        const response = await ComplaintAPIService.replyComplaintStaff(
          formData
        );
        if (
          response != null &&
          response.message != null &&
          response.message == "CREATE_SUCCESS"
        ) {
          // this.toast(this.$t("toast.Common.mess2"), {
          //   type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          // });
          this.loadingSections.section1 = false;
          this.getComplaintDetail().then(() => {
            //kéo xuống tin nhắn mới nhất
            this.scrollMessAreaToBottom();
          });
        } else {
          this.loadingSections.section1 = false;
          this.toast(this.$t("toast.Common.mess3"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      }

      if (this.authority.is.ViewStudent && !this.authority.is.ViewStaff) {
        const response = await ComplaintAPIService.replyComplaintStudent(
          formData
        );
        if (response != null && response.message == "CREATE_SUCCESS") {
          // this.toast(this.$t("toast.Common.mess2"), {
          //   type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
          // });
          this.loadingSections.section1 = false;
          this.getComplaintDetail().then(() => {
            //kéo xuống tin nhắn mới nhất
            this.scrollMessAreaToBottom();
          });
        } else {
          this.loadingSections.section1 = false;
          this.toast(this.$t("toast.Common.mess3"), {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      }

      // this.chatData.push(newMess);
      //xóa dữ liệu tin nhắn và attachments sau khi gửi xong
      this.messengerContent = "";
      this.messageAttachment = [];
    },

    copyTagUserEmail(email) {
      const el = document.createElement("textarea");
      el.value = email;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      this.toast("Email copied!", {
        type: TYPE.SUCCESS,
      });
    },

    openDepartmentListModal() {
      this.isShowDepartmentListModal = true;
    },
    closeDepartmentListModal() {
      this.isShowDepartmentListModal = false;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint-details.scss";
</style>
