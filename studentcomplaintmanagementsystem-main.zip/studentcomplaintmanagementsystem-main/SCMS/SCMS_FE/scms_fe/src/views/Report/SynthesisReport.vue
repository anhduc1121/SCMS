<template>
  <div id="page-complaint" class="page-complaint">
    <div class="page-complaint-content">
      <div class="page-complaint-search">
        <!--Filter by question-->
      </div>
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.from") }}</div>
          <div class="value">
            <input type="date" autocomplete="off" spellcheck="false" v-model="filter.from" @input="fetchData()" />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.to") }}</div>
          <div class="value">
            <input type="date" autocomplete="off" spellcheck="false" v-model="filter.to" @input="fetchData()" />
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <h4>{{ $t("span.generalStatistic") }}</h4>
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="from">{{ $t("table.total") }}</th>
            <th class="tag">{{ $t("table.created") }}</th>
            <th class="tag">{{ $t("table.assigned") }}</th>
            <th class="tag">{{ $t("table.received") }}</th>
            <th class="tag">{{ $t("table.solved") }}</th>
            <th class="tag">{{ $t("table.expired") }}</th>
            <th class="tag">{{ $t("table.avgProcessingTime") }}</th>
          </tr>
          <!--Table: Body-->
          <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
            <td>{{ DailyReport.totalTicket }}</td>
            <td>
              {{ DailyReport.created }}
            </td>
            <td>
              {{ DailyReport.assigned }}
            </td>
            <td>
              {{ DailyReport.received }}
            </td>
            <td>{{ DailyReport.solved }}</td>
            <td>{{ DailyReport.expired }}</td>
            <td>{{ DailyReport.averageProcessingTime }}</td>
          </tr>
        </table>
      </div>
      <div class="page-complaint-table">
        <h4>{{ $t("span.ratingReport") }}</h4>
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="from">{{ $t("table.ratingPoint") }}</th>
            <th class="tag">5</th>
            <th class="tag">4</th>
            <th class="tag">3</th>
            <th class="tag">2</th>
            <th class="tag">1</th>
          </tr>
          <!--Table: Body-->
          <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
            <td>{{ $t("table.quantity") }}</td>
            <td>
              {{ DailyReport.rating5 }}
            </td>
            <td>
              {{ DailyReport.rating4 }}
            </td>
            <td>
              {{ DailyReport.rating3 }}
            </td>
            <td>
              {{ DailyReport.rating2 }}
            </td>
            <td>{{ DailyReport.rating1 }}</td>
          </tr>
        </table>
        <h6>{{ $t("table.avgPoint") }}: {{ DailyReport.averageRating }}</h6>
      </div>

      <!--Phân loại yêu cầu-->
      <div class="fix-location" style="min-width: 1800px;">
        <h4>{{ $t("span.generalStatistic") }}</h4>
        <div class="statistic-table">
          <div class="statistic-header">
            <div class="table-thead width-250">{{ $t("table.category") }}</div>
            <div class="table-thead width-146">{{ $t("table.total") }}</div>
            <div class="table-thead width-146">{{ $t("table.created") }}</div>
            <div class="table-thead width-146">{{ $t("table.assigned") }}</div>
            <div class="table-thead width-146">{{ $t("table.received") }}</div>
            <div class="table-thead width-146">{{ $t("table.solved") }}</div>
            <div class="table-thead width-146">{{ $t("table.expired") }}</div>
            <div class="table-thead width-146">{{ $t("table.avgPoint") }}</div>
            <div class="table-thead width-220">{{ $t("table.avgProcessingTime") }}</div>
          </div>
          <div class="statistic-body">
            <div class="row-data" v-for="(item, index) in SynthesisReport" :key="index">
              <div class="parent-row" @click="showChildren(index)">
                <div class="parent-data width-250">{{ item.categoryParenName }} <span v-if="item.categoryChild.length"
                    class="icon icon-show">
                    <i v-if="show(index)" class="fa-solid fa-arrow-down">
                    </i>
                    <i v-else class="fa-solid fa-arrow-up">
                    </i>
                  </span></div>
                <div class="parent-data width-146">{{ item.reportParameterParens.totalTicket }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.created }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.assigned }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.received }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.solved }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.expired }}</div>
                <div class="parent-data width-146">{{ item.reportParameterParens.averageRating }}</div>
                <div class="parent-data width-220 solid-right">
                  {{ item.reportParameterParens.averageProcessingTime }}
                </div>
              </div>
              <div class="children-table" v-if="show(index)">
                <div class="children-row" v-for="(child, no) in item.categoryChild" :key="no">
                  <div class="children-data width-250">{{ child.categoryChildName }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.totalTicket }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.created }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.assigned }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.received }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.solved }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.expired }}</div>
                  <div class="children-data width-146">{{ child.reportParameters.averageRating }}</div>
                  <div class="children-data width-220 solid-right">
                    {{ child.reportParameters.averageProcessingTime }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import ReportAPIService from "@/script/services/ReportAPIService";
import { REPORT_1_DAILY_REPORT_TABLE_3_DATA } from "@/mock/report-1-data-table-3.mock";

export default defineComponent({
  name: "Report_3",
  components: {},
  data() {
    return {
      innerWidth: window.innerWidth,
      filter: {
        from: "2023-04-09",
        to: "",
      },
      DailyReport: {
        accountIdCreate: "",
        email: "",
        totalTicket: 9,
        created: 0,
        solved: 4,
        assigned: 3,
        expired: 2,
        received: 0,
        averageProcessingTime: 20,
        rating5: 5,
        rating4: 4,
        rating3: 3,
        rating2: 2,
        rating1: 1,
        averageRating: 3.0,
      },
      SynthesisReport: REPORT_1_DAILY_REPORT_TABLE_3_DATA,
      showMultiTable: [],
    };
  },
  async created() {
    this.filter.to = this.getCurrentTime();
    this.fetchData();
  },
  methods: {

    showChildren(parentIndex) {
      var exists = this.showMultiTable.some(function (obj) {
        return obj === parentIndex;
      });
      //if existed --> remove
      if (exists) {
        this.showMultiTable = this.showMultiTable.filter(function (element) {
          return element !== parentIndex;
        });
      } else {
        //if does not exist --> add
        this.showMultiTable.push(parentIndex);
      }
    },

    show(parentIndex) {

      return this.showMultiTable.some(function (obj) {
        return obj === parentIndex;
      });

    },

    fetchData() {
      this.getTable();
    },

    getCurrentTime() {
      const date = new Date();
      return date.toISOString().split("T")[0]; // Định dạng theo cài đặt hệ thống
    },

    async getTable() {
      const DailyReportData = {
        fromDate: this.filter.from,
        toDate: this.filter.to,
        url: "/Report/SynthesisReport", //DailyReport
        urlGetSize: "",
      };

      const SynthesisReportData = {
        fromDate: this.filter.from,
        toDate: this.filter.to,
        url: "/Report/SynthesisReport2", //RatingReportData
        urlGetSize: "",
      };

      const respon1 = await ReportAPIService.getReport(DailyReportData);
      if (respon1 != null) {
        this.DailyReport = respon1;
      }

      const respon2 = await ReportAPIService.getReport(SynthesisReportData);
      if (respon2 != null) {
        this.SynthesisReport = respon2;
      }
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";

.thead-multi {
  max-width: 190px;
  width: 190px;
  align-items: center;
}

.category-parent {
  width: 190px;
  max-width: 190px;
  // height: 50px;
  align-items: center;
}

.report-data-row {
  max-width: 190px;
  width: 190px;
}
</style>