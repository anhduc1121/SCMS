<template>
  <div id="page-complaint" class="page-complaint">
    <div class="page-complaint-content">
      <div class="page-complaint-search">
        <!--Filter by question-->
      </div>
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{$t('search.from')}}</div>
          <div class="value">
            <input 
            type="date" 
            autocomplete="off" 
            spellcheck="false" 
            v-model="filter.from"
              @input="fetchData()"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{$t('search.to')}}</div>
          <div class="value">
            <input 
            type="date" 
            autocomplete="off" 
            spellcheck="false" 
            v-model="filter.to"
              @input="fetchData()"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="tag">{{$t('table.reportTime')}}</th>
            <th class="from">{{$t('table.studentEmail')}}</th>
            <th class="tag">{{$t('table.category')}}</th>
            <th class="tag">{{$t('table.handlerEmail')}}</th>
            <th class="tag">{{$t('table.handlerResponseTime')}}</th>
            <th class="tag">{{$t('table.description')}}</th>
            <th class="tag">{{$t('table.point')}}</th>
          </tr>
          <!--Table: Body-->
          <template
            v-for="(item, index) in tableData"
            :key="index"
          >
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ this.formatDate(item.timeReport) }}</td>
              <td>
                {{ item.emailStudent }}
              </td>
              <td>
                {{ item.categoryName }}
              </td>
              <td>
                {{ item.emailStaff }}
              </td>
              <td>
                {{ item.timeProcess }}
              </td>
              <td v-html="item.description">
              </td>
              <td> {{ item.rate }} </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
  </div>
</template>
    
    <script>
import { defineComponent } from "vue";
import ReportAPIService from "@/script/services/ReportAPIService";
import { REPORT_5_DETAIL_REPORT_DATA } from "@/mock/report-5-data.mock"

export default defineComponent({
  name: "Report_5",
  components: {
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      filter: {
        from: "2023-04-09",
        to: "",
      },
      tableData: REPORT_5_DETAIL_REPORT_DATA,
    };
  },
  async created() {
    this.filter.to = this.getCurrentTime();
    this.fetchData();
  },
  methods: {
    fetchData() {
      this.getDetailsReport();
    },

    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },

    getCurrentTime() {
      const date = new Date();
      return date.toISOString().split("T")[0]; // Định dạng theo cài đặt hệ thống
    },

    async getDetailsReport() {
      const data = {
        fromDate: this.filter.from,
        toDate: this.filter.to,
        url: "/Report/ReportTicketReport",
        urlGetSize: "",
      };

      const respon = await ReportAPIService.getReport(data);
      if (respon != null) {
        this.tableData = respon;
      }
    },
  },
});
</script>
    
    <style lang="scss">
@import "@/assets/scss/views/complaint";
@import "@/assets/scss/views/complaint-report-1";
</style>
    