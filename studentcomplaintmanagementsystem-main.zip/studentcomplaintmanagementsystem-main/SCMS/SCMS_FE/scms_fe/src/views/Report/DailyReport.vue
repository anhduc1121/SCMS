<template>
  <div id="page-complaint" class="page-complaint">
    <div class="page-complaint-content">
      <div class="page-complaint-filter set-max-width">
        <!--{{$t('search.from')}}-->
        <div class="filter-item">
          <div class="label">{{ $t("search.from") }}</div>
          <div class="value">
            <input
              type="date"
              autocomplete="off"
              spellcheck="false"
              v-model="filter.from"
              @input="fetchData()"
            />
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.to") }}</div>
          <div class="value">
            <input
              type="date"
              autocomplete="off"
              spellcheck="false"
              v-model="filter.to"
              @input="fetchData()"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-table set-max-width">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.account") }}</th>
            <th class="from">{{ $t("table.total") }}</th>
            <th class="tag">{{ $t("table.created") }}</th>
            <th class="tag">{{ $t("table.assigned") }}</th>
            <th class="tag">{{ $t("table.received") }}</th>
            <th class="tag">{{ $t("table.solved") }}</th>
            <th class="tag">{{ $t("table.expired") }}</th>
            <th class="tag">{{ $t("table.avgProcessingTime") }}</th>
            <th class="tag">{{ $t("table.avgPoint") }}</th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>
                {{ item.email }}
              </td>
              <td>
                {{ item.totalTicket }}
              </td>
              <td>
                {{ item.created }}
              </td>
              <td>
                {{ item.assigned }}
              </td>
              <td>
                {{ item.received }}
              </td>
              <td>
                {{ item.solved }}
              </td>
              <td>{{ item.expired }}</td>
              <td>{{ item.averageProcessingTime }}</td>
              <td>{{ item.averageRating }}</td>
            </tr>
          </template>
        </table>
      </div>
      <div class="page-complaint-table report-1-table-2">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="title left-sticky"></th>
            <th class="small"
              v-for="(report_data, index) in tableData2[0].account"
              :key="index"
            >
              {{ report_data.email }}
            </th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, row_index) in tableData2" :key="row_index">
            <tr class="td-left-sticky">
              <td class="col-data td-left-sticky">
                {{ item.categoryName }}
              </td>
              <td
                v-for="(data, col_index) in item.account"
                :key="data.email"
                :class="{ 'bg-color': whiteColor(row_index, col_index) } "
                class="col-data"
              >
                {{ data.count }}
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    
  </div>
</template>
    
    <script>
import { defineComponent } from "vue";
import ReportAPIService from "@/script/services/ReportAPIService";
import {
  REPORT_2_DAILY_REPORT_DATA,
  REPORT_2_DAILY_REPORT_TABLE_2_DATA,
} from "@/mock/report-2-data.mock";

export default defineComponent({
  name: "Report_2",
  components: {
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      currentDate: null,
      filter: {
        from: "2023-04-09",
        to: "",
      },
      tableData: REPORT_2_DAILY_REPORT_DATA,
      tableData2: REPORT_2_DAILY_REPORT_TABLE_2_DATA,
    };
  },
  async created() {
    this.filter.to = this.getCurrentTime();
    this.fetchData();
  },
  methods: {
    whiteColor(row_index, col_index) {
      if (row_index % 2 != 0) {
        if (col_index % 2 != 0) {
          return true;
        }
      } else {
        if (col_index % 2 == 0) {
          return true;
        }
      }
      return false;
    },

    fetchData() {
      this.getReport_2_Table_1();
      this.getReport_2_Table_2();
    },

    getCurrentTime() {
      const date = new Date();
      return date.toISOString().split("T")[0]; // Định dạng theo cài đặt hệ thống
    },

    async getReport_2_Table_1() {
      const data = {
        fromDate: this.filter.from,
        toDate: this.filter.to,
        url: "/Report/DailyReport",
        urlGetSize: "",
      };

      const respon = await ReportAPIService.getReport(data);
      if (respon != null) {
        this.tableData = respon;
      }
    },

    async getReport_2_Table_2() {
      const data = {
        fromDate: this.filter.from,
        toDate: this.filter.to,
        url: "/Report/DailyReport2",
        urlGetSize: "",
      };

      const respon = await ReportAPIService.getReport(data);
      if (respon != null) {
        this.tableData2 = respon;
      }
    },
  },
});
</script>
    
    <style lang="scss">
@import "@/assets/scss/views/complaint";
@import "@/assets/scss/views/complaint-report-1";
.col-data {
  min-width: 250px;
}
.set-max-width {
  max-width: 1500px;
}
.report-1-table-2{
  max-height: 500px;
  max-width: 1500px;
  overflow: auto;
}
</style>
    