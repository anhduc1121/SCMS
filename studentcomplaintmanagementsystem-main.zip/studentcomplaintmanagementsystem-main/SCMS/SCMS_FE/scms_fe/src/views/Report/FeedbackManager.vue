<template>
    <div id="page-complaint" class="page-complaint">
        <div class="page-complaint-content">
            <div class="page-complaint-search">
                <div class="search-title">
                    <div class="label">{{ $t('search.title') }}</div>
                    <div class="value">
                        <input v-model="this.filter.title" @input="this.toogleSort('x')" type="text" autocomplete="off"
                            spellcheck="false" :placeholder="$t('placeholder.title')" />
                    </div>
                </div>
            </div>
            <div class="page-complaint-filter">
                <!--{{$t('search.category')}}-->
                <div class="filter-item">
                    <div class="label">{{ $t('search.category') }}</div>
                    <div class="value">
                        <select v-model="filter.categoryType.categoryName" @click="changeCategory()">
                            <option hidden>{{ filter.categoryType.categoryName }}</option>
                        </select>
                      
                    </div>
                </div>
                <div class="filter-item">
                    <div class="label">{{ $t('search.status') }}</div>
                    <div class="value">
                        <select v-model="filter.statusType" @change="this.toogleSort('x')">
                            <option value="" selected>All</option>
                            <option v-for="status in this.statusData" :key="status.statusTicketId"
                                :value="status.statusTicketId">
                                {{ status.statusTicketName }}
                            </option>
                        </select>
                    </div>
                </div>
                <div class="filter-item">
                    <div class="label">{{ $t('search.student') }}</div>
                    <div class="value">
                        <input v-model="this.filter.from" @input="this.toogleSort('x')" type="text" autocomplete="off"
                            spellcheck="false" :placeholder="$t('placeholder.email')" />
                    </div>
                </div>
                <!--Creator-->
                <div class="filter-item">
                    <div class="label">{{ $t('search.staff') }}</div>
                    <div class="value">
                        <input @input="this.toogleSort('x')" type="text" autocomplete="off" spellcheck="false"
                            :placeholder="$t('placeholder.email')" />
                    </div>
                </div>
            </div>
            <div class="page-complaint-table">
                <table>
                    <!--Table: Header-->
                    <tr class="header">
                        <th class="no">{{ $t('table.no') }}</th>
                        <th class="from">{{ $t('table.student') }}</th>
                        <th class="title">
                            <div class="th-sort" @click="toogleSort('title')">
                                <span class="icon">
                                    <i v-if="filter.sort.title == sortConst.A_Z ||
                                        filter.sort.title == sortConst.A_A
                                    " class="fa-solid fa-arrow-down">
                                    </i>
                                    <i v-if="filter.sort.title == sortConst.Z_A" class="fa-solid fa-arrow-up">
                                    </i>
                                </span>
                                <span class="label">{{ $t('table.title') }}</span>
                            </div>
                        </th>
                        <th class="tag">{{ $t('table.category') }}</th>
                        <th class="status">
                            <div class="th-sort" @click="toogleSort('status')">
                                <span class="icon">
                                    <i v-if="filter.sort.status == sortConst.A_Z ||
                                        filter.sort.status == sortConst.A_A
                                    " class="fa-solid fa-arrow-down"></i>
                                    <i v-if="filter.sort.status == sortConst.Z_A" class="fa-solid fa-arrow-up"></i>
                                </span>
                                <span class="label">{{ $t('table.status') }}</span>
                            </div>
                        </th>
                        <th class="creator">{{ $t('table.staff') }}</th>
                        <th class="created-date">
                            <div class="th-sort" @click="toogleSort('created-date')">
                                <span class="icon">
                                    <i v-if="filter.sort.createdDate == sortConst.A_Z ||
                                        filter.sort.createdDate == sortConst.A_A
                                    " class="fa-solid fa-arrow-down"></i>
                                    <i v-if="filter.sort.createdDate == sortConst.Z_A" class="fa-solid fa-arrow-up"></i>
                                </span>
                                <span class="label">{{ $t('table.createDate') }}</span>
                            </div>
                        </th>
                        <th class="star">
                        </th>
                    </tr>
                    <!--Table: Body-->
                    <template v-for="(item, index) in tableData" :key="index">
                        <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
                            <td>{{ index + 1 }}</td>
                            <td></td>
                            <td>
                                <router-link :to="`/complaint/details/${item.ticketId}`"
                                    class="text-decoration-none link-primary">
                                    {{ item.title }}
                                </router-link>
                            </td>
                            <td>
                                {{ item.categoryTicketName }}
                            </td>
                            <td>{{ item.statusTicketName }}</td>
                            <td>{{ item.emailBehaveCreate }}</td>
                            <td>{{ this.formatDate(item.createDate) }}</td>
                            <td class="star-item">
                                <i class="fa-solid fa-eye"></i>
                            </td>
                        </tr>
                    </template>
                </table>
            </div>
        </div>
        <div class="pagination">
            <div class="_page-size">
                <div class="label">{{ $t('label.pageSize') }}</div>
                <select v-model="pageSize" @change="changeItemPerPage()">
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
            <div class="_page-view">
                <Pagination v-model:dataInput="pageData" @change-page="changePage" />
            </div>
        </div>
    </div>
    <!-- Category Modal-->
    <b-modal v-model="isShowCategoryModal" centered hideFooter="true" :title="$t('placeholder.category')"
        class="select-category-modal">
        <EditCategory v-if="isShowCategoryModal" :isShowSelectAllCategoryModal="true"
            :selected-data-id="this.filter.categoryType.categoryTicketId" :source="'create-complaint'"
            @change-category="selectNewCategory($event)" @change-category-all="selectNewCategoryAll()"
            @close-modal="closeCategoryModal()" />
    </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
// import { CATEGORY_TREE_MOCK } from "@/mock/create-complaint.mock.js";
// import { TICKET_STATUS_DATA } from "@/mock/ticket-status.mooc";
// import { COMPLAINT_DATA } from "@/mock/complaint-data.mock.js";
// import Treeselect from "vue3-treeselect";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import TicketStatusAPIService from "@/script/services/TicketStatusAPIService";
import ComplaintAPIService from "@/script/services/ComplaintAPIService";
import PinAPIService from "@/script/services/PinAPIService";
import { BModal } from "bootstrap-vue-next";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";

export default defineComponent({
    name: "page-complaint",
    components: {
        Pagination,
        BModal,
        EditCategory
        // Treeselect,
    },
    data() {
        return {
            innerWidth: window.innerWidth,
            isShowCategoryModal: false,
            sortConst: SORT,
            filter: {
                title: "",
                categoryType: {
                    categoryTicketId: '',
                    categoryName: '',
                    fullPath: '',
                },
                statusType: "",
                sort: {
                    title: SORT.A_Z,
                    status: SORT.A_Z,
                    createdDate: SORT.A_Z,
                    pin: SORT.A_Z,
                },
                from: "",
                creator: "",
                tag: "",
            },
            pageSize: 20,
            pageData: {
                totalItem: 10,
                itemPerPage: 1,
                maxPageShow: 5,
                currentPage: 1,
            },
            categories: [],
            tableData: [],
            statusData: [],
        };
    },
    async created() {
        this.getCategorys();
        this.getStatus();
        this.getComplaint();
    },
    methods: {
        changeCategory() {
            this.isShowCategoryModal = true;
        },
        selectNewCategory(data) {
            this.isShowCategoryModal = false;
            this.filter.categoryType.categoryTicketId = data.item
            this.getCategorys();
            this.toogleSort('x')
        },

        selectNewCategoryAll() {
            this.isShowCategoryModal = false;
            this.filter.categoryType.categoryTicketId = '';
            this.filter.categoryType.categoryName = 'All'
            this.toogleSort('x');
        },
        closeCategoryModal() {
            this.isShowCategoryModal = false;
        },
        async addPinComplaint(id) {
            const res = await PinAPIService.add(id);
            if (res != null) {
                if (res.message == "SUCCESS") {
                    this.getComplaint();
                }
            }
        },
        async deletePinComplaint(id) {
            const res = await PinAPIService.delete(id);
            if (res != null) {
                console.log(res);
                if (res.message == "SUCCESS") {
                    this.getComplaint();
                }
            }
        },
        formatDate(dateString) {
            const date = new Date(dateString);
            const options = { year: "numeric", month: "long", day: "numeric" };
            return date.toLocaleDateString("en-US", options);
        },
        async getStatus() {
            const respon = await TicketStatusAPIService.getStatus();
            if (respon != null) {
                this.statusData = respon;
            }
        },
        async getCategorys() {
            if (this.filter.categoryType.categoryTicketId == '') {
                this.filter.categoryType.categoryName = 'All'
            } else {
                const respon = await CategoryAPIService.GetCategoryById(this.filter.categoryType.categoryTicketId);
                if (respon != null) {
                    this.filter.categoryType = respon;
                    // this.filter.categoryType = respon[0]["id"];
                }
            }
        },

        async getComplaint() {
            const data = {
                cateId: this.filter.categoryType.categoryTicketId, // Giá trị mẫu cho cateId
                statusTicketId: this.filter.statusType, // Giá trị mẫu cho statusTicketId
                accountIdCreate: "", // Giá trị mẫu cho accountIdCreate
                accountIDBehaveCreate: null,
                tagAccountId: null,
                accountGmaillCreate: this.filter.from,
                accountGmaillBehaveCreate: this.filter.creator,
                accountGmaillTag: this.filter.tag,
                status: "",
                title: this.filter.title,
                createDate: this.filter.createDate,
                pageIndex: this.pageData.currentPage,
                pageSize: this.pageSize,
                sortDate: this.filter.sort.createdDate,
                sortTitle: this.filter.sort.title,
                sortStatusTicket: this.filter.sort.status,
                isPin: this.filter.sort.pin == 1,
                // Thiết lập các trường khác theo yêu cầu
            };

            const respon = await ComplaintAPIService.getComplaints(data);
            if (respon != null) {
                this.tableData = respon;
            }

            // const responSize = await ComplaintAPIService.getComplaintsSize(data);
            // if (responSize != null) {
            //     // this.$emit('update:dataInput', responSize);
            //     const total = responSize;
            //     this.pageData = {
            //         totalItem: total,
            //         itemPerPage: parseInt(this.pageSize),
            //         maxPageShow: 5,
            //         currentPage: this.pageData.currentPage,
            //     };
            // }
        },

        async toogleSort(label) {
            switch (label) {
                case "title":
                    this.filter.sort.title =
                        this.filter.sort.title == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    this.filter.sort.status = SORT.A_Z;
                    this.filter.sort.pin = SORT.A_Z;
                    this.filter.sort.createdDate = SORT.A_Z;
                    break;
                case "status":
                    this.filter.sort.status =
                        this.filter.sort.status == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    this.filter.sort.title = SORT.A_Z;
                    this.filter.sort.pin = SORT.A_Z;
                    this.filter.sort.createdDate = SORT.A_Z;
                    break;
                case "pin":
                    this.filter.sort.pin =
                        this.filter.sort.pin == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    this.filter.sort.title = SORT.A_Z;
                    this.filter.sort.status = SORT.A_Z;
                    this.filter.sort.createdDate = SORT.A_Z;
                    break;
                case "created-date":
                    this.filter.sort.createdDate =
                        this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    this.filter.sort.title = SORT.A_Z;
                    this.filter.sort.status = SORT.A_Z;
                    this.filter.sort.pin = SORT.A_Z;
                    break;
            }
            this.getComplaint();
        },
        changeItemPerPage() {
            this.pageData.currentPage = 1;
            this.getComplaint();
        },
        changePage(page) {
            // console.log(page.page, "new page");
            this.pageData.currentPage = page.page;
            this.getComplaint();
        },
    },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";
</style>