<template>
    <div class="home">
        <div class="home">
            <p v-if="isLoggedIn">User: {{ username }}</p>
            <button class="btn" @click="login">Login</button>
            <button class="btn" @click="logout">Logout</button>
            <button class="btn" @click="getProtectedApiData" v-if="isLoggedIn">Get API data</button>
        </div>
        <div v-if="dataEventRecordsItems && dataEventRecordsItems.length">

            <br />
        </div>
    </div>
</template>

<script>
import AuthService from '@/script/AuthService.js';

const auth = new AuthService();

export default {
    name: 'LoginFEID',
    data() {
        return {
            currentUser: '',
            accessTokenExpired: undefined,
            isLoggedIn: false,
            dataEventRecordsItems: [],
        };
    },
    computed: {
        username() {
            return this.currentUser;
        },
    },

    methods: {
        login() {
            auth.login();
        },
        logout() {
            auth.logout();
        },

    },
    mounted() {
        this.$userManager.signinRedirectCallback().then(user => {
            // Sau khi người dùng đã xác thực thành công, bạn có thể lấy token truy cập từ user
            const accessToken = user.access_token
            console.log("Access Token:", accessToken)
        }).catch(error => {
            console.error("Error during login:", error)
        })
        auth.getUser().then((user) => {
            console.log(user);

            if (user && !user.expired) {
                auth.getAccessToken()
                    .then(accessToken => {
                        console.log('Access Token:', accessToken);
                        // Bạn có thể sử dụng accessToken cho các mục đích khác ở đây
                    })
                    .catch(error => {
                        console.error('Error getting access token:', error);
                    });
            }
        });
    },
};
</script>

<style>
.btn {
    color: #42b983;
    font-weight: bold;
    background-color: #007bff;
    border-color: #007bff;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-color: transparent;
    border: 1px solid #42b983;
    padding: 0.375rem 0.75rem;
    margin: 10px;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out,
        box-shadow 0.15s ease-in-out;
}
</style>