<template>
  <div class="main-login have-loading">
    <div class="logo">
      <img class="logo" src="../../assets/Pictures/DH_FPT.jpg" alt="Logo-FPT" />
    </div>
    <div class="login-card">
      <h1>Đăng nhập</h1>
      <div class="s-tt">
        Bắt đầu hành trình gửi, tiếp nhận thông tin, khiếu nại tại FPT
      </div>
      <div class="item">
        <div class="label">Chọn hệ đào tạo</div>
        <div class="value">
          <select v-model="this.educationSelect">
            <option
              v-for="(item, index) in educatios"
              :key="item.educationName"
              :value="item.educationId"
              :selected="index === 0"
            >
              {{ item.educationName }}
            </option>
          </select>
        </div>
      </div>
      <div class="item">
        <div class="label">Chọn cơ sở</div>
        <div class="value">
          <select v-model="this.campusSelect">
            <option
              v-for="(item, index) in campus"
              :key="item.campusName"
              :value="item.campusId"
              :selected="index === 0"
            >
              {{ item.campusName }}
            </option>
          </select>
        </div>
      </div>
      <GoogleLogin
        :on-click="(isLoggedInFeid = false)"
        v-if="!this.isLoggedIn"
        class="login-google"
        :callback="callback"
        prompt
      />
      <!-- <button @click="loginGoogle" class="google">
        <i class="fa-brands fa-google"></i>
        <span>Đăng nhập bằng Google</span>
      </button> -->
      <span class="noti">Với sinh viên từ K19 đăng nhập với FEID</span>
      <button class="feid" @click="loginFEID">
        <i class="fa-solid fa-envelope"></i>
        <span>Đăng nhập bằng FeID</span>
      </button>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
</template>

<script>
import { decodeCredential } from "vue3-google-login";
import ApiService from "@/script/api.service";
import CampusAPIService from "@/script/services/CampusAPIService";
import EducationAPIService from "@/script/services/EducationAPIService";
import UserApiService from "@/script/services/UserApiService";
import AuthService from "@/script/AuthService.js";
import { useToast } from "vue-toastification";
import { TYPE } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";

const auth = new AuthService();

export default {
  name: "LoginSystem",
  components: {
    Loading,
  },
  data() {
    return {
      apiService: new ApiService(),
      isLoggedIn: false,
      cookieValue: null,
      permissions: null,
      campus: [],
      campusSelect: null,
      educationSelect: null,
      educatios: [],
      user: null,
      idToken: null,
      isLoggedInFeid: false,
      callback: (response) => {
        this.user = decodeCredential(response.credential);
        if (this.user == null) {
          return;
        }

        if (!this.user.email.endsWith("@fpt.edu.vn")) {
          this.toast("Only email fpt login the system", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          return;
        }

        this.idToken = response.credential; // Nhận id_token từ đây
        this.cookieValue = this.user;
        //set cookie
        this.checkInfo();
        this.setCookie();
        // this.isLoggedIn = true;
      },
      loadingSections: {
        loadEducation: false,
        loadCampus: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
  },
  async mounted() {
    this.checkLoggedInStatus();
    if (!this.isLoggedIn) {
      this.getCampus();
      this.getEducation();
    }
    if (this.isLoggedInFeid) {
      while (localStorage.getItem("scms_check_feid") != null) {
        this.$userManager
          .signinRedirectCallback()
          .then((user) => {
            // Sau khi người dùng đã xác thực thành công, bạn có thể lấy token truy cập từ user
            const accessToken = user.access_token;
            // this.isLoggedIn = true;
            this.apiService.saveUserFEID(accessToken);

            this.isLoggedIn = true;
            this.$emit("reloadLogin");
          })
          .catch((error) => {
            this.isLoggedInFeid = false;
            console.error("Error during login:", error);
          });

        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }
  },
  methods: {
    loginFEID() {
      localStorage.setItem("scms_check_feid", true);
      auth.login();
    },
    async loyoutFEID() {
      this.isLoggedInFeid = true;
      await auth.logout();
    },

    async checkInfo() {
      try {
        const data = {
          idToken: this.idToken,
          campusId: this.campusSelect,
          educationId: this.educationSelect,
        };
        console.log(data);
        const response = await UserApiService.loginGoogle(data);
        if (
          response != null &&
          (response.message == "SUCCESS" ||
            response.message == "CREATE_SUCCESS")
        ) {
          this.apiService.saveToken(response.data.accessToken);
          this.apiService.saveUserSSO(this.idToken);
          this.isLoggedIn = true;
          this.$emit("reloadParent");
        } else {
          this.toast("Login failed", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
        }
      } catch (error) {
        console.error(error);
      }
    },
    async getCampus() {
      this.loadingSections.loadCampus = true;
      this.campus = await CampusAPIService.getCampus();
      if (this.campus != null && this.campus.length > 0) {
        this.campusSelect = this.campus[0].campusId;
        this.loadingSections.loadCampus = false;
      }
    },
    async getEducation() {
      this.loadingSections.loadEducation = true;
      this.educatios = await EducationAPIService.getEducations();
      if (this.educatios != null && this.educatios.length > 0) {
        this.educationSelect = this.educatios[0].educationId;
        this.loadingSections.loadEducation = false;
      }
    },
    async setCookie() {
      this.$cookies.set("currentUser", this.user, 7);
    },
    getCookie() {
      if (this.$cookies.get("currentUser") != null) {
        this.cookieValue = this.$cookies.get("currentUser"); // Get the value of the cookie 'myCookie'
      }
      // console.log(this.cookieValue);
    },
    checkLoggedInStatus() {
      if (localStorage.getItem("scms_check_feid")) {
        this.isLoggedInFeid = localStorage.getItem("scms_check_feid");
      }
      const cookieValue = this.$cookies.get("currentUser");
      // alert(cookieValue)
      if (cookieValue || this.apiService.getToken() != "") {
        this.user = cookieValue;
        this.isLoggedIn = true;
      }
    },
  },
  computed: {
    loadingSectionPage() {
      const { loadEducation, loadCampus } = this.loadingSections;
      return loadEducation || loadCampus;
    },
  },
};
</script>

<style>
@import "@/assets/scss/views/common/login-system.scss";
</style>
