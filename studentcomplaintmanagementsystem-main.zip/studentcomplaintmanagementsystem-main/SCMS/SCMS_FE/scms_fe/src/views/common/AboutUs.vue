<template>
  <div class="page-complaint about-us">
    <section class="about">
      <div class="about-info">
        <div class="about-img">
          <img src="@/assets/logo/scms_fill.png" alt="" />
        </div>
        <div>
          <p>
            {{ $t("span.introduce") }}
          </p>
          <p>
            {{ $t("span.motto") }}
          </p>
          <p>
            {{ $t("span.who") }}
          </p>
          <p>
            {{ $t("span.ourWork") }}
          </p>
          <p>
            {{ $t("span.milestone") }}
          </p>
        </div>
      </div>
    </section>

    <section class="team">
      <h1>{{ $t("span.ourTeam") }}</h1>
      <div class="team-cards">
        <div class="card">
          <div class="card-img">
            <img src="@/assets/members/leducviet.jpg" alt="User 1" />
          </div>
          <div class="card-info">
            <h2 class="card-name">{{ $t("span.viet") }}</h2>
            <p class="card-role">{{ $t("span.leader") }}</p>
            <p class="card-email">vietldhe153395@fpt.edu.vn</p>
            <p><button class="btn-contact">Contact</button></p>
          </div>
        </div>

        <!-- Card 2 -->

        <div class="card">
          <div class="card-img">
            <img
              src="https://media.geeksforgeeks.org/wp-content/uploads/20230822183347/
 man-portrait-businessman-male.jpg"
              alt="User 2"
            />
          </div>
          <div class="card-info">
            <h2 class="card-name">{{ $t("span.truong") }}</h2>
            <p class="card-role">{{ $t("span.member") }}</p>
            <p class="card-email">truongdvhe153164@fpt.edu.vn</p>
            <p><button class="btn-contact">Contact</button></p>
          </div>
        </div>

        <!-- Card 3 -->

        <div class="card">
          <div class="card-img">
            <img
              src="https://media.geeksforgeeks.org/wp-content/uploads/20230824122630/
 business-office-business-woman-professional.jpg"
              alt="User 3"
            />
          </div>
          <div class="card-info">
            <h2 class="card-name">{{ $t("span.huyanh") }}</h2>
            <p class="card-role">{{ $t("span.member") }}</p>
            <p class="card-email">anhthhe150479@fpt.edu.vn</p>
            <p><button class="btn-contact">Contact</button></p>
          </div>
        </div>
        <div class="card">
          <div class="card-img">
            <img src="@/assets/members/nguyenbavan.jpg" alt="User 4" />
          </div>
          <div class="card-info">
            <h2 class="card-name">{{ $t("span.van") }}</h2>
            <p class="card-role">{{ $t("span.member") }}</p>
            <p class="card-email">vannbhe161210@fpt.edu.vn</p>
            <p><button class="btn-contact">Contact</button></p>
          </div>
        </div>
        <div class="card">
          <div class="card-img">
            <img
              src="https://media.geeksforgeeks.org/wp-content/uploads/20230824122630/
 business-office-business-woman-professional.jpg"
              alt="User 5"
            />
          </div>
          <div class="card-info">
            <h2 class="card-name">{{ $t("span.duc") }}</h2>
            <p class="card-role">{{ $t("span.member") }}</p>
            <p class="card-email">ductahe150469@fpt.edu.vn</p>
            <p><button class="btn-contact">Contact</button></p>
          </div>
        </div>
      </div>
    </section>

    <footer class="footer">
      <p>© FlexiLearn All Rights Reserved.</p>
    </footer>
  </div>
</template>
<script>
import { defineComponent } from "vue";
import SignalRService from "@/script/signalr.service";

export default defineComponent({
  name: "about-us",
  data() {},
  async created() {
    console.log('s');
    await SignalRService.start();
  },
});
</script>
<style>
.about {
  background: rgb(78, 57, 165);
  background: linear-gradient(
    360deg,
    rgb(173, 216, 230) 0%,
    rgb(173, 252, 163) 100%
  );
  padding: 10px 0 20px 0;
  text-align: center;
}

.about h1 {
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.about p {
  font-size: 1rem;
  color: #323030;
  max-width: 800px;
  margin: 0 auto;
}

.about-info {
  margin: 2rem 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: left;
}
.about-info p {
  font-size: 1rem;
  font-weight: bold;
  max-width: 800px;
  margin: 0 auto;
}
.about-img {
  width: 17%;
  height: 40%;
}

.about-img img {
  width: 100%;
  height: 80%;
  border-radius: 5px;
  object-fit: contain;
}

.about-info p {
  font-size: 1.3rem;
  margin: 0 2rem;
  text-align: justify;
}

.btn-contact {
  border: none;
  outline: 0;
  padding: 10px;
  margin: 2rem;
  font-size: 1rem;
  color: white;
  background-color: #3643b7;
  text-align: center;
  cursor: pointer;
  width: 15rem;
  border-radius: 4px;
}

.btn-contact:hover {
  background-color: #1f9405;
}

.team {
  padding: 30px 0;
  text-align: center;
}

.team h1 {
  font-size: 2.5rem;
  margin-bottom: 20px;
  text-align: center;
}

.team-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 15px;
  margin-top: 20px;
}

.card {
  background-color: white;
  border-radius: 6px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.5);
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s;
  width: 18rem;
  height: 25rem;
  margin-top: 10px;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 12px rgba(0, 0, 0, 0.5);
}

.card-img {
  width: 100%; /* Đảm bảo ảnh lấp đầy khung */
  height: 100%; /* Cho phép ảnh co dãn theo tỷ lệ */
  display: block; /* Hiển thị ảnh là block element */
  border-radius: 8px; /* Bo góc ảnh bên trong */
}

.card-img img {
  width: 100%;
  height: 100%;
}

.card-info button {
  margin: 2rem 1rem;
}

.card-name {
  font-size: 2rem;
  margin: 10px 0;
}

.card-role {
  font-size: 1rem;
  color: #888;
  margin: 5px 0;
}

.card-email {
  font-size: 1rem;
  color: #555;
}

.footer {
  text-align: center;
}

.about-us {
  padding-bottom: 0;
}
</style>