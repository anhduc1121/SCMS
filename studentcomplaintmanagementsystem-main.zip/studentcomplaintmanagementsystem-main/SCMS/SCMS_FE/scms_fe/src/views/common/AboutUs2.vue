<template>
  <div id="about-us-2" class="about-us-2">
    <div class="content">
      <div class="image">
        <img class="img-base" src="@/assets/Pictures/about-us.jpg" alt="" />
        <div class="logo-view">
          <img class="logo" src="@/assets/logo/scms_fill.png" alt="" />
        </div>
      </div>
      <div class="title">
        <div class="tt1">{{ $t("span.introduce") }}</div>
        <div class="tt2">{{ $t("span.motto") }}</div>
      </div>
      <div class="des">
        {{ $t("span.who") }}
        {{ $t("span.ourWork") }}
        {{ $t("span.milestone") }}
      </div>

      <div class="our-team">
        <div class="icon">
          <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <g id="Layer_2" data-name="Layer 2">
              <path
                d="m9 12.25h-2a5.756 5.756 0 0 0 -5.75 5.75 2.752 2.752 0 0 0 2.75 2.75h8a2.752 2.752 0 0 0 2.75-2.75 5.756 5.756 0 0 0 -5.75-5.75z"
                fill="#29b6f6"
              />
              <circle cx="8" cy="7" fill="#29b6f6" r="4.75" />
              <path
                d="m18 13.25h-2a4.756 4.756 0 0 0 -4.75 4.75 2.752 2.752 0 0 0 2.75 2.75h6a2.752 2.752 0 0 0 2.75-2.75 4.756 4.756 0 0 0 -4.75-4.75z"
                fill="#2196f3"
              />
              <circle cx="17" cy="9" fill="#1565c0" r="3.75" />
            </g>
          </svg>
        </div>
        <div class="label">Meet Our Team</div>
        <div class="s-label">Contact to our team, FlexiLearn</div>
        <div class="members">
            <div class="item">
              <div class="image">
                <img src="@/assets/members/leducviet.jpg" alt="Le Duc Viet" />
                <div class="ct">
                  <button>
                    <span>Contact</span>
                  </button>
                </div>
              </div>
              <div class="name">{{ $t("span.viet") }}</div>
              <div class="email">vietldhe153395@fpt.edu.vn</div>
              <div class="role">{{ $t("span.leader") }}</div>
            </div>
            <div class="item">
              <div class="image">
                <img src="@/assets/members/nguyenbavan.jpg" alt="Nguyen Ba Van" />
                <div class="ct">
                  <button>
                    <span>Contact</span>
                  </button>
                </div>
              </div>
              <div class="name">{{ $t("span.van") }}</div>
              <div class="email">vannbhe161210@fpt.edu.vn</div>
              <div class="role">{{ $t("span.member") }}</div>
            </div>
            <div class="item">
              <div class="image">
                <img src="@/assets/members/tranhuyanh.jpg" alt="Tran Huy Anh" />
                <div class="ct">
                  <button>
                    <span>Contact</span>
                  </button>
                </div>
              </div>
              <div class="name">{{ $t("span.huyanh") }}</div>
              <div class="email">anhthhe150479@fpt.edu.vn</div>
              <div class="role">{{ $t("span.member") }}</div>
            </div>
            <div class="item">
              <div class="image">
                <img src="@/assets/members/dinhvantruong.jpg" alt="Dinh Van Truong" />
                <div class="ct">
                  <button>
                    <span>Contact</span>
                  </button>
                </div>
              </div>
              <div class="name">{{ $t("span.truong") }}</div>
              <div class="email">truongdvhe153164@fpt.edu.vn</div>
              <div class="role">{{ $t("span.member") }}</div>
            </div>
            <div class="item">
              <div class="image">
                <img src="@/assets/members/trinhanhduc.jpg" alt="Trinh Anh Duc" />
                <div class="ct">
                  <button>
                    <span>Contact</span>
                  </button>
                </div>
              </div>
              <div class="name">{{ $t("span.duc") }}</div>
              <div class="email">ductahe150469@fpt.edu.vn</div>
              <div class="role">{{ $t("span.member") }}</div>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
// import SignalRService from "@/script/signalr.service";

export default defineComponent({
  name: "about-us-2",
  components: {},
  data() {
    return {
      // members: [
      //   {
      //     img: "leducviet.jpg",
      //     email: this.$t("members.vietldhe153395.email"),
      //     name: this.$t("members.vietldhe153395.name"),
      //     role: this.$t("members.vietldhe153395.role")
      //   },
      //   {
      //     img: "",
      //     email: this.$t("members.truongdvhe153164.email"),
      //     name: this.$t("members.truongdvhe153164.name"),
      //     role: this.$t("members.truongdvhe153164.role")
      //   },
      //   {
      //     img: "",
      //     email: this.$t("members.anhthhe150479.email"),
      //     name: this.$t("members.anhthhe150479.name"),
      //     role: this.$t("members.anhthhe150479.role")
      //   },
      //   {
      //     img: "nguyenbavan.jpg",
      //     email: this.$t("members.vannbhe161210.email"),
      //     name: this.$t("members.vannbhe161210.name"),
      //     role: this.$t("members.vannbhe161210.role")
      //   },
      //   {
      //     img: "",
      //     email: this.$t("members.ductahe150469.email"),
      //     name: this.$t("members.ductahe150469.name"),
      //     role: this.$t("members.ductahe150469.role")
      //   },
      // ],
      // signalRConnection: new SignalRService(),
    };
  },
  mounted() {
    // window.addEventListener("beforeunload", this.handleBeforeUnload);
  },
  async created() {
    // await this.signalRConnection.start();
    // await Promise.all([
    //   this.registerServerMethods("09119967-168C-45BA-8FF1-07D2BBD3267C"),
    // ]);
  },
  // async beforeRouteLeave(to, from, next) {
  //   await this.signalRConnection.stop();
  //   next();
  // },
  methods: {
    // async handleBeforeUnload(event) {
    //   // Thực hiện các hành động trước khi rời khỏi trang
    //   // await this.signalRConnection.stop();

    //   // Có thể cung cấp một thông báo để hỏi người dùng có muốn rời khỏi hay không
    //   // event.returnValue = "Bạn có chắc chắn muốn rời khỏi trang?";
    // },
    // registerServerMethods(method) {
    //   // Đăng ký phương thức nhận dữ liệu từ server
    //   this.signalRConnection.connection.on(method, (message) => {
    //     console.log("Received message:", message);
    //   });
    // },
    getImage(img) {
      if (!img || img == "") return "";
      return require(`@/assets/members/${img}`);
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/common/about-us-2";
</style>
