<template>
  <div id="page-complaint" class="page-complaint have-loading">
    <div class="page-complaint-content">
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.question") }}</div>
          <div class="value">
            <input
              v-model="this.filter.question"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.text')"
            />
          </div>
        </div>
        <div class="add-new">
          <div class="label">&nbsp;</div>
          <button @click="openAddSUggestionModal()">
            <span>{{ $t("button.newSuggestion") }}</span>
          </button>
        </div>
      </div>

      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.category") }}</div>
          <div class="value">
            <select
              v-model="filter.categoryType.categoryName"
              @click="changeCategory()"
            >
              <option hidden>{{ filter.categoryType.categoryName }}</option>
            </select>
          </div>
        </div>
        <div class="filter-item">
          <div class="label">{{ $t("search.createDate") }}</div>
          <div class="value">
            <input
              v-model="this.filter.createDate"
              type="date"
              autocomplete="off"
              spellcheck="false"
              @change="this.toogleSort('x')"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="from">{{ $t("table.creator") }}</th>
            <th class="title">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.question == sortConst.A_Z ||
                      filter.sort.question == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  >
                  </i>
                  <i
                    v-if="filter.sort.question == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  >
                  </i>
                </span>
                <span class="label">{{ $t("table.question") }}</span>
              </div>
            </th>
            <th class="tag">{{ $t("table.category") }}</th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th></th>
          </tr>
          <!--Table: Body-->
          <template
            v-for="(item, index) in tableData"
            :key="item.ticketSuggestionID"
          >
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td>{{ item.creatorEmail }}</td>
              <td>{{ item.title }}</td>
              <td>
                {{ item.categoryName }}
              </td>
              <td>{{ this.formatDate(item.createDate) }}</td>
              <td class="star-item item-actions">
                <button class="edit" @click="EditSuggest(item)">
                  <i style="color: #fff !important" class="fa-solid fa-pen"></i>
                </button>
                <button class="delete" @click="DeleteSuggest(item)">
                  <i
                    style="color: #fff !important"
                    class="fa-solid fa-xmark"
                  ></i>
                </button>
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="false" />
  </div>
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    :title="$t('placeholder.category')"
    class="select-category-modal"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :isShowSelectAllCategoryModal="true"
      :selected-data-id="this.filter.categoryType.categoryTicketId"
      :source="'create-complaint'"
      @change-category="selectNewCategory($event)"
      @change-category-all="selectNewCategoryAll()"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
  <b-modal
    v-model="isShowAddSuggestModal"
    centered
    hideFooter="true"
    :title="keyTitleSuggestMess"
    class="select-category-modal"
  >
    <SuggestionModal
      v-if="isShowAddSuggestModal"
      :complaint="Complaint"
      :isAdd="isAdd"
      :dataMess="dataSelect"
      :ticketSuggestionId="ticketSuggestionId"
      @close="closeSuggestModal($event)"
      @reloadData="getSuggestion()"
      @add-suggest="addSuggestAfterEdit($event)"
    />
  </b-modal>
</template>
  
  <script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import { CATEGORY_TREE_MOCK } from "@/mock/create-complaint.mock.js";
import { SUGGESTION_DATA } from "@/mock/suggestion-data.mock";
import SuggestionAPIService from "@/script/services/SuggestionAPIService";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import { BModal } from "bootstrap-vue-next";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import SuggestionModal from "@/modal/complaint-details/SuggestionModal.vue";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
import { TYPE } from "vue-toastification";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "page-suggestion",
  components: {
    Pagination,
    BModal,
    EditCategory,
    SuggestionModal,
    Loading,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      sortConst: SORT,
      filter: {
        question: "",
        categoryType: {
          categoryTicketId: "",
          categoryName: "",
          fullPath: "",
        },
        sort: {
          question: SORT.A_Z,
          createdDate: SORT.A_Z,
        },
        creator: "",
      },
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      categories: CATEGORY_TREE_MOCK,
      tableData: SUGGESTION_DATA,
      isShowCategoryModal: false,
      isShowAddSuggestModal: false,
      dataSelect: [],
      keyTitleSuggestMess: "",
      isAdd: false,
      Complaint: null,
      ticketSuggestionId: "",
      loadingSections: {
        section1: false,
        loadCategorys: false,
        loadSuggestion: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    const res = await UserApiService.isChildAuthorized("/suggestion");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([this.getCategorys(), this.getSuggestion()]);
  },
  methods: {
    async EditSuggest(item) {
      this.loadingSections.section1 = true;
      const res = await SuggestionAPIService.getSuggestDetailById(
        item.ticketSuggestionId
      );
      if (res != null) {
        this.Complaint = {
          category: {
            categoryTicketName: res.data.categoryName,
            categoryTicketId: res.data.categoryTicketId,
          },
          title: res.data.title,
          description: res.data.description,
        };
        this.ticketSuggestionId = item.ticketSuggestionId;
        this.dataSelect = res.data.ticketSuggestionDetailReponVMs;
        this.keyTitleSuggestMess = this.$t("span.updateSuggest");
        this.isShowAddSuggestModal = true;
        this.loadingSections.section1 = false;
      } else {
        this.toast("Load Suggest Detail error!!!", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },
    async DeleteSuggest(item) {
      this.loadingSections.section1 = true;
      const res = await SuggestionAPIService.deleteSuggestDetailById(
        item.ticketSuggestionId
      );
      if (res != null) {
        this.loadingSections.section1 = false;
        this.toast("Delete success", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.getSuggestion();
      } else {
        this.loadingSections.section1 = false;
        this.toast("Delete Suggest error!!!", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },
    openAddSUggestionModal() {
      this.isShowAddSuggestModal = true;
      this.isAdd = true;
      this.keyTitleSuggestMess = this.$t("span.addSuggest");
      return;
    },
    cancelAddSUggestionModal() {
      this.isShowAddSuggestModal = false;
    },

    closeSuggestModal(data) {
      this.dataSelect = data;
      this.isShowAddSuggestModal = false;
    },

    addSuggestAfterEdit(data) {
      console.log(data.data, "sugguest messages");
      this.isShowAddSuggestModal = false;
    },

    //category
    changeCategory() {
      this.isShowCategoryModal = true;
    },
    selectNewCategory(data) {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = data.item;
      this.getCategorys();
      this.toogleSort("x");
    },

    selectNewCategoryAll() {
      this.isShowCategoryModal = false;
      this.filter.categoryType.categoryTicketId = "";
      this.filter.categoryType.categoryName = "All";
      this.toogleSort("x");
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },
    async getCategorys() {
      if (this.filter.categoryType.categoryTicketId == "") {
        this.filter.categoryType.categoryName = "All";
      } else {
        this.loadingSections.loadCategorys = true;
        const respon = await CategoryAPIService.GetCategoryById(
          this.filter.categoryType.categoryTicketId
        );
        if (respon != null) {
          this.filter.categoryType = respon;
          this.loadingSections.loadCategorys = false;
          // this.filter.categoryType = respon[0]["id"];
        } else {
          this.toast("Load data Categorys error", {
            type: TYPE.error, // or "success", "error", "default", "info" and "warning"
          });
          this.loadingSections.loadCategorys = false;
        }
      }
    },

    async getSuggestion() {
      const data = {
        cateId: this.filter.categoryType.categoryTicketId, // Giá trị mẫu cho cateId
        modifyUpdate: null,
        isDelete: false,
        isAccept: true,
        question: this.filter.question,
        createDate:
          this.filter.createDate == null ? "" : this.filter.createDate + "",
        requestUpdateID: null,
        pageIndex: this.pageData.currentPage,
        pageSize: this.pageSize,
        sortDate: this.filter.sort.createdDate,
        sortQuestion: this.filter.sort.question,
      };

      console.log(data);

      this.loadingSections.loadSuggestion = true;
      const respon = await SuggestionAPIService.getAllSuggestion(data);
      if (respon != null) {
        this.loadingSections.loadSuggestion = false;
        this.tableData = respon.data;
        const total = respon.numberOfRecords;
        this.pageData = {
          totalItem: total == 0 ? 1 : total,
          itemPerPage: parseInt(this.pageSize),
          maxPageShow: 5,
          currentPage: this.pageData.currentPage,
        };
      } else {
        this.loadingSections.loadSuggestion = false;
        this.toast("Load data Suggestions error", {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "title":
          this.filter.sort.question =
            this.filter.sort.question == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.createdDate = SORT.A_Z;
          break;
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.question = SORT.A_Z;
          break;
      }
      this.getSuggestion();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getSuggestion();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getSuggestion();
    },
  },
  computed: {
    loadingSectionPage() {
      const { loadCategorys, loadSuggestion, section1 } = this.loadingSections;
      return loadCategorys || loadSuggestion || section1;
    },
  },
});
</script>
  
  <style lang="scss">
@import "@/assets/scss/views/complaint";
</style>
  