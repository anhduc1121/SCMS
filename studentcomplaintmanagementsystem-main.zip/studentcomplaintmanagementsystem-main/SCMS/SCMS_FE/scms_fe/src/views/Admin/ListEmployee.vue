<template>
  <div id="page-complaint" class="page-complaint have-loading">
    <div class="page-complaint-content">
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.employee") }}</div>
          <div class="value">
            <input
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.email')"
              v-model="filter.email"
              @input="getEmployees()"
            />
          </div>
        </div>
        <div class="add-new">
          <div class="label">&nbsp;</div>
          <button @click="createNew()">
            <span>{{ $t("label.addNew") }}</span>
          </button>
        </div>
      </div>

      <div class="page-complaint-table" >
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="from">{{ $t("table.email") }}</th>
            <th class="tag">{{ $t("table.fullName") }}</th>
            <!-- <th class="star">
              <span class="label">{{ $t("table.permission") }}</span>
            </th> -->
            <th class="tag">Department</th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th class="star">
              <span class="label">{{ $t("table.action") }}</span>
            </th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td>{{ item.employeeEmail }}</td>
              <td>{{ item.firstname }} {{ item.lastname }}</td>
              <!-- <td @click="openEmpPermissModal($event)">
                <i class="fa-solid fa-eye"></i>
              </td> -->
              <td>{{ item.departmentName }}</td>
              <td>{{ this.formatDate(item.createDate) }}</td>
              <td>
                <div class="action-style">
                  <button
                    @click="showDetail(item)"
                    class="edit"
                    style="
                      border: none;
                      width: 25px;
                      height: 25px;
                      padding: 0px;
                      max-width: 25px;
                      max-height: 25px;
                      color: #fff;
                      font-size: 12px;
                      border-radius: 5px;
                      gap: 6px;
                    "
                  >
                    <i class="fa-solid fa-pen"></i>
                  </button>
                  <button
                    class="delete"
                    @click="deleteEmployee(item.employeeId)"
                    style="
                      border: none;
                      width: 25px;
                      height: 25px;
                      padding: 0px;
                      max-width: 25px;
                      max-height: 25px;
                      color: #fff;
                      font-size: 12px;
                      border-radius: 5px;
                    "
                  >
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>

    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
  <BModal
    v-model="isShowEmployeeDetailModal"
    centered
    hideFooter="true"
    :title="addEditEmployeeKey"
    class="select-category-modal"
  >
    <AddOrEdit
      v-if="isShowEmployeeDetailModal"
      :isAdd="isAdd"
      :employeeSelected="selectedEmployee"
      @close-modal="closeDetailModal()"
    />
  </BModal>
  
  <!--Permission Modal-->
  <b-modal
    v-model="isShowPermissModal"
    centered
    hideFooter="true"
    title="Employee Permission"
    class="employee-permiss-modal"
  >
    <EmployeePermission
      v-if="isShowPermissModal"
      :userId="yourId"
      @close="closeEmpPermissModal()"
    />
  </b-modal>
</template>

<script>
import Loading from "@/core/components/Loading.vue";
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import { LIST_EMPLOYEE_DATA } from "@/mock/list-employee-data.mock";
import EmployeeAPIService from "@/script/services/EmployeeAPIService";
import { BModal } from "bootstrap-vue-next";
import AddOrEdit from "@/modal/account/AddOrEdit.vue";
import EmployeePermission from "@/modal/permission/EmployeePermission.vue";
import { useToast } from "vue-toastification";
import { TYPE } from "vue-toastification";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "list-employee",
  components: {
    Pagination,
    BModal,
    AddOrEdit,
    EmployeePermission,
    Loading,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      addEditEmployeeKey: "",
      sortConst: SORT,
      filter: {
        email: "",
        sort: {
          createdDate: SORT.A_Z,
        },
      },
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      tableData: LIST_EMPLOYEE_DATA,
      isShowEmployeeDetailModal: false,
      isShowPermissModal: false,
      selectedEmployee: "",
      isAdd: false,
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    const res = await UserApiService.isChildAuthorized("/employee");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([this.getEmployees()]);
  },
  methods: {
    async deleteEmployee(employeeId) {
      this.loadingSections.section1 = true;
      const respon = await EmployeeAPIService.deleteEmployee(employeeId);
      // console.log("click btn delete");
      if (respon == true) {
        this.getEmployees();
        this.loadingSections.section1 = false;
      } else {
        this.toast(this.$t("toast.Common.mess11"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.section1 = false;
      }
    },

    createNew() {
      this.isShowEmployeeDetailModal = true;
      this.isAdd = true;
      this.addEditEmployeeKey = "Add Employee";
      this.selectedEmployee = {};
    },
    openEmpPermissModal(event) {
      event.stopPropagation();
      this.isShowPermissModal = true;
    },
    closeEmpPermissModal() {
      this.isShowPermissModal = false;
    },

    closeDetailModal() {
      this.isShowEmployeeDetailModal = false;
      this.isAdd = false;
    },

    showDetail(employee) {
      this.isAdd = false;
      this.selectedEmployee = employee;
      this.isShowEmployeeDetailModal = true;
      this.addEditEmployeeKey = "Edit Employee";
    },

    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },

    async getEmployees() {
      const data = {
        searchEmail: this.filter.email,
        sortDate: this.filter.sort.createdDate,
        pageIndex: this.pageData.currentPage,
        pageSize: this.pageSize,
        url: "/Account/GetListEmployee",
        urlGetSize: "/Account/GetListEmployeeSize",
      };

      this.loadingSections.section1 = true;
      const respon = await EmployeeAPIService.getEmployees(data);
      if (respon != null) {
        this.tableData = respon;
        this.loadingSections.section1 = false;
      }else{
        this.loadingSections.section1 = false;
        this.toast(this.$t("toast.Common.mess11"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }

      const responSize = await EmployeeAPIService.getPageSize(data);
      if (responSize != null) {
        // this.$emit('update:dataInput', responSize);
        const total = responSize;
        this.pageData = {
          totalItem: total,
          itemPerPage: parseInt(this.pageSize),
          maxPageShow: 5,
          currentPage: this.pageData.currentPage,
        };
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          break;
      }
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getEmployees();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getEmployees();
    },
  },
  computed: {
    loadingSectionPage() {
      const { section1 } =
        this.loadingSections;
      return section1;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";

.edit {
  background-color: #0ca678;
}

.delete {
  background-color: #f36944;
}
.action-style {
  align-items: center;
  justify-content: center;
}
</style>
