<template>
  <div id="edit-employee-modal" class="edit-employee-modal have-loading">
    <div class="section-detail">
      <div class="edit-detail" @click="editEnable()">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
          <path
            d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"
          />
        </svg>
        <!-- <i class="fa-solid fa-pen-to-square"></i> -->
      </div>
      <div hidden class="line-info" style="margin-top: 60px">
        <div class="field-name">{{ $t("span.accountID")}}</div>
        <div class="field-box">
          <div class="field-content">
            {{ employee.employeeId }}
          </div>
        </div>
      </div>
      <div class="line-info" style="margin-top: 60px">
        <div class="field-name">{{ $t("span.email")}}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              readonly
              class="input-content"
              type="email"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.employeeEmail"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.firstName")}}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              v-if="isEdit"
              required
              class="input-content input-firstname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.firstname" 
            />
            <input
              v-else
              readonly
              class="input-content input-firstname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.firstname"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.lastName")}}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              v-if="isEdit"
              required
              class="input-content input-lastname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.lastname"
            />
            <input
              v-else
              readonly
              class="input-content input-lastname"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.lastname"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.phone")}}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              v-if="isEdit"
              required
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.phone"
            />
            <input
              v-else
              readonly
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.phone"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.address")}}</div>
        <div class="field-box">
          <div class="field-content">
            <input
              v-if="isEdit"
              required
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.address"
            />
            <input
              v-else
              readonly
              class="input-content"
              type="text"
              autocomplete="off"
              spellcheck="false"
              v-model="employee.address"
            />
          </div>
        </div>
      </div>
      <div class="line-info">
        <div class="field-name">{{ $t("span.campus")}}</div>
        <div class="field-box">
          <div class="field-content">
            <div v-if="isEdit">
              <select class="select-campus" name="" v-model="employee.campusId">
                <option
                  v-for="item in listCampus"
                  :key="item.campusId"
                  :value="item.campusId"
                >
                  {{ item.campusName }}
                </option>
              </select>
            </div>
            <div v-else>
              <p>{{ employee.campusName }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="line-info" v-if="isEdit === false">
        <div class="field-name">{{ $t("span.status")}}</div>
        <div class="field-box">
          <div class="field-content">
            <div>{{ employee.statusName }}</div>
          </div>
        </div>
      </div>
      <div class="line-info" v-else>
        <div class="field-name">{{ $t("span.status")}}</div>
        <div class="field-box">
          <div class="field-content">
            <div>
              <select class="select-campus" name="" v-model="employee.statusId">
                <option
                  v-for="statusAccount in listStatusAccount"
                  :key="statusAccount.statusId"
                  :value="statusAccount.statusId"
                >
                  {{ statusAccount.statusName }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="isEdit" class="btn-close-edit">
      <button class="submit" @click="submitEdit()">
        <span>{{ $t("button.submit") }}</span>
      </button>
    </div>
    <div v-else class="btn-close-edit">
      <button class="submit" @click="closeModal()">
        <span>{{ $t("button.close") }}</span>
      </button>
    </div>
    <Loading v-if="loadingSectionPage" :isFullScreen="true" />
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { EMPLOYEE_DETAIL } from "@/mock/employee-data.mock";
import EmployeeAPIService from "@/script/services/EmployeeAPIService";
import CampusAPIService from "@/script/services/CampusAPIService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";
import Loading from "@/core/components/Loading.vue";
export default defineComponent({
  name: "employee-detail-popup",
  components: {Loading},
  data() {
    return {
      employee: EMPLOYEE_DETAIL,
      isEdit: false,
      isUpdateSuccess: null,
      status: false,
      listCampus: [],
      campusName: "",
      listStatusAccount: [],
      loadingSections: {
        statusAccount: false,
        campus: false,
        sesstion1: false
      },
    };
  },
  props: {
    employeeSelected: Object,
  },
  computed: {
    loadingSectionPage() {
      const { statusAccount , campus, sesstion1 } = this.loadingSections;
      return statusAccount || campus ||sesstion1;
    },
  },
  async created() {
    this.toast = useToast();
    this.getAllCampus();
    this.getStatusAccount();
    this.employee = this.employeeSelected;
  },
  methods: {
    async getStatusAccount() {
      this.loadingSections.statusAccount = true;
      const respon = await EmployeeAPIService.getStatusAccount();
      if (respon != null) {
        this.listStatusAccount = respon;
        this.loadingSections.statusAccount = false;
      }else{
        this.toast(this.$t("toast.Common.mess10"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
        this.loadingSections.statusAccount = false;
      }
    },

    async getAllCampus() {
      this.loadingSections.campus = true;
      const respon = await CampusAPIService.getCampus();
      if (respon != null) {
        this.listCampus = respon;
        this.loadingSections.campus = false;
      }else{
        this.loadingSections.campus = false;
        this.toast(this.$t("toast.Common.mess10"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },
    editEnable() {
      this.isEdit = true;
    },

    async submitEdit() {
      const data = {
        employee_update: this.employee,
        url: "/Employee/UpdateEmployee",
      };

      this.loadingSections.sesstion1 = true;
      const respon = await EmployeeAPIService.updateEmployee(data);
      if (respon != null) {
        this.isUpdateSuccess = respon;
        this.loadingSections.sesstion1 = false;
      }else{
        this.loadingSections.sesstion1 = false;
        this.toast(this.$t("toast.Common.mess9"), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },

    closeModal() {
      this.$emit("close-modal");
    },
  },
});
</script>
    
<style>
.section-detail {
  border: 3px solid rgb(0, 155, 160);
  height: 530px;
}
.line-info {
  display: block;
  /* background-color: aquamarine; */
  width: 80%;
  margin-top: 10px;
  margin-left: 10%;
  height: 50px;
}
.field-name {
  display: block;
  width: 15%;
  float: left;
  height: 50px;
  line-height: 50px;
  font-weight: 600;
  font-size: 18px;
}
.field-box {
  display: block;
  width: 83%;
  float: right;
  height: 50px;
  line-height: 50px;
  border: 1px solid rgb(211, 201, 201);
  border-radius: 10px;
  padding: 0;
}
.field-content {
  margin-left: 30px;
  font-weight: 400;
  font-size: 18px;
  position: relative;
}
.input-content {
  height: 46px;
  line-height: 46px;
  border: none;
  padding: 0;
  margin: 0;
  width: 95%;
  outline: none;
  position: absolute;
  top: 1px;
}
.btn-close-edit {
  /* background: orange; */
  width: 100%;
  height: 50px;
  display: block;
  margin-top: 10px;
  text-align: center;
}
.submit {
  background: rgb(248, 44, 37);
  border: 1px solid rgb(211, 201, 201);
  width: 140px;
  height: 50px;
  border-radius: 10px;
  font-size: 18px;
  font-weight: 600;
  color: white;
}
.edit-detail {
  width: 30px;
  height: 30px;
  float: right;
  margin-right: 10px;
  margin-top: 10px;
}
.edit-detail:hover {
  cursor: pointer;
}
.notification-span {
  display: block;
}
.select-campus {
  outline: none;
  border: none;
}
</style>