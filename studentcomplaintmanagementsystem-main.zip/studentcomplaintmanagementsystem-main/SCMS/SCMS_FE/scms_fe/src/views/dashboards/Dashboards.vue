<template>
  <div class="dashboard">
    <div class="dashboard-content">
      <h1 class="dashboard-title">{{ $t('span.welcome') }}</h1>
      <div class="dashboard-logo">
        <img class="" src="../../assets/Pictures/DH_FPT.jpg" alt="Logo-FPT" />
      </div>
    </div>
    <div class="dashboard-footer">
      <div class="footer-contact">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WelcomePage",
  props: {
    user: Object,
  },
  data() {
    return {};
  },
};
</script>

<style lang="scss">
@import "@/assets/scss/views/dashboards";
</style>