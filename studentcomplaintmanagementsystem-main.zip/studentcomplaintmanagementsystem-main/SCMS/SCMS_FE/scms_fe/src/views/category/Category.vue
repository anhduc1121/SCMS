<template>
  <div id="page-category" class="page-category">
    <div class="data-view">
      <div class="category-filter">
        <div class="add-category">
          <button @click="addOrEditCategory(null)">
            <span>{{ $t("button.addCategory") }}</span>
          </button>
        </div>
      </div>
      <CategoryList
        :dataList="data"
        :config="listConfig"
        :dataUpdate="dataUpdate"
        :isAdd="isAdd"
        @add-or-edit="addOrEditCategory($event)"
        @done-reload-update="this.dataUpdate = null"
      />
    </div>
  </div>

  <!-- Create or Edit Category Modal-->
  <b-modal
    v-model="isShowAddOrEditModal"
    centered
    hideFooter="true"
    :title="modalData?.title"
    class="add-or-edit-category-modal"
  >
    <AddOrEdit
      v-if="isShowAddOrEditModal"
      @cancel-add-or-edit="isShowAddOrEditModal = !isShowAddOrEditModal"
      @reload-add="reloadAfterUpdate($event, true)"
      @reload-edit="reloadAfterUpdate($event, false)"
      :modalData="modalData"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import CategoryList from "@/components/category/CategoryList.vue";
import { CATEGORY_DATA_MOCK } from "@/mock/category-data.mock.js";
import { BModal } from "bootstrap-vue-next";
import AddOrEdit from "@/modal/category/AddOrEdit.vue";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "page-category",
  components: {
    // Pagination,
    CategoryList,
    BModal,
    AddOrEdit,
  },
  data() {
    return {
      data: CATEGORY_DATA_MOCK,
      pageSize: 20,
      listConfig: {
        isShowAction: true,
        isShowSelect: false,
      },
      pageData: {
        totalItem: 200,
        itemPerPage: 20,
        maxPageShow: 5,
        currentPage: 1,
      },
      isShowAddOrEditModal: false,
      modalData: null,
      dataUpdate: null,
      isAdd: true,
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/category");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
  },
  watch: {},
  methods: {
    changeItemPerPage() {
      this.pageData = {
        totalItem: 200,
        itemPerPage: parseInt(this.pageSize),
        maxPageShow: 5,
        currentPage: 1,
      };
      console.log(this.pageData);
    },
    changePage(page) {
      console.log(page.page, "new page");
    },
    reloadAfterUpdate(data, isAdd) {
      // console.log(data);
      if (data != null && isAdd != null) {
        this.isShowAddOrEditModal = false;
        // this.dataUpdate = data;
        this.isAdd = !this.isAdd;
      }
    },
    addOrEditCategory(data) {
      data =
        data == null
          ? {
              title: this.$t("label.addNewCategory"),
              item: null,
              isAdd: true,
            }
          : data;
      this.modalData = { ...data };
      this.isShowAddOrEditModal = true;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/category.scss";
</style>
