<template>
  <div id="page-complaint" class="page-complaint have-loading">
    <div class="page-complaint-content">
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.pageName") }}</div>
          <div class="value">
            <input
              v-model="this.filter.name"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.pageName')"
            />
          </div>
        </div>
        <div class="add-new">
          <div class="label">&nbsp;</div>
          <button @click="createNew()">
            <span>{{ $t("label.addNewRole") }}</span>
          </button>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="title">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="label">{{ $t("table.name") }}</span>
              </div>
            </th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th class="star"></th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td>
                {{ item.roleName }}
              </td>
              <td>{{ this.formatDate(item.createDate) }}</td>
              <td class="star-item item-actions">
                <button class="edit" @click="editRole(item, $event)">
                  <i style="color: #fff !important" class="fa-solid fa-pen"></i>
                </button>
                <button @click="deleteRole(item)" class="delete">
                  <i
                    style="color: #fff !important"
                    class="fa-solid fa-xmark"
                  ></i>
                </button>
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>

  <!-- Add/Edit Modal-->
  <b-modal
    v-model="isShowAddEditModal"
    centered
    hideFooter="true"
    :title="addEditTitleKey"
    class="add-edit-role-modal"
  >
    <AddEditRole
      v-if="isShowAddEditModal"
      :isAdd="isAddRole"
      :data="roleSelected"
      @view-page="viewPage"
      @reLoadData="this.getRoles()"
      @cancel="closeAddEditRoleModal"
    />
  </b-modal>
  <!-- View Page Modal-->
  <b-modal
    v-model="isShowViewPageModal"
    centered
    hideFooter="true"
    title="View Page"
    class="view-page-modal"
  >
    <ViewPage v-if="isShowViewPageModal" @cancel="closeViewPage" />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import { BModal } from "bootstrap-vue-next";
import AddEditRole from "@/modal/role/AddEditRole.vue";
import ViewPage from "@/modal/role/ViewPage.vue";
import RoleAPIService from "@/script/services/RoleAPIService";
import Loading from "@/core/components/Loading.vue";
import UserApiService from "@/script/services/UserApiService";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";

export default defineComponent({
  name: "page-system",
  components: {
    Pagination,
    BModal,
    AddEditRole,
    ViewPage,
    Loading,
    // Treeselect,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      isShowCategoryModal: false,
      addEditTitleKey: "",
      isShowAddEditModal: false,
      roleSelected: null,
      isAddRole: true,
      isShowViewPageModal: false,
      sortConst: SORT,
      filter: {
        name: "",
        sort: {
          createdDate: SORT.A_Z,
        },
      },
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      tableData: [],
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  async created() {
    this.toast = useToast();
    
    const res = await UserApiService.isChildAuthorized("/manager-role");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([this.getRoles()]);
  },
  methods: {
    //Begin:: Actions
    createNew() {
      this.addEditTitleKey = "Add New Role";
      this.isAddRole = true;
      this.roleSelected = null;
      this.isShowAddEditModal = true;
    },
    editRole(item, event) {
      event.stopPropagation();
      this.addEditTitleKey = "Edit Role";
      this.isAddRole = false;
      this.roleSelected = item;
      this.isShowAddEditModal = true;
    },
    closeAddEditRoleModal() {
      this.roleSelected = null;
      this.isShowAddEditModal = false;
    },
    viewPage() {
      this.isShowViewPageModal = true;
    },
    closeViewPage() {
      this.isShowViewPageModal = false;
    },
    //End:: Actions

    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },

    async getRoles() {
      this.loadingSections.section1 = true;
      const formData = new FormData();
      formData.append("RoleName", this.filter.name);
      formData.append("pageIndex", this.pageData.currentPage);
      formData.append("pageSize", this.pageSize);
      formData.append("sortCreateDate", this.filter.sort.createdDate);

      const respon = await RoleAPIService.GetRoles(formData);
      if (respon != null) {
        this.tableData = respon.data;
        const total = respon.numberOfRecords;
        this.pageData = {
          totalItem: total,
          itemPerPage: parseInt(this.pageSize),
          maxPageShow: 5,
          currentPage: this.pageData.currentPage,
        };
        this.loadingSections.section1 = false;
      } else {
        this.loadingSections.section1 = false;
      }
    },

    async deleteRole(item){

      const formData = new FormData();
      formData.append("RoleId", item.roleId);

      const res = await RoleAPIService.delete(formData)

      if (res != null &&  res.message == 'SUCCESS') {
        this.toast(this.$t('toast.Common.mess15'), {
          type: TYPE.success, // or "success", "error", "default", "info" and "warning"
        });

        this.getRoles();
      }else{
        this.toast(this.$t('toast.Common.mess16'), {
          type: TYPE.error, // or "success", "error", "default", "info" and "warning"
        });
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          break;
      }
      this.getRoles();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getRoles();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getRoles();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/page";
@import "@/assets/scss/views/complaint";
</style>
