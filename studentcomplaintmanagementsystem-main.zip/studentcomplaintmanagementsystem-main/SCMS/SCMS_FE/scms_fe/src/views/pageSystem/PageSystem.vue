<template>
  <div id="page-complaint" class="page-complaint">
    <div class="page-complaint-content">
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.pageName") }}</div>
          <div class="value">
            <input
              v-model="this.filter.name"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.pageName')"
            />
          </div>
        </div>
        <div class="add-new">
          <div class="label">&nbsp;</div>
          <button @click="createNew()">
            <span>{{ $t("label.addNewPage") }}</span>
          </button>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="no">{{ $t("table.no") }}</th>
            <th class="title">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="label">{{ $t("table.name") }}</span>
              </div>
            </th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th class="star item-actions"></th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td>{{ index + 1 }}</td>
              <td>
                {{ item.pageName }}
              </td>
              <td>{{ this.formatDate(item.createDate) }}</td>
              <td class="star-item item-actions">
                <button class="edit" @click="editPage(item, $event)">
                  <i style="color: #fff !important" class="fa-solid fa-pen"></i>
                </button>
                <!-- <button class="delete">
                  <i
                    style="color: #fff !important"
                    class="fa-solid fa-xmark"
                  ></i>
                </button> -->
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
  </div>
  <!-- Create New Modal-->
  <b-modal
    v-model="isShowCreateNewModal"
    centered
    hideFooter="true"
    :title="addEditTitleKey"
    class="new-page-modal"
  >
    <NewPage
      v-if="isShowCreateNewModal"
      :data="dataPageSelected"
      :isReload="isReloadPageDetail"
      :isAdd="isAddPage"
      @add-function="addEditFunction($event, false)"
      @edit-function="addEditFunction($event, true)"
      @cancel="closeAddEditModal()"
    />
  </b-modal>
  <!-- Function Modal-->
  <b-modal
    v-model="isShowFunctionModal"
    centered
    hideFooter="true"
    :title="functionTitleKey"
    class="function-modal"
  >
    <Function
      v-if="isShowFunctionModal"
      :data="dataFunctionSelected"
      :isAdd="isAddFunction"
      @cancel="closeFunctionModal()"
      @reloadPageDetail="reloadNewPageModal()"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import { BModal } from "bootstrap-vue-next";
import NewPage from "@/modal/page/NewPage.vue";
import Function from "@/modal/page/Function.vue";
import PageSystemAPIService from "@/script/services/PageSystemAPIService";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "page-system",
  components: {
    Pagination,
    BModal,
    NewPage,
    Function,
    // Treeselect,
  },
  data() {
    return {
      innerWidth: window.innerWidth,
      addEditTitleKey: "",
      isShowCreateNewModal: false,
      dataPageSelected: null,
      isAddPage: true,
      functionTitleKey: "",
      isShowFunctionModal: false,
      dataFunctionSelected: null,
      sortConst: SORT,
      isReloadPageDetail: false,
      filter: {
        name: "",
        sort: {
          createdDate: SORT.A_Z,
        },
      },
      pageSize: 20,
      pageData: {
        totalItem: 10,
        itemPerPage: 1,
        maxPageShow: 5,
        currentPage: 1,
      },
      tableData: [],
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/page-system");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([this.getPages()]);
  },
  methods: {
    //Begin:: Actions
    createNew() {
      this.dataPageSelected = null;
      this.addEditTitleKey = this.$t("pageSystem.addNewPage");
      this.isAddPage = true;
      this.isShowCreateNewModal = true;
    },
    editPage(item, event) {
      event.stopPropagation();
      this.dataPageSelected = item;
      this.addEditTitleKey = this.$t("pageSystem.editPage");
      this.isAddPage = false;
      this.isShowCreateNewModal = true;
    },
    closeAddEditModal() {
      this.dataPageSelected = null;
      this.isShowCreateNewModal = false;
      this.getPages();
    },
    addEditFunction(data, isEdit) {
      this.functionTitleKey = isEdit
        ? this.$t("pageSystem.editFunction")
        : this.$t("pageSystem.createNewFunction");
      this.isAddFunction = isEdit ? false : true;
      this.dataFunctionSelected = data;
      this.isShowFunctionModal = true;
    },
    closeFunctionModal() {
      this.dataFunctionSelected = null;
      this.isShowFunctionModal = false;
      this.dataPageSelected;
    },

    reloadNewPageModal() {
      this.dataFunctionSelected = null;
      this.isShowFunctionModal = false;
      this.isReloadPageDetail = !this.isReloadPageDetail;
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "long", day: "numeric" };
      return date.toLocaleDateString("en-US", options);
    },

    async getPages() {
      const formData = new FormData();
      formData.append("PageName", this.filter.name.trim());
      formData.append("pageIndex", this.pageData.currentPage);
      formData.append("pageSize", this.pageSize);
      formData.append("sortCreateDate", this.filter.sort.createdDate);

      const respon = await PageSystemAPIService.getPages(formData);
      if (respon != null) {
        this.tableData = respon.data;
        const total = respon.numberOfRecords;
        this.pageData = {
          totalItem: total,
          itemPerPage: parseInt(this.pageSize),
          maxPageShow: 5,
          currentPage: this.pageData.currentPage,
        };
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
          this.filter.sort.title = SORT.A_Z;
          this.filter.sort.status = SORT.A_Z;
          this.filter.sort.pin = SORT.A_Z;
          break;
      }
      this.getPages();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getPages();
    },
    changePage(page) {
      // console.log(page.page, "new page");
      this.pageData.currentPage = page.page;
      this.getPages();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/page";
@import "@/assets/scss/views/complaint";
</style>
