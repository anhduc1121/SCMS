<template>
    <div id="page-complaint" class="page-complaint">
      <div class="page-complaint-content">
        <div class="page-complaint-search">
        <div class="search-title">
          <div class="label">{{$t('search.title')}}</div>
          <div class="value">
            <input
              v-model="this.filter.title"
              @input="this.toogleSort('x')"
              type="text"
              autocomplete="off"
              spellcheck="false"
              :placeholder="$t('placeholder.title')"
            />
          </div>
        </div>
      </div>
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{$t('search.status')}}</div>
          <div class="value">
            <select v-model="filter.statusType" @change="this.toogleSort('x')">
              <option value="" selected>All</option>
              <option
                v-for="status in this.statusData"
                :key="status.statusTicketId"
                :value="status.statusTicketId"
              >
                {{ status.statusTicketName }}
              </option>
            </select>
          </div>
        </div>
      </div>
        <div class="page-complaint-table">
          <table>
            <!--Table: Header-->
            <tr class="header">
              <th class="no">{{$t('table.pin')}}</th>
              <th class="from">{{$t('table.from')}}</th>
              <th class="title">{{$t('table.title')}}</th>
              <th class="from">
                <span class="label">{{$t('table.permission')}}</span>
              </th>
              <th class="created-date">
                <div class="th-sort" @click="toogleSort('created-date')">
                  <span class="icon">
                    <i
                      v-if="
                        filter.sort.createdDate == sortConst.A_Z ||
                        filter.sort.createdDate == sortConst.A_A
                      "
                      class="fa-solid fa-arrow-down"
                    ></i>
                    <i
                      v-if="filter.sort.createdDate == sortConst.Z_A"
                      class="fa-solid fa-arrow-up"
                    ></i>
                  </span>
                  <span class="label">{{ $t("table.dateTime") }}</span>
                </div>
              </th>
              <th class="tag">
                <span class="label">{{$t('table.action')}}</span>
              </th>
            </tr>
            <!--Table: Body-->
            <template v-for="(item, index) in tableData" :key="index">
              <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item" >
                <td class="star-item">
                <template v-if="!item.isPin">
                  <i
                    @click="addPinComplaint(item.ticketId)"
                    class="fa-regular fa-star"
                  ></i>
                </template>
                <template v-if="item.isPin">
                  <i
                    @click="deletePinComplaint(item.ticketId)"
                    class="fa-solid fa-star"
                  ></i>
                </template>
              </td>
                <td>{{ item.employeeEmail }}</td>
                <td>
                  {{ item.fullname }}
                </td>
                <td>
                  <i class="fa-solid fa-eye"></i>
                </td>
                <td>{{ this.formatDate(item.createDate) }}</td>
                <td>
                  <div class="action-style">
                    <button
                      @click="showDetail(item.employeeId)"
                      class="accept"
                      style="
                        border: none;
                        width: 25px;
                        height: 25px;
                        padding: 0px;
                        max-width: 25px;
                        max-height: 25px;
                        color: #fff;
                        font-size: 12px;
                        border-radius: 50%;
                        gap: 6px;
                      "
                    >
                    <i class="fa-solid fa-check"></i>
                    </button>
                    <button
                      class="reject"
                      style="
                        border: none;
                        width: 25px;
                        height: 25px;
                        padding: 0px;
                        max-width: 25px;
                        max-height: 25px;
                        color: #fff;
                        font-size: 12px;
                        border-radius: 50%;
                      "
                    >
                    <i class="fa-solid fa-xmark"></i>
                    </button>
                  </div>
                </td>
              </tr>
            </template>
          </table>
        </div>
      </div>
      <div class="pagination">
        <div class="_page-size">
          <div class="label">{{ $t("label.pageSize") }}</div>
          <select v-model="pageSize" @change="changeItemPerPage()">
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <div class="_page-view">
          <Pagination v-model:dataInput="pageData" @change-page="changePage" />
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { defineComponent } from "vue";
  import Pagination from "@/core/components/Pagination.vue";
  import { SORT } from "@/core/const/app.const.js";
  import { LIST_EMPLOYEE_DATA } from "@/mock/list-employee-data.mock";
  import EmployeeAPIService from "@/script/services/EmployeeAPIService";
  import PinAPIService from "@/script/services/PinAPIService";
  
  export default defineComponent({
    name: "list-employee",
    components: {
      Pagination,
    },
    data() {
      return {
        innerWidth: window.innerWidth,
  
        sortConst: SORT,
        filter: {
          email: "",
          sort: {
            createdDate: SORT.A_Z,
          },
        },
        pageSize: 20,
        pageData: {
          totalItem: 10,
          itemPerPage: 1,
          maxPageShow: 5,
          currentPage: 1,
        },
        tableData: LIST_EMPLOYEE_DATA,
        isShowEmployeeDetailModal: false,
        selectedEmployee: "",
      };
    },
    async created() {
      this.getEmployees();
    },
    methods: {
        async addPinComplaint(id) {
      const res = await PinAPIService.add(id);
      if (res != null) {
        if (res.message == "SUCCESS") {
          this.getComplaint();
        }
      }
    },
    async deletePinComplaint(id) {
      const res = await PinAPIService.delete(id);
      if (res != null) {
        console.log(res);
        if (res.message == "SUCCESS") {
          this.getComplaint();
        }
      }
    },
      closeDetailModal(){
        this.isShowEmployeeDetailModal = false;
      },
  
      showDetail(employeeId){
        this.selectedEmployee = employeeId;
        this.isShowEmployeeDetailModal = true;
      },
  
      formatDate(dateString) {
        const date = new Date(dateString);
        const options = { year: "numeric", month: "long", day: "numeric" };
        return date.toLocaleDateString("en-US", options);
      },
  
      async getEmployees() {
        const data = {
          searchEmail: this.filter.email,
          sortDate: this.filter.sort.createdDate,
          pageIndex: this.pageData.currentPage,
          pageSize: this.pageSize,
          url: "",
          urlGetSize: "",
        };
  
        const respon = await EmployeeAPIService.getEmployees(data);
        if (respon != null) {
          this.tableData = respon;
        }
  
        const responSize = await EmployeeAPIService.getPageSize(data);
        if (responSize != null) {
          // this.$emit('update:dataInput', responSize);
          const total = responSize;
          this.pageData = {
            totalItem: total,
            itemPerPage: parseInt(this.pageSize),
            maxPageShow: 5,
            currentPage: this.pageData.currentPage,
          };
        }
      },
  
      async toogleSort(label) {
        switch (label) {
          case "created-date":
            this.filter.sort.createdDate =
              this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
            break;
        }
      },
      changeItemPerPage() {
        this.pageData.currentPage = 1;
        this.getEmployees();
      },
      changePage(page) {
        // console.log(page.page, "new page");
        this.pageData.currentPage = page.page;
        this.getEmployees();
      },
    },
  });
  </script>
  
  <style lang="scss">
  @import "@/assets/scss/views/complaint";
  
  .accept {
    background-color: green;
  }
  
  .reject {
    background-color: red;
  }
  .action-style {
    align-items: center;
    justify-content: center;
  }
  </style>