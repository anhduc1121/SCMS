<template>
    <div id="page-complaint" class="page-complaint">
        <div class="page-complaint-content">
            <div class="page-complaint-search">
                <div class="search-title">
                    <div class="label">{{$t('search.scantime')}}</div>
                    <div class="value">
                        <input v-model="this.filter.title" type="number" autocomplete="off" spellcheck="false"
                            :placeholder="$t('placeholder.scantime')" />
                        <!-- <button class="search-btn">
              <span><i class="fa-solid fa-magnifying-glass"></i></span>
              <span>Search</span>
            </button> -->
                        <button class="search-btn new-complaint-btn">
                            <router-link to="/notification/create">
                                <span>{{$t('button.createNotification')}}</span>
                            </router-link>
                        </button>
                    </div>
                </div>
            </div>
            <div class="page-complaint-table">
                <table>
                    <!--Table: Header-->
                    <tr class="header">
                        <th class="created-date">
                            <div class="th-sort" @click="toogleSort('created-date')">
                                <span class="icon">
                                    <i v-if="filter.sort.createdDate == sortConst.A_Z || filter.sort.createdDate == sortConst.A_A"
                                        class="fa-solid fa-arrow-down"></i>
                                    <i v-if="filter.sort.createdDate == sortConst.Z_A" class="fa-solid fa-arrow-up"></i>
                                </span>
                                <span class="label">{{$t('table.dateTime')}}</span>
                            </div>
                        </th>
                        <th class="title">
                            <div class="th-sort" @click="toogleSort('title')">
                                <span class="icon">
                                    <i v-if="filter.sort.title == sortConst.A_Z || filter.sort.title == sortConst.A_A"
                                        class="fa-solid fa-arrow-down">
                                    </i>
                                    <i v-if="filter.sort.title == sortConst.Z_A" class="fa-solid fa-arrow-up">
                                    </i>
                                </span>
                                <span class="label">{{$t('table.title')}}</span>
                            </div>
                        </th>
                        <th class="status">
                            <div class="th-sort" @click="toogleSort('status')">
                                <span class="icon">
                                    <i v-if="filter.sort.status == sortConst.A_Z || filter.sort.status == sortConst.A_A"
                                        class="fa-solid fa-arrow-down"></i>
                                    <i v-if="filter.sort.status == sortConst.Z_A" class="fa-solid fa-arrow-up"></i>
                                </span>
                                <span class="label">{{$t('table.status')}}</span>
                            </div>
                        </th>
                        <th class="from">{{$t('table.to')}}</th>
                    </tr>
                    <!--Table: Body-->
                    <template v-for="(item, index) in tableData" :key="index">
                        <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
                            <td>{{ item.createdDate }}</td>
                            <td>{{ item.title }}</td>
                            <td>{{ item.status }}</td>
                            <td>{{ item.from }}</td>
                        </tr>
                    </template>
                </table>
            </div>
        </div>
        <div class="pagination">
            <div class="_page-size">
                <div class="label">{{$t('label.pageSize')}}</div>
                <select v-model="pageSize" @change="changeItemPerPage()">
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
            <div class="_page-view">
                <Pagination v-model:dataInput="pageData" @change-page="changePage" />
            </div>
        </div>
    </div>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import { CATEGORY_TREE_MOCK } from "@/mock/create-complaint.mock.js";
import { TICKET_STATUS_DATA } from "@/mock/ticket-status.mooc";
import { COMPLAINT_DATA } from "@/mock/complaint-data.mock.js";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import TicketStatusAPIService from "@/script/services/TicketStatusAPIService";
export default defineComponent({
    name: "system-notification",
    components: {
        Pagination,

    },
    data() {
        return {
            innerWidth: window.innerWidth,

            sortConst: SORT,
            filter: {
                title: "10",
                categoryType: null,
                statusType: "",
                sort: {
                    title: SORT.A_A,
                    status: SORT.A_A,
                    createdDate: SORT.A_A,
                },
                from: "",
                creator: "",
                tag: "",
            },
            pageSize: 20,
            pageData: {
                totalItem: 200,
                itemPerPage: 20,
                maxPageShow: 5,
                currentPage: 1,
            },
            categories: CATEGORY_TREE_MOCK,
            tableData: COMPLAINT_DATA,
            statusData: TICKET_STATUS_DATA,
        };
    },
    async created() {
        this.getCategorys();
        this.getStatus();
    },
    methods: {
        async getStatus() {
            const respon = await TicketStatusAPIService.getStatus();
            if (respon != null) {
                this.statusData = respon;
            }
        },
        async getCategorys() {
            const respon = await CategoryAPIService.getCategorysTree();
            if (respon != null) {
                this.categories = respon;
                this.filter.categoryType = respon[0]["id"];
            }
        },

        async getComplaint() { },

        toogleSort(label) {
            switch (label) {
                case "title":
                    this.filter.sort.title =
                        this.filter.sort.title == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    break;
                case "status":
                    this.filter.sort.status =
                        this.filter.sort.status == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    break;
                case "created-date":
                    this.filter.sort.createdDate =
                        this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
                    break;
            }
        },
        changeItemPerPage() {
            this.pageData = {
                totalItem: 200,
                itemPerPage: parseInt(this.pageSize),
                maxPageShow: 5,
                currentPage: 1,
            };
            console.log(this.pageData);
        },
        changePage(page) {
            console.log(page.page, "new page");
        },
    },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint";

.btn-seen {
    display: block;
    height: 40px;
}

.btn-Seen {
    float: right;
    height: 40px;
    width: 10%;
}

.search-btn {
    border: none;
    border-radius: 5px;
    background-color: #da6922;
    color: #fff;
    padding: 0 20px;

    i {
        margin-right: 10px;
    }
}

.search-btn:hover {
    background-color: #de7636;
}

.new-complaint-btn {
    background-color: #3e5b93;
    padding: 0 !important;

    a {
        padding: 0 20px;
        height: 100%;
        width: 100%;
        color: #fff !important;
        text-decoration: none !important;
    }
}

.new-complaint-btn:hover {
    background-color: #3e5a93e1;
}
</style>