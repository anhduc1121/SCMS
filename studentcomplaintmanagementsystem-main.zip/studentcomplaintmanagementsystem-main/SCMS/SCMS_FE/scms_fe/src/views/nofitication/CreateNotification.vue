<template>
  <div id="app-complaint-details" class="app-complaint-details">
    <div class="content-data">
      <div class="info">
        <button class="search-btn new-complaint-btn btn-back">
          <router-link class="router-content" to="/system">{{
            $t("button.back")
          }}</router-link>
        </button>
        <div class="centered">
          <div class="title">
            <div class="title-text">
              <input
                class="datetime"
                type="text"
                :placeholder="$t('placeholder.title')"
                style="width: 70%"
              />
            </div>
            <div class="datetime">
              <input
                class="input-email"
                type="email"
                :placeholder="$t('placeholder.email')"
              />
            </div>
          </div>
        </div>
      </div>
      <div ref="scrollContainer" class="chat chat-height notification-editors">
        <Editor
          class="editor-text"
          :placeholder="$t('placeholder.notification')"
          editorStyle="height: 100%"
        >
        </Editor>
      </div>

      <button class="search-btn new-complaint-btn">
        {{ $t("button.sendNotification") }}
      </button>
    </div>
    <div></div>
  </div>
  <!--User Tag Modal-->
  <b-modal
    v-model="isShowUserTagModal"
    centered
    hideFooter="true"
    title="User Tag"
  >
    <UserTag v-if="isShowUserTagModal" @submit-user="submitUserTag($event)" />
  </b-modal>
  <!--Edit Category Modal-->
  <b-modal
    v-model="isShowCategoryModal"
    centered
    hideFooter="true"
    title="Select Category"
  >
    <EditCategory
      v-if="isShowCategoryModal"
      :selectedDataId="complaintDetail.category.id"
      @change-category="selectNewCategory($event)"
      @close-modal="closeCategoryModal()"
    />
  </b-modal>
  <!--Suggestion Modal-->
  <b-modal
    v-model="isShowAddSuggestModal"
    centered
    hideFooter="true"
    title="Update Selected Messages"
  >
    <SuggestionModal
      v-if="isShowAddSuggestModal"
      :dataMess="messageSelected"
      :userId="yourId"
      @close="closeSuggestModal()"
      @add-suggest="addSuggestAfterEdit($event)"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
import { CHAT_DATA_MOCK } from "@/mock/chat-data.mock.js";
import Editor from "primevue/editor";
import { BModal } from "bootstrap-vue-next";
import SuggestionModal from "@/modal/complaint-details/SuggestionModal.vue";
import EditCategory from "@/modal/complaint-details/EditCategory.vue";
import UserTag from "@/modal/complaint-details/UserTag.vue";
// import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "create-notification",
  components: {
    BModal,
    Editor,
    SuggestionModal,
    EditCategory,
    UserTag,
  },
  data() {
    return {
      isShowRightMenu: false,
      isShowUserTagModal: false,
      isShowAddSuggestModal: false,
      isShowCategoryModal: false,
      userData: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
      ],
      yourId: 2, //id của user đang đăng nhập, dùng để kiểm tra xem tin nhắn có đến từ user đang đăng nhập không
      chatData: CHAT_DATA_MOCK,
      complaintDetail: {
        category: {
          id: 3,
          name: "Category 3",
          description: "Desccription for Category 3",
          isHaveChild: false,
          isShow: false,
          parentIds: [],
        },
      },
      tagUsers: [],
      addSuggestionStatus: false, // mặc định chế độ chọn tin nhắn Suggestion là false
      messageSelected: [],
      messengerContent: "",
      messageAttachment: [],
    };
  },
  async created() {
    // const res = await UserApiService.getPageAuthority("New Complaint");
    // if (res != null && !res) {
    //   this.$router.push("/dashboards"); // Chuyển hướng về trang home
    // }
  },
  mounted() {
    this.scrollMessAreaToBottom();
  },
  computed: {
    reverseFiles() {
      return this.messageAttachment.slice().reverse();
    },
  },
  methods: {
    //Begin:: User Tag
    openUserTagModal() {
      this.isShowUserTagModal = true;
    },
    submitUserTag(val) {
      this.tagUsers = val.data;
      console.log(this.tagUsers, "user tags");
      this.isShowUserTagModal = false;
    },
    removeTagUser(item) {
      const index = this.tagUsers.indexOf(item);
      this.tagUsers.splice(index, 1);
    },
    //End:: User Tag

    //Begin:: Edit Category
    openCategoryModal() {
      this.isShowCategoryModal = true;
    },
    selectNewCategory(item) {
      this.complaintDetail.category = item.item;
      this.isShowCategoryModal = false;
    },
    closeCategoryModal() {
      this.isShowCategoryModal = false;
    },
    //TODO: Chỗ này khi get data cần xử lý lấy Name thay vì Ids xho các Category cha của Category được chọn
    showCategoryTitle() {
      const tempTitle = this.complaintDetail.category.parentIds.join("/");
      if (tempTitle && tempTitle.length > 0) {
        return `${tempTitle}/${this.complaintDetail.category.name}`;
      }
      return this.complaintDetail.category.name;
    },
    //End:: Edit Category

    //Begin:: Add Suggestion
    openAddSUggestionModal() {
      if (this.addSuggestionStatus) {
        if (this.messageSelected.length == 0) return;
        //nếu ở chế độ chọn Suggestion => show modal
        this.isShowAddSuggestModal = true;
        return;
      }
      this.addSuggestionStatus = !this.addSuggestionStatus;
    },
    selectMessenger(id) {
      if (!this.addSuggestionStatus) return;
      const isExisting = this.messageSelected.find((f) => f.id == id);
      if (isExisting) {
        //gỡ tin nhắn khỏi list tin nhắn đã chọn
        const index = this.messageSelected.indexOf(isExisting);
        this.messageSelected.splice(index, 1);
        return;
      }
      const messSelected = this.chatData.find((f) => f.id == id);
      if (messSelected) {
        //thêm tin nhắn vào list được chọn
        this.messageSelected.push(messSelected);
        return;
      }
    },
    closeSuggestModal() {
      this.isShowAddSuggestModal = false;
    },
    addSuggestAfterEdit(data) {
      console.log(data.data, "sugguest messages");
      this.isShowAddSuggestModal = false;
      alert("submit");
    },
    //End:: Add Suggestion

    scrollMessAreaToBottom() {
      // Cuộn xuống tin nhắn mới nhất
      //nextTick để chắc chắn DOM đã render xong
      this.$nextTick(() => {
        this.$refs.scrollContainer.scrollTop =
          this.$refs.scrollContainer.scrollHeight;
      });
    },
    checkShowAvatar(index, id) {
      //nếu 2 tin nhắn liên tiếp đến từ 1 người thì chỉ hiện ảnh dại diện ở tin đầu tiên
      if (index == 0) return true;
      if (this.chatData[index - 1].id == id) return false;
      return true;
    },
    isMessSelected(id) {
      //kiểm tra xem tin nhắn có được chọn hay không
      return this.messageSelected.find((f) => f.id == id) ? true : false;
    },
    downloadFile(id) {
      //chỉ có thể tải tệp khi không ở chế độ chọn Suggestion
      if (this.addSuggestionStatus) return;
      alert(`Download file id: ${id}`);
    },
    selectAttachment() {
      this.$refs.selectAttachmentRef.click();
    },
    choosenAttachment(event) {
      const files = event.target.files;
      files.forEach((e) => {
        this.messageAttachment.push({
          id: this.messageAttachment.length + 1,
          name: e.name,
          link: "",
          type: e.type,
          file: e,
        });
      });
      event.target.value = null;
    },
    removeAttachment(id) {
      if (this.messageAttachment.length == 0) return;
      const fileSelected = this.messageAttachment.find((f) => f.id == id);
      if (fileSelected) {
        const index = this.messageAttachment.indexOf(fileSelected);
        this.messageAttachment.splice(index, 1);
      }
    },
    sendMessenger() {
      //kiểm tra nếu chưa có tin nhắn và attaschment thì k gửi
      if (this.messengerContent == "" && this.messageAttachment.length == 0)
        return;
      //Cần submit và lấy ID của tin nhắn mới fill vào trường id của biến newMess
      //mock nên mặc định thì tăng dần, id mới sẽ bằng id lớn nhất + 1
      const lastestMess = this.chatData.reduce(function (prev, current) {
        return prev.id > current.id ? prev : current;
      });
      const newMess = {
        id: lastestMess.id + 1,
        userId: 2,
        avatar:
          "https://images.pexels.com/photos/2607544/pexels-photo-2607544.jpeg?cs=srgb&dl=pexels-simona-kidri%C4%8D-2607544.jpg&fm=jpg",
        content: this.messengerContent,
        orderNumber: lastestMess.orderNumber + 1,
        attachments: this.messageAttachment,
      };
      this.chatData.push(newMess);
      //xóa dữ liệu tin nhắn và attachments sau khi gửi xong
      this.messengerContent = "";
      this.messageAttachment = [];
      //kéo xuống tin nhắn mới nhất
      this.scrollMessAreaToBottom();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint-details.scss";

.search-btn {
  border: none;
  border-radius: 5px;
  background-color: #da6922;
  color: #fff;
  padding: 0 20px;

  i {
    margin-right: 10px;
  }
}

.search-btn:hover {
  background-color: #de7636;
}

.new-complaint-btn {
  background-color: #3e5b93;
  padding: 0 !important;

  a {
    padding: 0 20px;
    height: 100%;
    width: 100%;
    color: #fff !important;
    text-decoration: none !important;
  }
}

.new-complaint-btn:hover {
  background-color: #3e5a93e1;
}

.btn-back {
  width: 10%;
}

.input-email {
  width: 100%;
  height: 90%;
  position: relative;
  border: none;
}

.input-email:focus {
  outline: none;
}

.title-text {
  width: 70%;
}
.editor-text {
  width: 100%;
  height: 67vh !important;
}
.notification-editors {
  padding: 0 !important;
  border: none !important;
}
</style>