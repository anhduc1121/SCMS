<template>
  <div id="page-complaint" class="page-complaint">
    <div class="page-complaint-content">
      <div class="page-complaint-filter">
        <div class="filter-item">
          <div class="label">{{ $t("search.status") }}</div>
          <div class="value">
            <select v-model="filter.statusType" @change="this.toogleSort('x')">
              <option value="" selected>All</option>
              <option value="1">Watched</option>
              <option value="0">Not seen</option>
            </select>
          </div>
        </div>
        <div class="filter-item"></div>
        <div class="filter-item"></div>
        <div class="filter-item"></div>
        <div class="filter-item"></div>
        <div class="filter-item">
          <div class="value">
            <button @click="markAllAsRead(accountId)">
              {{ $t("button.seen") }}
            </button>
          </div>
        </div>
      </div>
      <div class="page-complaint-table">
        <table>
          <!--Table: Header-->
          <tr class="header">
            <th class="title">
              <div class="th-sort" @click="toogleSort('title')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.title == sortConst.A_Z ||
                      filter.sort.title == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  >
                  </i>
                  <i
                    v-if="filter.sort.title == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  >
                  </i>
                </span>
                <span class="label">{{ $t("table.title") }}</span>
              </div>
            </th>
            <th class="created-date">
              <div class="th-sort" @click="toogleSort('created-date')">
                <span class="icon">
                  <i
                    v-if="
                      filter.sort.createdDate == sortConst.A_Z ||
                      filter.sort.createdDate == sortConst.A_A
                    "
                    class="fa-solid fa-arrow-down"
                  ></i>
                  <i
                    v-if="filter.sort.createdDate == sortConst.Z_A"
                    class="fa-solid fa-arrow-up"
                  ></i>
                </span>
                <span class="label">{{ $t("table.createDate") }}</span>
              </div>
            </th>
            <th class="star"></th>
          </tr>
          <!--Table: Body-->
          <template v-for="(item, index) in tableData" :key="index">
            <tr :class="{ 'bg-color': index % 2 != 0 }" class="data-item">
              <td :style="{ fontWeight: convertColor(item.isView) }">
                <router-link
                  :style="{ color: 'black', textDecoration: 'none' }"
                  @click="markRead(item.notificationId)"
                  :to="item.urlSulg ? { path: item.urlSulg } : '#'"
                  >{{ item.title }}</router-link
                >
              </td>
              <td>{{ this.formatDateFull(item.createDate) }}</td>
              <td class="star-item">
                <router-link
                  :to="{ path: '/notification/details', query: item }"
                  @click="markRead(item.notificationId)"
                  ><i class="fa-solid fa-circle-info"></i
                ></router-link>
              </td>
            </tr>
          </template>
        </table>
      </div>
    </div>
    <div class="pagination">
      <div class="_page-size">
        <div class="label">{{ $t("label.pageSize") }}</div>
        <select v-model="pageSize" @change="changeItemPerPage()">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
      </div>
      <div class="_page-view">
        <Pagination v-model:dataInput="pageData" @change-page="changePage" />
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import Pagination from "@/core/components/Pagination.vue";
import { SORT } from "@/core/const/app.const.js";
import NotificationAPIService from "@/script/services/NotificationAPIService";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "page-notification",
  components: {
    Pagination,
  },
  data() {
    return {
      innerWidth: window.innerWidth,

      sortConst: SORT,
      filter: {
        statusType: "",
        title: "",
        sort: {
          title: SORT.A_A,
          createdDate: SORT.A_A,
        },
        from: "",
        creator: "",
        tag: "",
      },
      pageSize: 20,
      pageData: {
        totalItem: 200,
        itemPerPage: 20,
        maxPageShow: 5,
        currentPage: 1,
      },
      tableData: null,
    };
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/nofitication");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
    await Promise.all([this.getNotifications()]);
  },
  methods: {
    formatDateFull(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },
    async markAllAsRead(accountId) {
      //
      //this.tableData.forEach((notification) => (notification.isView = true));
      console.log(accountId);
      NotificationAPIService.markAllAsRead(accountId);
      this.getNotifications();
      //Save data to db
    },
    async markRead(notificationId) {
      console.log(notificationId);
      NotificationAPIService.setViewed(notificationId);
      this.getNotifications();
    },
    convertColor(isView) {
      if (isView) {
        return "300";
      } else {
        return "600";
      }
    },
    async getNotifications() {
      const formData = new FormData();
      formData.append("statusView", this.filter.statusType);
      formData.append("statusView", "");
      formData.append("pageIndex", this.pageData.currentPage);
      formData.append("pageSize", this.pageSize);
      formData.append("sortDate", this.filter.sort.createdDate);
      formData.append("sortTitle", this.filter.sort.title);

      const respon = await NotificationAPIService.getNotifications(formData);
      if (respon != null) {
        this.tableData = respon.data;
        const total = respon.numberOfRecords;
        this.pageData = {
          totalItem: total,
          itemPerPage: parseInt(this.pageSize),
          maxPageShow: 5,
          currentPage: this.pageData.currentPage,
        };
      }
    },

    async toogleSort(label) {
      switch (label) {
        case "title":
          this.filter.sort.title =
            this.filter.sort.title == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
            this.filter.sort.createdDate = SORT.A_A
          break;
        case "created-date":
          this.filter.sort.createdDate =
            this.filter.sort.createdDate == SORT.A_Z ? SORT.Z_A : SORT.A_Z;
            this.filter.sort.title = SORT.A_A
          break;
      }

      this.getNotifications();
    },
    changeItemPerPage() {
      this.pageData.currentPage = 1;
      this.getNotifications();
    },
    changePage(page) {
      this.pageData.currentPage = page.page;
      this.getNotifications();
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/notification";

.btn-seen {
  display: block;
  height: 40px;
}

.btn-Seen {
  float: right;
  height: 40px;
  width: 10%;
}

.search-btn {
  border: none;
  border-radius: 5px;
  background-color: #da6922;
  color: #fff;
  padding: 0 20px;

  i {
    margin-right: 10px;
  }
}

.search-btn:hover {
  background-color: #de7636;
}

.new-complaint-btn {
  background-color: #3e5b93;
  padding: 0 !important;

  a {
    padding: 0 20px;
    height: 100%;
    width: 100%;
    color: #fff !important;
    text-decoration: none !important;
  }
}

.new-complaint-btn:hover {
  background-color: #3e5a93e1;
}
</style>
