<template>
  <div id="app-complaint-details" class="app-complaint-details">
    <div class="content-data">
      <div class="info">
        <button class="search-btn new-complaint-btn btn-back">
          <router-link class="router-content" to="/nofitication">{{
            $t("button.back")
          }}</router-link>
        </button>
        <div class="centered">
          <div class="title">
            <h2>{{ $route.query.title }}</h2>
            <div class="datetime">
              <!-- <span class="time">13:20</span> -->
              <span class="date">{{
                this.formatDateFull($route.query.createDate)
              }}</span>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="question">
                <div class="label">Status</div>
            </div> -->
      <div ref="scrollContainer" class="chat chat-height">
        <div class="content-text" v-html="$route.query.content"></div>
      </div>

      <button class="search-btn new-complaint-btn">
        <router-link
          class="router-content"
          :to="
            $route.query.urlSulg ? { path: '/' + $route.query.urlSulg } : '#'
          "
          >{{ $t("button.goto") }}</router-link
        >
      </button>
    </div>
    <div></div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import UserApiService from "@/script/services/UserApiService";

export default defineComponent({
  name: "notification-details",
  components: {},
  data() {
    return {};
  },
  async created() {
    const res = await UserApiService.isChildAuthorized("/notification/details");
    if (res != null && !res) {
      this.$router.push("/dashboards"); // Chuyển hướng về trang home
    }
  },
  methods: {
    formatDateFull(dateString) {
      const date = new Date(dateString);
      const options = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false, // Use 24-hour format
      };
      const formattedDate = date
        .toLocaleString("en-GB", options)
        .replace(/, /g, " ");
      return formattedDate;
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/views/complaint-details.scss";
.search-btn {
  border: none;
  border-radius: 5px;
  background-color: #da6922;
  color: #fff;
  padding: 0 20px;

  i {
    margin-right: 10px;
  }
}

.search-btn:hover {
  background-color: #de7636;
}

.new-complaint-btn {
  background-color: #3e5b93;
  padding: 0 !important;

  a {
    padding: 0 20px;
    height: 100%;
    width: 100%;
    color: #fff !important;
    text-decoration: none !important;
  }
}

.new-complaint-btn:hover {
  background-color: #3e5a93e1;
}
.btn-back {
  width: 10%;
}
.router-content {
  height: 40px;
  line-height: 40px;
}
</style>