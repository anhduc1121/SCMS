import { createRouter, createWebHistory } from "vue-router";
import Layout from "@/layout/Layout.vue";
import WelcomePage from "@/components/common/WelcomePage.vue";
import Dashboards from "@/views/dashboards/Dashboards.vue";
import CreateComplaint from "@/views/complaint/CreateComplaint.vue";
import Complaint from "@/views/complaint/Complaint.vue";
import ComplaintDetails from "@/views/complaint/ComplaintDetails.vue";
import Nofitication from "@/views/nofitication/Nofitication.vue";
import Category from "@/views/category/Category.vue";
import NotificationDetails from "@/views/nofitication/NotificationDetails.vue";
import SystemNotification from "@/views/nofitication/SystemNotification.vue";
import CreateNotification from "@/views/nofitication/CreateNotification.vue";
import ViewSuggestion from "@/views/suggest/ViewSuggestion.vue";
import DailyReport from "@/views/Report/DailyReport.vue";
import AccountReport from "@/views/Report/AccountReport.vue";
import SynthesisReport from "@/views/Report/SynthesisReport.vue";
import DetailRating from "@/views/Report/DetailRating.vue";
import DetailReport from "@/views/Report/DetailReport.vue";
import ListEmployee from "@/views/Admin/ListEmployee.vue";
import ListRequest from "@/views/request/ListRequest.vue";
import AboutUs2 from "@/views/common/AboutUs2.vue";
import FeedbackManager from "@/views/Report/FeedbackManager.vue";
import OtherDepartment from "@/views/Department/OtherDepartment.vue";
import PageSystem from "@/views/pageSystem/PageSystem.vue";
import RoleSystem from "@/views/managerRole/RoleSystem.vue";
import HelpDocumentList from "@/views/helpSystem/HelpDocumentList.vue";
import HelpFAQsList from "@/views/helpSystem/HelpFAQsList.vue";
import HelpSupportList from "@/views/helpSystem/HelpSupportList.vue";
import HelpVideoList from "@/views/helpSystem/HelpVideoList.vue";
import UserHelp from "@/views/helpSystem/UserHelp.vue";
import OtherDepartmentDetail from "@/views/Department/OtherDepartmentDetail.vue";

const routes = [
  {
    path: "/",
    redirect: "/dashboards",
    component: Layout,
    meta: {},
    children: [
      {
        path: "/department-complaint/details/:id",
        name: "system-department-detail",
        component: OtherDepartmentDetail,
        meta: {
          title: "menu.title.otherDepartmentDetails",
          pageTitle: "Other Department Details",
        },
      },
      {
        path: "/dashboards",
        name: "dashboards",
        component: Dashboards,
        meta: {
          title: "menu.title.dashboard",
          pageTitle: "Dashboards",
        },
      },
      {
        path: "/manager-role",
        name: "list-role",
        component: RoleSystem,
        meta: {
          title: "menu.title.listRole",
          pageTitle: "List Role",
        },
      },
      {
        path: "/page-system",
        name: "list-page",
        component: PageSystem,
        meta: {
          title: "menu.title.listPage",
          pageTitle: "List Page",
        },
      },
      {
        path: "/category",
        name: "list-category",
        component: Category,
        meta: {
          title: "menu.title.listCategory",
          pageTitle: "List Category",
        },
      },
      {
        path: "/complaint/create",
        name: "create-complaint",
        component: CreateComplaint,
        meta: {
          title: "menu.title.newComplaint",
          pageTitle: "Create Complaint",
        },
      },
      {
        path: "/complaint",
        name: "list-complaint",
        component: Complaint,
        meta: {
          title: "menu.title.listComplaint",
          pageTitle: "List Complaint",
        },
      },
      {
        path: "/complaint/details/:id",
        name: "complaint-details",
        component: ComplaintDetails,
        meta: {
          title: "menu.title.complaintDetails",
          pageTitle: "Complaint Details",
        },
      },
      {
        path: "/nofitication",
        name: "list-nofitication",
        component: Nofitication,
        meta: {
          title: "menu.title.listNofitication",
          pageTitle: "List Nofitication",
        },
      },
      {
        path: "/notification/details",
        name: "notification-details",
        component: NotificationDetails,
        meta: {
          title: "menu.title.notificationDetails",
          pageTitle: "Notification Details",
        },
      },
      {
        path: "/system",
        name: "system-notification",
        component: SystemNotification,
        meta: {
          title: "menu.title.systemNotificationSetting",
          pageTitle: "Notification System",
        },
      },
      {
        path: "/notification/create",
        name: "notification-create",
        component: CreateNotification,
        meta: {
          title: "menu.title.createNotification",
          pageTitle: "Create Notification",
        },
      },
      {
        path: "/suggestion",
        name: "list-suggestion",
        component: ViewSuggestion,
        meta: {
          title: "menu.title.viewSuggestion",
          pageTitle: "View Suggestion",
        },
      },
      {
        path: "/dailyReport",
        name: "system-report2",
        component: DailyReport,
        meta: {
          title: "menu.title.dailyReport",
          pageTitle: "Daily Report",
        },
      },
      {
        path: "/accountReport",
        name: "system-report1",
        component: AccountReport,
        meta: {
          title: "menu.title.accountReport",
          pageTitle: "Account Report",
        },
      },
      {
        path: "/synthesisReport",
        name: "system-report3",
        component: SynthesisReport,
        meta: {
          title: "menu.title.synthesisReport",
          pageTitle: "Synthesis Report",
        },
      },
      {
        path: "/detailRating",
        name: "system-report4",
        component: DetailRating,
        meta: {
          title: "menu.title.detailRating",
          pageTitle: "Detail Rating",
        },
      },
      {
        path: "/detailReport",
        name: "system-report5",
        component: DetailReport,
        meta: {
          title: "menu.title.detailReport",
          pageTitle: "Detail Report",
        },
      },
      {
        path: "/request",
        name: "system-request",
        component: ListRequest,
        meta: {
          title: "menu.title.listRequest",
          pageTitle: "List Request",
        },
      },
      {
        path: "/about",
        name: "system-aboutUs",
        component: AboutUs2,
        meta: {
          title: "menu.title.aboutUs",
          pageTitle: "About Us",
        },
      },
      {
        path: "/employee",
        name: "system-employee",
        component: ListEmployee,
        meta: {
          title: "menu.title.listEmployee",
          pageTitle: "List Employee",
        },
      },
      {
        path: "/feedback",
        name: "system-feedback",
        component: FeedbackManager,
        meta: {
          title: "menu.title.listFeedback",
          pageTitle: "List Feedback",
        },
      },
      {
        path: "/department-complaint",
        name: "system-department",
        component: OtherDepartment,
        meta: {
          title: "menu.title.otherDepartment",
          pageTitle: "Other Department",
        },
      },
      {
        path: "/manager-help-document-list",
        name: "document-list",
        component: HelpDocumentList,
        meta: {
          title: "menu.title.listDocumentHelp",
          pageTitle: "List Document Help",
        },
      },
      {
        path: "/manager-help-faqs-list",
        name: "faqs-list",
        component: HelpFAQsList,
        meta: {
          title: "menu.title.listFAQs",
          pageTitle: "List FAQs",
        },
      },
      {
        path: "/manager-help-support-list",
        name: "support-list",
        component: HelpSupportList,
        meta: {
          title: "menu.title.listSupport",
          pageTitle: "List Support",
        },
      },
      {
        path: "/manager-help-video-list",
        name: "video-list",
        component: HelpVideoList,
        meta: {
          title: "menu.title.listVideo",
          pageTitle: "List Video",
        },
      },
      {
        path: "/user-help",
        name: "user-help",
        component: UserHelp,
        meta: {
          title: "User Help",
          pageTitle: "User Help",
        },
      },
    ],
  },
  // { path: "/Home", component: ListComplaint },
  { path: "/111", component: WelcomePage },
  // { path: "/Detail", component: ComplaintDetails },
];

// khởi tạo router
const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
