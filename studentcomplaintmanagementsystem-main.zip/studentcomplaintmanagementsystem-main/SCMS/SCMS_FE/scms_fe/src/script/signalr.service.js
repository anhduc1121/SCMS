import * as signalR from '@microsoft/signalr';
import ApiService from "@/script/api.service";

class SignalRService {
  constructor() {
    this.connection = null;
  }

  async start() {
    try {
      const apiService  = new ApiService();
      const token = apiService.getToken();
      console.log(token)
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl('http://localhost:7252/chat', {
          accessTokenFactory: ()=> token
        }) // Thay đổi URL tùy theo cấu hình server của bạn

        // .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.start().then(()=> {
        // this.connection = connection;
  
        // Đăng ký các phương thức nhận dữ liệu từ server
      }).catch(()=> {
        // console.log(err)
      });
     
    } catch (err) {
      // console.error('Error starting SignalR connection:', err);
    }
    return null;
  }

  stop() {
    if (this.connection) {
      this.connection.onclose(() => {
        console.log('SignalR connection closed');
        // Xử lý logic sau khi kết nối đóng
      });
      this.connection.stop();
      this.connection = null;
    }
  }

  registerServerMethods(method) {
    // Đăng ký phương thức nhận dữ liệu từ server
    this.connection.on(method, (message) => {
      console.log('Received message:', message);
    });
  }

  sendMessage(message) {
    // Gọi phương thức trên server để gửi dữ liệu
    this.connection.invoke('a', message)
      .catch((err) => console.error('Error sending message:', err));
  }
}

// const signalRService = new SignalRService();
export default SignalRService;