import { UserManager, WebStorageStateStore } from 'oidc-client';

export default class AuthService {
  constructor() {
    const STS_DOMAIN = 'https://feid.ptudev.net';
    const settings = {
        // userStore Đối tượng WebStorageStateStore lưu trữ dữ liệu trạng thái của OpenID Connect trong localStorage của trình duyệt.
      userStore: new WebStorageStateStore({ store: window.localStorage }), 
      //authority: Đây là URL của máy chủ STS, tương tự như STS_DOMAIN.
      authority: STS_DOMAIN,
      // client_id: Đây là ID của ứng dụng client được đăng ký với STS. Trong trường hợp này, ID là cms-front-end.
      client_id: 'cms-front-end',
      //redirect_uri: Đây là URL mà STS sẽ chuyển hướng về sau khi xác thực thành công. Trong trường hợp này, URL là http://localhost:8696
      redirect_uri: 'http://localhost:8696',
      //automaticSilentRenew: Nếu đặt là true, UserManager sẽ tự động làm mới token truy cập trong trường hợp token hết hạn.
      automaticSilentRenew: true,
      //silent_redirect_uri: Đây là URL mà STS sẽ chuyển hướng về trong quá trình làm mới token truy cập tự động.
      silent_redirect_uri: 'http://localhost:8696',
      //response_type: Loại phản hồi mong muốn từ STS, trong trường hợp này là code.
      response_type: 'code',
      //scope: Đây là danh sách các quyền (scopes) mà ứng dụng client yêu cầu từ STS. 
      //Trong trường hợp này, danh sách bao gồm openid, profile và email.
      scope: 'openid profile email',
      //post_logout_redirect_uri: Đây là URL mà STS sẽ chuyển hướng về sau khi đăng xuất thành công.
      post_logout_redirect_uri: 'http://localhost:8696',
      //filterProtocolClaims: Nếu đặt là true, UserManager sẽ lọc các khẳng định giao thức (protocol claims) trong token truy cập.
      filterProtocolClaims: false,
    };

    this.userManager = new UserManager(settings);
  }

  getUser() {
    return this.userManager.getUser();
  }

  login() {
    //  mật khẩu nhé :
    return this.userManager.signinRedirect();
  }

  logout() {
    return this.userManager.signoutRedirect();
  }

  getAccessToken() {
    return this.userManager.getUser().then((data) => {
      if(data != null){
        return data.access_token;
      }
      return null;
    });
  }
}