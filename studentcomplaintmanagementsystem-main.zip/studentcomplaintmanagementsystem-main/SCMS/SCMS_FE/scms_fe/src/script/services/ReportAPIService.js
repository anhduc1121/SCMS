import ApiService from "@/script/api.service";

class ReportAPIService extends ApiService {
    constructor() {
        super();
    }

    //get report data
    async getReport(data) {
        try {
            const response = await this.post(
                `${data.url}?fromDate=${data.fromDate || ""}
                &toDate=${data.toDate || ""}`,
                null
            );
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data.data;
                }
            }

        } catch (error) {
            console.log("error ReportAPIService:" + data.url);
            return null;
        }
    }
}

export default new ReportAPIService();
