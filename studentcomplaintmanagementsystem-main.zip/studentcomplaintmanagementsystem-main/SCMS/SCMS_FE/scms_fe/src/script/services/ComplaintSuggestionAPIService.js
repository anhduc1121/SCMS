import ApiService from "@/script/api.service";

class ComplaintSuggestionAPIService extends ApiService {
    constructor() {
        super();
    }

    async getComplaintByCategoryAndTitle(categoryId, title) {
        try {
            const response = await this.postImg(
                `TicketSuggestion/GetAllTicketSuggestionForCreateTicket?categoryId=${categoryId}&title=${title}`,
                null
            );
            if (response != null) {
                return response.data;
            }
        } catch (error) {
            console.error("ComplaintSuggestionAPIService getComplaintByCategoryAndTitle", error);
        }
        return null
    }

    

}

export default new ComplaintSuggestionAPIService();
