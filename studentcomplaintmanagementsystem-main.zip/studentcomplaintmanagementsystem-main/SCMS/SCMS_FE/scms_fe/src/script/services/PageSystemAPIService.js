import ApiService from "@/script/api.service";

class PageSystemAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getPages(data) {
    try {
      const response = await this.postImg(`PageSystem/GetAllPageSystem`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("getPages PageSystemAPIService " + error);
    }
    return null;
  }

  async addPage(data) {
    try {
      const response = await this.postImg(`PageSystem/AddPageSystem`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("addPages PageSystemAPIService " + error);
    }
    return null;
  }

  async updatePages(data) {
    try {
      const response = await this.putImg(`PageSystem/UpdatePageSystem`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("updatePages PageSystemAPIService " + error);
    }
    return null;
  }

  async deletePages(data) {
    try {
      const response = await this.putImg(`PageSystem/DeletePageSystem`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("deletePages PageSystemAPIService " + error);
    }
    return null;
  }

  async getRoleAccpect(data) {
    try {
      const response = await this.postImg(`PageCrudSystem/GetRoleByPageCrudId`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("getRoleAccpect PageSystemAPIService " + error);
    }
    return null;
  }

  async createPageCrud(data) {
    try {
      const response = await this.postImg(`PageCrudSystem/AddPageCrud`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("createPageCrud PageSystemAPIService " + error);
    }
    return null;
  }

  async updatePageCrud(data) {
    try {
      const response = await this.putImg(`PageCrudSystem/UpdatePageCrud`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("updatePageCrud PageSystemAPIService " + error);
    }
    return null;
  }

  async loadFunctionPageCrud(data) {
    try {
      const response = await this.postImg(`PageCrudSystem/GetAllByPage`, data);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("loadFunctionPageCrud PageSystemAPIService " + error);
    }
    return null;
  }

  
}

export default new PageSystemAPIService();
