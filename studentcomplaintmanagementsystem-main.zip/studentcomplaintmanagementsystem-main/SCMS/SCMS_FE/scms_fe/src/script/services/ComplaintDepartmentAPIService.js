import ApiService from "@/script/api.service";

class ComplaintDepartmentAPIService extends ApiService {
  constructor() {
    super();
  }

  async create(data){
    try {
      const response = await this.postImg(`TicketDepartment/CreateNewTicket`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("create ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getComplaintDepartmentForStaff(data){
    try {
      const response = await this.postImg(`TicketDepartment/GetAllForStaff`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("getComplaintDepartmentForStaff ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getComplaintDepartmentForStaffOther(data){
    try {
      const response = await this.postImg(`TicketDepartment/GetAllForStaffOther`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("getComplaintDepartmentForStaffOther ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getTicketDepartmentByTicketStaff(ticketDepartmentId){
    try {
      const response = await this.postImg(`TicketDepartment/GetTicketDepartmentByTicketStaff?ticketDepartmentId=${ticketDepartmentId}`, null);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("getTicketDepartmentByTicketStaff ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getTicketDepartmentByTicketStaffOther(ticketDepartmentId){
    try {
      const response = await this.postImg(`TicketDepartment/GetTicketDepartmentByTicketStaffOther?ticketDepartmentId=${ticketDepartmentId}`, null);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("GetTicketDepartmentByTicketStaffOther ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getViewTicketCommentsChatStaff(ticketDepartmentId){
    try {
      const response = await this.postImg(`TicketDepartmentComments/ViewTicketCommentsChatStaff?tichketDepartmentId=${ticketDepartmentId}`, null);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("getViewTicketCommentsChatStaff ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async getViewTicketCommentsChatStaffOther(ticketDepartmentId){
    try {
      const response = await this.postImg(`TicketDepartmentComments/ViewTicketCommentsChatStaffOther?tichketDepartmentId=${ticketDepartmentId}`, null);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("getViewTicketCommentsChatStaffOther ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async replyTicketStaff(data){
    try {
      const response = await this.postImg(`TicketDepartmentComments/ReplyTicketStaff`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("replyTicketStaff ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async endTicketDepartment(ticketDepartmentId){
    try {
      const response = await this.post(`TicketDepartment/EndTicketDepartment?ticketDepartmentId=${ticketDepartmentId}`, null);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("endTicketDepartment ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async replyTicketStaffs(data){
    try {
      const response = await this.postImg(`TicketDepartmentComments/ReplyTicketStaffs`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("replyTicketStaffs ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }

  async replyTicketStaffOther(data){
    try {
      const response = await this.postImg(`TicketDepartmentComments/ReplyTicketStaffOther`, data);
      if(response != null){
        return response.data;
      }
    } catch (error) {
      console.log("replyTicketStaffOther ComplaintDepartmentAPIService "+ error);
    }
    return null;
  }


}

export default new ComplaintDepartmentAPIService();
