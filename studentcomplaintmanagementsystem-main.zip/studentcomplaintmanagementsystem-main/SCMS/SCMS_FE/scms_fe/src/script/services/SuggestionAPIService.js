import ApiService from "@/script/api.service";

class SuggestionAPIService extends ApiService {
  constructor() {
    super();
  }
  async getAllSuggestion(data) {
    try {
      const response = await this.post(
        `/TicketSuggestion/GetAllTicketSuggestion?cateId=${data.cateId || ""}
        &modifyUpdate=${data.modifyUpdate || ""}&isDelete=${
          data.isDelete || ""
        }&isAccept=${data.isAccept || ""}&description=${
          data.question || ""
        }&requestUpdateID=${data.requestUpdateID || ""}&createDate=${
          data.createDate
            ?data.createDate
            : ""
        }&pageIndex=${data.pageIndex}&pageSize=${data.pageSize}&sortDate=${
          data.sortDate
        }&sortQuestion=${data.sortQuestion}&accountCreatorID=${
          data.accountCreatorID
        }&accountUpdateID=${data.accountUpdateID}`,
        null
      );

      return response.data;
    } catch (error) {
      console.error("SuggestionAPIService getAllSuggestion", error);
      return null;
    }
  }

  async createSuggest(data) {
    try {
      const response = await this.postImg(
        "TicketSuggestion/CreateTicketSuggestion",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("SuggestionAPIService createSuggest", error);
    }
    return null;
  }

  async updateSuggest(data) {
    try {
      const response = await this.putImg(
        "TicketSuggestion/UpdateTicketSuggestion",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("SuggestionAPIService updateSuggest", error);
    }
    return null;
  }

  async getSuggestDetailById(id) {
    try {
      const response = await this.postImg(
        `TicketSuggestion/GetTicketSuggestionsByID?id=${id}`,
        null
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error(
        "SuggestionAPIService getComplaintTicketSuggestById",
        error
      );
    }
    return null;
  }

  async deleteSuggestDetailById(id) {
    try {
      const response = await this.putImg(
        `TicketSuggestion/DeleteTicketSuggestion?ticketSuggestionId=${id}`,
        null
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error(
        "SuggestionAPIService getComplaintTicketSuggestById",
        error
      );
    }
    return null;
  }
}
export default new SuggestionAPIService();
