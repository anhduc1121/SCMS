import ApiService from "@/script/api.service";

class EducationAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getEducations() {
    try {
      return (await this.post("Education/GetEducation", null)).data.data;
    } catch (error) {
      console.log("getCategorys CategoryAPIService");
      return null;
    }
  }
 
}

export default new EducationAPIService();
