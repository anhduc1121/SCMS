import ApiService from "@/script/api.service";

class ComplaintReportAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getUserReportOfComplaint(complaintId) {
    try {
      const response = await this.post(
        `TicketReport/GetListUserByTicket?ticketId=${complaintId}`,
        null
      );
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
      return response.data;
    } catch (error) {
      console.log("getUserReportOfComplaint ComplaintReportAPIService");
      return null;
    }
  }

  async add(data) {
    try {
      const response = await this.postImg(
        `TicketReport/AddReportTicket`,
        data
      );
      if (response != null) {
        return response.data;
      }
      return response.data;
    } catch (error) {
      console.log("getUserReportOfComplaint ComplaintReportAPIService");
      return null;
    }
  }

}

export default new ComplaintReportAPIService();
