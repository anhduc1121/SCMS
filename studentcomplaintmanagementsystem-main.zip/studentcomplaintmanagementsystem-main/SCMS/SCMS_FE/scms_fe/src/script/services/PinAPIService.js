import ApiService from "@/script/api.service";

class PinAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async add(ticketId) {
    try {
        const response = await this.post(`Pin/CreatePinTicket?ticketId=${ticketId}`, null);
        if(response != null){
            if (response.data.message == "SUCCESS") {
              return response.data;
            }
          }
    } catch (error) {
      console.log("add PinAPIService");
      return null;
    }
  }

  async delete(pinTicketId) {
    try {
      const response = await this.put(`Pin/DeletePinTicket?pinTicketId=${pinTicketId}`, null);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("delete PinAPIService "+ error);
    }
    return null;
  }
}

export default new PinAPIService();
