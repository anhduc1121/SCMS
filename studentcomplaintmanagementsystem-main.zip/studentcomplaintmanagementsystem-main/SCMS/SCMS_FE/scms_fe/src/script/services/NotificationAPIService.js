import ApiService from "@/script/api.service";

class NotificationAPIService extends ApiService {
  constructor() {
    super();
  }

  async getNotifications(data) {
    try {
      const res = await this.postImg(`Notification/ViewNotification`, data);
      if(res != null){
        return res.data
      }
    } catch (error) {
      console.log("getNotifications NotificationAPIService");
    }
    return null;
  }

  async setViewed(notificationId){
    //Set viewed here
    try {
      return (await this.put("/Notification/MarkAsRead?notificationId=" + notificationId, null)).data.data;
    } catch (error) {
      console.log(error)
      return null
    }
  }
  async markAllAsRead(){
    try {
      return (await this.put("/Notification/MarkAllAsRead" , null)).data.data;
    } catch (error) {
      console.log(error)
    }
    return true
  }
}

export default new NotificationAPIService();
