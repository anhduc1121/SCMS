import ApiService from "@/script/api.service";

class ComplaintAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getComplaints(data) {
    try {
      const response = await this.postImg(
        `Ticket/GetAllTicket`,
        data
      );
      return response.data;
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
    }
  }

  async getComplaintsForStudent(data) {
    try {
      const response = await this.postImg(
        `Ticket/GetTicketForStudent`,
        data
      );
      return response.data;
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      throw error; // hoặc trả về một giá trị mặc định khác nếu cần
    }
  }

  async getViewNode(ticketID) {
    try {
      const response = await this.post(`TicketHandling/ViewNode?ticketId=${ticketID}`, null);

      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      return null;
    }
  }

  async getComplaintCommentChatStudent(ticketID) {
    try {
      const response = await this.post(`TicketComment/ViewTicketCommentsChatStudent?tichketId=${ticketID}`, null);

      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      return null;
    }
  }
  async getComplaintCommentChatStaff(ticketID) {
    try {
      const response = await this.post(`TicketComment/ViewTicketCommentsChatStaff?tichketId=${ticketID}`, null);

      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      return null;
    }
  }

  async getComplaintCommentDetailStudent(ticketID) {
    try {
      const response = await this.post(`Ticket/GetTicketByTicketStudent?ticketId=${ticketID}`, null);

      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      return null;
    }
  }

  async getComplaintCommentDetailStaff(ticketID) {
    try {
      const response = await this.post(`Ticket/GetTicketByTicketStaff?ticketId=${ticketID}`, null);

      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getComplaints:", error);
      return null;
    }
  }

  async create(ticketCreate) {
    try {
      const response = await this.postImg(
        "Ticket/CreateNewTicket",
        ticketCreate
      );
       if(response != null){
        return response.data;
       }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }



  async updateComplaintCategory(CategoryId, ComplaintId) {
    try {
      const response = await this.put(
        `Ticket/UpdateCategorysOfTicketId?tickketId=${ComplaintId}&categoryTicketId=${CategoryId}`,
        null
      );
      if(response != null){
        return response.data;
       }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }

  async replyComplaintStaff(data) {
    try {
      const response = await this.postImg(
        "Ticket/ReplyTicketStaff",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }

  async replyComplaintStaffs(data) {
    try {
      const response = await this.postImg(
        "Ticket/ReplyTicketStaffs",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }


  async replyComplaintStudent(data) {
    try {
      const response = await this.postImg(
        "Ticket/ReplyTicketStudent",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }
}

export default new ComplaintAPIService();
