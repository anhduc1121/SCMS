import ApiService from "@/script/api.service";

class CampusAPIService extends ApiService {
  constructor() {
    super();
  }

//   postUser(data) {
//     return this.post("Home/GetUser", data);
//   }

  async getCampus() {
    try{
      return (await this.post("Campus/GetListCampus", null)).data.data;
    }catch(error){
      console.log("getUser UserApiService");
      return null;
    }
  }
}

export default new CampusAPIService();
