import ApiService from "@/script/api.service";

class TicketStatusAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getStatus() {
    try {
      const res = await this.post("Ticket/ViewStatusTicket", null);
      if (res != null) {
        if (res.data.message == "SUCCESS") {
          return res.data.data;
        }
      }
    } catch (error) {
      console.log("getStatus TicketStatusAPIService");
    }
    return null;
  }
}

export default new TicketStatusAPIService();
