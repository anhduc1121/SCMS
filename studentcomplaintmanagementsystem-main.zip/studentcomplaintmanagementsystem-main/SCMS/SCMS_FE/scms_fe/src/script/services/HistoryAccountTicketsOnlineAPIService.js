import ApiService from "@/script/api.service";

class HistoryAccountTicketsOnlineAPIService extends ApiService {
  constructor() {
    super();
  }

  async getAllByTicket(data){
    try {
      const response = await this.postImg(`HistoryAccountTicketsOnline/GetAllByTicket`, data);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data;
        }
      }
    } catch (error) {
      console.log("getAllByTicket HistoryAccountTicketsOnlineAPIService "+ error);
    }
    return null;
  }

  async add(data){
    try {
      const response = await this.postImg(`HistoryAccountTicketsOnline/Add`, data);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("add HistoryAccountTicketsOnlineAPIService "+ error);
    }
    return null;
  }

  async remove(data){
    try {
      const response = await this.postImg(`HistoryAccountTicketsOnline/Remove`, data);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("remove HistoryAccountTicketsOnlineAPIService "+ error);
    }
    return null;
  }
}

export default new HistoryAccountTicketsOnlineAPIService();
