import ApiService from "@/script/api.service";

class DepartmentAPIService extends ApiService {
    constructor() {
        super();
    }

    async getDepartments() {
        try {
            const response = await this.post(`Department/GetListDepartment`, null);
            if(response != null){
              if (response.data.message == "SUCCESS") {
                return response.data;
              }
            }
          } catch (error) {
            console.log("getDepartments DepartmentAPIService "+ error);
          }
          return null;
    }
}

export default new DepartmentAPIService();
