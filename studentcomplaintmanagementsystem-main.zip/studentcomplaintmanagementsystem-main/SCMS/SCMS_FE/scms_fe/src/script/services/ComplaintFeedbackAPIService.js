import ApiService from "@/script/api.service";

class ComplaintFeedbackAPIService extends ApiService {
  constructor() {
    super();
  }

  async replyComplaintStudent(data) {
    try {
      const response = await this.postImg(
        "TicketFeedback/AddFeedback",
        data
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức create:", error);
    }
    return null
  }
}

export default new ComplaintFeedbackAPIService();
