import ApiService from "@/script/api.service";
import { MENU_CONFIG } from "@/core/const/menu.const.js";

class UserApiService extends ApiService {
  constructor() {
    super();
  }

  async postUser(data) {
    return this.post("Home/GetUser", data);
  }

  async getUser() {
    try {
      return (await this.post("Home/GetUser", null)).data.data;
    } catch (error) {
      console.log("getUser UserApiService");
      return null;
    }
  }

  getUserSession() {
    try {
      const data = this.decodeToken();
      // console.log(data);
      return data;
    } catch (error) {
      console.log("getUserSession UserApiService");
      return null;
    }
  }

  async getViewAuthority(data) {
    try {
      const response = await this.post(
        `Home/GetViewAuthority?pageCrudId=${data}`,
        null
      );
      if (response != null) {
        return response.data.data;
      }
    } catch (error) {
      console.log("getViewAuthority UserApiService " + error);
      return null;
    }
  }

  async getInforUser() {
    try {
      const response = await this.post(
        `Home/GetInforUser`,
        null
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.log("getViewAuthority UserApiService " + error);
      return null;
    }
  }

  async isChildAuthorized(link) {
    if(link == null || link == undefined || (link != null && link.length == 0)){
      return null;
    }
    try {
      // console.log(getMenuItemByLink(link), "kkk")
      const response = await this.getPageAuthority(getMenuItemByLink(link));
      // console.log(response);
      return response;
    } catch (error) {
      // console.error("Error checking page authority:", error);
      return false;
    }
    function getMenuItemByLink(link) {
      function findMenuItemRecursive(menu) {
        for (const item of menu) {
          // console.log(item, link);
          if (item.link === link) {
            return item.nameAuthority;
          }
          if (item.children != null) {
            const childItem = findMenuItemRecursive(item.children);
            if (childItem != "") {
              return childItem;
            } else {
              continue;
            }
          }
        }
        return "";
      }

      return findMenuItemRecursive(MENU_CONFIG);
    }
  }

  async getPageAuthority(data) {
    if(data == null || data == undefined || (data != null && data.length == 0)){
      return null;
    }
    try {
      // console.log(data, "ssss")
      const response = await this.post(
        `Home/GetPageAuthority?name=${data}`,
        null
      );
      if (response != null) {
        return response.data.data;
      }
    } catch (error) {
      console.log("getPageAuthority UserApiService " + error);
    }
    return null;
  }

  
  async getEmailByRole(data) {
    try {
      // console.log(data, "ssss")
      const response = await this.post(
        `Account/GetEmailByRole?gmail=${data}`,
        null
      );
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.log("getEmailByRole UserApiService " + error);
      return null;
    }
  }

  async loginGoogle(data) {
    try {
      const response = await this.post(
        `Home/verify-google-token?idToken=${data.idToken}&CampusId=${data.campusId}&EducationId=${data.educationId}`,
        null
      );
      // console.log(response);
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.log("loginGoogle UserApiService " + error);
      return null;
    }
  }

  async loginFeidSystem() {
    try {
      const response = await this.post(`Home/oidc`, null);
      // console.log(response);
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.log("loginFeidSystem UserApiService " + error);
      return null;
    }
  }
}

export default new UserApiService();
