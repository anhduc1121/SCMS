import ApiService from "@/script/api.service";

class ComplaintTagAPIService extends ApiService {
  constructor() {
    super();
  }

  async getComplaintTag(ticketID) {
    try {
      const response = await this.post(
        `TagTicket/ViewUserTag?ticketId=${ticketID}`,
        null
      );
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("getComplaintTag  ComplaintTagAPIService", error);
      return null;
    }
  }
  async create(data) {
    try {
      const response = await this.postImg("TagTicket/AddTag", data);
      if (response != null) {
        return response.data;
      }
    } catch (error) {
      console.error("create  ComplaintTagAPIService", error);
    }
    return null;
  }

  async updateStatus(id, status) {
    try {
      const response = await this.put(
        `TagTicket/UpdateUserTag?tagTicketId=${id}&status=${status}`,
        null
      );
      if (response != null) {                   
        return response.data;
      }
    } catch (error) {
      console.error("updateStatus  ComplaintTagAPIService", error);
    }
    return null;
  }
}

export default new ComplaintTagAPIService();
