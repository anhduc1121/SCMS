import ApiService from "@/script/api.service";

class CategoryAPIService extends ApiService {
  constructor() {
    super();
  }

  //   postUser(data) {
  //     return this.post("Home/GetUser", data);
  //   }

  async getCategorys() {
    try {
      return (await this.post("Category/GetCategory", null)).data.data;
    } catch (error) {
      console.log("getCategorys CategoryAPIService");
      return null;
    }
  }

  async GetCategoryById(categoryId) {
    try {
      const response = await this.post(`Category/GetCategoryById?categoryId=${categoryId}`, null);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("getCategorysTree CategoryAPIService "+ error);
    }
    return null;
  }

  

  async getCategorysParent(IdParentCategory, categorySelected) {
    try {
      const response = await this.post(`Category/GetCategorysByIdParentCategory?IdParentCategory=${IdParentCategory}&categorySelected=${categorySelected}`, null);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("getCategorysTree CategoryAPIService "+ error);
    }
    return null;
  }

  async createCategory(data){
    try {
      const response = await this.postImg(`Category/CreateCategoryTicket`, data);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("getCategorysTree CategoryAPIService "+ error);
    }
    return null;
  }

  async updateCategory(data){
    try {
      const response = await this.putImg(`Category/UpdateCategoryTicket`, data);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("getCategorysTree CategoryAPIService "+ error);
    }
    return null;
  }

  async deleteCategory(categoryTicketId){
    try {
      const response = await this.put(`Category/DeleteCategoryTicket?categoryTicketId=${categoryTicketId}`, null);
      if(response != null){
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("getCategorysTree CategoryAPIService "+ error);
    }
    return null;
  }

}

export default new CategoryAPIService();
