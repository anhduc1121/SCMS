import ApiService from "@/script/api.service";

class RoleAPIService extends ApiService {
    constructor() {
        super();
    }


    async GetRoles(data) {
        try {
            const response = await this.postImg(`Role/GetListRole`, data);
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data;
                }
            }
        } catch (error) {
            console.log("GetRoles RoleAPIService " + error);
        }
        return null;
    }

    async GetListFunctionByRoles(data) {
        try {
            const response = await this.postImg(`Role/GetListFunctionAPIByRole?roleId=${data}`, null);
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data;
                }
            }
        } catch (error) {
            console.log("GetListFunctionByRoles RoleAPIService " + error);
        }
        return null;
    }

    async add(data) {
        try {
            const response = await this.postImg(`Role/CreateRole`, data);
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data;
                }
            }
        } catch (error) {
            console.log("add RoleAPIService " + error);
        }
        return null;
    }

    async delete(data) {
        try {
            const response = await this.putImg(`Role/DeleteRole`, data);
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data;
                }
            }
        } catch (error) {
            console.log("add RoleAPIService " + error);
        }
        return null;
    }

    async update(data) {
        try {
            const response = await this.putImg(`Role/UpdateRole`, data);
            if (response != null) {
                if (response.data.message == "SUCCESS") {
                    return response.data;
                }
            }
        } catch (error) {
            console.log("add RoleAPIService " + error);
        }
        return null;
    }

}

export default new RoleAPIService();
