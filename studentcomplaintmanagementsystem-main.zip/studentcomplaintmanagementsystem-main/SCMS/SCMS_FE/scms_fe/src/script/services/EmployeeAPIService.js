import ApiService from "@/script/api.service";

class EmployeeAPIService extends ApiService {
  constructor() {
    super();
  }

  //get getEmployees data

  async getEmployees(data) {
    var fieldNames = Object.keys(data);
    try {
      const response = await this.post(
        `${data.url}?${fieldNames[0]}=${data[fieldNames[0]]}
                &${fieldNames[1]}=${data[fieldNames[1]]}
                &${fieldNames[2]}=${data[fieldNames[2]]}
                &${fieldNames[3]}=${data[fieldNames[3]]}`,
        null
      );
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.log("error EmployeeAPIService:" + data.url);
      return null;
    }
  }

  async updateEmployee(data) {
    try {
      const response = await this.put(`${data.url}`, data.employee_update);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          if (response.data.data == true) return "Update success!";
        } else {
          return "Update failed!";
        }
      }
    } catch (error) {
      console.log("error EmployeeAPIService: updateEmployee" + data.url);
      return "error";
    }
  }

  async addEmployee(data) {
    //validate
    if (!data.employee_update.exEmployee.employeeEmail) {
      return "Email can not empty!";
    }
    try {
      const response = await this.post(`${data.url}`, data.employee_update);
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data;
        } else {
          return null;
        }
      }
    } catch (error) {
      console.log("error EmployeeAPIService: addEmployee" + data.url);
      return "error";
    }
  }

  //Page size
  async getPageSize(data) {
    try {
      var fieldNames = Object.keys(data);
      const response = await this.post(
        `${data.urlGetSize}?${fieldNames[0]}=${data[fieldNames[0]]}
                &${fieldNames[1]}=${data[fieldNames[1]]}
                &${fieldNames[2]}=${data[fieldNames[2]]}
                &${fieldNames[3]}=${data[fieldNames[3]]}`,
        null
      );
      if (response != null) {
        if (response.data.message == "SUCCESS") {
          return response.data.data;
        }
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getPageSize:", error);
      return null;
    }
  }

  async getStatusAccount() {
    try {
      const response = await this.get("/Account/GetAllStatusAccount");
      if (response != null && response.data.message === "SUCCESS") {
        return response.data.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getStatusAccount:", error);
    }
  }

  async getAllDepartment() {
    try {
      const response = await this.post("/Department/GetListDepartment");
      if (response != null && response.data.message === "SUCCESS") {
        return response.data.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getAllDepartment:", error);
    }
  }

  async getRolesByAccountId(accountId) {
    try {
      const response = await this.post(
        `/Role/GetRolesByAccountId?accountId=${accountId}`,
        null
      );
      if (response != null && response.data.message === "SUCCESS") {
        return response.data.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức getRolesById:" + error);
    }
  }

  async deleteEmployee(accountId) {
    try {
      const response = await this.post(
        `/Account/DeleteAccountByAccountId?accountId=${accountId}`,
        null
      );
      if (response != null && response.data.message === "SUCCESS") {
        return response.data.data;
      }
    } catch (error) {
      console.error("Lỗi khi gọi phương thức DeleteAccountByAccountId:", error);
    }
  }
}

export default new EmployeeAPIService();
