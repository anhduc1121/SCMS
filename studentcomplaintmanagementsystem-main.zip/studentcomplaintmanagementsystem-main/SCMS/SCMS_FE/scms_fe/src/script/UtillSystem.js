class UtillSystem {
  constructor() {}

  // 08/04/2024 02:42
  static formatDateFull(dateString) {
    const date = new Date(dateString);
    const options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false, // Use 24-hour format
    };
    const formattedDate = date
      .toLocaleString("en-GB", options)
      .replace(/, /g, " ");
    return formattedDate;
  }

  // March 31, 2024
  static formatDateString(dateString) {
    const date = new Date(dateString);
    const options = { year: "numeric", month: "long", day: "numeric" };
    return date.toLocaleDateString("en-US", options);
  }

  // 02:42
  static formatTime(dateString) {
    const date = new Date(dateString);
    const options = {
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23", // Hiển thị theo định dạng 24 giờ
    };
    const formattedTime = date
      .toLocaleString("en-US", options)
      .replace(/:/g, ":");
    return formattedTime;
  }
  //08/04/2024
  static formatDate(dateString) {
    const date = new Date(dateString);
    const options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    };
    const formattedDate = date
      .toLocaleString("en-US", options)
      .replace(/\//g, "/");
    return formattedDate;
  }

  //phương thức install để có thể sử dụng UtillSystem như một plugin của Vue
  // static install(Vue) {
  //   Vue.mixin({
  //     methods: {
  //       $utils: UtillSystem,
  //     },
  //   });
  // }
}

export default UtillSystem;
