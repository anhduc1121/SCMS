import axios from "axios";
// import jwtDecode from 'jwt-decode';
import { decodeCredential } from "vue3-google-login";
import AuthService from '@/script/AuthService.js';

const API_URL = "http://localhost:7252/api/";
const auth = new AuthService();

class ApiService {
  constructor() {
    this.apiClient = axios.create({
      baseURL: API_URL,
      headers: {
        "Content-Type": "application/json",
        'Accept': 'text/json'
      },
    });
  }

  saveToken(token) {
    localStorage.setItem("scms_token", token);
  }

  saveUserSSO(token) {
    localStorage.setItem("scms_user_sso", token);
  }
  saveUserFeid(token) {
    localStorage.setItem("scms_user_feid", token);
  }
  saveUserFEID(token) {
    localStorage.setItem("scms_user_feid", token);
  }
  getUser() {
    const userData = {
      name: "",
      img: ""
    }
    if (localStorage.getItem("scms_user_sso")) {
      const user = localStorage.getItem("scms_user_sso");
      const decoded = decodeCredential(user);
      userData.name = decoded.email;
      userData.img = decoded.picture;
    } else if (localStorage.getItem("scms_user_feid")) {
      const user = localStorage.getItem("scms_user_feid");
      const decoded = decodeCredential(user);
      userData.name = decoded.email;
      userData.img = decoded.picture;
    }

    return userData;
  }

   decodeToken() {
    const token = this.getToken();

    if (token != null) {
      const decodedToken = decodeCredential(token);
      
      return decodedToken;
    } else {
      return null;
    }
  }

  getToken() {
    if (localStorage.getItem("scms_token")) {
      
      return localStorage.getItem("scms_token");
    }
    if (localStorage.getItem("scms_user_feid")) {
      
      return localStorage.getItem("scms_user_feid");
    }
    return "";
  }
  async removeToken() {
    localStorage.removeItem("scms_token");
    if (localStorage.getItem("scms_user_sso")) {
      localStorage.removeItem("scms_user_sso");
      location.reload();
    } else if (localStorage.getItem("scms_user_feid")) {
      await auth.logout();
      localStorage.removeItem("scms_user_feid");
    }else{
      location.reload();
    }
    // await auth.logout();
    // location.reload();
  }

  setHeader(name, value) {
    this.apiClient.defaults.headers.common[name] = value;
  }

  getDefaultHeaders() {
    const token = this.getToken();
    if (token && token !== "") {
      return {
        "Content-Type": "application/json",
        Accept: "text/json",
        Authorization: `Bearer ${token}`,
      };
    } else {
      return {
        "Content-Type": "application/json",
        Accept: "text/json",
      };
    }
  }

  getDefaultHeadersImg() {
    const token = this.getToken();
    if (token && token !== "") {
      return {
        "Content-Type": "multipart/form-data",
        Accept: "text/json",
        Authorization: `Bearer ${token}`,
      };
    } else {
      return {
        "Content-Type": "multipart/form-data",
        Accept: "text/json",
      };
    }
  }

  removeHeader(name) {
    delete this.apiClient.defaults.headers.common[name];
  }

  get(path, config = {}) {
    return this.apiClient.get(path, {
      ...config,
      headers: this.getDefaultHeaders(),
    });
  }

  post(path, data, config = {}) {
    return this.apiClient.post(path, data, {
      ...config,
      headers: this.getDefaultHeaders(),
    });
  }

  postImg(path, data, config = {}) {
    return this.apiClient.post(path, data, {
      ...config,
      headers: this.getDefaultHeadersImg(),
    });
  }

  put(path, data, config = {}) {
    return this.apiClient.put(path, data, {
      ...config,
      headers: this.getDefaultHeaders(),
    });
  }

  putImg(path, data, config = {}) {
    return this.apiClient.put(path, data, {
      ...config,
      headers: this.getDefaultHeadersImg(),
    });
  }

  delete(path, config = {}) {
    return this.apiClient.delete(path, {
      ...config,
      headers: this.getDefaultHeaders(),
    });
  }
}

export default ApiService;
