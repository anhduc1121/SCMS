<template>
  <div
    id="page-loading-core"
    class="page-loading-core"
    :class="{ 'loading-core-fullscreen': isFullScreen }"
  >
    <div class="loading-icon rotating">
        <img src="@/assets/svg-icon/loading.svg" alt="" />
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "page-loading-core",
  props: {
    // nếu truyền vào true thì loadding sẽ full cả màn hình, false thì chỉ trên phạm vi đặt thẻ loadding thôi
    // Mặc định là không fullscreen (nếu không truền vào)
    isFullScreen: Boolean,
  },
  components: {},
  data() {
    return {};
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/core/components/loading";
</style>
