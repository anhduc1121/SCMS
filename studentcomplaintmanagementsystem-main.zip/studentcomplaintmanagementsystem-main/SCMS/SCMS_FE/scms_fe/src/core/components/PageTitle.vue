<template>
  <div id="page-title" class="page-title">
    <h1>{{ $t(getPageTitle())  }}</h1>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { useRoute } from "vue-router";

export default defineComponent({
  name: "page-title",
  components: {},
  setup() {
    const route = useRoute();
    const getPageTitle = () => {
      return route.meta.title ?? "";
    };

    return {
      getPageTitle,
    };
  },
});
</script>
