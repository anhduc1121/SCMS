<template>
  <div id="page-pagination" class="page-pagination">
    <vue-awesome-paginate
      :total-items="pageData.totalItem"
      :items-per-page="pageData.itemPerPage"
      :max-pages-shown="pageData.maxPageShow"
      prev-button-content="< Previous"
      next-button-content="Next >"
      v-model="pageData.currentPage"
      :on-click="onClickHandler"
    />
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "page-pagination",
  props: {
    dataInput: Object,
  },
  components: {},
  data() {
    return {
      pageData: {},
    };
  },
  watch: {
    dataInput(newVal) {
      // this.pageData = { ...newVal };
      this.pageData = JSON.parse(JSON.stringify(newVal));
    },
  },
  created() {
    // this.pageData = { ...this.dataInput };
    this.pageData = JSON.parse(JSON.stringify(this.dataInput));
  },
  methods: {
    onClickHandler(page) {
      this.$emit("change-page", { page: page });
    },
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/core/components/page-pagination";
</style>
