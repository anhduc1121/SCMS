export const FILE_SIZE_LIMIT = 1024 * 1024;
export const TOTAL_FILE_SIZE_LIMIT = 50 * 1024 * 1024;

export const SORT = {
    A_Z: 0,
    Z_A: 1,
    A_A: 2
}
