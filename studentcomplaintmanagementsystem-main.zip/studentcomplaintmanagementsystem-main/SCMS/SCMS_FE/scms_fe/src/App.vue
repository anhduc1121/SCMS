<template>
  <div v-if="isLoggedIn">
    <RouterView />
  </div>
  <div v-else class="have-loading">
    <LoginSystem @reloadParent="checkLoggedInStatus" @reloadLogin="loginFeid"></LoginSystem>
    <Loading v-if="loadingSections.section1" :isFullScreen="true" />
  </div>
</template>

<script>
import { RouterView } from "vue-router";
import ApiService from "@/script/api.service";
import LoginSystem from "./views/common/LoginSystem.vue";
import UserApiService from "@/script/services/UserApiService";
import Loading from "@/core/components/Loading.vue";

export default {
  name: "App",
  data() {
    return {
      apiService: new ApiService(),
      isLoggedIn: false,
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
    };
  },
  created() {
    this.checkLoggedInStatus();
  },
  methods: {
    async checkLoggedInStatus() {
      this.isLoggedIn = this.apiService.getToken() != "";
    },

    async loginFeid() {
      this.loadingSections.section1 = true;
      while (this.loadingSections.section1) {
        const res = await UserApiService.loginFeidSystem();
        if (res != null) {
          this.apiService.saveToken(res.data.accessToken);
          console.log(res);
          this.isLoggedIn = true;
          this.loadingSections.section1 = false;
          localStorage.removeItem("scms_check_feid");
          return;
        }
        await new Promise(resolve => setTimeout(resolve, 3000));
      }
    },
  },
  components: { RouterView, LoginSystem, Loading },
};
</script>

<style lang="scss">
@import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css");
@import url("https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Wix+Madefor+Text:ital,wght@0,400..800;1,400..800&display=swap");
@import "assets/scss/style";
</style>
