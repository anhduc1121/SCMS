<template>
  <div
    id="category-list-component"
    class="category-list-component have-loading"
  >
    <div class="category-list">
      <div class="data-header">
        <div v-if="config.isShowSelect" class="select-item h-cell">
          <span>{{ $t("category.select") }}</span>
        </div>
        <div :class="{ 'have-select': config.isShowSelect }" class="stt h-cell">
          <span>{{ $t("category.no") }}</span>
        </div>
        <div class="path h-cell"></div>
        <div class="name h-cell">
          <span>{{ $t("category.name") }}</span>
        </div>
        <div class="description h-cell">
          <span>{{ $t("category.description") }}</span>
        </div>
        <div class="description h-cell">
          <span>{{ $t("category.emailReponsible") }} </span>
        </div>
        <div v-if="config.isShowAction" class="actions h-cell"></div>
      </div>
      <template v-for="(item, index) in data" :key="index">
        <div
          @click="viewCategoryChild(item)"
          class="data-item"
          :class="{
            'row-color': index % 2 != 0,
            'row-child-viewed': item.isShow,
            'have-child': item.isHaveChild,
          }"
        >
          <!--Select-->
          <div
            v-if="config.isShowSelect"
            :class="{
              'd-child': item.stt == null,
              'end-child': item.isEnd,
            }"
            class="select-item d-cell"
            @click="toogleSelect($event)"
          >
            <input
              type="radio"
              name="select-category"
              :checked="item.categoryTicketId == this.selectedDataId"
              @change="tempSelectCategory(item.categoryTicketId)"
            />
          </div>
          <!--Stt-->
          <div
            :class="{
              'have-select': config.isShowSelect,
              'd-child': item.stt == null,
              'end-child': item.isEnd,
            }"
            class="stt d-cell"
          >
            {{ item.stt }}
          </div>
          <!--icon-->
          <div
            :class="{
              'end-child': item.isEnd,
            }"
            class="path d-cell d-cell-path"
          >
            <div v-if="item.isHaveChild" class="icon-child">
              <i v-if="!item.isShow" class="fa-solid fa-angle-down"></i>
              <i v-if="item.isShow" class="fa-solid fa-angle-up"></i>
            </div>
          </div>
          <!--Name-->
          <div
            :class="{
              'end-child': item.isEnd,
            }"
            class="name d-cell d-text"
          >
            {{ item.categoryName }}
          </div>
          <!--Description-->
          <div
            :class="{
              'end-child': item.isEnd,
            }"
            class="description d-cell d-text"
          >
            {{ item.description }}
          </div>
          <div
            :class="{
              'end-child': item.isEnd,
            }"
            class="description d-cell d-text"
          >
            {{ item.responsiblePersonEmail }}
          </div>
          <!--Action-->
          <div
            v-if="config.isShowAction"
            :class="{
              'd-child-end': item.stt == null,
              'end-child': item.isEnd,
            }"
            class="actions d-cell"
          >
            <button class="edit" @click="addOrEditCategory(item, true, $event)">
              <i class="fa-solid fa-plus"></i>
            </button>
            <button
              class="edit"
              @click="addOrEditCategory(item, false, $event)"
            >
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="delete" @click="onDeleteCategory(item, $event)">
              <i class="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      </template>
    </div>
    <Loading v-if="loadingSections.section1" :isFullScreen="false" />
  </div>

  <b-modal
    v-model="isShowConfirmModal"
    centered
    hideFooter="true"
    :title="$t('confirm.confirm')"
    class="confirm-modal"
  >
    <Confirm
      v-if="isShowConfirmModal"
      :config="confirmConfig"
      @submit="submitForm()"
      @cancel="closeConfirmModal()"
    />
  </b-modal>
</template>

<script>
import { defineComponent } from "vue";
// import { CHILL_CATEGORY_DATA_MOCK } from "@/mock/category-data.mock.js";
import CategoryAPIService from "@/script/services/CategoryAPIService";
import Loading from "@/core/components/Loading.vue";
import Confirm from "@/modal/common/Confirm.vue";
import { BModal } from "bootstrap-vue-next";
import { TYPE } from "vue-toastification";
import { useToast } from "vue-toastification";

export default defineComponent({
  name: "category-list-component",
  props: {
    dataList: Array,
    selectedDataId: String,
    config: Object,
    dataUpdate: Object,
    isAdd: Boolean,
  },
  components: {
    Loading,
    BModal,
    Confirm,
  },
  data() {
    return {
      data: [],
      selectedId: null,
      selectedItem: null,
      isShowConfirmModal: false,
      //Lưu ý, các funcs call bất đồng bộ cùng 1 thời điểm thì không được dùng chung 1 section loading
      loadingSections: {
        section1: false,
        // Thêm các section khác nếu cần | Trường  hợp màn hình cần loadding nhiều phần
      },
      confirmConfig: {
        content: this.$t("category.messConfirmDelete"),
      },
      isAddItem: true,
      dataUpdateItem: {
        categoryTicketId: "",
        categoryName: "",
        status: true,
        fullPath: " ",
        description: "",
        createDate: "",
        modifyUpdate: null,
        responseTime: 0,
        responseHours: 0,
        accountIdCreate: "",
        categoryTicketParentId: "",
        isDelete: false,
        responsiblePersonEmail: "a",
        stt: null,
        childLength: null,
        isHaveChild: false,
        isShow: false,
        isEnd: false,
        parentIds: [],
      },
    };
  },
  watch: {
    isAdd(newVal){
      console.log('s', 'test')
      if(newVal != null){
        this.getCategory()
      }
      
    }
    // dataList(newVal) {
    // //this.data = [...newVal];
    //   this.data = JSON.parse(JSON.stringify(newVal));
    // },
    // selectedItem(newData) {
    //   console.log(newData, "test Watch");
    // },
  },
  async created() {
    this.toast = useToast();

    if (this.dataUpdate != null) {
      this.dataUpdateItem = this.dataUpdate;
      this.updateCategorys(this.dataUpdateItem);
    } else {
      //this.data = [...this.dataList];
      this.data = JSON.parse(JSON.stringify(this.dataList));
      this.selectedId = this.selectedDataId;
      this.getCategory();
    }
  },
  updated() {
    // console.log("updateDate");
    if (this.dataUpdate != null) {
      this.isAddItem = this.isAdd;
      this.dataUpdateItem = this.dataUpdate;
      this.updateCategorys(this.dataUpdateItem);
    }
  },
  methods: {
    async onDeleteCategory(item, event) {
      event.stopPropagation();
      // this.isShowConfirmModal = true;
      const res = CategoryAPIService.deleteCategory(item.categoryTicketId);
      if (res != null) {
        this.toast( this.$t("toast.Common.mess4"), {
          type: TYPE.SUCCESS, // or "success", "error", "default", "info" and "warning"
        });

        const index = this.data.findIndex(
          (x) => x.categoryTicketId === item.categoryTicketId
        );

        if (this.data[index] != null) {
          this.data = this.data.filter(
            (x) =>
             (x.fullPath && !x.fullPath.includes(this.data[index].categoryTicketId)) || x.fullPath == null
          );

          if (index != -1) {
            this.data.splice(index, 1);
          }
        }
      }
      console.log(item);
    },

    closeConfirmModal() {
      this.isShowConfirmModal = false;
    },

    submitForm() {},

    async getCategory() {
      this.loadingSections.section1 = true;
      if (this.selectedDataId != null) {
        const res = await CategoryAPIService.getCategorysParent(
          "",
          this.selectedDataId
        );
        if (res != null) {
          this.data = res;
          this.loadingSections.section1 = false;
        }
      } else {
        const res = await CategoryAPIService.getCategorysParent("", "");
        if (res != null) {
          this.data = res;
          this.loadingSections.section1 = false;
        }
      }
    },
    toogleSelect(event) {
      event.stopPropagation();
    },
    tempSelectCategory(item) {
      this.$emit("select-category", { item: item });
    },

    updateCategorys(item) {
      if (this.isAddItem) {
        // Add new not sub-category
        if (item != null && item.categoryTicketParentId == null) {
          const list = this.data.filter(
            (item) => item.categoryTicketParentId == null
          );
          item.stt = list.length + 1;

          Array.prototype.splice.apply(
            this.data,
            [this.data.length + 1, 0].concat(item)
          );

          return;
        }

        // Add new sub-category
        const index = this.data.findIndex(
          (x) => x.categoryTicketId === item.categoryTicketParentId
        );

        if (this.data[index] != null) {
          if (this.data[index].isShow) {
            const list = this.data.filter(
              (x) =>
                x.fullPath != null && x.fullPath == item.categoryTicketParentId
            );

            item.stt = this.data[index].stt + "." + (list.length + 1);

            const listSubAll = this.data.filter(
              (x) =>
                x.fullPath != null &&
                x.fullPath.includes(item.categoryTicketParentId)
            );

            Array.prototype.splice.apply(
              this.data,
              [
                index +
                  (listSubAll.length == 0 ? 0 : listSubAll.length + 1) +
                  1,
                0,
              ].concat(item)
            );
          } else {
            this.data[index].isHaveChild = true;
          }
        }
      } else {
        const index = this.data.findIndex(
          (x) => x.categoryTicketId === item.categoryTicketId
        );

        if (this.data[index] != null) {
          this.data[index] = item;
        }

        // console.log(this.data, "data111111");
        // console.log(item, "2222222222");
        // console.log(index, "3333");
      }

      this.$emit("done-reload-update", null);
    },
    async viewCategoryChild(item) {
      if (!item.isHaveChild) return;
      this.loadingSections.section1 = true;
      const index = this.data.indexOf(item);
      if (!item.isShow) {
        const res = await CategoryAPIService.getCategorysParent(
          item.categoryTicketId,
          ""
        );
        if (res != null) {
          const childData = res;

          childData.forEach((e, index) => {
            e.stt = item.stt + "." + (index + 1);
            e.parentIds = JSON.parse(JSON.stringify(item.parentIds));
            e.parentIds.push(item.categoryTicketId);

            if (index == childData.length - 1) {
              e.isEnd = true;
            }
          });
          Array.prototype.splice.apply(
            this.data,
            [index + 1, 0].concat(childData)
          );
          item.childLength = childData.length;
        }
        console.log(this.data);
      } else {
        const childrenNeedToClose = this.data.filter(function (o) {
          return o.parentIds.some(function (i) {
            return i === item.categoryTicketId;
          });
        });
        this.data.splice(index + 1, childrenNeedToClose.length);
      }
      item.isShow = !item.isShow;
      this.loadingSections.section1 = false;
    },

    //Begin:: Actions
    addOrEditCategory(item, isAdd, event) {
      event.stopPropagation();
      const data = {
        title: `[${item.categoryName}] - ${
          isAdd == true ? this.$t("label.addNewCategory") : this.$t("label.edit")
        }`,
        item: { ...item },
        isAdd: isAdd,
      };
      this.$emit("add-or-edit", data);
    },
    //End:: Actions
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/components/category-list.scss";
</style>
