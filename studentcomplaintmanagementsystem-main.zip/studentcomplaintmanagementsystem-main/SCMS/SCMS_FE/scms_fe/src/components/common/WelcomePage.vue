<template>
  <div class="main">
    <div class="main-body">
      <h1 class="welcome">
        {{ $t("mess.messWelcomePage1") }} {{ user.email }}
        {{ $t("mess.messWelcomePage2") }}
      </h1>
      <div class="logo-div">
        <img
          class="logo"
          src="../../assets/Pictures/DH_FPT.jpg"
          alt="Logo-FPT"
        />
      </div>
    </div>
    <!-- <div class="main-footer">
      <div class="contact">Thông tin liên hệ</div>
    </div> -->
  </div>
</template>
  
  <script>
import UserApiService from "@/script/services/UserApiService";
export default {
  name: "WelcomePage",
  data() {
    return {
      user: {
        firstName: "",
        lastName: "",
        picture: "",
        email: "",
        phone: "",
        address: "",
        createDate: "",
        campus: "",
        education: "",
        department: "",
        role: [],
      },
    };
  },
  async created() {
    this.lang = this.$i18n.locale;
    const user = await UserApiService.getInforUser();
    if (user != null) {
      this.user = user.data;
    }
  },
};
</script>
  
  <style>
.main {
  /* background-color: blue; */
  width: 100%;
  height: 72vh;
  border: 1px solid rgba(0, 0, 0, 0.3);
  position: relative;
}
.main-body {
  width: 98%;
  height: 70%;
  position: absolute;
  top: 1%;
  left: 1%;
  /* border: 1px solid rgba(0, 0, 0, 0.3); */
}
.main-footer {
  width: 98%;
  height: 27%;
  position: absolute;
  bottom: 1%;
  left: 1%;
  /* border: 1px solid rgba(0, 0, 0, 0.3); */
}
.welcome {
  position: absolute;
  top: 30%;
  left: 34%;
}
.contact {
  position: absolute;
  top: 40%;
  left: 46%;
}
.logo-div {
  width: 100%;
  position: absolute;
  top: 50%;
}
.logo {
  height: 15vh;
  vertical-align: middle;
}
</style>
  