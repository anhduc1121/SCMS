<template>
  <div class="container">
    <table v-if="categories.length" class="table table-bordered">
      <!-- <thead>
          <tr>
            <th>Category</th>
          </tr>
        </thead> -->
      <tbody>
        <tr v-for="(category, index) in categories" :key="index">
          <td>
            <a
              data-bs-toggle="collapse"
              :href="'#row' + (index + 1)"
              role="button"
              aria-expanded="false"
            >
              {{ category.name }}
            </a>
            <div class="collapse" :id="'row' + (index + 1)">
              <table class="child-table table table-bordered">
                <tbody>
                  <tr
                    v-for="(child, childIndex) in category.children"
                    :key="childIndex"
                  >
                    <td>
                      <a href="#">{{ child }}</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div v-else>
      <p>{{$t('span.loadingCategory')}}</p>
    </div>
  </div>
</template>
  
  <script>
export default {
  data() {
    return {
      categories: [],
    };
  },
  mounted() {
    fetch("http://localhost:3000/categories")
      .then((res) => res.json())
      .then((data) => (this.categories = data))
      .catch((err) => console.log(err.message));
  },
};
</script>
  
  <style scoped>
/* You can customize the table styling using your own CSS here */
a {
  text-decoration: none;
}
.child-table {
  font-size: 12px;
}
/* .child-table {
  position: absolute;
  top: 0;
  left: 100%;
  z-index: 1;
  display: none;
  min-width: 150px;
}

.table-hover tr:hover .child-table {
  display: table;
} */
</style>
  