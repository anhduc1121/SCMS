<template>
  <div id="faq-item" class="faq-item">
    <div class="faq-header" @click="isView = !isView">
      <span>Token hết hiệu lực</span>
      <div class="icon">
        <i v-if="!isView" class="fa-solid fa-angle-down"></i>
        <i v-if="isView" class="fa-solid fa-angle-up"></i>
      </div>
    </div>
    <div class="faq-content" v-if="isView">
      <div>
        Khi bạn gặp thông báo lỗi chữ ký số hết hạn, điều này có nghĩa là chữ ký số bạn đang sử dụng đã hết hạn và không còn hiệu lực. Mỗi chữ ký số thường được cấp phép sử dụng trong một khoảng thời gian nhất định, sau đó nó sẽ hết hạn và không thể sử dụng để ký tài liệu hay xác thực thông tin nữa.
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "faq-item",
  components: {},
  data() {
    return {
      isView: false,
    };
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/components/help/user-help-faq-item.scss";
</style>
