<template>
  <div id="user-help-left-view" class="user-help-left-view">
    <div class="l-menu">
      <div
        class="l-menu-item"
        :class="{ 'l-menu-item-active': menuActive == 1 }"
        @click="selectMenu(1)"
      >
        <span>Video hướng dẫn (0)</span>
      </div>
      <div
        class="l-menu-item"
        :class="{ 'l-menu-item-active': menuActive == 2 }"
        @click="selectMenu(2)"
      >
        <span>Tài liệu hướng dẫn (0)</span>
      </div>
      <div
        class="l-menu-item"
        :class="{ 'l-menu-item-active': menuActive == 3 }"
        @click="selectMenu(3)"
      >
        <span>Lịch sử phiên bản (Version 1.0)</span>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "user-help-left-view",
  components: {},
  props: { menuActive: Number },
  data() {
    return {};
  },
  methods: {
    selectMenu(id) {
        this.$emit('select', id);
    }
  },
});
</script>

<style lang="scss">
@import "@/assets/scss/components/help/user-help-left-view.scss";
</style>
