﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface IFunctionActionAPIRepository : IGennericRepository<TblFunctionActionApi>
    {
        public TblFunctionActionApi GetTblFunctionActionApiById(Guid? id);
        public TblFunctionActionApi GetCheckRoleFunction(string controller, string action, Guid? userID);

        public TblFunctionActionApi GetTblFunctionActionApiByControllerAndAction(string controller, string action);
        public List<TblFunctionActionApi> GetAllFunctionActionApi();

        public List<TblFunctionActionApi> GetFunctionActionApiByIdRole(Guid roleId);
    }
}
