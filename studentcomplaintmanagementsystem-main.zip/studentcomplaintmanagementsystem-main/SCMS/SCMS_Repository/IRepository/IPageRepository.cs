﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface IPageRepository : IGennericRepository<TblPage>
    {
        public (int, List<TblPage>) GetAll(string? PageName, int? pageIndex = 1, int? pageSize = 5, int? sortCreateDate = 0);
        public TblPage DeletePage(TblPage page);
        public TblPage GetPageById(Guid id);
    }
}
