﻿using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface ITicketFeedbackRepository
    {
        public string AddFeedback(TicketFeedbackRequestAddVM ticket);
        public (int, List<TicketFeedbackResponseGetDataVM>) GetAll(TicketFeedbackRequestGetDataVM ticket);
    }
}
