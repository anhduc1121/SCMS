﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface ITagTicketRepository : IGennericRepository<TblTagTicket>
    {
        public TblTagTicket GetTagTicketByTagId(Guid tagticketId);
        public TblTagTicket UpdateUserTag(Guid tagTicketId, string status);
        public List<TblTagTicket> ViewUserTag(Guid ticketId);
        public Boolean IsUserTagExist(Guid ticketId, string gmail);
    }
}
