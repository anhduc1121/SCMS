﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface IAccountRepository : IGennericRepository<TblAccount>
    {
        public TblAccount GetAccountByEmaill(string email);
        public TblAccount GetAccountByEmaillAndCampusAndEducation(string email, Guid campus, Guid education);

        public TblAccount GetAccount(string email);
        public List<TblAccount> GetAccountByName(string name);
        public List<TblAccount> GetStaff(Guid? roleId);
        public TblAccount GetAccountById(Guid? id);
        public List<TblAccount> GetListUserJoinTicket(Guid ticketId);
        public (int, List<ExEmployee>) GetEmployees(string searchEmail, int sortDate, int pageIndex, int pageSize);
        bool UpdateEmployee(ExEmployee employee_update, List<TblRole> responRoles);
        public List<ExStatusAccount> GetAllStatusAccount();
        public TblAccount GetViewAuthority(Guid pageCrudId, Guid accountId);
        public TblAccount GetPageAuthority(string name, Guid userId);
        public bool DeleteAccountByAccountId(Guid accountId);
        public bool AddEmployee(ExEmployee exEmployee, List<TblRole> responRoles);
        public List<TblAccount> GetEmailByRole(Guid userID, string? gmail);
        public AccountInforVM GetInforUser(Guid userID);
    }
}
