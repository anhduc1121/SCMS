﻿using SCMS_Models.Models;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface IDepartmentRepository
    {
        public TblDepartment CreateDepartment(DepartmentVM? departmentVM);
        public TblDepartment DeleteDepartment(Guid departmentId);
        public List<TblDepartment> GetAllDepartment();
        public TblDepartment UpdateDepartment(DepartmentVM? departmentVM);
    }
}
