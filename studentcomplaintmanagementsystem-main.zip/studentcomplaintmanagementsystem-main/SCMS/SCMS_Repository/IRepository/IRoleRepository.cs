﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface IRoleRepository : IGennericRepository<TblRole>
    {
        public TblRole CreateRole(string RoleName, List<Guid> FunctionIds);

        public List<TblRole> GetRoleByRoleFeid(Guid idRoleFeid);

        public List<TblRole> GetRolesByRoleIds(List<Guid> idRoles);

        public List<TblRole> GetRoles();
        public (int, List<TblRole>) GetRolesByCondition(string RoleName, int? pageIndex = 1, int? pageSize = 5, int? sortCreateDate = 0);
        public TblRole UpdateRole(Guid RoleId, string RoleName, List<Guid> functionIds);
        public TblRole DeleteRole(Guid RoleId);
        public List<TblRole> GetRolesByAccountId(Guid accountId);
        public List<TblAccountRole> GetListAccountRoleByAccountId(Guid accountId);
    }
}
