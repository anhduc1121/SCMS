﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface ITicketReportRepository : IGennericRepository<TblTicketReport>
    {
        public ReportForEachAccountVM ReportForEachAccount(Guid userID, DateTime fromDate, DateTime toDate);
        public List<ReportForEachAccountVM> DailyReport(DateTime fromDate, DateTime toDate);
        public List<RatingReportVM> RatingReport(DateTime fromDate, DateTime toDate);
        public List<ReportTicketReportVM> ReportTicketReport(DateTime fromDate, DateTime toDate);
        public ReportForEachAccountVM SynthesisReport(DateTime fromDate, DateTime toDate);
        public List<ReportForEachAccount2VM> DailyReport2(DateTime fromDate, DateTime toDate);
        public List<ReportForEachCategoryVM> ReportForEachAccount2(Guid userID, DateTime fromDate, DateTime toDate);
        public List<ReportForEachCategoryVM> SynthesisReport2(DateTime fromDate, DateTime toDate);
        public List<TicketReportVM> ViewReport(Guid? categoryId, string? titleTicket, Guid? studentId, string? status, DateTime? createDate, int sortDate, int sortTitle, int pageIndex, int pageSize);
        public List<ViewStaffWithStaffOtherVM> ViewStaffWithStaffOther(Guid? studentId, Guid? staffId, Guid? staffOtherId, Guid? cateId, string? title,
            DateTime? createDate, string? status, int sortTitle, int sortStatus, int sortDate, int pageIndex, int pageSize);
    }
}
