﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface ITicketDepartmentCommentsImportRepository : IGennericRepository<TblTicketDepartmentCommentsImport>
    {
        public List<TblTicketDepartmentCommentsImport> GetAllByTicketDepartmentId(Guid? ticketDepartmentId);
    }
}
