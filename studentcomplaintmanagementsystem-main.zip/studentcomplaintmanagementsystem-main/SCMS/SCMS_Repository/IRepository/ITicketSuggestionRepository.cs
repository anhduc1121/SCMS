﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface ITicketSuggestionRepository : IGennericRepository<TblTicketSuggestion>
    {
        public TblTicketSuggestion CreateTicketSuggestion(string description, Guid categoryTicketId, Guid accountCreatorId);
        public TblTicketSuggestion DeleteTicketSuggestion(Guid ticketSuggestionId);
        public (int, List<TblTicketSuggestion>) GetAllTicketSuggestion(string? question, Guid? cateId, DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortQuestion = 0, int sortDate = 0);
        public TblTicketSuggestion GetTblTicketSuggestionByID(Guid? id);
        public List<TblTicketSuggestion> GetTblTicketSuggestionByIDCaterory(Guid? id);
        public TblTicketSuggestion UpdateTicketSuggestion(TblTicketSuggestion ticketSuggestionVM);
    }
}
