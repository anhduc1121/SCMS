﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface INotificationRepository : IGennericRepository<TblNotification>
    {
        public TblNotification AddNotification(NotificationVM notification);
        public TblNotification MarkAsRead(Guid notificationId);
        public List<TblNotification> MarkAllAsRead(Guid accountId);
        public (int, List<TblNotification>) ViewNotification(Guid accountId, string? statusView, int pageIndex = 1,
            int pageSize = 5, int sortDate = 0, int sortTitle = 0);
    }
}
