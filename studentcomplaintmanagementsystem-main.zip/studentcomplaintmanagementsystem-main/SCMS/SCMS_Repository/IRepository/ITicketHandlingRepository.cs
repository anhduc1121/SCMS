﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface ITicketHandlingRepository : IGennericRepository<TblTicketHandling>
    {
        public List<TblTicketHandling> GetParentTicketHandlings(Guid ticketId);
        public List<TblTicketHandling> GetTicketHandlingsByTicketId(Guid ticketId);
        public List<TblTicketHandling> GetChildTicketHandlings(Guid ticketId);
        public string GetColorForStatus(Guid statusId);
        public void UpdateAccpect(Guid ticketHandlingsId, bool isAccpect);
        public List<TblTicketHandling> GetAllByTicketId(Guid ticketId);
    }
}
