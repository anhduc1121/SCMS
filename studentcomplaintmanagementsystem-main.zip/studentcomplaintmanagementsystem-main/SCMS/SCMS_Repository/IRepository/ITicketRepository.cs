﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface ITicketRepository : IGennericRepository<TblTicket>
    {
        public TblTicket SendTicket(TicketVM ticket);
        public TblTicket UpdateCategorysOfTicketId(Guid ticketId, Guid categoryTicketId);
        public TblPinTicket CreatePinTicket(Guid ticketId, Guid accountId);
        public bool DeletePinTicket(Guid pinPinTicketId, Guid accountId);
        public TblTicket EndTicket(Guid ticketId, string positive, string negative, string rate);
        public TblTicket GetTicketByTicketId(Guid ticketId, Guid? userId);
        public (int, List<TblTicket>) GetAllTicket(Guid userID, Guid? cateId, Guid? statusTicketId,
                  Guid? accountIdCreate, Guid? accountIDBehaveCreate, Guid? tagAccountId,
                  string? accountGmaillCreate, string? accountGmaillBehaveCreate, string? accountGmaillTag, string? status, string? title,
                 DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortDate = 0, int sortTitle = 1, int sortStatusTicket = 0, bool isPin = false);

        public List<TblTicket> GetTicketByAccountId(string? status, string? title, Guid? cateId, DateTime? createDate, Guid accountId, int pageIndex = 1, int pageSize = 5, int sortDate = 0);
        public List<TblStatusTicket> ViewStatusTicket();
        public List<TblAccount> GetAccountTagTicket(Guid ticketId);
        public List<TblAccount> GetAccountTagTicketDoingAndHaviingDone(Guid ticketId);
        public TblAccount GetAccountTagTicketAccept(Guid ticketId);
        public TblTicket GetListUserByTicket(Guid ticketId);
    }
}
