﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface ICategoryTicketRepository : IGennericRepository<TblCategoryTicket>
    {
        public List<TblCategoryTicket> GetParentCategory();
        public List<TblCategoryTicket> GetCategoryByPath(List<Guid> categoryIds);
        public List<TblCategoryTicket> GetCategorysByIdParentCategory(Guid? IdParentCategory);
        public List<TblCategoryTicket> GetAllCategorysByIdParentCategory(Guid? IdParentCategory);
        public TblCategoryTicket DeteleCategoryTicket(Guid categoryTicketId);
        public TblCategoryTicket GetCategorysByIdCategory(Guid? categoryId);
        public string GetCategoryName(Guid categoryId);
        public TblCategoryTicket UpdateCategoryTicket(TblCategoryTicket category);
        public TblCategoryTicket CreateCategoryTicket(TblCategoryTicket categoryTicketVM);


    }
}
