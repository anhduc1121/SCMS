﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{

    public interface ITicketCommentRepository : IGennericRepository<TblTicketComment>
    {
        public TblAccount GetAccountInfor(Guid ticketCommentId);
        public List<TblTicketAttachment> GetCommentAttachmentById(Guid ticketCommentId);
        public List<TblTicketComment> ListCommentsByTicketId(Guid ticketId);
        
    }
}
