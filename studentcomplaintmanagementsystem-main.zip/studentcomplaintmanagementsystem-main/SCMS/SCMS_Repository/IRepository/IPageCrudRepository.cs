﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;

namespace SCMS_Repository.IRepository
{
    public interface IPageCrudRepository : IGennericRepository<TblPageCrud>
    {
        public List<TblPageCrud> GetAllByPage(Guid pageId);

        public TblPageCrud GetPageCrudById(Guid pageCrudId);

        public TblPageCrud DeletePageCrudById(Guid pageCrudId);
    }
}
