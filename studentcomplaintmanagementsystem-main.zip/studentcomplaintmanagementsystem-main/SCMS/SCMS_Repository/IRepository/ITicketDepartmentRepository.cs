﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using ViewModel;

namespace SCMS_Repository.IRepository
{
    public interface ITicketDepartmentRepository : IGennericRepository<TblTicketDepartment>
    {
        public TblDepartment CreateDepartment(DepartmentVM? departmentVM);
        public TblDepartment DeleteDepartment(Guid departmentId);
        public List<TblDepartment> GetAllDepartment();
        public TblDepartment UpdateDepartment(DepartmentVM? departmentVM);

        public TblTicketDepartment GetTicketDepartment(Guid ticketDepartmentsId);
        public List<TblTicketDepartment> GetTicketDepartmentsById(Guid ticketDepartmentsId);

        public (int, List<TblTicketDepartment>) GetTicketDepartments(string? title, Guid? CategoryTicketId, Guid? DepartmentId, string? accountGmaillStudent,
            string? accountGmaillStaff, string? accountGmaillOtherStaff, Guid? statusTicketId, DateTime? createDate, int sortTitle, int sortDate, int pageIndex, int pageSize, Guid? TicketId);

    }
}
