﻿using SCMS_Models.Models;
using SCMS_Repository.ImplementRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.IUnitOfWorks
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ScmsContext _context;
        private IAccountRepository _accountRepository;
        private ICampusRepository _campusRepository;
        private ICategoryTicketRepository _categoryTicketRepository;
        private IHistoryCategoryTicketRepository _historyCategoryTicketRepository;
        private INotificationEmailRepository _notificationEmailRepository;
        private INotificationRepository _notificationRepository;
        private IPinTicketRepository _pinTicketRepository;
        private IRoleRepository _roleRepository;
        private IStatusAccountRepository _statusAccountRepository;
        private IStatusTicketRepository _statusTicketRepository;
        private ITagTicketAttachmentRepository _tagTicketAttachmentRepository;
        private ITagTicketRepository _tagTicketRepository;
        private ITicketAttachmentRepository _ticketAttachmentRepository;
        private ITicketCommentRepository _ticketCommentRepository;
        private ITicketDepartmentAttachmentRepository _ticketDepartmentAttachmentRepository;
        private ITicketDepartmentCommentRepository _ticketDepartmentCommentRepository;
        private ITicketDepartmentCommentsImportRepository _ticketDepartmentCommentsImportRepository;
        private ITicketDepartmentRepository _ticketDepartmentRepository;
        private ITicketHandlingRepository _ticketHandlingRepository;
        private ITicketRepository _ticketRepository;
        private ITicketSuggestionRepository _ticketSuggestionRepository;
        private ITicketSuggestionDetailRepository _ticketSuggestionDetailRepository;
        private IFuntionGroupsRepository _roleFuntionRepository;
        private IFunctionActionAPIRepository _functionActionAPIRepository;
        private IPageRepository _pageRepository;
        private IFunctionAPIRepository _functionAPIRepository;
        private IEducationRepository _educationRepository;
        private ITicketReportRepository _ticketReportRepository;
        private ITicketReportAttachmentRepository _ticketReportAttachmentRepository;
        private IRoleFeidRepository _roleFeidRepository;
        private ISystemSettingRepository _systemSettingRepository;
        private IHistoryLoginRepository _historyLoginRepository;
        private IPageCrudRepository _pageCrudRepository;
        private ITicketFeedbackRepository _ticketFeedbackRepository;
        private IDepartmentRepository _departmentRepository;
        private IHistoryAccountTicketsOnlineRepository _historyAccountTicketsOnline;

        public UnitOfWork(ScmsContext context = null)
        {
            _context = context ?? new ScmsContext();
        }
        public IAccountRepository AccountRepository => _accountRepository ?? new AccountRepository(_context);

        public ICampusRepository CampusRepository => _campusRepository ?? new CampusRepository(_context);

        public ICategoryTicketRepository CategoryTicketRepository => _categoryTicketRepository ?? new CategoryTicketRepository(_context);

        public IHistoryCategoryTicketRepository HistoryCategoryTicketRepository => _historyCategoryTicketRepository ?? new HistoryCategoryTicketRepository(_context);

        public INotificationEmailRepository NotificationEmailRepository => _notificationEmailRepository ?? new NotificationEmailRepository(_context);

        public INotificationRepository NotificationRepository => _notificationRepository ?? new NotificationRepository(_context);

        public IPinTicketRepository PinTicketRepository => _pinTicketRepository ?? new PinTicketRepository(_context);

        public IRoleRepository RoleRepository => _roleRepository ?? new RoleRepository(_context);

        public IStatusAccountRepository StatusAccountRepository => _statusAccountRepository ?? new StatusAccountRepository(_context);

        public IStatusTicketRepository StatusTicketRepository => _statusTicketRepository ?? new StatusTicketRepository(_context);

        public ITagTicketAttachmentRepository TagTicketAttachmentRepository => _tagTicketAttachmentRepository ?? new TagTicketAttachmentRepository(_context);

        public ITagTicketRepository TagTicketRepository => _tagTicketRepository ?? new TagTicketRepository(_context);

        public ITicketAttachmentRepository TicketAttachmentRepository => _ticketAttachmentRepository ?? new TicketAttachmentRepository(_context);

        public ITicketCommentRepository TicketCommentRepository => _ticketCommentRepository ?? new TicketCommentRepository(_context);

        public ITicketDepartmentAttachmentRepository TicketDepartmentAttachmentRepository => _ticketDepartmentAttachmentRepository ?? new TicketDepartmentAttachmentRepository(_context);

        public ITicketDepartmentCommentRepository TicketDepartmentCommentRepository => _ticketDepartmentCommentRepository ?? new TicketDepartmentCommentRepository(_context);

        public ITicketDepartmentCommentsImportRepository TicketDepartmentCommentsImportRepository => _ticketDepartmentCommentsImportRepository ?? new TicketDepartmentCommentsImportRepository(_context);

        public ITicketDepartmentRepository TicketDepartmentRepository => _ticketDepartmentRepository ?? new TicketDepartmentRepository(_context);
        public ITicketHandlingRepository TicketHandlingRepository => _ticketHandlingRepository ?? new TicketHandlingRepository(_context);

        public ITicketRepository TicketRepository => _ticketRepository ?? new TicketRepository(_context);

        public ITicketSuggestionRepository TicketSuggestionRepository => _ticketSuggestionRepository ?? new TicketSuggestionRepository(_context);

        public ITicketSuggestionDetailRepository TicketSuggestionDetailRepository => _ticketSuggestionDetailRepository ?? new TicketSuggestionDetailRepository(_context);

        public IFuntionGroupsRepository RoleFuntionRepository => _roleFuntionRepository ?? new FuntionGroupsRepository(_context);

        public IFunctionActionAPIRepository FunctionActionAPIRepository => _functionActionAPIRepository ?? new FunctionActionAPIRepository(_context);

        public IPageRepository PageRepository => _pageRepository ?? new PageRepository(_context);

        public IFunctionAPIRepository FunctionAPIRepository => _functionAPIRepository ?? new FunctionAPIRepository(_context);
        public IEducationRepository EducationRepository => _educationRepository ?? new EducationRepository(_context);
        public ITicketReportRepository TicketReportRepository => _ticketReportRepository ?? new TicketReportRepository(_context);
        public ITicketReportAttachmentRepository TicketReportAttachmentRepository => _ticketReportAttachmentRepository ?? new TicketReportAttachmentRepository(_context);

        public IRoleFeidRepository RoleFeidRepository => _roleFeidRepository ?? new RoleFeidRepository(_context);

        public ISystemSettingRepository SystemSettingRepository => _systemSettingRepository ?? new SystemSettingRepository(_context);

        public IHistoryLoginRepository HistoryLoginRepository => _historyLoginRepository ?? new HistoryLoginRepository(_context);

        public IPageCrudRepository PageCrudRepository => _pageCrudRepository ?? new PageCrudRepository(_context);
        public ITicketFeedbackRepository TicketFeedbackRepository => _ticketFeedbackRepository ?? new TicketFeedbackRepository(_context);
        public IDepartmentRepository DepartmentRepository => _departmentRepository ?? new DepartmentRepository(_context);

        public IHistoryAccountTicketsOnlineRepository HistoryAccountTicketsOnline => _historyAccountTicketsOnline ?? new HistoryAccountTicketsOnlineRepository(_context);
    }
}