﻿using SCMS_Repository.IRepository;

namespace SCMS_Repository.IUnitOfWorks
{
    public interface IUnitOfWork
    {
        public IAccountRepository AccountRepository { get; }
        public ICampusRepository CampusRepository { get; }
        public ICategoryTicketRepository CategoryTicketRepository { get; }
        public IHistoryCategoryTicketRepository HistoryCategoryTicketRepository { get; }
        public INotificationEmailRepository NotificationEmailRepository { get; }
        public INotificationRepository NotificationRepository { get; }
        public IPinTicketRepository PinTicketRepository { get; }
        public IRoleRepository RoleRepository { get; }
        public IPageRepository PageRepository { get; }
        public IFunctionAPIRepository FunctionAPIRepository { get; }
        public IStatusAccountRepository StatusAccountRepository { get; }
        public IStatusTicketRepository StatusTicketRepository { get; }
        public ITagTicketAttachmentRepository TagTicketAttachmentRepository { get; }
        public ITagTicketRepository TagTicketRepository { get; }
        public ITicketAttachmentRepository TicketAttachmentRepository { get; }
        public ITicketCommentRepository TicketCommentRepository { get; }
        public ITicketDepartmentAttachmentRepository TicketDepartmentAttachmentRepository { get; }
        public ITicketDepartmentCommentRepository TicketDepartmentCommentRepository { get; }
        public ITicketDepartmentCommentsImportRepository TicketDepartmentCommentsImportRepository { get; }
        public ITicketDepartmentRepository TicketDepartmentRepository { get; }
        public ITicketHandlingRepository TicketHandlingRepository { get; }
        public ITicketRepository TicketRepository { get; }
        public ITicketSuggestionRepository TicketSuggestionRepository { get; }
        public ITicketSuggestionDetailRepository TicketSuggestionDetailRepository { get; }
        public IFuntionGroupsRepository RoleFuntionRepository { get; }
        public IFunctionActionAPIRepository FunctionActionAPIRepository { get; }
        public IEducationRepository EducationRepository { get; }
        public ITicketReportRepository TicketReportRepository { get; }
        public ITicketReportAttachmentRepository TicketReportAttachmentRepository { get; }
        public IRoleFeidRepository RoleFeidRepository { get; }
        public ISystemSettingRepository SystemSettingRepository { get; }
        public IHistoryLoginRepository HistoryLoginRepository { get; }
        public IPageCrudRepository PageCrudRepository { get; }
        public ITicketFeedbackRepository TicketFeedbackRepository { get; }
        public IDepartmentRepository DepartmentRepository { get; }
        public IHistoryAccountTicketsOnlineRepository HistoryAccountTicketsOnline { get; }
    }
}
