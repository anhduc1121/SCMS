﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;

namespace SCMS_Repository.GenericRepository
{
    public class GennericRepository<TEntity> : IGennericRepository<TEntity> where TEntity : class
    {
        protected readonly ScmsContext context;
        protected DbSet<TEntity> entities;

        public GennericRepository(ScmsContext context = null)
        {
            this.context = context ?? new ScmsContext();
            entities = this.context.Set<TEntity>();
        }
        /// <summary>
        /// Create entity 
        /// </summary>
        /// <param name="entity">the entity user want to create</param>
        public void Create(TEntity entity)
        {
            entities.Add(entity);
            context.SaveChanges();

        }

        public void CreateRange(TEntity entity)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Delete entity 
        /// </summary>
        /// <param name="entity">the entity user want to Delete</param>
        public void Delete(TEntity entity)
        {
            if (context.Entry(entity).State == EntityState.Detached)
            {
                entities.Attach(entity);
            }
            entities.Remove(entity);
            context.SaveChanges();
        }
        /// <summary>
        /// Delete entity  by id
        /// </summary>
        /// <param name="id">the id of entity user want to Delete</param>
        public void Delete(int id)
        {
            TEntity entityToDelete = entities.Find(id);
            Delete(entityToDelete);

        }
        /// <summary>
        /// Find entity by id
        /// </summary>
        /// <param name="id">the id of entity user want to find</param>
        /// <returns>TEntity</returns>
        public TEntity Find(int id)
        {
            try
            {
                return entities.Find(id);
            }
            catch (Exception)
            {

                return null;

            }

        }
        /// <summary>
        /// Get all entity user want
        /// </summary>
        /// <returns></returns>
        //public IEnumerable<TEntity> GetAll()
        //{
        //    return entities;
        //}

        /// <summary>
        /// Dùng inlcue các bảng con
        /// </summary>
        /// <param name="includes"></param>
        /// <returns></returns>
        public IEnumerable<TEntity> GetAll(params Expression<Func<TEntity, object>>[] includes)
        {
            IQueryable<TEntity> query = entities;

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            return query.ToList();
        }

        /// <summary>
        /// Update entity 
        /// </summary>
        /// <param name="entity">the entity user want to update</param>
        public void Update(TEntity entity)
        {
            entities.Attach(entity);
            context.Entry(entity).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void UpdateRange(TEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}
