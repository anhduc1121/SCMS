﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCMS_Repository.Helpers
{
    public class ApiMessage
    {
        public string Message { get; set; }
    }
}
