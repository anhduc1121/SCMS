﻿using AutoMapper;
using SCMS_Models.Models;
using ViewModel;

namespace SCMS_Repository.Helpers
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<TblAccount, AccountVM>().ReverseMap();
            CreateMap<TblPage, PageRequestVM>().ReverseMap();
            CreateMap<TblPage, PageResponVM>().ReverseMap();
            CreateMap<TblPageCrud, PageCrudResponVM>().ReverseMap();
            CreateMap<TblPageCrud, PageCrudRequestVM>().ReverseMap();
            CreateMap<TblRole, RoleResponVM>().ReverseMap();
            CreateMap<TblRole, RoleRequestVM>().ReverseMap();
            CreateMap<TblTicketSuggestion, TicketSuggestionResponseVM>().ReverseMap();
            CreateMap<TblEducation, EducationResponse>().ReverseMap();
            CreateMap<TblAccount, AccountProfileVM>().ReverseMap();
            CreateMap<TblCategoryTicket, CategoryTicketVM>().ReverseMap();
            CreateMap<TblCategoryTicket, CategoryTicketRequestVM>().ReverseMap();

            CreateMap<TblTicketSuggestionDetail, TicketSuggestionDetailRequestVM>()
                .ForMember(dest => dest.Attachments, opt => opt.Ignore())
                .ReverseMap();

            CreateMap<TblNotification, NotificationVM>()
                 .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Account.Email))
                .ReverseMap();

            CreateMap<TblTicketComment, TicketCommentVM>().ReverseMap();
            CreateMap<TblTicketComment, TicketCommentReplyVM>().ReverseMap();
            CreateMap<TblTicket, TicketVM>()
                .ReverseMap();
            CreateMap<TicketResponVM, TblTicket>()
     .ForMember(dest => dest.CategoryTicketId, opt => opt.MapFrom(src => src.CategoryTicketId))
     .ForMember(dest => dest.StatusTicketId, opt => opt.MapFrom(src => src.StatusTicketId))
     .ForMember(dest => dest.AccountIdCreate, opt => opt.MapFrom(src => src.AccountIdCreate))
     .AfterMap((src, dest) =>
     {
         if (dest.CategoryTicket != null)
             dest.CategoryTicket.CategoryName = src.CategoryTicketName;
         if (dest.StatusTicket != null)
             dest.StatusTicket.StatusTicketName = src.StatusTicketName;
         if (dest.AccountIdCreateNavigation != null)
             dest.AccountIdCreateNavigation.Email = src.AccountEmail;
     })
     .ReverseMap();

            CreateMap<TblTicketComment, TicketCommentTurnVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketCommentId))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.AccountCreateId))
                .ForMember(dest => dest.Avatar, opt => opt.MapFrom(src => src.AccountCreate.Picture))
                .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.Comment))
                .ReverseMap();

            CreateMap<TblTicketAttachment, TicketAttachmentVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketAttachmentId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.UrlPath))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
                .ReverseMap();

            CreateMap<TblTicketSuggestion, TicketSuggestionVM>().ReverseMap();
            CreateMap<TblTicketSuggestionDetail, TicketSuggestionDetailReponVM>()
                .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.Comment))
                .ReverseMap();
            CreateMap<TblTicketSuggestionAttachment, TicketSuggestionAttachmentResponVM>()
                 .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                 .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketSuggestionAttachmentsId))
                 .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.UrlPath))
                 .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ReverseMap();

            CreateMap<TblTagTicket, TagTicketVM>()
                .ForMember(dest => dest.From, opt => opt.MapFrom(src => src.AccountCreate.Email))
                .ForMember(dest => dest.To, opt => opt.MapFrom(src => src.RequiredAccount.Email))
                .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.CreateDate))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.IsAccept))
                .ForMember(dest => dest.Note, opt => opt.MapFrom(src => src.RequestDetails));

            CreateMap<TblTagTicketAttachment, TagTicketAttachmentVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TagTicketAttachmentId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.Url))
                .ForMember(dest => dest.File, opt => opt.MapFrom(src => src.Url));

            CreateMap<TblPinTicket, PinTicketVM>().ReverseMap();
            CreateMap<TblCategoryTicket, CategoryTicketReponseVM>().ReverseMap();
            CreateMap<TblRole, RoleVM>().ReverseMap();
            CreateMap<TblFunctionActionApi, FunctionActionApiVM>().ReverseMap();
            CreateMap<TblTicket, TicketCreateVM>().ReverseMap();
            CreateMap<TblCampus, CampusVM>().ReverseMap();
            CreateMap<TblPage, PageVM>().ReverseMap();
            CreateMap<TblStatusTicket, StatusTicketVM>().ReverseMap();
            CreateMap<TblTagTicket, TagsVM>().ReverseMap();
            CreateMap<TblAccount, AccountTicketVM>().ReverseMap();
            CreateMap<TblTicketReport, TblTicketReportVM>().ReverseMap();
            CreateMap<TblTicketReport, TicketReportRequestVM>().ReverseMap();
            CreateMap<TblTicketSuggestion, TicketSuggestionRequestVM>().ReverseMap();

            CreateMap<TblAccount, ExEmployee>()
                 .ForMember(dest => dest.EmployeeId, opt => opt.MapFrom(src => src.AccountId))
                 .ForMember(dest => dest.EmployeeEmail, opt => opt.MapFrom(src => src.Email))
                 .ForMember(dest => dest.StatusId, opt => opt.MapFrom(src => src.StatusAccountId))
                .ReverseMap();

            CreateMap<TblDepartment, DepartmentVM>().ReverseMap();

            CreateMap<TblTicketDepartmentCommentsImport, TicketDepartmentCommentsImportRequestAddVM>().ReverseMap();

            CreateMap<TblTicketDepartmentAttachment, TblTicketDepartmentAttachmentRequestAddVM>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.UrlPath))
                .ForMember(dest => dest.File, opt => opt.MapFrom(src => src.UrlPath))
                .ReverseMap();

            CreateMap<TblTicketDepartment, TicketDepartmentRequestAddVM>().ReverseMap();
            CreateMap<TblTicketDepartment, TicketDepartmentResponseGetsVM>().ReverseMap();
            CreateMap<TblTicketDepartmentCommentsImport, TicketDepartmentCommentsImportResponseGetVM>().ReverseMap();

            CreateMap<TblTicketDepartmentAttachment, TicketDepartmentAttachmentResponseGetVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketDepartmentAttachment))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.UrlPath))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description));

            CreateMap<TblTicketDepartmentComment, TicketDepartmentCommentRequestGetVM>()
                 .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketDepartmentCommentId))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.AccountId))
                .ForMember(dest => dest.Avatar, opt => opt.MapFrom(src => src.Account.Picture))
                .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.Comment))
                .ReverseMap();

            CreateMap<TblTicketDepartmentAttachment, TicketDepartmentCommentAttachmentRequestGetVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.TicketDepartmentAttachment))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.FileType))
                .ForMember(dest => dest.Link, opt => opt.MapFrom(src => src.UrlPath))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description));


            CreateMap<TblTicketDepartmentComment, TicketDepartmentCommentRequestReplyVM>().ReverseMap();
        }
    }
}
