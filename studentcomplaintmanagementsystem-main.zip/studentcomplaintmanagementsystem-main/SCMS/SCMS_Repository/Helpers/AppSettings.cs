﻿namespace SCMS_Repository.Helpers
{
    public class AppSettings
    {
        public string SecretKey { get; set; }

        public string GoogleDriver_ClientId { get; set; }
        public string GoogleDriver_ClientSecret { get; set; }
        public string GoogleDriver_UploadFolderId { get; set; }
        public string GoogleDriver_SaveFile { get; set; }
        public string VirusTotal_Key { get; set; }
        public string VirusTotal_Url { get; set; }

    }
}
