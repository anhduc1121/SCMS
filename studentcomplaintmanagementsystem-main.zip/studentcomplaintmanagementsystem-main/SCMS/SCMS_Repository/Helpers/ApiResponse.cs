﻿namespace SCMS_Repository.Helpers
{
    public class ApiResponse
    {
        public string Message { get; set; }
        public object Data { get; set; }
        public List<object> Datas { get; set; }
        public int NumberOfRecords { get; set; }

    }
}
