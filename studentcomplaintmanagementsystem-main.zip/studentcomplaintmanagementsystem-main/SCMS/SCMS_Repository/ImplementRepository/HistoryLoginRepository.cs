﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class HistoryLoginRepository : GennericRepository<TblHistoryLogin>, IHistoryLoginRepository
    {
        public HistoryLoginRepository(ScmsContext context = null) : base(context)
        {
        }
    }
}
