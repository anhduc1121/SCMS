﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class CampusRepository : GennericRepository<TblCampus>, ICampusRepository
    {
        public CampusRepository(ScmsContext context = null) : base(context) { }

        public List<TblCampus> GetListCampus()
        {
            return context.TblCampuses.Include(x => x.TblAccounts).ToList();
        }
    }
}
