﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketDepartmentRepository : GennericRepository<TblTicketDepartment>, ITicketDepartmentRepository
    {
        public TicketDepartmentRepository(ScmsContext context = null) : base(context) { }

        public TblDepartment CreateDepartment(DepartmentVM? departmentVM)
        {
            if (departmentVM == null)
            {
                throw new ArgumentNullException(nameof(departmentVM));
            }

            var department = new TblDepartment
            {
                DepartmentId = Guid.NewGuid(),
                DepartmentName = departmentVM.DepartmentName.Trim(),
                IsDelete = false,
                CreateDate = DateTime.Now,
                ModifyUpdate = departmentVM.ModifyUpdate,
                AccountCreateId = (Guid)departmentVM.AccountCreateId,
                AccountUpdateId = departmentVM.AccountUpdateId,
                ResponsiblePersonEmail = departmentVM.EmailReponsible
            };

            context.TblDepartments.Add(department);
            context.SaveChanges();

            return department;
        }

        public TblDepartment DeleteDepartment(Guid departmentId)
        {
            var department = context.TblDepartments.Find(departmentId);
            if (department == null)
            {
                throw new ArgumentException("Department not found", nameof(departmentId));
            }

            department.IsDelete = true;
            context.SaveChanges();
            return department;
        }

        public List<TblDepartment> GetAllDepartment()
        {
            return context.TblDepartments.Where(x => !x.IsDelete).ToList();
        }

        public TblTicketDepartment GetTicketDepartment(Guid ticketDepartmentsId)
        {
            return context.TblTicketDepartments
                .Include(x => x.CategoryTicket)
                .Include(x => x.StatusTicket)
                .Include(x => x.Ticket)
                .Include(x => x.Ticket.AccountIdCreateNavigation)
                .Include(x => x.Department)
                .Include(x => x.AccountIdCreateNavigation)
                .FirstOrDefault(x => x.TicketDepartmentsId == ticketDepartmentsId);
        }

        public List<TblTicketDepartment> GetTicketDepartmentsById(Guid ticketId)
        {
            return context.TblTicketDepartments
               .Include(x => x.CategoryTicket)
               .Include(x => x.StatusTicket)
               .Include(x => x.Ticket)
               .Include(x => x.Ticket.AccountIdCreateNavigation)
               .Include(x => x.Department)
               .Include(x => x.AccountIdCreateNavigation)
               .Where(x => x.TicketId == ticketId).ToList();
        }

        public (int, List<TblTicketDepartment>) GetTicketDepartments(string? title, Guid? CategoryTicketId, Guid? DepartmentId,
            string? accountGmaillStudent, string? accountGmaillStaff, string? accountGmaillOtherStaff
            , Guid? statusTicketId, DateTime? createDate, int sortTitle, int sortDate, int pageIndex, int pageSize, Guid? TicketId)
        {
            List<TblTicketDepartment> query = context.TblTicketDepartments
                .Include(x => x.CategoryTicket)
                .Include(x => x.StatusTicket)
                .Include(x => x.Ticket)
                .Include(x => x.Ticket.AccountIdCreateNavigation)
                .Include(x => x.Department)
                .Include(x => x.AccountIdCreateNavigation)
                .Where(x => x.AccountId == null)
                .ToList();

            List<TblTicketDepartment> queryNon = context.TblTicketDepartments
               .Include(x => x.CategoryTicket)
               .Include(x => x.StatusTicket)
               .Include(x => x.Ticket)
               .Include(x => x.Ticket.AccountIdCreateNavigation)
               .Include(x => x.Department)
               .Include(x => x.AccountIdCreateNavigation)
               .Where(x => x.AccountId != null)
               .Include(x => x.Account)
               .ToList();

            query = queryNon.Concat(query).ToList();

            if (TicketId != null && query.Count > 0)
            {
                query = query.Where(x => x.TicketId.ToString().ToLower().Equals(TicketId.ToString().ToLower())).ToList();
            }

            if (!String.IsNullOrEmpty(title) && query.Count > 0)
            {
                query = query.Where(x => x.Title.StartsWith(title)).ToList();
            }
            if (CategoryTicketId != null && query.Count > 0)
            {
                query = query.Where(x => x.CategoryTicketId.ToString().ToLower().Equals(CategoryTicketId.ToString().ToLower())).ToList();
            }
            if (DepartmentId != null && query.Count > 0)
            {
                query = query.Where(x => x.DepartmentId.ToString().ToLower().Equals(DepartmentId.ToString().ToLower())).ToList();
            }
            if (statusTicketId != null && query.Count > 0)
            {
                query = query.Where(x => x.StatusTicketId.ToString().ToLower().Equals(statusTicketId.ToString().ToLower())).ToList();
            }
            if (!String.IsNullOrEmpty(accountGmaillStudent) && query.Count > 0)
            {
                query = query.Where(x => x.Ticket.AccountIdCreateNavigation.Email.ToLower().Contains(accountGmaillStudent.ToString().ToLower())).ToList();
            }
            if (!String.IsNullOrEmpty(accountGmaillStaff) && query.Count > 0)
            {
                query = query.Where(x => x.AccountIdCreateNavigation.Email.ToLower().Contains(accountGmaillStaff)).ToList();
            }
            if (!String.IsNullOrEmpty(accountGmaillOtherStaff) && query.Count > 0)
            {
                query = query.Where(x => x.AccountId != null && x.Account.Email.ToLower().Contains(accountGmaillOtherStaff)).ToList();
            }
            if (createDate != null && query.Count > 0 && query.Count > 0)
            {
                query = query.Where(x => x.CreateDate.Date == createDate?.Date && x.CreateDate.Month == createDate?.Month && x.CreateDate.Year == createDate?.Year).ToList();
            }
            if (sortTitle == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.Title).ToList();
            }
            if (sortTitle == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.Title).ToList();
            }
            if (sortDate == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }
            if (sortDate == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            // Số lượng và danh sách bản cần lấy
            if (pageIndex == 0 && pageSize == 0)
            {
                return (query.Count, query.ToList());
            }
            else
            {
                return (query.Count, query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList());
            }
        }

        public TblDepartment UpdateDepartment(DepartmentVM? departmentVM)
        {
            if (departmentVM == null)
            {
                throw new ArgumentNullException(nameof(departmentVM));
            }

            var department = context.TblDepartments.Find(departmentVM.DepartmentId);
            if (department == null)
            {
                throw new ArgumentException("Department not found", nameof(departmentVM.DepartmentId));
            }

            department.DepartmentName = departmentVM.DepartmentName;
            department.ModifyUpdate = departmentVM.ModifyUpdate;
            department.AccountUpdateId = departmentVM.AccountUpdateId;
            department.ResponsiblePersonEmail = departmentVM.EmailReponsible;
            context.SaveChanges();

            return department;
        }
    }
}
