﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class DepartmentRepository : GennericRepository<TblDepartment>, IDepartmentRepository
    {
        public DepartmentRepository(ScmsContext context = null) : base(context)
        {
        }

        public TblDepartment CreateDepartment(DepartmentVM? departmentVM)
        {
            if (departmentVM == null)
            {
                throw new ArgumentNullException(nameof(departmentVM));
            }

            var department = new TblDepartment
            {
                DepartmentId = Guid.NewGuid(),
                DepartmentName = departmentVM.DepartmentName.Trim(),
                IsDelete = false,
                CreateDate = DateTime.Now,
                ModifyUpdate = departmentVM.ModifyUpdate,
                AccountCreateId = (Guid)departmentVM.AccountCreateId,
                AccountUpdateId = departmentVM.AccountUpdateId,
                ResponsiblePersonEmail = departmentVM.EmailReponsible
            };

            context.TblDepartments.Add(department);
            context.SaveChanges();

            return department;
        }

        public TblDepartment DeleteDepartment(Guid departmentId)
        {
            var department = context.TblDepartments.Find(departmentId);
            if (department == null)
            {
                throw new ArgumentException("Department not found", nameof(departmentId));
            }

            department.IsDelete = true;
            context.SaveChanges();
            return department;
        }

        public List<TblDepartment> GetAllDepartment()
        {
            return context.TblDepartments.Where(x => !x.IsDelete).ToList();
        }

        public TblDepartment UpdateDepartment(DepartmentVM? departmentVM)
        {
            if (departmentVM == null)
            {
                throw new ArgumentNullException(nameof(departmentVM));
            }

            var department = context.TblDepartments.Find(departmentVM.DepartmentId);
            if (department == null)
            {
                throw new ArgumentException("Department not found", nameof(departmentVM.DepartmentId));
            }

            department.DepartmentName = departmentVM.DepartmentName;
            department.ModifyUpdate = DateTime.Now;
            department.AccountUpdateId = departmentVM.AccountUpdateId;
            department.ResponsiblePersonEmail = departmentVM.EmailReponsible;
            context.SaveChanges();

            return department;
        }
    }
}
