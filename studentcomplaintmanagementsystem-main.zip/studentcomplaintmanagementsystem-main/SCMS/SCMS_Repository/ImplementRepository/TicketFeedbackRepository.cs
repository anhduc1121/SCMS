﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketFeedbackRepository : GennericRepository<TblTicketFeedback>, ITicketFeedbackRepository
    {
        public TicketFeedbackRepository(ScmsContext context = null) : base(context) { }

        public string AddFeedback(TicketFeedbackRequestAddVM ticket)
        {
            TblTicketFeedback ticketFeedback = new TblTicketFeedback();
            ticketFeedback.TicketFeedbackPositive = ticket.Positive;
            ticketFeedback.TicketFeedbackNegative = ticket.Negative;
            ticketFeedback.Rate = ticket.Rate;
            ticketFeedback.TicketId = ticket.TicketId;

            TblTagTicket tblTagTicket = context.TblTagTickets.FirstOrDefault(x => x.TicketId == ticket.TicketId && x.IsAccept == "1");
            if (tblTagTicket == null)
            {
                tblTagTicket = context.TblTagTickets.FirstOrDefault(x => x.TicketId == ticket.TicketId && x.IsAccept == "2");
            }

            if (tblTagTicket != null)
            {
                ticketFeedback.AccountIdStaff = (Guid)tblTagTicket.RequiredAccountId;
            }

            if (ticketFeedback.AccountIdStaff == default)
            {
                TblTicketComment ticketComment = context.TblTicketComments.FirstOrDefault(x => x.TicketId == ticket.TicketId && x.AccountCreateId != ticket.AccountCreatedId);
                if (ticketComment != null)
                {
                    ticketFeedback.AccountIdStaff = (Guid)ticketComment.AccountCreateId;
                }
            }

            if (ticketFeedback.AccountIdStaff == default)
            {
                return "Done";
            }
            else
            {
                context.TblTicketFeedbacks.Add(ticketFeedback);
                context.SaveChanges();
            }

            return "Done Create";
            //var listTagTicket = context.TblTagTickets.Where(x => x.TicketId == ticket.TicketId && x.IsAccept == "1").ToList();
            //var ticketInfor = context.TblTickets.FirstOrDefault(x => x.TicketId == ticket.TicketId);
            //try
            //{
            //    if (ticket.AccountCreatedId == ticketInfor.AccountIdCreate)
            //    {
            //        foreach (var item in listTagTicket)
            //        {
            //            var feedback = new TblTicketFeedback
            //            {
            //                Rate = ticket.Rate,
            //                TicketFeedbackPositive = ticket.Positive,
            //                TicketFeedbackNegative = ticket.Negative,
            //                AccountIdStaff = item.RequiredAccountId.Value,
            //                TicketId = ticket.TicketId
            //            };
            //            context.TblTicketFeedbacks.Add(feedback);
            //            context.SaveChanges();
            //        }
            //        return "Success";
            //    }
            //    else
            //    {
            //        return "error: AccountCreatedId is required";
            //    }
            //}
            //catch (Exception ex)
            //{
            //    return "error";
            //}
        }

        public (int, List<TicketFeedbackResponseGetDataVM>) GetAll(TicketFeedbackRequestGetDataVM ticket)
        {
            var query = context.TblTicketFeedbacks.AsQueryable();

            if (!string.IsNullOrEmpty(ticket.Rate))
            {
                query = query.Where(x => x.Rate == ticket.Rate);
            }
            if (ticket.CreateDate != null)
            {
                query = query.Where(x => x.CreateDate.Date == ticket.CreateDate.Value.Date);
            }
            if (ticket.TicketId != null)
            {
                query = query.Where(x => x.TicketId == ticket.TicketId);
            }

            if (ticket.SortDate == 1)
            {
                query = query.OrderByDescending(x => x.CreateDate);
            }
            else if (ticket.SortDate == 2)
            {
                query = query.OrderBy(x => x.CreateDate);
            }

            var result = query.Select(x => new TicketFeedbackResponseGetDataVM
            {
                TicketFeedbackId = x.TicketFeedbackId,
                TicketFeedbackPositive = x.TicketFeedbackPositive,
                TicketFeedbackNegative = x.TicketFeedbackNegative,
                Rate = x.Rate,
                CreateDate = x.CreateDate,
                TicketId = x.TicketId
            }).ToList();

            return (result.Count, result.Skip((ticket.pageIndex - 1) * ticket.pageSize).Take(ticket.pageSize).ToList());
        }
    }
}
