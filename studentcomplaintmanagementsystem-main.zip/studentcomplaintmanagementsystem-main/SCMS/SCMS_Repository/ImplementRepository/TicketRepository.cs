﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{

    public class TicketRepository : GennericRepository<TblTicket>, ITicketRepository
    {
        public TicketRepository(ScmsContext context = null) : base(context) { }

        public TblTicket EndTicket(Guid ticketId, string positive, string negative, string rate)
        {
            List<TblTicketFeedback> tblTicketFeedbacks = new List<TblTicketFeedback>();
            var accountStaff = context.TblTickets.Include(x => x.TblTicketComments).Where(x => x.TicketId == ticketId).OrderBy(x => x.CreateDate)
                    .FirstOrDefault().AccountIdCreate;
            var ticket = context.TblTickets.Include(x => x.TblTicketFeedbacks).FirstOrDefault(x => x.TicketId == ticketId);

            if (ticket != null)
            {
                var statusTicket = context.TblStatusTickets.FirstOrDefault(x => x.StatusTicketId == ticket.StatusTicketId);
                if (statusTicket != null)
                {
                    statusTicket.IsDelete = true;
                    statusTicket.ModifyUpdate = DateTime.Now;
                    statusTicket.StatusTicketName = "done";
                }

                ticket.EndDate = DateTime.Now;
                TblTicketFeedback tblTicketFeedback = new TblTicketFeedback()
                {
                    TicketFeedbackPositive = positive,
                    TicketFeedbackNegative = negative,
                    Rate = rate,
                    TicketId = ticketId,
                    AccountIdStaff = accountStaff
                };
                tblTicketFeedbacks.Add(tblTicketFeedback);
                ticket.TblTicketFeedbacks = tblTicketFeedbacks;

                context.SaveChanges();
                return ticket;
            }
            else
            {
                throw new Exception("Ticket not found");
            }
        }
        public TblTicket GetTicketByTicketId(Guid ticketId, Guid? userId)
        {
            var ticket = context.TblTickets
                .Include(x => x.StatusTicket)
                .Include(x => x.CategoryTicket)
                .Include(x => x.AccountIdCreateNavigation)
                .FirstOrDefault(x => x.TicketId == ticketId);

            // add thông báo cho sinh viên và nhân viên 

            if (userId != null && ticket != null && ticket.AccountIdCreate != userId)
            {
                return null;
            }
            return ticket;
        }

        public List<TblTicket> GetTicketForStudent(string? status, string? title, Guid? cateId, DateTime? createDate, Guid? accountId, int pageIndex = 1, int pageSize = 5, int sortDate = 0)
        {
            var query = context.TblTickets
                .Include(x => x.AccountIdCreateNavigation)
                .Include(x => x.StatusTicket)
                .Include(x => x.CategoryTicket)
                .ToList();
            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(x => x.Status == status).ToList();
            }
            if (!string.IsNullOrEmpty(title))
            {
                query = query.Where(x => x.Title == title).ToList();
            }

            if (cateId != null)
            {
                query = query.Where(x => x.CategoryTicketId == cateId).ToList();
            }
            if (createDate != null)
            {
                query = query.Where(x => x.CreateDate.Date == createDate?.Date && x.CreateDate.Month == createDate?.Month && x.CreateDate.Year == createDate?.Year).ToList();
            }

            if (accountId != null)
            {
                query = query.Where(x => x.AccountIdCreate == accountId).ToList();
            }
            if (sortDate == 1)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }
            if (sortDate == 2)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }
            return query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }
        public List<TblTicket> GetTicketByAccountId(string? status, string? title, Guid? cateId, DateTime? createDate, Guid accountId, int pageIndex = 1, int pageSize = 5, int sortDate = 0)
        {
            var query = context.TblTickets.Include(c => c.CategoryTicket).Include(x => x.StatusTicket)
                    .Where(t => t.AccountIdCreate == accountId)
                    .OrderByDescending(t => t.TblPinTickets.Any(pt => pt.AccountId == accountId && pt.IsDelete == false))
                    .ThenByDescending(t => t.CreateDate).ToList();

            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(x => x.Status == status && x.AccountIdCreate == accountId).ToList();
            }
            if (!string.IsNullOrEmpty(title))
            {
                query = query.Where(x => x.Title == title && x.AccountIdCreate == accountId).ToList();
            }

            if (cateId != null)
            {
                query = query.Where(x => x.CategoryTicketId == cateId && x.AccountIdCreate == accountId).ToList();
            }
            if (createDate != null)
            {
                query = query.Where(x => x.CreateDate.Date == createDate?.Date && x.CreateDate.Month == createDate?.Month && x.CreateDate.Year == createDate?.Year && x.AccountIdCreate == accountId).ToList();
            }
            if (sortDate == 1)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }
            if (sortDate == 2)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }
            return query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

        /// <summary>
        /// Trả về số lượng của Ticket, danh sách Ticket theo page
        /// </summary>
        /// <param name="userID">ID của tài khoản đăng nhập</param>
        /// <param name="status"></param>
        /// <param name="title"></param>
        /// <param name="cateId">ID của thể loại</param>
        /// <param name="statusTicketId"></param>
        /// <param name="accountIdCreate">ID của người tạo đơn</param>
        /// <param name="accountIDBehaveCreate">ID của người tạo hộ đơn</param>
        /// <param name="tagAccountId">ID của người đc tag</param>
        /// <param name="createDate">Date tạo</param>
        /// <param name="sortTitle">Sắp xếp theo Title</param>
        /// <param name="pageIndex">Trang số bn</param>
        /// <param name="pageSize"></param>
        /// <param name="sortDate">Sắp xếp theo date</param>
        /// <param name="isPin">có hiện thị bọn bị pin lên trước hay ko</param>
        /// <returns></returns>
        public (int, List<TblTicket>) GetAllTicket(Guid userID, Guid? cateId, Guid? statusTicketId,
             Guid? accountIdCreate, Guid? accountIDBehaveCreate, Guid? tagAccountId,
            string? accountGmaillCreate, string? accountGmaillBehaveCreate, string? accountGmaillTag, string? status, string? title,
            DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortDate = 0, int sortTitle = 1, int sortStatusTicket = 0, bool isPin = false)
        {
            var query = context.TblTickets
                           .Include(x => x.AccountIdCreateNavigation)
                           .Include(x => x.StatusTicket)
                           .Include(x => x.CategoryTicket)
                           .Include(x => x.TblTagTickets)
                           .Include(x => x.TblPinTickets)
                           .Include(x => x.TblTicketHandlings)
                           .ToList();
            if (!string.IsNullOrEmpty(accountGmaillCreate) && query.Count > 0)
            {
                List<Guid> ids = context.TblAccounts.Where(x => x.Email.StartsWith(accountGmaillCreate)).Select(x => x.AccountId).ToList();
                query = query.Where(x => ids.Any(i => i == x.AccountIdCreate)).ToList();
            }
            if (!string.IsNullOrEmpty(accountGmaillBehaveCreate) && query.Count > 0)
            {
                List<Guid> ids = context.TblAccounts.Where(x => x.Email.StartsWith(accountGmaillBehaveCreate)).Select(x => x.AccountId).ToList();
                query = query.Where(x => ids.Any(i => i == x.AccountIdbehaveCreate)).ToList();
            }
            if (!string.IsNullOrEmpty(accountGmaillTag) && query.Count > 0)
            {
                List<Guid> accountIds = context.TblAccounts.Where(x => x.Email.StartsWith(accountGmaillTag)).Select(x => x.AccountId).ToList();
                List<Guid> ticketIds = context.TblTagTickets.Where(x => accountIds.Any(i => i == x.RequiredAccountId))
                    .Select(x => x.TicketId).ToList();

                query = query.Where(x => ticketIds.Any(i => i == x.TicketId)).ToList();
            }
            if (!string.IsNullOrEmpty(status) && query.Count > 0)
            {
                query = query.Where(x => x.Status == status).ToList();
            }
            if (!string.IsNullOrEmpty(title) && query.Count > 0)
            {
                query = query.Where(x => x.Title.StartsWith(title)).ToList();
            }
            if (cateId != null && query.Count > 0)
            {
                query = query.Where(x => x.CategoryTicketId == cateId).ToList();
            }
            if (statusTicketId != null && query.Count > 0)
            {
                query = query.Where(x => x.StatusTicketId == statusTicketId).ToList();
            }
            if (accountIdCreate != null && query.Count > 0)
            {
                query = query.Where(x => x.AccountIdCreate == accountIdCreate).ToList();
            }
            if (accountIDBehaveCreate != null && query.Count > 0)
            {
                query = query.Where(x => x.AccountIdbehaveCreate == accountIDBehaveCreate).ToList();
            }
            if (tagAccountId != null && query.Count > 0)
            {
                query = query.Where(ticket => ticket.TblTagTickets.Any(tagTicket => tagTicket.RequiredAccountId == tagAccountId)).ToList();
            }
            if (createDate != null && query.Count > 0)
            {
                query = query.Where(x => x.CreateDate.Date == createDate?.Date && x.CreateDate.Month == createDate?.Month && x.CreateDate.Year == createDate?.Year).ToList();
            }

            // Sort
            if (isPin && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.TblPinTickets.Any(z => z.AccountId == userID && z.IsDelete == false)).ToList();
            }
            if (sortTitle == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.Title).ToList();
            }
            if (sortTitle == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.Title).ToList();
            }
            if (sortDate == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }
            if (sortDate == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            if (sortStatusTicket == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.StatusTicketId).ToList();
            }

            if (sortStatusTicket == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.StatusTicketId).ToList();
            }


            // Số lượng và danh sách bản cần lấy
            return (query.Count, query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList());
        }

        public TblTicket SendTicket(TicketVM ticket)
        {
            var newTicket = new TblTicket
            {
                TicketId = Guid.NewGuid(),
                Title = ticket.Title,
                Description = ticket.Description,
                CreateDate = DateTime.Now,


            };
            context.TblTickets.Add(newTicket);
            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Error");
            }
            return newTicket;
        }

        public TblTicket UpdateCategorysOfTicketId(Guid ticketId, Guid categoryTicketId)
        {
            var ticket = context.TblTickets.FirstOrDefault(x => x.TicketId == ticketId);
            if (ticket == null)
                throw new ArgumentException("Ticket not found.");

            ticket.CategoryTicketId = categoryTicketId;
            context.SaveChanges();

            return ticket;
        }

        public TblPinTicket CreatePinTicket(Guid ticketId, Guid accountId)
        {
            var pinTicket = context.TblPinTickets.FirstOrDefault(x => x.TicketId == ticketId && x.AccountId == accountId);
            if (pinTicket == null)
            {
                pinTicket = new TblPinTicket
                {
                    TicketId = ticketId,
                    CreateDate = DateTime.Now,
                    IsDelete = false,
                    AccountId = accountId,
                };
                context.TblPinTickets.Add(pinTicket);
            }
            else
            {
                pinTicket.ModifyUpdate = DateTime.Now;
                pinTicket.IsDelete = false;
            }

            context.SaveChanges();

            return pinTicket;
        }
        public bool DeletePinTicket(Guid ticketId, Guid accountId)
        {
            var pinTicket = context.TblPinTickets.FirstOrDefault(x => x.TicketId == ticketId && x.AccountId == accountId);
            if (pinTicket == null)
                throw new ArgumentException("PinTicket not found.");

            pinTicket.IsDelete = true;
            pinTicket.ModifyUpdate = DateTime.Now;
            if (context.SaveChanges() > 0)
            {
                return true;
            }

            return false;
        }

        public List<TblStatusTicket> ViewStatusTicket()
        {
            return context.TblStatusTickets
                .Include(x => x.TblTickets)
                .ToList();
        }

        public List<TblAccount> GetAccountTagTicketDoingAndHaviingDone(Guid ticketId)
        {
            List<TblAccount> accountList = context.TblAccounts.Include(z => z.TblTagTicketRequiredAccounts)
                .Where(x => x.TblTagTicketRequiredAccounts.Any(z => z.TicketId == ticketId && (z.IsAccept == "2" || z.IsAccept == "1"))).ToList();
            return accountList;
        }
        public TblAccount GetAccountTagTicketAccept(Guid ticketId)
        {
            TblAccount account = context.TblAccounts.Include(z => z.TblTagTicketRequiredAccounts)
                .FirstOrDefault(x => x.TblTagTicketRequiredAccounts.Any(z => z.TicketId == ticketId && z.IsAccept == "1"));
            return account;
        }
        public List<TblAccount> GetAccountTagTicket(Guid ticketId)
        {
            List<TblAccount> accountList = context.TblAccounts.Include(z => z.TblTagTicketRequiredAccounts)
                .Where(x => x.TblTagTicketRequiredAccounts.Any(z => z.TicketId == ticketId)).ToList();
            return accountList;
        }

        public TblTicket GetListUserByTicket(Guid ticketId)
        {
            var ticket = context.TblTickets
                             .Include(x => x.CategoryTicket)
                             .Include(x => x.TblTagTickets)
                             .Include(x => x.AccountIdbehaveCreateNavigation)
                             .Include(x => x.AccountIdupdateNavigation)
                             .ThenInclude(x => x.Campus)
                             .FirstOrDefault(x => x.TicketId == ticketId);
            return ticket;
        }
    }
}
