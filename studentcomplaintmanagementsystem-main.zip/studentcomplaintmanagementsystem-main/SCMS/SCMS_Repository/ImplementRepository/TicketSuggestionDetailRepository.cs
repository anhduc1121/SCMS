﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketSuggestionDetailRepository : GennericRepository<TblTicketSuggestionDetail>, ITicketSuggestionDetailRepository
    {
        public TicketSuggestionDetailRepository(ScmsContext context = null) : base(context) { }

        public TblTicketSuggestionDetail GetSuggestionDetailById(Guid id)
        {
            return context.TblTicketSuggestionDetails.Include(x => x.TblTicketSuggestionAttachments).FirstOrDefault(x => x.TicketSuggestionDetailId == id);
        }
    }
}
