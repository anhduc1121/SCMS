﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketDepartmentCommentRepository : GennericRepository<TblTicketDepartmentComment>, ITicketDepartmentCommentRepository
    {
        public TicketDepartmentCommentRepository(ScmsContext context = null) : base(context) { }

        public List<TblTicketDepartmentComment> GetAllByTicketDepartmentId(Guid ticketDepartmentId)
        {
            return context.TblTicketDepartmentComments
                .Include(x => x.Account)
                .Include(x => x.TblTicketDepartmentAttachments)
                .OrderBy(x => x.CreateDate)
                .Where(x => x.TicketDepartmentsId == ticketDepartmentId).ToList();
        }
    }
}
