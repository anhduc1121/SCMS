﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketReportAttachmentRepository : GennericRepository<TblTicketReportAttachment>, ITicketReportAttachmentRepository
    {
        public TicketReportAttachmentRepository(ScmsContext context = null) : base(context) { }
    }
}
