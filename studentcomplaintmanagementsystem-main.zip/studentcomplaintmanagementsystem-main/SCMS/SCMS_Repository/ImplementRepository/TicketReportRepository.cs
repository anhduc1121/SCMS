﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketReportRepository : GennericRepository<TblTicketReport>, ITicketReportRepository
    {
        public TicketReportRepository(ScmsContext context = null) : base(context) { }

        public ReportForEachAccountVM ReportForEachAccount(Guid userID, DateTime fromDate, DateTime toDate)
        {

            var email = context.TblAccounts.FirstOrDefault(x => x.AccountId == userID).Email;

            var totalTicket = (from tc in context.TblTicketComments
                               join t in context.TblTickets on tc.TicketId equals t.TicketId
                               where tc.AccountCreateId == userID
                                      && t.CreateDate >= fromDate && t.CreateDate <= toDate
                               group tc by tc.AccountCreateId into g
                               select new
                               {
                                   TotalTicketsProcessed = g.Select(x => x.TicketId).Distinct().Count()
                               }).FirstOrDefault()?.TotalTicketsProcessed ?? 0;
            int avgProcessingTimeInSeconds = 0;
            var averageProcessingTime = context.TblTickets
            .Where(t => t.AccountIdCreate == userID && t.CreateDate >= fromDate && t.CreateDate <= toDate)
            .AsEnumerable()
            .Average(t => TicketReportRepository.GetTimeSpanTotalSeconds(
                modifyUpdate: t.ModifyUpdate,
                createDate: t.CreateDate));
            if (averageProcessingTime != null)
            {
                avgProcessingTimeInSeconds = (int)(averageProcessingTime);
            }

            var createTicketId = new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45");
            var expiredTicketId = new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54");
            var solvedTicketId = new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50");
            var receivedTicketId = new Guid("810b802f-b503-4b5c-a929-7da50385234c");
            var assignedTicketId = new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7");

            int createTicket = context.TblTickets
            .Join(
                    context.TblStatusTickets,
                    t => t.StatusTicketId,
                    st => st.StatusTicketId,
                    (t, st) => new { Ticket = t, StatusTicket = st })
                .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == createTicketId.ToString()
                && joinResult.Ticket.AccountIdCreate == userID)
                .Count();

            int expiredTicket = context.TblTickets
                            .Join(
                                    context.TblStatusTickets,
                                    t => t.StatusTicketId,
                                    st => st.StatusTicketId,
                                    (t, st) => new { Ticket = t, StatusTicket = st })
                                .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == expiredTicketId.ToString()
                                    && joinResult.Ticket.AccountIdCreate == userID)
                                .Count();

            int solvedTicket = context.TblTickets
                            .Join(
                                    context.TblStatusTickets,
                                    t => t.StatusTicketId,
                                    st => st.StatusTicketId,
                                    (t, st) => new { Ticket = t, StatusTicket = st })
                                .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == solvedTicketId.ToString()
                                && joinResult.Ticket.AccountIdCreate == userID)
                                .Count();
            int receivedTicket = context.TblTickets
                .Join(
                        context.TblStatusTickets,
                        t => t.StatusTicketId,
                        st => st.StatusTicketId,
                        (t, st) => new { Ticket = t, StatusTicket = st })
                    .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == receivedTicketId.ToString()
                    && joinResult.Ticket.AccountIdCreate == userID)
                    .Count();
            int assignedTicket = context.TblTickets
                .Join(
                        context.TblStatusTickets,
                        t => t.StatusTicketId,
                        st => st.StatusTicketId,
                        (t, st) => new { Ticket = t, StatusTicket = st })
                    .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == assignedTicketId.ToString()
                    && joinResult.Ticket.AccountIdCreate == userID)
                    .Count();

            int rating1 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("1") && feedback.AccountIdStaff == userID
                           select feedback).Count();
            int rating2 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("2") && feedback.AccountIdStaff == userID
                           select feedback).Count();
            int rating3 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("3") && feedback.AccountIdStaff == userID
                           select feedback).Count();
            int rating4 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("4") && feedback.AccountIdStaff == userID
                           select feedback).Count();
            int rating5 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("5") && feedback.AccountIdStaff == userID
                           select feedback).Count();
            int avgRate = 0;
            int totalRate = (rating1 + rating2 + rating3 + rating4 + rating5);
            if (totalRate != 0)
            {
                avgRate = (int)((rating1 * 1 + rating2 * 2 + rating3 * 3 + rating4 * 4 + rating5 * 5) / (rating1 + rating2 + rating3 + rating4 + rating5));
            }
            ReportForEachAccountVM resutl = new ReportForEachAccountVM()
            {
                AccountIdCreate = userID,
                Email = email,
                TotalTicket = totalTicket,
                Created = createTicket,
                Expired = expiredTicket,
                Solved = solvedTicket,
                Received = receivedTicket,
                Assigned = expiredTicket,
                AverageProcessingTime = avgProcessingTimeInSeconds,
                Rating1 = rating1,
                Rating2 = rating2,
                Rating3 = rating3,
                Rating4 = rating4,
                Rating5 = rating5,
                AverageRating = avgRate,
            };
            return resutl;
        }
        private static double? GetTimeSpanTotalSeconds(DateTime? modifyUpdate, DateTime? createDate)
        {
            if (modifyUpdate.HasValue && createDate.HasValue)
            {
                return (modifyUpdate.Value - createDate.Value).TotalHours;
            }
            return null;
        }

        public List<ReportForEachAccountVM> DailyReport(DateTime fromDate, DateTime toDate)
        {
            var roleId = new Guid("21842bcb-fae8-4c00-9c33-de997d4e8103");
            var listUser = context.TblAccountRoles
                .Where(x => x.RoleId.ToString() != roleId.ToString())
                .ToList();

            List<ReportForEachAccountVM> listResult = new List<ReportForEachAccountVM>();
            foreach (var account in listUser)
            {
                ReportForEachAccountVM reportForEachAccountVM = ReportForEachAccount(account.AccountId, fromDate, toDate);
                listResult.Add(reportForEachAccountVM);
            }
            return listResult;
        }

        public List<RatingReportVM> RatingReport(DateTime fromDate, DateTime toDate)
        {
            var rateByStudent = context.TblTicketFeedbacks.Include(x => x.AccountIdStaffNavigation)
                .Include(x => x.Ticket).ThenInclude(x => x.CategoryTicket)
                .Where(x => x.CreateDate >= fromDate && x.CreateDate <= toDate)
                .ToList();
            List<RatingReportVM> result = new List<RatingReportVM>();
            foreach (var rating in rateByStudent)
            {
                var earliestComment = context.TblTicketComments
                    .Where(tc => tc.TicketId == rating.TicketId)
                    .OrderBy(tc => tc.CreateDate)
                    .FirstOrDefault();
                var timeProcess = DateTime.MinValue;
                if (earliestComment != null)
                {
                    timeProcess = earliestComment.CreateDate;
                }
                var emailStudent = context.TblAccounts.FirstOrDefault(x => x.AccountId == rating.Ticket.AccountIdCreate).Email;

                var rateByStudentVM = new RatingReportVM
                {
                    TimeRate = rating.CreateDate,
                    EmailStudent = emailStudent,
                    AccountId = rating.Ticket.AccountIdCreate,
                    CategoryName = rating.Ticket.CategoryTicket.CategoryName,
                    AccountStaffId = rating.AccountIdStaff,
                    EmailStaff = rating.AccountIdStaffNavigation.Email,
                    TimeProcess = timeProcess,
                    Rate = rating.Rate,
                    PossitiveComment = rating.TicketFeedbackPositive,
                    NegativeComment = rating.TicketFeedbackNegative
                };
                result.Add(rateByStudentVM);
            }
            return result;
        }

        public List<ReportTicketReportVM> ReportTicketReport(DateTime fromDate, DateTime toDate)
        {
            var reportTicketByStudent = context.TblTicketReports
                .Include(x => x.AccountIdStaffNavigation).Include(x => x.Ticket).ThenInclude(x => x.CategoryTicket)
                .Where(x => x.CreateDate >= fromDate && x.CreateDate <= toDate)
                .ToList();
            List<ReportTicketReportVM> result = new List<ReportTicketReportVM>();
            foreach (var report in reportTicketByStudent)
            {
                var earliestComment = context.TblTicketComments
                    .Where(tc => tc.TicketId == report.TicketId)
                    .OrderBy(tc => tc.CreateDate)
                    .FirstOrDefault();

                var timeProcess = earliestComment.CreateDate;
                var emailStudent = context.TblAccounts.FirstOrDefault(x => x.AccountId == report.Ticket.AccountIdCreate).Email;
                var rate = context.TblTicketFeedbacks.FirstOrDefault(x => x.TicketId == report.TicketId)?.Rate ?? null;


                var reportTicketByStudentVM = new ReportTicketReportVM
                {
                    TimeReport = report.CreateDate,
                    EmailStudent = emailStudent,
                    AccountId = report.Ticket.AccountIdCreate,
                    CategoryName = report.Ticket.CategoryTicket.CategoryName,
                    AccountStaffId = report.AccountIdStaff,
                    EmailStaff = report.AccountIdStaffNavigation.Email,
                    TimeProcess = timeProcess,
                    Description = report.Description,
                    Rate = rate
                };
                result.Add(reportTicketByStudentVM);
            }
            return result;
        }

        public ReportForEachAccountVM SynthesisReport(DateTime fromDate, DateTime toDate)
        {

            var totalTicketsProcessed = (from t in context.TblTickets
                                         join tc in context.TblTicketComments on t.TicketId equals tc.TicketId
                                         select tc.TicketId).Distinct().Count();
            int avgProcessingTimeInSeconds = 0;
            var averageProcessingTime = context.TblTickets
            .Where(t => t.CreateDate >= fromDate && t.CreateDate <= toDate)
            .AsEnumerable()
            .Average(t => TicketReportRepository.GetTimeSpanTotalSeconds(
                modifyUpdate: t.ModifyUpdate,
                createDate: t.CreateDate));
            if (averageProcessingTime != null)
            {
                avgProcessingTimeInSeconds = (int)(averageProcessingTime);
            }

            var createTicketId = new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45");
            var expiredTicketId = new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54");
            var solvedTicketId = new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50");
            var receivedTicketId = new Guid("810b802f-b503-4b5c-a929-7da50385234c");
            var assignedTicketId = new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7");

            int createTicket = context.TblTickets
           .Join(
                   context.TblStatusTickets,
                   t => t.StatusTicketId,
                   st => st.StatusTicketId,
                   (t, st) => new { Ticket = t, StatusTicket = st })
               .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == createTicketId.ToString()
               )
               .Count();

            int expiredTicket = context.TblTickets
                            .Join(
                                    context.TblStatusTickets,
                                    t => t.StatusTicketId,
                                    st => st.StatusTicketId,
                                    (t, st) => new { Ticket = t, StatusTicket = st })
                                .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == expiredTicketId.ToString()
                                    )
                                .Count();

            int solvedTicket = context.TblTickets
                            .Join(
                                    context.TblStatusTickets,
                                    t => t.StatusTicketId,
                                    st => st.StatusTicketId,
                                    (t, st) => new { Ticket = t, StatusTicket = st })
                                .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == solvedTicketId.ToString()
                                )
                                .Count();
            int receivedTicket = context.TblTickets
                .Join(
                        context.TblStatusTickets,
                        t => t.StatusTicketId,
                        st => st.StatusTicketId,
                        (t, st) => new { Ticket = t, StatusTicket = st })
                    .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == receivedTicketId.ToString()
                    )
                    .Count();
            int assignedTicket = context.TblTickets
                .Join(
                        context.TblStatusTickets,
                        t => t.StatusTicketId,
                        st => st.StatusTicketId,
                        (t, st) => new { Ticket = t, StatusTicket = st })
                    .Where(joinResult => joinResult.StatusTicket.StatusTicketId.ToString() == assignedTicketId.ToString()
                    )
                    .Count();

            int rating1 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("1")
                           select feedback).Count();
            int rating2 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("2")
                           select feedback).Count();
            int rating3 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("3")
                           select feedback).Count();
            int rating4 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("4")
                           select feedback).Count();
            int rating5 = (from feedback in context.TblTicketFeedbacks
                           where feedback.Rate.Equals("5")
                           select feedback).Count();
            int avgRate = 0;
            int totalRate = (rating1 + rating2 + rating3 + rating4 + rating5);
            if (totalRate != 0)
            {
                avgRate = (int)((rating1 * 1 + rating2 * 2 + rating3 * 3 + rating4 * 4 + rating5 * 5) / (rating1 + rating2 + rating3 + rating4 + rating5));
            }
            ReportForEachAccountVM resutl = new ReportForEachAccountVM()
            {
                TotalTicket = totalTicketsProcessed,
                Created = createTicket,
                Expired = expiredTicket,
                Solved = solvedTicket,
                Received = receivedTicket,
                Assigned = expiredTicket,
                AverageProcessingTime = avgProcessingTimeInSeconds,
                Rating1 = rating1,
                Rating2 = rating2,
                Rating3 = rating3,
                Rating4 = rating4,
                Rating5 = rating5,
                AverageRating = avgRate,
            };
            return resutl;
        }

        public List<ReportForEachAccount2VM> DailyReport2(DateTime fromDate, DateTime toDate)
        {
            var listCate = context.TblCategoryTickets.Include(x => x.TblTickets).ToList();
            var listAccount = context.TblAccounts.ToList();
            List<ReportForEachAccount2VM> result = new List<ReportForEachAccount2VM>();
            foreach (var item in listCate)
            {
                List<AccountProcess> accountProcesses = new List<AccountProcess>();
                foreach (var item2 in listAccount)
                {
                    var totalTicket = (from tc in context.TblTicketComments
                                       join t in context.TblTickets on tc.TicketId equals t.TicketId
                                       where t.CreateDate >= fromDate && t.CreateDate <= toDate
                                            && tc.AccountCreateId == item2.AccountId
                                            && t.CategoryTicketId == item.CategoryTicketId
                                       group tc by tc.AccountCreateId into g
                                       select new
                                       {
                                           TotalTicketsProcessed = g.Select(x => x.TicketId).Distinct().Count()
                                       }).FirstOrDefault()?.TotalTicketsProcessed ?? 0;
                    AccountProcess a = new AccountProcess()
                    {
                        Email = item2.Email,
                        Count = totalTicket,
                    };
                    accountProcesses.Add(a);
                }
                ReportForEachAccount2VM reportForEachAccount2VM = new ReportForEachAccount2VM()
                {
                    CategoryName = item.CategoryName,
                    Account = accountProcesses
                };
                result.Add(reportForEachAccount2VM);
            }
            return result;
        }

        public List<TicketReportVM> ViewReport(Guid? categoryId, string? titleTicket, Guid? studentId, string? status, DateTime? createDate, int sortDate, int sortTitle, int pageIndex, int pageSize)
        {
            List<TicketReportVM> result = new List<TicketReportVM>();
            List<TblTicketReport> query = context.TblTicketReports.Include(x => x.Ticket).ThenInclude(x => x.CategoryTicket)
                                                                  .ToList();

            if (categoryId.HasValue)
            {
                query = query.Where(x => x.Ticket.CategoryTicketId == categoryId).ToList();
            }

            if (!string.IsNullOrEmpty(titleTicket))
            {
                query = query.Where(x => x.Ticket.Title.Contains(titleTicket)).ToList();
            }

            if (studentId.HasValue)
            {
                query = query.Where(x => x.Ticket.AccountIdCreate == studentId).ToList();
            }

            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(x => x.Ticket.Status == status).ToList();
            }

            if (createDate.HasValue)
            {
                query = query.Where(x => x.CreateDate.Date == createDate.Value.Date).ToList();
            }

            if (sortDate == 1)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }
            else if (sortDate == -1)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }

            if (sortTitle == 1)
            {
                query = query.OrderBy(x => x.Ticket.Title).ToList();
            }
            else if (sortTitle == -1)
            {
                query = query.OrderByDescending(x => x.Ticket.Title).ToList();
            }

            query = query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();

            foreach (var item in query)
            {
                var staff = context.TblAccounts.Where(x => x.AccountId == item.AccountIdStaff).FirstOrDefault().Email;
                var student = context.TblAccounts.Where(x => x.AccountId == item.Ticket.AccountIdCreate).FirstOrDefault().Email;
                TicketReportVM ticketReportVM = new TicketReportVM()
                {
                    TicketReportId = item.TicketReportId,
                    TicketTitle = item.Ticket.Title,
                    Staff = staff,
                    Student = student,
                    Category = item.Ticket.CategoryTicket.CategoryName,
                    CreateDate = item.CreateDate,
                    Status = item.Ticket.Status
                };
                result.Add(ticketReportVM);
            }

            return result;
        }

        public List<ViewStaffWithStaffOtherVM> ViewStaffWithStaffOther(Guid? studentId, Guid? staffId, Guid? staffOtherId, Guid? cateId, string? title, DateTime? createDate, string? status, int sortTitle, int sortStatus, int sortDate, int pageIndex, int pageSize)
        {
            List<ViewStaffWithStaffOtherVM> result = new List<ViewStaffWithStaffOtherVM>();
            List<TblTicketDepartment> query = context.TblTicketDepartments.Include(x => x.Ticket).ToList();

            if (cateId.HasValue)
            {
                query = query.Where(x => x.CategoryTicketId == cateId).ToList();
            }

            if (!string.IsNullOrEmpty(title))
            {
                query = query.Where(x => x.Title.Contains(title)).ToList();
            }

            if (studentId.HasValue)
            {
                query = query.Where(x => x.Ticket.AccountIdCreate == studentId).ToList();
            }
            if (staffId.HasValue)
            {
                query = query.Where(x => x.AccountIdCreate == staffId).ToList();
            }
            if (staffOtherId.HasValue)
            {
                query = query.Where(x => x.AccountId == staffOtherId).ToList();
            }
            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(x => x.Status == status).ToList();
            }

            if (createDate.HasValue)
            {
                query = query.Where(x => x.CreateDate.Date == createDate.Value.Date).ToList();
            }

            if (sortDate == 1)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }
            else if (sortDate == -1)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }

            if (sortTitle == 1)
            {
                query = query.OrderBy(x => x.Title).ToList();
            }
            else if (sortTitle == -1)
            {
                query = query.OrderByDescending(x => x.Title).ToList();
            }

            if (sortStatus == 1)
            {
                query = query.OrderBy(x => x.Status).ToList();
            }
            else if (sortStatus == -1)
            {
                query = query.OrderByDescending(x => x.Status).ToList();
            }
            query = query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();

            foreach (var item in query)
            {
                var student = context.TblAccounts.Where(x => x.AccountId == item.Ticket.AccountIdCreate).FirstOrDefault().Email;
                var staff = context.TblAccounts.Where(x => x.AccountId == item.AccountIdCreate).FirstOrDefault().Email;
                var otherStaff = context.TblAccounts.Where(x => x.AccountId == item.AccountId).FirstOrDefault().Email;
                var category = context.TblCategoryTickets.Where(x => x.CategoryTicketId == item.CategoryTicketId).FirstOrDefault().CategoryName;
                ViewStaffWithStaffOtherVM viewStaffWithStaffOtherVM = new ViewStaffWithStaffOtherVM()
                {
                    Title = item.Title,
                    Student = student,
                    Staff = staff,
                    OtherStaff = otherStaff,
                    Category = item.CategoryTicket.CategoryName,
                    CreateDate = item.CreateDate,
                    Status = item.Status
                };
                result.Add(viewStaffWithStaffOtherVM);
            }

            return result;
        }


        //////////////////////
        ///
        public List<ReportForEachCategoryVM> ReportForEachAccount2(Guid userID, DateTime fromDate, DateTime toDate)
        {
            var listCategoryParent = context.TblCategoryTickets.Include(x => x.TblTickets).Where(x => x.CategoryTicketParentId == null).ToList();
            List<ReportForEachCategoryVM> result = new List<ReportForEachCategoryVM>();

            foreach (var categoryParent in listCategoryParent)
            {
                // Lấy danh sách sub category của category cha
                var listChildCategory = context.TblCategoryTickets.Include(x => x.TblTickets).Where(x => x.CategoryTicketParentId == categoryParent.CategoryTicketId).ToList();

                if (listChildCategory.Count == 0)
                {
                    // Lấy thông số của category cha
                    var reportParametersParent = GetReportParameters(userID, fromDate, toDate, categoryParent.CategoryTicketId);
                    List<CategoryChild> categoryChildren = new List<CategoryChild>();
                    ReportForEachCategoryVM reportForEachCategoryVM = new ReportForEachCategoryVM()
                    {
                        CategoryParenName = categoryParent.CategoryName,
                        CategoryChild = categoryChildren,
                        ReportParameterParens = reportParametersParent
                    };
                    result.Add(reportForEachCategoryVM);
                }
                else
                {
                    List<CategoryChild> categoryChildren = new List<CategoryChild>();
                    ReportParameters reportParametersParent = new ReportParameters();

                    foreach (var categoryChild in listChildCategory)
                    {
                        // Lấy thông số của sub category
                        var reportParametersChild = GetReportParameters(userID, fromDate, toDate, categoryChild.CategoryTicketId);
                        CategoryChild child = new CategoryChild()
                        {
                            CategoryChildName = categoryChild.CategoryName,
                            ReportParameters = reportParametersChild,
                        };
                        categoryChildren.Add(child);

                        // Tính tổng thông số của parent và child
                        reportParametersParent.TotalTicket += reportParametersChild.TotalTicket;
                        reportParametersParent.Created += reportParametersChild.Created;
                        reportParametersParent.Expired += reportParametersChild.Expired;
                        reportParametersParent.Solved += reportParametersChild.Solved;
                        reportParametersParent.Received += reportParametersChild.Received;
                        reportParametersParent.Assigned += reportParametersChild.Assigned;
                        reportParametersParent.AverageProcessingTime += reportParametersChild.AverageProcessingTime;
                        reportParametersParent.AverageRating += reportParametersChild.AverageRating;
                    }

                    // Lấy thông số của parent
                    var reportParametersParentOnly = GetReportParameters(userID, fromDate, toDate, categoryParent.CategoryTicketId);

                    // Cộng thêm thông số của parent vào tổng thông số
                    reportParametersParent.TotalTicket += reportParametersParentOnly.TotalTicket;
                    reportParametersParent.Created += reportParametersParentOnly.Created;
                    reportParametersParent.Expired += reportParametersParentOnly.Expired;
                    reportParametersParent.Solved += reportParametersParentOnly.Solved;
                    reportParametersParent.Received += reportParametersParentOnly.Received;
                    reportParametersParent.Assigned += reportParametersParentOnly.Assigned;
                    reportParametersParent.AverageProcessingTime += reportParametersParentOnly.AverageProcessingTime;
                    reportParametersParent.AverageRating += reportParametersParentOnly.AverageRating;

                    ReportForEachCategoryVM reportForEachCategoryVM = new ReportForEachCategoryVM()
                    {
                        CategoryParenName = categoryParent.CategoryName,
                        CategoryChild = categoryChildren,
                        ReportParameterParens = reportParametersParent
                    };
                    result.Add(reportForEachCategoryVM);
                }
            }

            return result;
        }
        private int GetTotalTicketForCategory(Guid userID, DateTime fromDate, DateTime toDate, Guid categoryTicketId)
        {
            return (from tc in context.TblTicketComments
                    join t in context.TblTickets on tc.TicketId equals t.TicketId
                    where tc.AccountCreateId == userID
                          && t.CreateDate >= fromDate && t.CreateDate <= toDate
                          && t.CategoryTicketId == categoryTicketId
                    group tc by tc.AccountCreateId into g
                    select new
                    {
                        TotalTicketsProcessed = g.Select(x => x.TicketId).Distinct().Count()
                    }).FirstOrDefault()?.TotalTicketsProcessed ?? 0;
        }

        private ReportParameters GetReportParameters(Guid userID, DateTime fromDate, DateTime toDate, Guid categoryTicketId)
        {
            var totalTicketChild = GetTotalTicketForCategory(userID, fromDate, toDate, categoryTicketId);
            int avgProcessingTimeInSeconds = 0;
            var averageProcessingTime = context.TblTickets
                .Where(t => t.AccountIdCreate == userID && t.CreateDate >= fromDate && t.CreateDate <= toDate && t.CategoryTicketId == categoryTicketId)
                .AsEnumerable()
                .Average(t => TicketReportRepository.GetTimeSpanTotalSeconds(modifyUpdate: t.ModifyUpdate, createDate: t.CreateDate));
            if (averageProcessingTime != null)
            {
                avgProcessingTimeInSeconds = (int)(averageProcessingTime);
            }

            // Lấy các ID của các trạng thái ticket
            var statusIds = new List<Guid>
            {
                new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45"),
                new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54"),
                new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50"),
                new Guid("810b802f-b503-4b5c-a929-7da50385234c"),
                new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7")
            };
            // Đếm số lượng ticket theo từng trạng thái
            var ticketCounts = context.TblTickets
                .Join(context.TblStatusTickets,
                      t => t.StatusTicketId,
                      st => st.StatusTicketId,
                      (t, st) => new { Ticket = t, StatusTicket = st })
                .Where(joinResult => statusIds.Contains(joinResult.StatusTicket.StatusTicketId) && joinResult.Ticket.CategoryTicketId == categoryTicketId)
                .GroupBy(joinResult => joinResult.StatusTicket.StatusTicketId)
                .Select(g => new { StatusTicketId = g.Key, Count = g.Count() })
                .ToDictionary(x => x.StatusTicketId, x => x.Count);

            int createTicket = ticketCounts.GetValueOrDefault(new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45"));
            int expiredTicket = ticketCounts.GetValueOrDefault(new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54"));
            int solvedTicket = ticketCounts.GetValueOrDefault(new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50"));
            int receivedTicket = ticketCounts.GetValueOrDefault(new Guid("810b802f-b503-4b5c-a929-7da50385234c"));
            int assignedTicket = ticketCounts.GetValueOrDefault(new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7"));

            // Tính trung bình rating
            int rating1 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("1") && feedback.AccountIdStaff == userID && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating2 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("2") && feedback.AccountIdStaff == userID && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating3 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("3") && feedback.AccountIdStaff == userID && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating4 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("4") && feedback.AccountIdStaff == userID && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating5 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("5") && feedback.AccountIdStaff == userID && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int avgRate = 0;
            int totalRate = (rating1 + rating2 + rating3 + rating4 + rating5);
            if (totalRate != 0)
            {
                avgRate = (int)((rating1 * 1 + rating2 * 2 + rating3 * 3 + rating4 * 4 + rating5 * 5) / (rating1 + rating2 + rating3 + rating4 + rating5));
            }

            return new ReportParameters()
            {
                TotalTicket = totalTicketChild,
                Created = createTicket,
                Expired = expiredTicket,
                Solved = solvedTicket,
                Received = receivedTicket,
                Assigned = assignedTicket,
                AverageProcessingTime = avgProcessingTimeInSeconds,
                AverageRating = avgRate,
            };
        }

        //////

        public List<ReportForEachCategoryVM> SynthesisReport2(DateTime fromDate, DateTime toDate)
        {
            var listCategoryParent = context.TblCategoryTickets.Include(x => x.TblTickets).Where(x => x.CategoryTicketParentId == null).ToList();
            List<ReportForEachCategoryVM> result = new List<ReportForEachCategoryVM>();

            foreach (var categoryParent in listCategoryParent)
            {
                // Lấy danh sách sub category của category cha
                var listChildCategory = context.TblCategoryTickets.Include(x => x.TblTickets).Where(x => x.CategoryTicketParentId == categoryParent.CategoryTicketId).ToList();

                if (listChildCategory.Count == 0)
                {
                    // Lấy thông số của category cha
                    var reportParametersParent = GetReportParameters1(fromDate, toDate, categoryParent.CategoryTicketId);
                    List<CategoryChild> listChild = new List<CategoryChild>();
                    ReportForEachCategoryVM reportForEachCategoryVM = new ReportForEachCategoryVM()
                    {
                        CategoryParenName = categoryParent.CategoryName,
                        CategoryChild = listChild,
                        ReportParameterParens = reportParametersParent
                    };
                    result.Add(reportForEachCategoryVM);
                }
                else
                {
                    List<CategoryChild> categoryChildren = new List<CategoryChild>();
                    ReportParameters reportParametersParent = new ReportParameters();

                    foreach (var categoryChild in listChildCategory)
                    {
                        // Lấy thông số của sub category
                        var reportParametersChild = GetReportParameters1(fromDate, toDate, categoryChild.CategoryTicketId);
                        CategoryChild child = new CategoryChild()
                        {
                            CategoryChildName = categoryChild.CategoryName,
                            ReportParameters = reportParametersChild,
                        };
                        categoryChildren.Add(child);

                        // Tính tổng thông số của parent và child
                        reportParametersParent.TotalTicket += reportParametersChild.TotalTicket;
                        reportParametersParent.Created += reportParametersChild.Created;
                        reportParametersParent.Expired += reportParametersChild.Expired;
                        reportParametersParent.Solved += reportParametersChild.Solved;
                        reportParametersParent.Received += reportParametersChild.Received;
                        reportParametersParent.Assigned += reportParametersChild.Assigned;
                        reportParametersParent.AverageProcessingTime += reportParametersChild.AverageProcessingTime;
                        reportParametersParent.AverageRating += reportParametersChild.AverageRating;
                    }

                    // Lấy thông số của parent
                    var reportParametersParentOnly = GetReportParameters1(fromDate, toDate, categoryParent.CategoryTicketId);

                    // Cộng thêm thông số của parent vào tổng thông số
                    reportParametersParent.TotalTicket += reportParametersParentOnly.TotalTicket;
                    reportParametersParent.Created += reportParametersParentOnly.Created;
                    reportParametersParent.Expired += reportParametersParentOnly.Expired;
                    reportParametersParent.Solved += reportParametersParentOnly.Solved;
                    reportParametersParent.Received += reportParametersParentOnly.Received;
                    reportParametersParent.Assigned += reportParametersParentOnly.Assigned;
                    reportParametersParent.AverageProcessingTime += reportParametersParentOnly.AverageProcessingTime;
                    reportParametersParent.AverageRating += reportParametersParentOnly.AverageRating;

                    ReportForEachCategoryVM reportForEachCategoryVM = new ReportForEachCategoryVM()
                    {
                        CategoryParenName = categoryParent.CategoryName,
                        CategoryChild = categoryChildren,
                        ReportParameterParens = reportParametersParent
                    };
                    result.Add(reportForEachCategoryVM);
                }
            }

            return result;
        }
        private int GetTotalTicketForCategory1(DateTime fromDate, DateTime toDate, Guid categoryTicketId)
        {
            return (from tc in context.TblTicketComments
                    join t in context.TblTickets on tc.TicketId equals t.TicketId
                    where t.CreateDate >= fromDate && t.CreateDate <= toDate
                          && t.CategoryTicketId == categoryTicketId
                    group tc by tc.AccountCreateId into g
                    select new
                    {
                        TotalTicketsProcessed = g.Select(x => x.TicketId).Distinct().Count()
                    }).FirstOrDefault()?.TotalTicketsProcessed ?? 0;
        }

        private ReportParameters GetReportParameters1(DateTime fromDate, DateTime toDate, Guid categoryTicketId)
        {
            var totalTicketChild = GetTotalTicketForCategory1(fromDate, toDate, categoryTicketId);
            int avgProcessingTimeInSeconds = 0;
            var averageProcessingTime = context.TblTickets
                .Where(t => t.CreateDate >= fromDate && t.CreateDate <= toDate && t.CategoryTicketId == categoryTicketId)
                .AsEnumerable()
                .Average(t => TicketReportRepository.GetTimeSpanTotalSeconds(modifyUpdate: t.ModifyUpdate, createDate: t.CreateDate));
            if (averageProcessingTime != null)
            {
                avgProcessingTimeInSeconds = (int)(averageProcessingTime);
            }

            // Lấy các ID của các trạng thái ticket
            var statusIds = new List<Guid>
            {
                new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45"),
                new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54"),
                new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50"),
                new Guid("810b802f-b503-4b5c-a929-7da50385234c"),
                new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7")
            };
            // Đếm số lượng ticket theo từng trạng thái
            var ticketCounts = context.TblTickets
                .Join(context.TblStatusTickets,
                      t => t.StatusTicketId,
                      st => st.StatusTicketId,
                      (t, st) => new { Ticket = t, StatusTicket = st })
                .Where(joinResult => statusIds.Contains(joinResult.StatusTicket.StatusTicketId) && joinResult.Ticket.CategoryTicketId == categoryTicketId)
                .GroupBy(joinResult => joinResult.StatusTicket.StatusTicketId)
                .Select(g => new { StatusTicketId = g.Key, Count = g.Count() })
                .ToDictionary(x => x.StatusTicketId, x => x.Count);

            int createTicket = ticketCounts.GetValueOrDefault(new Guid("7d2d2ebe-bc30-4631-a679-12a238ea2f45"));
            int expiredTicket = ticketCounts.GetValueOrDefault(new Guid("7b57e41c-aaea-4fa7-bf2c-2d58b67bbd54"));
            int solvedTicket = ticketCounts.GetValueOrDefault(new Guid("fd6e17b5-c63d-42b6-bd10-40fb98629c50"));
            int receivedTicket = ticketCounts.GetValueOrDefault(new Guid("810b802f-b503-4b5c-a929-7da50385234c"));
            int assignedTicket = ticketCounts.GetValueOrDefault(new Guid("411c603f-3f61-40d1-802b-d1811d4f3aa7"));

            // Tính trung bình rating
            int rating1 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("1") && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating2 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("2") && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating3 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("3") && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating4 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("4") && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int rating5 = context.TblTicketFeedbacks.Count(feedback => feedback.Rate.Equals("5") && feedback.Ticket.CategoryTicketId == categoryTicketId);
            int avgRate = 0;
            int totalRate = (rating1 + rating2 + rating3 + rating4 + rating5);
            if (totalRate != 0)
            {
                avgRate = (int)((rating1 * 1 + rating2 * 2 + rating3 * 3 + rating4 * 4 + rating5 * 5) / (rating1 + rating2 + rating3 + rating4 + rating5));
            }

            return new ReportParameters()
            {
                TotalTicket = totalTicketChild,
                Created = createTicket,
                Expired = expiredTicket,
                Solved = solvedTicket,
                Received = receivedTicket,
                Assigned = assignedTicket,
                AverageProcessingTime = avgProcessingTimeInSeconds,
                AverageRating = avgRate,
            };
        }
    }
}

