﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class AccountRepository : GennericRepository<TblAccount>, IAccountRepository
    {

        public AccountRepository(ScmsContext context = null) : base(context) { }

        public TblAccount GetAccount(string email)
        {
            return context.TblAccounts.Include(x => x.TblAccountRoles).Include(x => x.Campus).Include(x => x.StatusAccount).SingleOrDefault(x => x.Email == email && x.IsDelete == true);
        }

        public TblAccount GetAccountByEmaill(string email)
        {
            return context.TblAccounts.Include(x => x.TblAccountRoles).Include(x => x.Campus).Include(x => x.StatusAccount).SingleOrDefault(x => x.Email.ToLower() == email.ToLower());
        }
        public TblAccount GetAccountByEmaillAndCampusAndEducation(string email, Guid campus, Guid education)
        {
            return context.TblAccounts
                .Include(x => x.TblAccountRoles).Include(x => x.Campus)
                .Include(x => x.StatusAccount)
                .SingleOrDefault(x => x.Email.ToLower() == email.ToLower() && x.CampusId == campus && x.EducationId == education);
        }

        public TblAccount GetAccountById(Guid? id)
        {
            return context.TblAccounts.Include(x => x.TblAccountRoles).Include(x => x.Campus).Include(x => x.StatusAccount)
                .SingleOrDefault(x => x.AccountId.ToString().ToLower() == id.ToString().ToLower());
        }

        public List<TblAccount> GetAccountByName(string name)
        {
            return context.TblAccounts.Include(x => x.TblAccountRoles).Include(x => x.Campus).Include(x => x.StatusAccount).Where(x => x.FirstName.ToString().ToLower().StartsWith(name) || x.LastName.ToString().ToLower().StartsWith(name)).ToList();
        }

        public (int, List<ExEmployee>) GetEmployees(string searchEmail, int sortDate, int pageIndex, int pageSize)
        {
            var query = context.GetAllEmployeesWithFilters(searchEmail, sortDate).Result;
            return (query.Count, query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList());
        }

        public List<ExStatusAccount> GetAllStatusAccount()
        {
            var query = context.GetAllStatusAccount().Result;
            return query.ToList();
        }
        public bool UpdateEmployee(ExEmployee employee_update, List<TblRole> responRoles)
        {
            Guid accountId = employee_update.EmployeeId;
            var employee = context.TblAccounts.FirstOrDefault(e => e.AccountId == accountId);
            if (employee != null)
            {
                employee.FirstName = employee_update.Firstname;
                employee.LastName = employee_update.Lastname;
                employee.Phone = employee_update.Phone;
                employee.Address = employee_update.Address;
                employee.CampusId = employee_update.CampusId;
                employee.StatusAccountId = employee_update.StatusId;
                employee.DepartmentId = employee_update.DepartmentId;
                employee.ModifyUpdate = DateTime.Now;

                List<TblAccountRole> currentAccountRoles = context.TblAccountRoles.Where(ar => ar.AccountId == accountId).ToList();
                //Remove all in currentAccountRoles
                foreach (var currentRole in currentAccountRoles)
                {
                    context.TblAccountRoles.Remove(currentRole);
                }
                //Add from responRoles
                foreach (var role in responRoles)
                {
                    TblAccountRole addRole = new TblAccountRole();
                    addRole.AccountId = accountId;
                    addRole.RoleId = role.RoleId;
                    addRole.CreateDate = role.CreateDate;
                    context.TblAccountRoles.Add(addRole);
                }

                context.SaveChanges();
                return true;
            }
            return false;
        }

        public bool AddEmployee(ExEmployee employee_update, List<TblRole> responRoles)
        {
            if (employee_update.EmployeeEmail == null || employee_update.EmployeeEmail == "")
            {
                return false;
            }
            var findEmployee = context.TblAccounts.FirstOrDefault(a => a.Email == employee_update.EmployeeEmail);
            if (findEmployee == null)
            {
                TblAccount employee = new TblAccount();
                employee.Email = employee_update.EmployeeEmail;
                employee.FirstName = employee_update.Firstname;
                employee.LastName = employee_update.Lastname;
                employee.Phone = employee_update.Phone;
                employee.Address = employee_update.Address;
                employee.CampusId = employee_update.CampusId;
                employee.StatusAccountId = employee_update.StatusId;
                employee.DepartmentId = employee_update.DepartmentId;
                employee.ModifyUpdate = DateTime.Now;
                employee.CreateDate = DateTime.Now;

                context.TblAccounts.Add(employee);
                context.SaveChanges();
                var accountId = context.TblAccounts.FirstOrDefault(a => a.Email == employee_update.EmployeeEmail).AccountId;

                //Add from responRoles
                foreach (var role in responRoles)
                {
                    TblAccountRole addRole = new TblAccountRole();
                    addRole.AccountId = accountId;
                    addRole.RoleId = role.RoleId;
                    addRole.CreateDate = role.CreateDate;
                    context.TblAccountRoles.Add(addRole);
                }

                context.SaveChanges();
                return true;

            }

            return false;
        }

        public List<TblAccount> GetListUserJoinTicket(Guid ticketId)
        {
            return context.TblAccounts
                .Include(x => x.TblTicketComments)
                .Include(x => x.TblTicketAccountIdCreateNavigations)
                .Where(x => x.TblTicketComments.Any(z => z.TicketId == ticketId && z.Ticket.AccountIdCreate != x.AccountId))
                .ToList();
        }

        public List<TblAccount> GetStaff(Guid? roleId)
        {
            //update id role staff
            return context.TblAccounts.Include(x => x.TblAccountRoles).Include(x => x.Campus).Include(x => x.StatusAccount).Where(x => x.TblAccountRoles.Any(z => z.RoleId == roleId)).ToList();
        }

        public TblAccount GetViewAuthority(Guid pageCrudId, Guid accountId)
        {
            TblAccount account = GetAccountById(accountId);
            foreach (var item in account.TblAccountRoles)
            {
                TblPageRole pageRole = context.TblPageRoles.Include(x => x.PageCrud).Include(x => x.PageCrud.Page)
                    .FirstOrDefault(x => x.RoleId == item.RoleId && x.PageCrudId == pageCrudId);
                // && x.PageCrud.IsDelete == false && x.PageCrud.Page.IsDelete == false


                if (pageRole != null)
                {
                    TblPageCrud pageCrud = context.TblPageCruds.FirstOrDefault(x => x.PageCrudId == pageRole.PageCrudId && x.IsDelete == false);

                    if (pageCrud != null)
                    {
                        TblPage page = context.TblPages.FirstOrDefault(x => x.PageId == pageCrud.PageId && x.IsDelete == false);
                        if (page != null)
                        {
                            return account;
                        }
                    }
                }
            }

            return null;
        }

        public TblAccount GetPageAuthority(string name, Guid userId)
        {
            TblAccount account = GetAccountById(userId);

            foreach (var item in account.TblAccountRoles)
            {
                var pageRoles = context.TblPageRoles.Include(x => x.PageCrud).Include(x => x.PageCrud.Page)
                    .Where(x => x.RoleId == item.RoleId
                    && x.PageCrud.Page.PageName.ToLower() == name.ToLower()
                  ).ToList();

                if (pageRoles != null && pageRoles.Count() > 0)
                {
                    return account;
                }
            }


            return null;
        }

        public bool DeleteAccountByAccountId(Guid accountId)
        {
            TblAccount account = context.TblAccounts.FirstOrDefault(a => a.AccountId == accountId);
            if (account != null)
            {
                account.IsDelete = true;
                context.SaveChanges();
                return true;
            }
            return false;
        }

        public List<TblAccount> GetEmailByRole(Guid userID, string? gmail)
        {
            List<TblAccount> result = new List<TblAccount>();
            var listAccountRole = context.TblAccountRoles.Where(x => x.AccountId == userID).ToList();
            foreach (var item in listAccountRole)
            {
                var emails = context.TblAccounts
                    .Where(a => a.TblAccountRoles.Any(r => r.RoleId == item.RoleId) && a.Email.Contains(gmail))
                    .ToList();
                result.AddRange(emails);
            }
            return result;
        }

        public AccountInforVM GetInforUser(Guid userID)
        {
            var inforUser = context.TblAccounts.Include(x => x.Campus).Include(x => x.Department).Include(x => x.Education).FirstOrDefault(x => x.AccountId == userID);
            List<string> listRole = new List<string>();
            var role = context.TblAccountRoles.Include(x => x.Role).Where(x => x.AccountId == userID).ToList();
            foreach (var item in role)
            {
                string name = item.Role.RoleName;
                listRole.Add(name);
            }

            AccountInforVM result = new AccountInforVM()
            {
                FirstName = inforUser.FirstName,
                LastName = inforUser.LastName,
                Address = inforUser.Address,
                Campus = inforUser.Campus.CampusName,
                CreateDate = inforUser.CreateDate,
                Department = inforUser.Department.DepartmentName,
                Education = inforUser.Education.EducationName,
                Email = inforUser.Email,
                Phone = inforUser.Phone,
                Picture = inforUser.Picture,
                Role = listRole,
            };
            return result;
        }
    }
}
