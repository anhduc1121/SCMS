﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class PageCrudRepository : GennericRepository<TblPageCrud>, IPageCrudRepository
    {
        public PageCrudRepository(ScmsContext context = null) : base(context)
        {
        }

        public List<TblPageCrud> GetAllByPage(Guid pageId)
        {
            return context.TblPageCruds.Include(x => x.TblPageRoles).Where(x => x.PageId == pageId).ToList();
        }

        public TblPageCrud DeletePageCrudById(Guid pageCrudId)
        {
            TblPageCrud pageCrudItem = context.TblPageCruds.Include(x => x.TblPageRoles).FirstOrDefault(x => x.PageCrudId == pageCrudId);
            if (pageCrudItem != null)
            {
                pageCrudItem.IsDelete = true;
            }
            context.SaveChanges();

            return pageCrudItem;
        }

        public TblPageCrud GetPageCrudById(Guid pageCrudId)
        {
            TblPageCrud pageCrudItem = context.TblPageCruds.Include(x => x.TblPageRoles).FirstOrDefault(x => x.PageCrudId == pageCrudId);

            return pageCrudItem;
        }
    }
}
