﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using System.Data;

namespace SCMS_Repository.ImplementRepository
{
    public class RoleRepository : GennericRepository<TblRole>, IRoleRepository
    {
        public RoleRepository(ScmsContext context = null) : base(context) { }
        public List<TblRole> GetRoles()
        {
            return context.TblRoles.Where(x => x.IsDelete == false).ToList();
        }

        public (int, List<TblRole>) GetRolesByCondition(string RoleName, int? pageIndex = 1, int? pageSize = 5, int? sortCreateDate = 0)
        {
            List<TblRole> query = context.TblRoles.Where(x => x.IsDelete == false).ToList();

            if (!String.IsNullOrEmpty(RoleName))
            {
                query = query.Where(x => x.RoleName.ToLower().Contains(RoleName.ToLower())).ToList();
            }

            if (sortCreateDate == 1)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            if (sortCreateDate == 2)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }

            return (query.Count, query.Skip((int)((pageIndex - 1) * pageSize)).Take((int)pageSize).ToList());
        }

        public TblRole CreateRole(string RoleName, List<Guid> functionIds)
        {
            var existingRole = context.TblRoles
                .Include(r => r.TblFuntionGroups).Where(x => x.IsDelete == false)
                .ToList() // Lấy dữ liệu từ cơ sở dữ liệu thành danh sách ở phía máy chủ
                .FirstOrDefault(
                r =>
                    r.TblFuntionGroups
                        .Select(fg => fg.FunctionActionApi)
                        .SequenceEqual(functionIds
                        ));
            if (existingRole != null)
            {
                return null;
            }
            else
            {
                var newRole = new TblRole
                {
                    RoleName = RoleName,
                };

                foreach (var funtionGroups in functionIds)
                {
                    var pageFunctionApi = new TblFuntionGroup
                    {
                        FunctionActionApi = funtionGroups,
                    };
                    newRole.TblFuntionGroups.Add(pageFunctionApi);
                }

                context.TblRoles.Add(newRole);
                context.SaveChanges();

                return newRole;
            }
        }

        public TblRole UpdateRole(Guid RoleId, string RoleName, List<Guid> functionIds)
        {
            var existingRole = context.TblRoles
                .Include(r => r.TblFuntionGroups)
                .ToList() // Lấy dữ liệu từ cơ sở dữ liệu thành danh sách ở phía máy chủ
                .FirstOrDefault(
                r =>
                r.RoleId != RoleId &&
                    r.TblFuntionGroups
                        .Select(fg => fg.FunctionActionApi)
                        .SequenceEqual(functionIds
                        ));
            if (existingRole != null && functionIds.Count > 0)
            {
                return null;
            }
            else
            {
                TblRole role = context.TblRoles.Include(x => x.TblFuntionGroups).FirstOrDefault(x => x.RoleId == RoleId);
                role.RoleName = RoleName;
                role.TblFuntionGroups = new List<TblFuntionGroup>();

                foreach (var funtionGroups in functionIds)
                {
                    var pageFunctionApi = new TblFuntionGroup
                    {
                        FunctionActionApi = funtionGroups,
                    };
                    role.TblFuntionGroups.Add(pageFunctionApi);
                }

                context.TblRoles.Update(role);
                context.SaveChanges();

                return role;
            }
        }

        public TblRole DeleteRole(Guid RoleId)
        {
            TblRole role = context.TblRoles.FirstOrDefault(x => x.RoleId == RoleId);
            role.IsDelete = true;
            context.SaveChanges();
            return role;
        }

        public List<TblRole> GetRoleByRoleFeid(Guid idRoleFeid)
        {
            return context.TblRoles.Where(x => x.TblRoleSystemRoleFeids.Any(z => z.RoleFeidId == idRoleFeid)).ToList();
        }

        public List<TblRole> GetRolesByRoleIds(List<Guid> idRoles)
        {
            return context.TblRoles.Where(x => idRoles.Any(z => z == x.RoleId)).ToList();
        }

        public List<TblRole> GetRolesByAccountId(Guid accountId)
        {
            return context.TblRoles.Where(r => r.TblAccountRoles.Any(a => a.AccountId == accountId)).ToList();
        }

        public List<TblAccountRole> GetListAccountRoleByAccountId(Guid accountId)
        {
            return context.TblAccountRoles.Where(ar => ar.AccountId == accountId).ToList();
        }
    }
}
