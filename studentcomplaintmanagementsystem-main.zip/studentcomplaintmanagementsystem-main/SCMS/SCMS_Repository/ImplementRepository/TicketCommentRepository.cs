﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketCommentRepository : GennericRepository<TblTicketComment>, ITicketCommentRepository
    {
        public TicketCommentRepository(ScmsContext context = null) : base(context) { }

        public TblAccount GetAccountInfor(Guid ticketCommentId)
        {
            var ticketComments = context.TblTicketComments.FirstOrDefault(x => x.TicketCommentId == ticketCommentId);
            if (ticketComments.AccountCreateId == null)
            {
                var ticket = context.TblTickets.FirstOrDefault(t => t.TicketId == ticketComments.TicketId);
                if (ticket != null)
                {
                    return context.TblAccounts.FirstOrDefault(t => t.AccountId == ticket.AccountIdCreate);
                }
            }
            else
            {
                return context.TblAccounts.FirstOrDefault(account => account.AccountId == ticketComments.AccountCreateId);
            }
            return null;
        }

        public List<TblTicketAttachment> GetCommentAttachmentById(Guid ticketCommentId)
        {
            return context.TblTicketAttachments.Where(t => t.TicketCommentId == ticketCommentId).ToList();
        }

        public List<TblTicketComment> ListCommentsByTicketId(Guid ticketId)
        {
            return context.TblTicketComments
                    .Where(comment => comment.TicketId == ticketId)
                    .Include(x => x.TblTicketAttachments)
                    .Include(x => x.AccountCreate)
                    .OrderBy(comment => comment.CreateDate)
                    .ToList();
        }
    }
}
