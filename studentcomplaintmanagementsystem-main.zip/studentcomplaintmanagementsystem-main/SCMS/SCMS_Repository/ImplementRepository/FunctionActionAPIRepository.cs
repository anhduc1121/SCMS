﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class FunctionActionAPIRepository : GennericRepository<TblFunctionActionApi>, IFunctionActionAPIRepository
    {
        //
        public FunctionActionAPIRepository(ScmsContext context = null) : base(context) { }

        public TblFunctionActionApi GetTblFunctionActionApiByControllerAndAction(string controller, string action)
        {
            return context.TblFunctionActionApis.FirstOrDefault(x => x.FuntionNameController.Equals(controller) && x.FuntionNameAction.Equals(action));
        }

        public TblFunctionActionApi GetCheckRoleFunction(string controller, string action, Guid? userID)
        {
            return context.TblFunctionActionApis.FirstOrDefault(x => x.TblFuntionGroups.Any(z => z.Role.TblAccountRoles.Any(k => k.AccountId == userID))
            && x.FuntionNameController == controller
             && x.FuntionNameAction == action
            );
        }

        public TblFunctionActionApi GetTblFunctionActionApiById(Guid? id)
        {
            return context.TblFunctionActionApis.FirstOrDefault(x => x.FunctionActionApiId.ToString().ToLower().Equals(id.ToString().ToLower()));
        }

        public List<TblFunctionActionApi> GetFunctionActionApiByIdRole(Guid roleId)
        {
            return context.TblFunctionActionApis.Include(x => x.TblFuntionGroups).Where(x => x.TblFuntionGroups.Any(z => z.RoleId == roleId)).ToList();
        }

        public List<TblFunctionActionApi> GetAllFunctionActionApi()
        {
            return context.TblFunctionActionApis.ToList();
        }
    }
}
