﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketHandlingRepository : GennericRepository<TblTicketHandling>, ITicketHandlingRepository
    {

        public TicketHandlingRepository(ScmsContext context = null) : base(context) { }

        public List<TblTicketHandling> GetChildTicketHandlings(Guid ticketId)
        {
            return context.TblTicketHandlings
                .Include(x => x.TicketHandlingParent)
                .Include(x => x.TicketHandlingStatus)
                .Include(x => x.InverseTicketHandlingParent)
                .Where(h => h.TicketHandlingParentId != null && h.TicketHandlingParentId == ticketId).ToList();
        }

        public string GetColorForStatus(Guid statusId)
        {
            var ticketHandlingStatus = context.TblTicketHandlings
                 .Include(x => x.TicketHandlingStatus)
                 .FirstOrDefault(h => h.TicketHandlingStatusId == statusId);

            if (ticketHandlingStatus != null)
            {
                return ticketHandlingStatus.TicketHandlingStatus.ColorStatus;
            }
            else
            {
                return "gray";
            }
        }

        public List<TblTicketHandling> GetParentTicketHandlings(Guid ticketId)
        {
            return context.TblTicketHandlings
                .Include(x => x.TicketHandlingStatus)
                .Include(x => x.InverseTicketHandlingParent)
                 .Where(h => h.TicketHandlingParentId == null && h.TicketId == ticketId).ToList();
        }

        public List<TblTicketHandling> GetTicketHandlingsByTicketId(Guid ticketId)
        {
            return context.TblTicketHandlings
                .Include(x => x.TicketHandlingStatus)
                .Include(x => x.InverseTicketHandlingParent)
                .Where(h => h.TicketId == ticketId && h.IsAccpect == true).OrderBy(x => x.CreateDate).ToList();
        }

        public List<TblTicketHandling> GetAllByTicketId(Guid ticketId)
        {
            return context.TblTicketHandlings
                .Include(x => x.TicketHandlingStatus)
                .Include(x => x.InverseTicketHandlingParent)
                .Where(h => h.TicketId == ticketId).ToList();
        }

        public void UpdateAccpect(Guid ticketHandlingsId, bool isAccpect)
        {
            TblTicketHandling ticketHandling = context.TblTicketHandlings.FirstOrDefault(x => x.TicketHandlingId == ticketHandlingsId && x.IsAccpect != isAccpect);

            if (ticketHandling != null)
            {
                ticketHandling.IsAccpect = isAccpect;
                context.SaveChanges();
            }
        }
    }
}
