﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TagTicketRepository : GennericRepository<TblTagTicket>, ITagTicketRepository
    {
        public TagTicketRepository(ScmsContext context = null) : base(context) { }

        public TblTagTicket GetTagTicketByTagId(Guid tagticketId)
        {
            var tagTicket = context.TblTagTickets
                .Include(x => x.Ticket)
                .Include(x => x.Ticket.CategoryTicket)
                 .Include(x => x.TblTagTicketAttachments)
                 .Include(x => x.RequiredAccount)
                 .Include(x => x.AccountCreate)
                 .FirstOrDefault(tag => tag.TagTicketId == tagticketId);
            return tagTicket;
        }

        /// <summary>
        /// Đang set up dở
        /// </summary>
        /// <param name="tagTicketId"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public TblTagTicket UpdateUserTag(Guid tagTicketId, string status)
        {
            var userTag = context.TblTagTickets.Include(x => x.AccountCreate).FirstOrDefault(ut => ut.TagTicketId == tagTicketId);
            if (status == "1")
            {
                var tagAccpect = context.TblTagTickets.Include(x => x.AccountCreate).FirstOrDefault(x => x.TicketId == userTag.TicketId && x.IsAccept == "1");
                if (tagAccpect != null)
                {
                    TblTicket tblTicket = context.TblTickets.Include(x => x.CategoryTicket).FirstOrDefault(x => x.TicketId == userTag.TicketId);

                    TblNotification notification = new TblNotification();
                    notification.Title = "Staff " + userTag.AccountCreate.Email + " will be in charge of processing your application";
                    notification.UrlSulg = "complaint/details/" + tblTicket.TicketId;
                    notification.Content = "Staff " + userTag.AccountCreate.Email + " has accepted to handle your application on behalf of staff " + tagAccpect.AccountCreate.Email;
                    notification.AccountId = (Guid)tagAccpect.RequiredAccountId;

                    tagAccpect.IsAccept = "2";
                }
            }
            if (userTag != null)
            {

                // Thêm thông báo cho userTag đã nhận và thông báo cho cả sinh viên


                userTag.IsAccept = status;
            }

            context.SaveChanges();
            return userTag;
        }

        public List<TblTagTicket> ViewUserTag(Guid ticketId)
        {
            var tagTickets = context.TblTagTickets
                .Include(x => x.Ticket)
                .Include(x => x.RequiredAccount)
                .Include(x => x.AccountCreate)
                .Include(x => x.TblTagTicketAttachments)
                .Where(tag => tag.TicketId == ticketId).ToList();
            return tagTickets;
        }

        public Boolean IsUserTagExist(Guid ticketId, string gmail)
        {
            return context.TblTagTickets.Where(x => x.TicketId == ticketId && x.RequiredAccount.Email.StartsWith(gmail)).Any();
        }
    }
}
