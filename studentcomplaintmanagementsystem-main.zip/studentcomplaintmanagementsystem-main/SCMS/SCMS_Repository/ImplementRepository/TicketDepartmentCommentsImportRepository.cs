﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketDepartmentCommentsImportRepository : GennericRepository<TblTicketDepartmentCommentsImport>, ITicketDepartmentCommentsImportRepository
    {
        public TicketDepartmentCommentsImportRepository(ScmsContext context = null) : base(context) { }

        public List<TblTicketDepartmentCommentsImport> GetAllByTicketDepartmentId(Guid? ticketDepartmentId)
        {
            return context.TblTicketDepartmentCommentsImports.Include(x => x.TblTicketDepartmentAttachments).Where(x => x.TicketDepartmentsId == ticketDepartmentId).ToList();
        }
    }
}
