﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class RoleFeidRepository : GennericRepository<TblRoleFeid>, IRoleFeidRepository
    {
        public RoleFeidRepository(ScmsContext context = null) : base(context) { }

        public TblRoleFeid GetRoleByName(string roleName)
        {
            return context.TblRoleFeids.FirstOrDefault(x => x.RoleFeidName == roleName);
        }
    }
}
