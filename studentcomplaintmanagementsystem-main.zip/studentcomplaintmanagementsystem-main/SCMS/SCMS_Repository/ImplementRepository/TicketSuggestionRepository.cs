﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TicketSuggestionRepository : GennericRepository<TblTicketSuggestion>, ITicketSuggestionRepository
    {
        public TicketSuggestionRepository(ScmsContext context = null) : base(context) { }

        public TblTicketSuggestion CreateTicketSuggestion(string description, Guid categoryTicketId, Guid accountCreatorId)
        {
            var newSuggestion = new TblTicketSuggestion
            {
                Description = description,
                CategoryTicketId = categoryTicketId,
                IsDelete = false,
                IsAccept = false,
                AccountCreatorId = accountCreatorId,
            };
            context.TblTicketSuggestions.Add(newSuggestion);
            context.SaveChanges();

            return newSuggestion;
        }

        public TblTicketSuggestion DeleteTicketSuggestion(Guid ticketSuggestionId)
        {
            var tblTicket = context.TblTicketSuggestions.FirstOrDefault(x => x.TicketSuggestionId == ticketSuggestionId);
            if (tblTicket == null)
                throw new ArgumentException("Ticket Suggestion not found.");

            tblTicket.IsDelete = true;
            context.SaveChanges();

            return tblTicket;


        }

        public (int, List<TblTicketSuggestion>) GetAllTicketSuggestion(string? question, Guid? cateId, DateTime? createDate, int pageIndex = 1, int pageSize = 5, int sortQuestion = 0, int sortDate = 0)
        {
            var query = context.TblTicketSuggestions
                           .Include(x => x.CategoryTicket)
                           .Include(x => x.AccountCreator)
                           .Where(x => !x.IsDelete && x.RequestUpdate == null)
                           .ToList();

            if (!string.IsNullOrEmpty(question) && query.Count > 0)
            {
                query = query.Where(x => x.Description.StartsWith(question)).ToList();
            }

            if (cateId != null && query.Count > 0)
            {
                query = query.Where(x => x.CategoryTicketId == cateId).ToList();
            }

            if (createDate != null && query.Count > 0)
            {
                query = query.Where(x => x.CreateDate.Date == createDate?.Date && x.CreateDate.Month == createDate?.Month && x.CreateDate.Year == createDate?.Year).ToList();
            }

            // Sort
            if (sortQuestion == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.Description).ToList();
            }

            if (sortQuestion == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.Description).ToList();
            }

            if (sortDate == 1 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }

            if (sortDate == 2 && query.Count > 0)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            // Danh sách bản cần lấy
            return (query.Count, query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList());
        }

        public TblTicketSuggestion GetTblTicketSuggestionByID(Guid? id)
        {
            return context.TblTicketSuggestions
                .Include(x => x.CategoryTicket)
                .Include(x => x.TblTicketSuggestionDetails)
                .FirstOrDefault(x => x.TicketSuggestionId == id);
        }

        public List<TblTicketSuggestion> GetTblTicketSuggestionByIDCaterory(Guid? id)
        {
            return context.TblTicketSuggestions.Include(x => x.CategoryTicket).Include(x => x.TblTicketSuggestionDetails)
                .OrderByDescending(x => x.CreateDate)
                 .Where(x => x.CategoryTicketId == id).ToList();
        }

        public TblTicketSuggestion UpdateTicketSuggestion(TblTicketSuggestion ticketSuggestion)
        {
            var checkSuggestion = context.TblTicketSuggestions.FirstOrDefault(s => s.TicketSuggestionId == ticketSuggestion.TicketSuggestionId);
            if (checkSuggestion != null)
            {
                checkSuggestion.Description = ticketSuggestion.Description;
                checkSuggestion.ModifyUpdate = DateTime.Now;
                context.SaveChanges();
            }
            else
            {
                throw new ArgumentException("Ticket not found.");
            }
            return checkSuggestion;
        }

    }
}
