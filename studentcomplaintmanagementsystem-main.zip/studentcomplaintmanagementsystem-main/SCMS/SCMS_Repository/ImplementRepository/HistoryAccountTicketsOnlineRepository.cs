﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class HistoryAccountTicketsOnlineRepository : GennericRepository<TblHistoryAccountTicketsOnline>, IHistoryAccountTicketsOnlineRepository
    {
        public HistoryAccountTicketsOnlineRepository(ScmsContext context = null) : base(context)
        {
        }

        public List<TblHistoryAccountTicketsOnline> GetAllByTicketID(Guid? ticketId)
        {
            DateTime date = DateTime.Now;
            if (ticketId == null)
            {
                return context.TblHistoryAccountTicketsOnlines.Include(x => x.Account).Where(x => x.EndDate == null && x.CreateDate.Date == date.Date && x.CreateDate.Month == date.Month && x.CreateDate.Year == date.Year).ToList();
            }
            else
            {
                return context.TblHistoryAccountTicketsOnlines.Include(x => x.Account).Where(x => x.TicketId == ticketId && x.EndDate == null && x.CreateDate.Date == date.Date && x.CreateDate.Month == date.Month && x.CreateDate.Year == date.Year).ToList();
            }
        }

        public TblHistoryAccountTicketsOnline GetByTicketIDUserId(Guid? ticketId, Guid? UserID)
        {
            DateTime date = DateTime.Now;
            return context.TblHistoryAccountTicketsOnlines.Include(x => x.Account)
                .FirstOrDefault(x => x.TicketId == ticketId && x.AccountId == UserID && x.CreateDate.Date == date.Date && x.CreateDate.Month == date.Month && x.CreateDate.Year == date.Year);
        }
    }
}
