﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class NotificationEmailRepository : GennericRepository<TblNotificationEmail>, INotificationEmailRepository
    {
        public NotificationEmailRepository(ScmsContext context = null) : base(context) { }
    }
}
