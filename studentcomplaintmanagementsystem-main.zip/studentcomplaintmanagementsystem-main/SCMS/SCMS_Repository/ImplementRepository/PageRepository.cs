﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class PageRepository : GennericRepository<TblPage>, IPageRepository
    {
        public PageRepository(ScmsContext context = null) : base(context) { }


        public TblPage DeletePage(TblPage page)
        {
            TblPage pageUpdate = context.TblPages.FirstOrDefault(x => x.PageId == page.PageId);

            if (pageUpdate != null)
            {
                pageUpdate.IsDelete = true;
                context.SaveChanges();
            }
            return pageUpdate;
        }

        public (int, List<TblPage>) GetAll(string? PageName, int? pageIndex = 1, int? pageSize = 5, int? sortCreateDate = 0)
        {
            int pageIndexItem = (int)pageIndex;
            int? pageSizeItem = (int)pageSize;
            int? sortCreateDateItem = (int)sortCreateDate;

            List<TblPage> query = context.TblPages.Include(x => x.TblPageCruds).Where(x => x.IsDelete == false).ToList();

            if (!String.IsNullOrEmpty(PageName))
            {
                query = query.Where(x => x.PageName.ToLower().Contains(PageName.ToLower())).ToList();
            }

            if (sortCreateDate == 1)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }

            if (sortCreateDate == 2)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            return (query.Count, query.Skip((int)((pageIndex - 1) * pageSizeItem)).Take((int)pageSize).ToList());
        }

        public TblPage GetPageById(Guid id)
        {
            return context.TblPages.Include(x => x.TblPageCruds).FirstOrDefault(x => x.PageId == id);
        }
    }
}
