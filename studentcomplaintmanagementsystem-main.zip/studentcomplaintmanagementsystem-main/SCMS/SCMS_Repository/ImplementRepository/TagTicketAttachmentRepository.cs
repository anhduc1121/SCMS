﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class TagTicketAttachmentRepository : GennericRepository<TblTagTicketAttachment>, ITagTicketAttachmentRepository
    {
        public TagTicketAttachmentRepository(ScmsContext context = null) : base(context) { }

        public List<TblTagTicketAttachment> GetByTagTicketId(Guid tagTicketId)
        {
            var tagTicketAttachments = context.TblTagTicketAttachments
             .Where(attachment => attachment.TagTicketId == tagTicketId)
             .ToList();
            return tagTicketAttachments;
        }
    }
}
