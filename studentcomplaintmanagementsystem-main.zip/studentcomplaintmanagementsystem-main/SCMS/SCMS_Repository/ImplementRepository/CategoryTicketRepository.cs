﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class CategoryTicketRepository : GennericRepository<TblCategoryTicket>, ICategoryTicketRepository
    {
        public CategoryTicketRepository(ScmsContext context = null) : base(context) { }

        public List<TblCategoryTicket> GetCategorysByIdParentCategory(Guid? IdParentCategory)
        {
            var subCategories = context.TblCategoryTickets
                            .Where(x => x.CategoryTicketParentId == IdParentCategory && x.IsDelete == false)
                            .Include(x => x.CategoryTicketParent)
                            .Include(x => x.InverseCategoryTicketParent)
                            .OrderBy(x => x.CreateDate)
                            .ToList();
            return subCategories;

        }

        public List<TblCategoryTicket> GetAllCategorysByIdParentCategory(Guid? IdParentCategory)
        {
            var category = context.TblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == IdParentCategory);
            if (category == null)
            {
                return null;
            }
            var subCategories = context.TblCategoryTickets
                            .Where(x => x.CategoryTicketParentId == IdParentCategory && x.CategoryTicketId != category.CategoryTicketId).OrderBy(x => x.CreateDate)
                            .ToList();
            return subCategories;

        }
        public List<TblCategoryTicket> GetCategoryByPath(List<Guid> categoryIds)
        {
            return context.TblCategoryTickets
               .Include(x => x.InverseCategoryTicketParent)
               .Where(x => categoryIds.Any(i => i == x.CategoryTicketId) && x.IsDelete == false).OrderBy(x => x.CreateDate).ToList();
        }

        public List<TblCategoryTicket> GetParentCategory()
        {
            return context.TblCategoryTickets
                .Include(x => x.InverseCategoryTicketParent)
                .Where(x => x.CategoryTicketParentId == null && x.IsDelete == false).OrderBy(x => x.CreateDate).ToList();
        }

        public TblCategoryTicket DeteleCategoryTicket(Guid categoryTicketId)
        {

            var categoryD = context.TblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == categoryTicketId);
            if (categoryD == null)
                throw new ArgumentException("CategoryTicket not found.");

            categoryD.IsDelete = true;
            context.SaveChanges();

            return categoryD;
        }
        public TblCategoryTicket UpdateCategoryTicket(TblCategoryTicket categoryTicketVM)
        {

            var categoryD = context.TblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == categoryTicketVM.CategoryTicketId);
            if (categoryD == null)
                throw new ArgumentException("CategoryTicket not found.");
            categoryD.ResponseHours = categoryD.ResponseTime / 60;

            categoryD.CategoryName = categoryTicketVM.CategoryName;
            //categoryD.Status = categoryTicketVM.Status;
            //categoryD.FullPath = categoryTicketVM.FullPath;
            categoryD.Description = categoryTicketVM.Description;
            categoryD.ModifyUpdate = DateTime.Now;
            categoryD.ResponseTime = categoryTicketVM.ResponseTime * 60;
            categoryD.ResponseHours = categoryTicketVM.ResponseTime;
            categoryD.AccountIdUpdate = categoryTicketVM.AccountIdCreate;
            //categoryD.CategoryTicketParentId = categoryTicketVM.CategoryTicketParentId;
            //categoryD.IsDelete = categoryTicketVM.IsDelete;
            categoryD.ResponsiblePersonEmail = categoryTicketVM.ResponsiblePersonEmail;
            context.SaveChanges();

            return categoryD;
        }

        public TblCategoryTicket CreateCategoryTicket(TblCategoryTicket categoryTicket)
        {

            context.TblCategoryTickets.Add(categoryTicket);
            context.SaveChanges();

            return categoryTicket;
        }

        public TblCategoryTicket GetCategorysByIdCategory(Guid? categoryId)
        {
            TblCategoryTicket tblCategoryTicket = null;
            if (categoryId == null)
            {
                tblCategoryTicket = context.TblCategoryTickets.First(x => x.CategoryTicketParentId == null);
            }
            else
            {
                tblCategoryTicket = context.TblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == categoryId);
            }

            return tblCategoryTicket;
        }

        public string GetCategoryName(Guid categoryId)
        {
            TblCategoryTicket categoryTicket = context.TblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == categoryId);

            if (String.IsNullOrEmpty(categoryTicket.FullPath))
            {
                return categoryTicket.CategoryName;
            }
            try
            {
                String[] arrIdStr = categoryTicket.FullPath.Trim().Split(' ');
                Guid[] arrId = Array.ConvertAll(arrIdStr, s => Guid.Parse(s));
                List<TblCategoryTicket> tblCategoryTickets = context.TblCategoryTickets.Where(x => arrId.Any(i => i == x.CategoryTicketId)).ToList();
                String output = "";
                foreach (var item in arrId)
                {
                    output += tblCategoryTickets.FirstOrDefault(x => x.CategoryTicketId == item).CategoryName.ToString() + "/";
                }
                return (output += categoryTicket.CategoryName);
            }
            catch (Exception ex)
            {
                return categoryTicket.CategoryName;
            }


        }
    }
}
