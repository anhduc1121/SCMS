﻿using Microsoft.EntityFrameworkCore;
using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;
using ViewModel;

namespace SCMS_Repository.ImplementRepository
{
    public class NotificationRepository : GennericRepository<TblNotification>, INotificationRepository
    {
        public NotificationRepository(ScmsContext context = null) : base(context) { }

        public TblNotification AddNotification(NotificationVM notification)
        {
            var newNotification = new TblNotification
            {
                NotificationId = Guid.NewGuid(),
                Content = notification.Content,
                Title = notification.Title,
                UrlSulg = notification.UrlSulg,
                CreateDate = DateTime.Now,
                ModifyUpdate = null,
                IsView = false,
                AccountId = notification.AccountId,
                IsDelete = false,
                TicketId = notification.TicketId,
                TicketCommentId = notification.TicketCommentId
            };

            context.TblNotifications.Add(newNotification);
            context.SaveChanges();

            return newNotification;
        }

        public TblNotification MarkAsRead(Guid notificationId)
        {
            var notification = context.TblNotifications.FirstOrDefault(n => n.NotificationId == notificationId);

            if (notification != null)
            {
                notification.IsView = true;
                context.SaveChanges();
            }

            return notification;
        }

        public List<TblNotification> MarkAllAsRead(Guid accountId)
        {
            var notifications = context.TblNotifications.Where(n => n.AccountId == accountId && !n.IsView).ToList();

            foreach (var notification in notifications)
            {
                notification.IsView = true;
            }

            context.SaveChanges();

            return notifications;
        }

        public (int, List<TblNotification>) ViewNotification(Guid accountId, string? statusView, int pageIndex = 1,
            int pageSize = 5, int sortDate = 0, int sortTitle = 0)
        {

            List<TblNotification> query = context.TblNotifications
                .Include(x => x.Account).Where(x => x.AccountId == accountId)
            .ToList();

            if (!String.IsNullOrEmpty(statusView))
            {
                query = query.Where(x => x.IsView == (statusView.Equals("1"))).ToList();
            }

            if (sortDate == 0 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.CreateDate).ToList();
            }
            if (sortDate == 1 && query.Count > 0)
            {
                query = query.OrderBy(x => x.CreateDate).ToList();
            }

            if (sortTitle == 0 && query.Count > 0)
            {
                query = query.OrderByDescending(x => x.Title).ToList();
            }
            if (sortTitle == 1 && query.Count > 0)
            {
                query = query.OrderBy(x => x.Title).ToList();
            }

            return (query.Count, query.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList());
        }
    }
}
