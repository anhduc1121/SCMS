﻿using SCMS_Models.Models;
using SCMS_Repository.GenericRepository;
using SCMS_Repository.IRepository;

namespace SCMS_Repository.ImplementRepository
{
    public class SystemSettingRepository : GennericRepository<TblSystemSetting>, ISystemSettingRepository
    {
        public SystemSettingRepository(ScmsContext context = null) : base(context) { }

        public TblSystemSetting GetSystemById(Guid id)
        {
            return context.TblSystemSettings.FirstOrDefault(x => x.SystemSettingId == id);
        }
    }
}
