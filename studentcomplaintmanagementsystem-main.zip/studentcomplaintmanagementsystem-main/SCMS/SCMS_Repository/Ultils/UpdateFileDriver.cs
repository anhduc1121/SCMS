﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Microsoft.AspNetCore.Http;
using RestSharp;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;

namespace SCMS_Repository.Ultils
{
    public class UpdateFileDriver
    {
        public UpdateFileDriver(AppSettings appSettings, string? applicationName = null, string? uploadFolderId = null)
        {
            this._appSettings = appSettings;

            _applicationName = applicationName ?? _appSettings.GoogleDriver_UploadFolderId;
            _uploadFolderId = uploadFolderId ?? uploadFolderId;

            GetConnect();
        }

        private readonly AppSettings _appSettings;

        private string[] _scopes = { DriveService.Scope.Drive };
        private string _applicationName = "Viet2001";
        public string _uploadFolderId = "1eefgfn-IRwtsWKCsB_-ph0MMHaNmlGIU";
        private DriveService service;

        private async void GetConnect()
        {
            // Xác thực với Google Drive API
            UserCredential credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                new ClientSecrets
                {
                    ClientId = _appSettings.GoogleDriver_ClientId,
                    ClientSecret = _appSettings.GoogleDriver_ClientSecret
                },
            _scopes,
            "user",
             CancellationToken.None,
                new DatabaseDataStore(new ScmsContext(), "6E3E49F9-29F0-4B99-9A3E-06AE5C4886C9"));
            //CancellationToken.None,
            //         new FileDataStore(_appSettings.GoogleDriver_SaveFile));

            // Tạo đối tượng DriveService
            service = new DriveService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = _applicationName
            });
        }



        public string GetFolderId(string nameFolder, string idParentFolder)
        {

            string folderId = null;

            var listRequest = service.Files.List();
            listRequest.Q = $"name='{nameFolder}' and '{idParentFolder}' in parents and mimeType='application/vnd.google-apps.folder'";
            listRequest.Fields = "files(id, name)";
            var folders = listRequest.Execute().Files;

            var fd = folders.FirstOrDefault(x => x.Name == nameFolder);

            if (fd != null)
            {
                folderId = fd.Id;
            }

            if (folderId == null)
            {
                // Tạo thư mục to
                var folderMetadata = new Google.Apis.Drive.v3.Data.File
                {
                    Name = nameFolder,
                    MimeType = "application/vnd.google-apps.folder",
                    Parents = new List<string> { idParentFolder }
                };
                var createRequest = service.Files.Create(folderMetadata);
                createRequest.Fields = "id";
                var folder = createRequest.Execute();
                folderId = folder.Id;
            }

            return folderId;
        }

        public string CopyFile(string folderIdFrom, string name, string folderIdTo)
        {
            // First, get the file ID of the file you want to copy
            string fileId = folderIdFrom;

            // Create a new file metadata object
            var fileCopyMetadata = new Google.Apis.Drive.v3.Data.File
            {
                Name = name, // Set the name of the new file
                Parents = new List<string> { folderIdTo } // Set the target folder ID
            };

            // Copy the file using the Drive API
            var copyRequest = service.Files.Copy(fileCopyMetadata, fileId);
            var copiedFile = copyRequest.Execute();

            return copiedFile.Id;
        }

        public void Delete(string fileId)
        {
            try
            {
                // Create a delete request using the file ID
                var deleteRequest = service.Files.Delete(fileId);

                // Execute the delete request
                deleteRequest.Execute();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<(string, string)> SaveFile(string folderId, IFormFile scope)
        {
            var result = await ScanFileAsync(scope);
            if (!result.IsSuccessStatusCode)
            {
                throw new Exception();
            }
            string idFile = null;
            //VirusTotal virusTotal = new VirusTotal("YOUR API KEY HERE");

            Google.Apis.Drive.v3.Data.File fileMetadata = new Google.Apis.Drive.v3.Data.File
            {
                Name = scope.FileName,
                Parents = new List<string> { folderId }
            };

            // Tạo đối tượng FilesResource.CreateMediaUpload
            FilesResource.CreateMediaUpload request = service.Files.Create(fileMetadata, scope.OpenReadStream(), scope.ContentType);
            request.Fields = "id";
            request.Upload();

            var file = request.ResponseBody;

            // Cập nhật quyền truy cập của tệp thành công khai
            var permission = new Google.Apis.Drive.v3.Data.Permission
            {
                Role = "reader",
                Type = "anyone",
                AllowFileDiscovery = false
            };

            var updatePermissionRequest = service.Permissions.Create(permission, file.Id);
            updatePermissionRequest.Fields = "id";
            var updatedPermission = updatePermissionRequest.Execute();

            // Lưu trữ ID và liên kết xem của tệp
            idFile = file.Id;

            return ("https://drive.google.com/uc?id=" + idFile + "&export=view", idFile);
        }

        public async Task<RestResponse> ScanFileAsync(IFormFile file)
        {
            var options = new RestClientOptions(_appSettings.VirusTotal_Url);
            var client = new RestClient(options);
            var request = new RestRequest("");
            request.AlwaysMultipartFormData = true;
            request.AddHeader("accept", "application/json");
            request.AddHeader("x-apikey", _appSettings.VirusTotal_Key);
            request.FormBoundary = "---011000010111000001101001";

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                var fileBytes = ms.ToArray();
                request.AddFile("file", fileBytes, file.FileName);
            }

            //request.AddFile("file", @"C:\Users\NCC\OneDrive\Pictures\189206206_256239759616680_809833562490706133_n.png");
            var response = await client.PostAsync(request);
            return response;
        }

        private async Task<byte[]> GetFileContentAsync(IFormFile file)
        {
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                return memoryStream.ToArray();
            }
        }
    }
}
