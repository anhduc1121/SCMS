﻿using Newtonsoft.Json;
using SCMS_Models.Models;

namespace SCMS_Repository.Ultils
{
    public class DatabaseDataStore : Google.Apis.Util.Store.IDataStore
    {
        private readonly ScmsContext _dbContext;
        private readonly string _userId;

        public DatabaseDataStore(ScmsContext dbContext, string userId)
        {
            _dbContext = dbContext;
            _userId = userId;
        }

        public Task ClearAsync()
        {
            var credential = _dbContext.GoogleApiCredentials.FirstOrDefault(c => c.UserId == _userId);
            if (credential != null)
            {
                _dbContext.GoogleApiCredentials.Remove(credential);
                return _dbContext.SaveChangesAsync();
            }
            return Task.CompletedTask;
        }

        public Task DeleteAsync<T>(string key)
        {
            // Không cần triển khai nếu không sử dụng
            List<GoogleApiCredential> googleApiCredentials = _dbContext.GoogleApiCredentials.Where(x => x.Key == key).ToList();
            _dbContext.GoogleApiCredentials.RemoveRange(googleApiCredentials);
            _dbContext.SaveChanges();
            return Task.CompletedTask;
        }

        public Task<T> GetAsync<T>(string key)
        {

            var generatedKey = GenerateStoredKey(key, typeof(T));
            var item = _dbContext.GoogleApiCredentials.FirstOrDefault(x => x.Key == generatedKey);
            T value = item == null ? default(T) : JsonConvert.DeserializeObject<T>(item.Value);

            return Task.FromResult<T>(value);
        }
        private static string GenerateStoredKey(string key, Type t)
        {
            return string.Format("{0}-{1}", t.FullName, key);
        }
        public Task StoreAsync<T>(string key, T value)
        {
            var generatedKey = GenerateStoredKey(key, typeof(T));
            string json = JsonConvert.SerializeObject(value);

            var item = _dbContext.GoogleApiCredentials.SingleOrDefault(x => x.Key.ToString() == generatedKey);

            if (item == null)
            {
                _dbContext.GoogleApiCredentials.Add(new GoogleApiCredential { UserId = "6E3E49F9-29F0-4B99-9A3E-06AE5C4886C9", Key = generatedKey, Value = json });
            }
            else
            {
                item.Value = json;
            }

            _dbContext.SaveChanges();

            var itemNew = _dbContext.GoogleApiCredentials.FirstOrDefault(x => x.Key == generatedKey);
            T valueNew = itemNew == null ? default(T) : JsonConvert.DeserializeObject<T>(itemNew.Value);

            return Task.FromResult<T>(valueNew);
        }
    }
}