﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SCMS_Models.Models;
using SCMS_Repository.Helpers;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using ViewModel;

namespace SCMS_Repository.Ultils
{
    public class Jwt
    {
        private readonly AppSettings _appSettings;

        private readonly IConfiguration _config;

        public Jwt(AppSettings appSettings, IConfiguration config)
        {
            this._appSettings = appSettings;
            this._config = config;
        }

        public TokenModel GenerateToken(TblAccount account)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var secretKeyBytes = Encoding.UTF8.GetBytes(_appSettings.SecretKey);
            var tokenDescription = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                        new Claim(ClaimTypes.NameIdentifier, account.AccountId.ToString()),
                        new Claim(ClaimTypes.MobilePhone, account.Phone??""),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                     //Roles
                }),
                Expires = DateTime.UtcNow.AddDays(7), // Thiết lập thời gian hết hạn sau 1 ngày
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(secretKeyBytes), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = jwtTokenHandler.CreateToken(tokenDescription);
            var accessToken = jwtTokenHandler.WriteToken(token);
            return new TokenModel
            {
                AccessToken = accessToken
            };
        }

        public string GenerateRefreshToken()
        {
            var random = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(random);
                return Convert.ToBase64String(random);
            }
        }

    }
}
