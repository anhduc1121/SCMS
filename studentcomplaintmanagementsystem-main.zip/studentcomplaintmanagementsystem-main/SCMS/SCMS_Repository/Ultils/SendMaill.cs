﻿using System.Net;
using System.Net.Mail;

namespace SCMS_Repository.Ultils
{
    public class SendMaill
    {
        private static readonly string FromEmail = "levietaqviet2001@gmail.com";
        private static readonly string FromPassword = "hheu uhpa ozyz bffk";
        public static bool SendEmail(string toEmail, string subject, string body)
        {
            // Thiết lập thông tin email người gửi
            MailAddress from = new MailAddress(FromEmail);

            // Thiết lập thông tin email người nhận
            MailAddress to = new MailAddress(toEmail);

            // Thiết lập nội dung email
            MailMessage message = new MailMessage(from, to);
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true; // Đặt giá trị này thành true để gửi mã HTML

            // Thiết lập máy chủ SMTP của Gmail
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);

            // Xác thực tài khoản Gmail
            smtpClient.Credentials = new NetworkCredential(FromEmail, FromPassword);
            smtpClient.EnableSsl = true;

            // Gửi email
            try
            {
                smtpClient.Send(message);
                //Console.WriteLine("Email đã được gửi thành công!");
                return true;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("Lỗi khi gửi email: " + ex.Message);
                return false;
            }
        }
    }
}
