﻿namespace SCMS_Repository.Ultils
{
    public class SuggestBot
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="s1"></param>
        /// <param name="s2"></param>
        /// <returns></returns>
        public static int LevenshteinDistance(string s1, string s2)
        {
            s1 = s1.Trim().ToLower();
            s2 = s2.Trim().ToLower();
            int size_x = s1.Length + 1;
            int size_y = s2.Length + 1;
            int[,] matrix = new int[size_x, size_y];

            for (int x = 0; x < size_x; x++)
                matrix[x, 0] = x;

            for (int y = 0; y < size_y; y++)
                matrix[0, y] = y;

            for (int x = 1; x < size_x; x++)
            {
                for (int y = 1; y < size_y; y++)
                {
                    if (s1[x - 1] == s2[y - 1])
                    {
                        matrix[x, y] = Math.Min(
                            matrix[x - 1, y] + 1,
                            Math.Min(matrix[x - 1, y - 1], matrix[x, y - 1] + 1)
                        );
                    }
                    else
                    {
                        matrix[x, y] = Math.Min(
                            matrix[x - 1, y] + 1,
                            Math.Min(matrix[x - 1, y - 1] + 1, matrix[x, y - 1] + 1)
                        );
                    }
                }
            }

            return matrix[size_x - 1, size_y - 1];
        }

        /// <summary>
        /// trả về phần trăm độ lệch
        /// </summary>
        /// <param name="s1"></param>
        /// <param name="s2"></param>
        /// <returns>
        /// 1 là giống
        /// 0 là ko giống tí nào
        /// </returns>
        public static double LevenshteinRatio(string s1, string s2)
        {
            s1 = s1.Trim().ToLower();
            s2 = s2.Trim().ToLower();
            int size_x = s1.Length + 1;
            int size_y = s2.Length + 1;
            int[,] matrix = new int[size_x, size_y];

            for (int x = 0; x < size_x; x++)
                matrix[x, 0] = x;

            for (int y = 0; y < size_y; y++)
                matrix[0, y] = y;

            for (int x = 1; x < size_x; x++)
            {
                for (int y = 1; y < size_y; y++)
                {
                    if (s1[x - 1] == s2[y - 1])
                    {
                        matrix[x, y] = Math.Min(
                            matrix[x - 1, y] + 1,
                            Math.Min(matrix[x - 1, y - 1], matrix[x, y - 1] + 1)
                        );
                    }
                    else
                    {
                        matrix[x, y] = Math.Min(
                            matrix[x - 1, y] + 1,
                            Math.Min(matrix[x - 1, y - 1] + 1, matrix[x, y - 1] + 1)
                        );
                    }
                }
            }

            int lev_distance = matrix[size_x - 1, size_y - 1];
            double ratio = ((double)(s1.Length + s2.Length) - lev_distance) / (s1.Length + s2.Length);
            return ratio;
        }

        /// <summary>
        /// Trả về chuỗi tương đồng của X và Y
        /// </summary>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <returns></returns>
        public static string LCS(string X, string Y)
        {
            X = X.Trim().ToLower();
            Y = Y.Trim().ToLower();
            int m = X.Length;
            int n = Y.Length;
            int[,] L = new int[m + 1, n + 1];

            for (int i = 0; i <= m; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (i == 0 || j == 0)
                    {
                        L[i, j] = 0;
                    }
                    else if (X[i - 1] == Y[j - 1])
                    {
                        L[i, j] = L[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        L[i, j] = Math.Max(L[i - 1, j], L[i, j - 1]);
                    }
                }
            }

            int index = L[m, n];
            char[] lcs = new char[index];
            int k = index - 1;
            int p = m;
            int q = n;
            while (p > 0 && q > 0)
            {
                if (X[p - 1] == Y[q - 1])
                {
                    lcs[k] = X[p - 1];
                    k--;
                    p--;
                    q--;
                }
                else if (L[p - 1, q] > L[p, q - 1])
                {
                    p--;
                }
                else
                {
                    q--;
                }
            }

            return new string(lcs);
        }

    }
}
