# Step 1

npm i

# Step 2

npm run serve


## How to login: 


student --> 
user: truong98hiro@gmail.com
password: Tt7@Km4!

staff --> 
user: levietaqviet1@gmail.com 
password: Xw3!Jv9$

# Note: Just login only localhost 8696
